cd "$(dirname "$0")"
sudo fuser -k 8000/tcp || true
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
