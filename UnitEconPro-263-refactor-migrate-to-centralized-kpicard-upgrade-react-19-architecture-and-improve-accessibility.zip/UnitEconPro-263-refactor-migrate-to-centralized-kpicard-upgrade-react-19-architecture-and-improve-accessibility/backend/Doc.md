
## Base URL

All API endpoints are served from the following base URLs:

-   **Production:** *https://uniteconpro-api.k8s.opstree.dev/api/v1*

## API Endpoints

Endpoints are grouped by functional area. All endpoints support the
common *start_date*, *end_date*, and *account* parameters unless
otherwise noted.

### Dashboard

Aggregated overview of the entire AWS environment.

-   **`GET /dashboard/summary`**

    -   **Description:** Top-level statistics across all services.
    -   **Response Model:** *DashboardSummary*

| Field | Type | Description |
|---|---|---|
| total_cost | float | Total cost across all services. |
| avg_daily_cost | float | Average daily cost. |
| active_services | int | Number of services with non-zero cost. |
| total_accounts | int | Number of distinct AWS accounts. |
| active_regions | int | Number of regions with cost. |
| total_resources | int | Total distinct resources (approximate). |


-   **`GET /dashboard/trend`**

    -   **Description:** Daily cost trend for the selected period, with a previous-period overlay for comparison.
    -   **Response:** Array of *TrendPoint*

| Field | Type | Description |
|---|---|---|
| date | string | Date (YYYY-MM-DD). |
| cost | float | Cost on that day. |
| previous_period_cost | float | Cost on the same day in the previous period (if exists). |


-   **`GET /dashboard/breakdown/service`**

    -   **Description:** Cost split by AWS service (e.g., EC2, S3, RDS). Useful for bar charts.
    -   **Response:** Array of *BreakdownItem*

-   **`GET /dashboard/breakdown/account`**

    -   **Description:** Cost split by AWS account.
    -   **Response:** Array of *BreakdownItem*

-   **`GET /dashboard/comparison`**

    -   **Description:** Predefined period comparisons: yesterday, last week, this week, last month.
    -   **Response:** *PeriodComparison*

| Field | Type | Description |
|---|---|---|
| yesterday_cost | float | Cost for yesterday. |
| last_week_cost | float | Cost for last week (Mon-Sun). |
| this_week_cost | float | Cost from Monday to today. |
| last_month_cost | float | Cost for last calendar month. |

-   **`GET /dashboard/forecast`**

    -   **Description:** Forecasted cost for the current week and month based on the last 7 days' burn rate.
    -   **Response:** *Forecast*

| Field | Type | Description |
|---|---|---|
| predicted_week_cost | float | Predicted cost for this week. |
| predicted_month_cost | float | Predicted cost for this month. |

### Unified Analytics

Two generic endpoints that accept a *service* parameter, allowing you to
fetch trend or breakdown data for any supported service with a single
call.

-   **`GET /analytics/trend`**

    -   **Description:** Daily cost trend for a specific service.

    -   Query Parameters:

        -   *service* (string): AWS service name. One of: *ec2*, *ecr*,
            *eks*, *s3*, *ebs*, *rds*, *vpc*, *elb*, *cloudwatch*.

    -   **Response:** Array of *TrendPoint*

-   **`GET /analytics/breakdown`**

    -   **Description:** Cost breakdown for a service by a specific dimension.

    -   Query Parameters:

        -   *service* (string): AWS service name.
        -   *dimension* (string): Grouping dimension (see service sections below for valid options).

    -   **Response:** Array of *BreakdownItem*

### Compute -- EC2

-   **`GET /compute/ec2/summary`**

    -   **Response:** *EC2Summary*

| Field | Type | Description |
|---|---|---|
| total_cost | float | Total EC2 cost. |
| avg_daily_cost | float | Average daily cost. |
| total_instances | int | Number of distinct instances. |
| total_usage_hours | float | Total instance hours. |

-   **`GET /compute/ec2/instances`**

    -   **Description:** Top 50 EC2 instances by cost.
    -   **Response:** Array of *EC2Instance*

| Field | Type | Description |
|---|---|---|
| instance_id | string | EC2 instance ID. |
| instance_type | string | Instance type. |
| region | string | Region. |
| account | string | Account name. |
| total_cost | float | Total cost. |
| usage_hours | float | Total hours run. |

-   **`GET /compute/ec2/lifecycle`**

    -   **Description:** Instance lifecycle view -- launch date, last seen, active/stopped days, and stop-start gaps.

    -   Endpoint-Specific Query Parameters:

        -   *instance_id* (string): Filter to a specific instance ID.
        -   *include_gaps* (boolean): If *true*, return detailed stop-period arrays. Default: *false*.
        -   *lookback_days* (integer): Number of days of CUR history to scan (used only in list mode). Default: *90*.
        -   *limit* (integer): Max instances to return. Default: *100*.

    -   **Response:** Array of *EC2LifecycleInstance*

| Field | Type | Description |
|---|---|---|
| instance_id | string | EC2 instance ID. |
| instance_type | string | Latest instance type. |
| region | string | Latest region. |
| account | string | Account name. |
| pricing_model | string | Pricing model (OnDemand, Spot, etc.). |
| asg_name | string | Auto Scaling group name (if any). |
| first_seen | string | Timestamp of the first billing record. |
| last_seen | string | Timestamp of the last billing record. |
| active_days | int | Days with at least one billing record. |
| stopped_days | int | Days between first and last with no billing record. |
| total_hours | float | Total hours run. |
| total_cost | float | Total cost. |
| gaps | array | List of stop periods (only if *include_gaps=true*). |

-   **Valid Analytics Dimensions:** *account*, *region*,
    *availability-zone*, *instance-family*, *instance-type*,
    *instance-type-family*, *pricing-model*

### Compute -- ECR

-   **`GET /compute/ecr/summary`**

    -   **Response:** *ECRSummary*

| Field | Type | Description |
|---|---|---|
| total_cost | float | Total ECR cost. |
| avg_daily_cost | float | Average daily cost. |
| active_repositories | int | Number of repositories. |
| total_storage_gb | float | Average storage in GB. |
| storage_cost | float | Cost of storage. |
| transfer_cost | float | Cost of data transfer. |


-   **`GET /compute/ecr/repositories`**

    -   **Description:** Top 50 repositories by cost.
    -   **Response:** Array of *ECRRepository*

| Field | Type | Description |
|---|---|---|
| repository_name | string | Repository name. |
| region | string | Region. |
| account | string | Account name. |
| storage_gb | float | Average storage GB. |
| transfer_gb | float | Data transfer GB. |
| total_cost | float | Total cost. |


-   **Valid Analytics Dimensions:** *usage-type*, *region*, *account*

### Compute -- EKS

-   **`GET /compute/eks/summary`**

    -   **Response:** *EKSSummary*

| Field | Type | Description |
|---|---|---|
| total_cost | float | Total EKS cost. |
| avg_daily_cost | float | Average daily cost. |
| total_clusters | int | Number of clusters. |
| total_cluster_hours | float | Total cluster hours. |


-   **`GET /compute/eks/clusters`**

    -   **Description:** Top 50 clusters by cost.
    -   **Response:** Array of *EKSCluster*

| Field | Type | Description |
|---|---|---|
| cluster_name | string | Cluster name. |
| region | string | Region. |
| account | string | Account name. |
| cluster_hours | float | Hours run. |
| total_cost | float | Total cost. |


-   **Valid Analytics Dimensions:** *cluster*, *region*, *account*,
    *operation*, *usage-type*, *pricing-model*

### Storage -- S3

-   **`GET /storage/s3/summary`**

    -   **Response:** *S3Summary*

| Field | Type | Description |
|---|---|---|
| total_cost | float | Total S3 cost. |
| avg_daily_cost | float | Average daily cost. |
| total_buckets | int | Number of buckets. |
| total_storage_gb | float | Average storage in GB. |
| request_efficiency | float | Requests per dollar (requests/$). |

-   **`GET /storage/s3/buckets`**

    -   **Description:** Top 50 buckets by cost, with detailed usage.
    -   **Response:** Array of *S3Bucket*

| Field | Type | Description |
|---|---|---|
| bucket_name | string | Bucket name. |
| region | string | Region. |
| account | string | Account name. |
| storage_gb | float | Average storage GB. |
| request_count | float | Number of requests. |
| transfer_gb | float | Data transfer GB. |
| total_cost | float | Total cost. |


-   **Valid Analytics Dimensions:** *bucket*, *region*, *account*,
    *operation*, *usage-type*, *pricing-model*, *request-type*,
    *transfer-direction*

### Storage -- EBS

-   **`GET /storage/ebs/summary`**

    -   **Response:** *EBSSummary*

| Field | Type | Description |
|---|---|---|
| total_cost | float | Total EBS cost. |
| avg_daily_cost | float | Average daily cost. |
| total_volumes | int | Number of volumes. |
| total_snapshots | int | Number of snapshots. |
| total_storage_gb | float | Volume storage GB. |
| total_snapshot_gb | float | Snapshot storage GB. |


-   **`GET /storage/ebs/volumes`**

    -   **Description:** Top 50 EBS volumes by cost.
    -   **Response:** Array of *EBSVolume*

| Field | Type | Description |
|---|---|---|
| volume_id | string | Volume ID. |
| region | string | Region. |
| account | string | Account name. |
| volume_type | string | Volume type (gp2, gp3, io1, etc.). |
| storage_gb | float | Storage GB. |
| total_cost | float | Total cost. |


-   **`GET /storage/ebs/snapshots`**

    -   **Description:** Top 50 EBS snapshots by cost.
    -   **Response:** Array of *EBSSnapshot*

| Field | Type | Description |
|---|---|---|
| snapshot_id | string | Snapshot ID. |
| region | string | Region. |
| account | string | Account name. |
| snapshot_gb | float | Snapshot size GB. |
| total_cost | float | Total cost. |


-   **Valid Analytics Dimensions:** *volume-type*, *region*, *account*,
    *operation*, *product-family*, *usage-type*, *pricing-model*

### Databases -- RDS

-   **`GET /databases/rds/summary`**

    -   **Response:** *RDSSummary*

| Field | Type | Description |
|---|---|---|
| total_cost | float | Total RDS cost. |
| avg_daily_cost | float | Average daily cost. |
| total_instances | int | Number of DB instances. |
| total_usage_hours | float | Total instance hours. |


-   **`GET /databases/rds/instances`**

    -   **Description:** Top 50 RDS instances by cost.
    -   **Response:** Array of *RDSInstance*

| Field | Type | Description |
|---|---|---|
| instance_id | string | RDS instance ID. |
| region | string | Region. |
| account | string | Account name. |
| instance_type | string | Instance type. |
| engine | string | Database engine. |
| usage_hours | float | Hours run. |
| total_cost | float | Total cost. |


-   **Valid Analytics Dimensions:** *engine*, *instance-type*, *region*,
    *account*, *operation*, *usage-type*, *pricing-model*

### Networking -- VPC

-   **`GET /networking/vpc/summary`**

    -   **Response:** *VPCSummary*

| Field | Type | Description |
|---|---|---|
| total_cost | float | Total VPC cost. |
| avg_daily_cost | float | Average daily cost. |
| total_resources | int | Number of distinct resources. |
| total_usage | float | Total usage units (GB/hours). |


-   **`GET /networking/vpc/breakdown/public-ip`**

    -   **Description:** Detailed breakdown of Public IPv4 costs (idle vs in-use, by type).
    -   **Response:** Array of *VPCPublicIPItem*

| Field | Type | Description |
|---|---|---|
| name | string | Category (Idle, In-Use). |
| cost | float | Cost. |
| ip_hours | float | Total IP hours. |


-   **`GET /networking/vpc/resources`**

    -   **Description:** Top 50 VPC resources by cost (ENIs, NAT gateways, endpoints, etc.).
    -   **Response:** Array of *VPCResource*

| Field | Type | Description |
|---|---|---|
| resource_id | string | Resource ARN or ID. |
| resource_type | string | Type (Elastic IP, NAT Gateway, etc.). |
| region | string | Region. |
| account | string | Account name. |
| usage_amount | float | Usage amount (GB/hours). |
| total_cost | float | Total cost. |


-   **Valid Analytics Dimensions:** *account*, *region*, *usage-type*,
    *operation*, *pricing-model*

### Networking -- ELB

-   **`GET /networking/elb/summary`**

    -   **Response:** *ELBSummary*

| Field | Type | Description |
|---|---|---|
| total_cost | float | Total ELB cost. |
| avg_daily_cost | float | Average daily cost. |
| total_load_balancers | int | Number of load balancers. |
| total_lb_hours | float | Total load balancer hours. |


-   **`GET /networking/elb/load-balancers`**

    -   **Description:** Top 50 load balancers by cost.
    -   **Response:** Array of *ELBLoadBalancer*

| Field | Type | Description |
|---|---|---|
| resource_id | string | ELB ARN. |
| lb_name | string | Friendly name. |
| region | string | Region. |
| account | string | Account name. |
| lb_hours | float | Hours run. |
| total_cost | float | Total cost. |


-   **`GET /networking/elb/idle-load-balancers`**

    -   **Description:** Load balancers that are running (have LB hours) but have zero LCU/NLCU consumption -- i.e., no traffic. Useful for zombie LB detection.
    -   **Response:** Array of *ELBLoadBalancer* (same schema as above).

-   **Valid Analytics Dimensions:** *region*, *account*, *usage-type*, *family*

### Monitoring -- CloudWatch

-   **`GET /monitoring/cloudwatch/summary`**

    -   **Response:** *CWSummary*

| Field | Type | Description |
|---|---|---|
| total_cost | float | Total CloudWatch cost. |
| avg_daily_cost | float | Average daily cost. |
| total_log_gb | float | Total log ingestion GB. |
| total_alarms | float | Number of alarm-monitor usage. |
| total_api_calls | float | Number of API call units. |


-   **`GET /monitoring/cloudwatch/eks-clusters`**

    -   **Description:** Breakdown of CloudWatch log costs by EKS cluster.
    -   **Response:** Array of *CWClusterCost*

| Field | Type | Description |
|---|---|---|
| cluster_name | string | EKS cluster name. |
| cost | float | Total log cost. |
| gb_ingested | float | GB of logs ingested. |


-   **`GET /monitoring/cloudwatch/log-groups`**

    -   **Description:** Top 20 log groups by ingestion cost.
    -   **Response:** Array of *CWLogGroup*

| Field | Type | Description |
|---|---|---|
| log_group_name | string | CloudWatch log group. |
| region | string | Region. |
| account | string | Account name. |
| gb_ingested | float | GB ingested. |
| total_cost | float | Total cost. |


-   **Valid Analytics Dimensions:** *cost-group*, *region*, *account*,
    *operation*, *log-prefix*, *eks-cluster*

## Data Models

Below are the common response schemas used across endpoints. All fields are returned as JSON.

**BreakdownItem**

```json
{
  "name": "string",
  "cost": 0.0,
  "usage": 0.0,
  "unit": "string"
}
```

**TrendPoint**

```json
{
  "date": "string",
  "cost": 0.0
}
```

**DashboardSummary**

```json
{
  "total_cost": 0.0,
  "avg_daily_cost": 0.0,
  "active_services": 0,
  "total_accounts": 0,
  "active_regions": 0,
  "total_resources": 0
}
```

**PeriodComparison**

```json
{
  "yesterday_cost": 0.0,
  "last_week_cost": 0.0,
  "this_week_cost": 0.0,
  "last_month_cost": 0.0
}
```

**Forecast**

```json
{
  "predicted_week_cost": 0.0,
  "predicted_month_cost": 0.0
}
```
               *float*            Total IP hours.
  -----------------------------  -----------------  --------------------------

Export to Sheets

-   *GET /networking/vpc/resources*

    -   **Description:** Top 50 VPC resources by cost (ENIs, NAT
        gateways, endpoints, etc.).
    -   **Response:** Array of *VPCResource*

  -----------------------------  -----------------  ---------------------------------------
  *resource_id*                  *string*           Resource ARN or ID.

  *resource_type*                *string*           Type (Elastic IP, NAT Gateway, etc.).

  *region*                       *string*           Region.

  *account*                      *string*           Account name.

  *usage_amount*                 *float*            Usage amount (GB/hours).

  *total_cost*                   *float*            Total cost.
  -----------------------------  -----------------  ---------------------------------------

Export to Sheets

-   **Valid Analytics Dimensions:** *account*, *region*, *usage-type*,
    *operation*, *pricing-model*

### Networking -- ELB

-   *GET /networking/elb/summary*

    -   **Response:** *ELBSummary*

  -----------------------------  -----------------  ----------------------------
  *total_cost*                   *float*            Total ELB cost.

  *avg_daily_cost*               *float*            Average daily cost.

  *total_load_balancers*         *int*              Number of load balancers.

  *total_lb_hours*               *float*            Total load balancer hours.
  -----------------------------  -----------------  ----------------------------

Export to Sheets

-   *GET /networking/elb/load-balancers*

    -   **Description:** Top 50 load balancers by cost.
    -   **Response:** Array of *ELBLoadBalancer*

  -----------------------------  -----------------  ----------------
  *resource_id*                  *string*           ELB ARN.

  *lb_name*                      *string*           Friendly name.

  *region*                       *string*           Region.

  *account*                      *string*           Account name.

  *lb_hours*                     *float*            Hours run.

  *total_cost*                   *float*            Total cost.
  -----------------------------  -----------------  ----------------

Export to Sheets

-   *GET /networking/elb/idle-load-balancers*

    -   **Description:** Load balancers that are running (have LB hours)
        but have zero LCU/NLCU consumption -- i.e., no traffic. Useful
        for zombie LB detection.
    -   **Response:** Array of *ELBLoadBalancer* (same schema as above).

-   **Valid Analytics Dimensions:** *region*, *account*, *usage-type*,
    *family*

### Monitoring -- CloudWatch

-   *GET /monitoring/cloudwatch/summary*

    -   **Response:** *CWSummary*

  -----------------------------  -----------------  --------------------------------
  *total_cost*                   *float*            Total CloudWatch cost.

  *avg_daily_cost*               *float*            Average daily cost.

  *total_log_gb*                 *float*            Total log ingestion GB.

  *total_alarms*                 *float*            Number of alarm-monitor usage.

  *total_api_calls*              *float*            Number of API call units.
  -----------------------------  -----------------  --------------------------------

Export to Sheets

-   *GET /monitoring/cloudwatch/eks-clusters*

    -   **Description:** Breakdown of CloudWatch log costs by EKS
        cluster.
    -   **Response:** Array of *CWClusterCost*

  -----------------------------  -----------------  ----------------------
  *cluster_name*                 *string*           EKS cluster name.

  *cost*                         *float*            Total log cost.

  *gb_ingested*                  *float*            GB of logs ingested.
  -----------------------------  -----------------  ----------------------

Export to Sheets

-   *GET /monitoring/cloudwatch/log-groups*

    -   **Description:** Top 20 log groups by ingestion cost.
    -   **Response:** Array of *CWLogGroup*

  -----------------------------  -----------------  -----------------------
  *log_group_name*               *string*           CloudWatch log group.

  *region*                       *string*           Region.

  *account*                      *string*           Account name.

  *gb_ingested*                  *float*            GB ingested.

  *total_cost*                   *float*            Total cost.
  -----------------------------  -----------------  -----------------------
