"""
Data Transfer SQL Query Templates
-------------------------------
Strategy: AWS does not have a single "DataTransfer" product_code. Transfer costs
are embedded in the service that generated them (AmazonEC2, AmazonS3, AmazonECR,
AmazonCloudWatch, AmazonVPC, etc.). The universal identifier across all of them is
that the usage_type ends with 'Bytes' (e.g., DataTransfer-Out-Bytes,
APS3-DataTransfer-Out-Bytes, VendedLog-Bytes, NatGateway-Bytes).

Placeholders: {start}, {end}, {account_filter}
usage_qty is stored in GB for Bytes usage types.
"""

# ══════════════════════════════════════════════════════════
# SUMMARY  – 4 stat cards
# ══════════════════════════════════════════════════════════

DT_SUMMARY = """
    SELECT
        ROUND(SUM(cost_unblended), 2) AS total_cost,
        CASE
            WHEN COUNT(DISTINCT toDate(usage_start_ts)) > 0
            THEN ROUND(SUM(cost_unblended) / COUNT(DISTINCT toDate(usage_start_ts)), 2)
            ELSE 0
        END AS avg_daily_cost,
        ROUND(SUM(usage_qty) / 1024, 4) AS total_tb,
        COUNT(DISTINCT resource_id) AS unique_resources
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND usage_type LIKE '%Bytes%'
      {account_filter}
"""

# ══════════════════════════════════════════════════════════
# TREND – daily cost line chart
# ══════════════════════════════════════════════════════════

DT_COST_TREND = """
    SELECT
        toDate(usage_start_ts) AS date_obj,
        formatDateTime(date_obj, '%Y-%m-%d') AS date,
        ROUND(SUM(cost_unblended), 2) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND usage_type LIKE '%Bytes%'
      {account_filter}
    GROUP BY date_obj
    ORDER BY date_obj ASC
"""

# ══════════════════════════════════════════════════════════
# DIRECTION BREAKDOWN – donut chart (Outbound/Inbound/Regional/Other)
# ══════════════════════════════════════════════════════════

DT_BY_DIRECTION = """
    SELECT
        CASE
            WHEN usage_type LIKE '%Out-Bytes%' THEN 'Outbound'
            WHEN usage_type LIKE '%In-Bytes%'  THEN 'Inbound'
            WHEN usage_type LIKE '%Regional-Bytes%' THEN 'Regional/Inter-AZ'
            ELSE 'Other'
        END AS name,
        ROUND(SUM(cost_unblended), 2) AS cost,
        ROUND(SUM(usage_qty), 2) AS usage,
        'GB' AS unit
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND usage_type LIKE '%Bytes%'
      {account_filter}
    GROUP BY name
    ORDER BY cost DESC
"""

# ══════════════════════════════════════════════════════════
# BREAKDOWN BY USAGE TYPE – table / bar
# ══════════════════════════════════════════════════════════

DT_BY_USAGE_TYPE = """
    SELECT
        trim(usage_type) AS name,
        ROUND(SUM(cost_unblended), 6) AS cost,
        ROUND(SUM(usage_qty), 2) AS usage,
        'GB' AS unit
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND usage_type LIKE '%Bytes%'
      AND trimBoth(usage_type) != ''
      {account_filter}
    GROUP BY name
    ORDER BY cost DESC
    LIMIT 100
"""

# ══════════════════════════════════════════════════════════
# BREAKDOWN BY SOURCE SERVICE – which AWS service generated the traffic
# ══════════════════════════════════════════════════════════

DT_BY_SERVICE = """
    SELECT
        product_code AS name,
        ROUND(SUM(cost_unblended), 2) AS cost,
        ROUND(SUM(usage_qty), 2) AS usage,
        'GB' AS unit
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND usage_type LIKE '%Bytes%'
      AND product_code IS NOT NULL
      AND trimBoth(product_code) != ''
      {account_filter}
    GROUP BY name
    ORDER BY cost DESC
"""

# ══════════════════════════════════════════════════════════
# BREAKDOWN BY REGION
# ══════════════════════════════════════════════════════════

DT_BY_REGION = """
    SELECT
        region AS name,
        ROUND(SUM(cost_unblended), 2) AS cost,
        ROUND(SUM(usage_qty), 2) AS usage,
        'GB' AS unit
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND usage_type LIKE '%Bytes%'
      AND trimBoth(region) != ''
      {account_filter}
    GROUP BY region
    ORDER BY cost DESC
"""

# ══════════════════════════════════════════════════════════
# BREAKDOWN BY ACCOUNT
# ══════════════════════════════════════════════════════════

DT_BY_ACCOUNT = """
    SELECT
        account_name AS name,
        ROUND(SUM(cost_unblended), 2) AS cost,
        ROUND(SUM(usage_qty), 2) AS usage,
        'GB' AS unit
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND usage_type LIKE '%Bytes%'
      AND account_name IS NOT NULL
      {account_filter}
    GROUP BY account_name
    ORDER BY cost DESC
"""

# ══════════════════════════════════════════════════════════
# INTER-REGION PAIRS – source→destination usage types
# ══════════════════════════════════════════════════════════

DT_INTER_REGION = """
    SELECT
        trim(usage_type) AS name,
        ROUND(SUM(cost_unblended), 2) AS cost,
        ROUND(SUM(usage_qty), 2) AS usage,
        'GB' AS unit
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND usage_type LIKE '%-AWS-%-Bytes%'
      {account_filter}
    GROUP BY name
    HAVING cost > 0
    ORDER BY cost DESC
    LIMIT 20
"""

# ══════════════════════════════════════════════════════════
# TOP RESOURCES – data table (top 50 by cost)
# ══════════════════════════════════════════════════════════

DT_TOP_RESOURCES = """
    SELECT
        resource_id,
        argMax(region, usage_start_ts)       AS region,
        argMax(account_name, usage_start_ts) AS account,
        argMax(product_code, usage_start_ts) AS service,
        argMax(usage_type, usage_start_ts)   AS dt_usage_type,
        ROUND(SUM(cost_unblended), 2)        AS total_cost,
        ROUND(SUM(usage_qty), 1)             AS total_gb
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND usage_type LIKE '%Bytes%'
      AND resource_id != ''
      {account_filter}
    GROUP BY resource_id
    HAVING total_cost > 0 OR total_gb > 0
    ORDER BY total_cost DESC
    LIMIT 50
"""
