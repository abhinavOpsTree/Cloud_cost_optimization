"""
Data Transfer Page Routes
--------------------------
Prefix: /api/v1/networking/datatransfer

Service-specific endpoints (this file):
  GET /summary   – 4 stat cards: total cost, avg daily, TB transferred, unique resources
  GET /resources – top 50 resources by transfer cost

Trend + all dimension breakdowns are served by the unified analytics router:
  GET /api/v1/analytics/trend?service=data-transfer
  GET /api/v1/analytics/breakdown?service=data-transfer&dimension=<dim>

Valid analytics dimensions:
  direction | service | region | account | usage-type | inter-region
"""
from fastapi import APIRouter

from core import database as db
from core.dependencies import DateCtx
from . import queries as q
from . import schemas

router = APIRouter(prefix="/api/v1/networking/datatransfer", tags=["Networking – Data Transfer"])


# ─────────────────────────────────────────────────────────────
#  GET /summary
# ─────────────────────────────────────────────────────────────
@router.get("/summary", response_model=schemas.DataTransferSummary)
async def get_dt_summary(ctx: DateCtx):
    """
    4 stat cards:
      - Total Cost        – all usage_type LIKE '%Bytes%' in date range
      - Avg Daily Cost    – total / distinct days with data
      - Total TB          – SUM(usage_qty) / 1024
      - Unique Resources  – COUNT(DISTINCT resource_id)
    """
    sql = q.DT_SUMMARY.format(start=ctx.start, end=ctx.end, account_filter=ctx.account_filter)
    rows = db.query_safe(sql, ctx.params)
    if not rows:
        return schemas.DataTransferSummary(
            total_cost=0.0, avg_daily_cost=0.0,
            total_tb=0.0, unique_resources=0,
        )
    r = rows[0]
    return schemas.DataTransferSummary(
        total_cost=float(r.get("total_cost") or 0),
        avg_daily_cost=float(r.get("avg_daily_cost") or 0),
        total_tb=float(r.get("total_tb") or 0),
        unique_resources=int(r.get("unique_resources") or 0),
    )


# ─────────────────────────────────────────────────────────────
#  GET /resources
# ─────────────────────────────────────────────────────────────
@router.get("/resources", response_model=list[schemas.DataTransferResource])
async def get_dt_resources(ctx: DateCtx):
    """
    Top 50 resources by transfer cost.
    Columns: resource_id, region, account, service (product_code),
             usage_type, total_cost (USD), total_gb.
    """
    sql = q.DT_TOP_RESOURCES.format(start=ctx.start, end=ctx.end, account_filter=ctx.account_filter)
    rows = db.query_safe(sql, ctx.params)
    return [
        schemas.DataTransferResource(
            resource_id=r.get("resource_id") or "",
            region=r.get("region") or None,
            account=r.get("account") or None,
            service=r.get("service") or None,
            usage_type=r.get("dt_usage_type") or None,
            total_cost=float(r.get("total_cost") or 0),
            total_gb=float(r.get("total_gb") or 0),
        )
        for r in rows
    ]


# ── Removed endpoints ─────────────────────────────────────────
# /trend      → GET /api/v1/analytics/trend?service=data-transfer
# /direction  → GET /api/v1/analytics/breakdown?service=data-transfer&dimension=direction
# /types      → GET /api/v1/analytics/breakdown?service=data-transfer&dimension=usage-type
# /breakdown  → GET /api/v1/analytics/breakdown?service=data-transfer&dimension=<dim>
#
# Valid dimensions for analytics/breakdown:
#   direction | service | region | account | usage-type | inter-region
