"""
Data Transfer Response Schemas

Only the two service-specific endpoints (/summary, /resources) need schemas here.
Trend and breakdowns use the shared TrendPoint / BreakdownItem schemas from
the unified analytics router (pages/analytics/routes.py).
"""
from typing import Optional
from pydantic import BaseModel


class DataTransferSummary(BaseModel):
    """Stat cards returned by GET /networking/datatransfer/summary."""
    total_cost: float
    avg_daily_cost: float
    total_tb: float          # SUM(usage_qty) / 1024
    unique_resources: int    # COUNT(DISTINCT resource_id)


class DataTransferResource(BaseModel):
    """Row in the top-50 resources table, GET /networking/datatransfer/resources."""
    resource_id: str
    region: Optional[str] = None
    account: Optional[str] = None
    service: Optional[str] = None    # product_code that generated the transfer
    usage_type: Optional[str] = None # raw usage_type string (e.g. DataTransfer-Out-Bytes)
    total_cost: float
    total_gb: float
