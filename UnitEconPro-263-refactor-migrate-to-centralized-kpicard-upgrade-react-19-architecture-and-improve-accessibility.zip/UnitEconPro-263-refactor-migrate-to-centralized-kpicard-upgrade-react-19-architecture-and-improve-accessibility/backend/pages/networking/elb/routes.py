from fastapi import APIRouter, HTTPException, Query
from core import database as db
from core.dependencies import DateCtx
from . import queries as q
from . import schemas

router = APIRouter(prefix="/api/v1/networking/elb", tags=["Networking – ELB"])

# AWS ELB pricing constants — verified 2025-07 (us-east-1)
# https://aws.amazon.com/elasticloadbalancing/pricing/
_LB_HOURLY_COST = 0.008          # ALB/NLB base: ~$5.84/month
_CLB_HOURLY_COST = 0.025         # Classic LB: ~$18/month
_NLB_CROSS_ZONE_PER_GB = 0.01   # NLB cross-zone data: $0.01/GB


def _compute_elb_finops_flags(lb: dict, tgs: list, listeners: list, financials: dict):
    flags = []
    savings = 0.0
    lb_type = lb.get("load_balancer_type", "")
    scheme = lb.get("scheme", "")
    hours_cost = financials.get("hours_cost", 0.0)

    # 1. Idle LB — running but zero registered targets
    if lb.get("is_idle") and hours_cost > 0:
        monthly = round(_CLB_HOURLY_COST * 730 if lb_type == "classic" else _LB_HOURLY_COST * 730, 2)
        savings += monthly
        flags.append(schemas.ELBFinOpsFlag(
            flag="IDLE_LOAD_BALANCER",
            severity="HIGH",
            evidence=f"LB has {lb.get('total_registered_targets', 0)} registered targets but incurs ${hours_cost:.2f} in hourly charges.",
            reason="Load balancer is running with no targets — pure waste.",
            action=f"Delete load balancer: aws elbv2 delete-load-balancer --load-balancer-arn {lb.get('load_balancer_arn', '')}",
        ))

    # 2. Classic LB — deprecated, 3x more expensive than ALB
    if lb_type == "classic":
        monthly_clb = round(_CLB_HOURLY_COST * 730, 2)
        monthly_alb = round(_LB_HOURLY_COST * 730, 2)
        savings += round(monthly_clb - monthly_alb, 2)
        flags.append(schemas.ELBFinOpsFlag(
            flag="CLASSIC_LOAD_BALANCER_MIGRATION",
            severity="HIGH",
            evidence=f"Classic LB costs ~${monthly_clb}/month vs ~${monthly_alb}/month for ALB.",
            reason="Classic LBs are deprecated. ALB provides path-based routing, HTTP/2, WebSockets, and WAF at 1/3 the cost.",
            action="Migrate to ALB: https://docs.aws.amazon.com/elasticloadbalancing/latest/userguide/migrate-from-classic-load-balancer.html",
        ))

    # 2. Internet-facing ALB without WAF
    if lb_type == "application" and scheme == "internet-facing" and not lb.get("waf_enabled"):
        flags.append(schemas.ELBFinOpsFlag(
            flag="ALB_NO_WAF",
            severity="HIGH",
            evidence="Internet-facing ALB has no WAF Web ACL attached.",
            reason="Public ALBs without WAF are exposed to OWASP Top 10 attacks.",
            action="Attach an AWS WAF Web ACL via: aws wafv2 associate-web-acl",
        ))

    # 3. HTTP listener without redirect
    if lb.get("has_http_listener") and not lb.get("http_to_https_redirect"):
        flags.append(schemas.ELBFinOpsFlag(
            flag="HTTP_WITHOUT_REDIRECT",
            severity="MEDIUM",
            evidence="HTTP listener present with no HTTPS redirect rule.",
            reason="Unencrypted traffic accepted — security and compliance risk.",
            action="Add a redirect rule on port 80 → HTTPS 443.",
        ))

    # 4. Deprecated SSL policy
    if lb.get("has_deprecated_ssl_policy"):
        flags.append(schemas.ELBFinOpsFlag(
            flag="DEPRECATED_SSL_POLICY",
            severity="HIGH",
            evidence="One or more listeners use a deprecated SSL policy (allows TLS 1.0/1.1).",
            reason="TLS 1.0/1.1 are deprecated and fail PCI-DSS / SOC2 audits.",
            action="Update listener SSL policy to ELBSecurityPolicy-TLS13-1-2-2021-06.",
        ))

    # 5. No access logs
    if not lb.get("access_logs_enabled"):
        flags.append(schemas.ELBFinOpsFlag(
            flag="ACCESS_LOGS_DISABLED",
            severity="MEDIUM",
            evidence="Access logs are not enabled for this load balancer.",
            reason="Without access logs you cannot audit traffic, debug errors, or detect attacks.",
            action="Enable access logs to S3: aws elbv2 modify-load-balancer-attributes --attributes Key=access_logs.s3.enabled,Value=true ...",
        ))

    # 6. No deletion protection on active LB
    if not lb.get("deletion_protection_enabled") and not lb.get("is_idle"):
        flags.append(schemas.ELBFinOpsFlag(
            flag="NO_DELETION_PROTECTION",
            severity="LOW",
            evidence="Deletion protection is disabled.",
            reason="Active load balancers can be accidentally deleted.",
            action="Enable deletion protection: aws elbv2 modify-load-balancer-attributes --attributes Key=deletion_protection.enabled,Value=true ...",
        ))

    # 7. Orphaned target groups
    orphaned = [tg for tg in tgs if tg.get("is_orphaned")]
    if orphaned:
        flags.append(schemas.ELBFinOpsFlag(
            flag="ORPHANED_TARGET_GROUPS",
            severity="LOW",
            evidence=f"{len(orphaned)} target group(s) not attached to any load balancer.",
            reason="Orphaned target groups are dead configuration — no cost but adds clutter.",
            action="Delete orphaned TGs to keep the account clean.",
        ))

    # 8. NLB cross-zone enabled (costs $0.01/GB)
    if lb_type == "network" and lb.get("cross_zone_load_balancing"):
        flags.append(schemas.ELBFinOpsFlag(
            flag="NLB_CROSS_ZONE_ENABLED",
            severity="LOW",
            evidence="NLB cross-zone load balancing is enabled.",
            reason="Unlike ALB, NLB cross-zone load balancing charges $0.01/GB for cross-AZ traffic.",
            action="Disable if traffic is AZ-local: aws elbv2 modify-load-balancer-attributes --attributes Key=load_balancing.cross_zone.enabled,Value=false ...",
        ))

    return flags, round(savings, 2)


@router.get("/summary", response_model=schemas.ELBSummary)
def get_elb_summary(ctx: DateCtx):
    sql = q.ELB_SUMMARY.format(start=ctx.start, end=ctx.end, account_filter=ctx.account_filter, account_name=ctx.account_name)
    rows = db.query_safe(sql, ctx.params)
    if not rows:
        return schemas.ELBSummary(total_cost=0, total_lbs=0, idle_lbs=0, classic_lbs=0,
                                  alb_count=0, nlb_count=0, gwlb_count=0, albs_without_waf=0, avg_daily_cost=0)
    r = rows[0]
    return schemas.ELBSummary(
        total_cost=float(r.get("total_cost") or 0),
        total_lbs=int(r.get("total_lbs") or 0),
        idle_lbs=int(r.get("idle_lbs") or 0),
        classic_lbs=int(r.get("classic_lbs") or 0),
        alb_count=int(r.get("alb_count") or 0),
        nlb_count=int(r.get("nlb_count") or 0),
        gwlb_count=int(r.get("gwlb_count") or 0),
        albs_without_waf=int(r.get("albs_without_waf") or 0),
        avg_daily_cost=float(r.get("avg_daily_cost") or 0),
    )

@router.get("/lbs", response_model=list[schemas.ELBListItem])
def list_elbs(ctx: DateCtx, limit: int = Query(100, ge=1, le=500)):
    sql = q.ELB_LIST.format(start=ctx.start, end=ctx.end, account_filter=ctx.account_filter, limit=limit)
    rows = db.query_safe(sql, ctx.params)
    return [schemas.ELBListItem(**row) for row in rows]

@router.get("/gwlb-endpoints", response_model=list[schemas.GWLBEndpointCost])
def list_gwlb_endpoints(ctx: DateCtx):
    sql = q.GWLB_ENDPOINT_COSTS.format(start=ctx.start, end=ctx.end, account_filter=ctx.account_filter)
    rows = db.query_safe(sql, ctx.params)
    return [schemas.GWLBEndpointCost(**row) for row in rows]

@router.get("/lbs/{lb_arn:path}/metadata", response_model=schemas.ELBMetadataDetail)
def get_elb_detail(lb_arn: str, ctx: DateCtx):
    lb_params = {"lb_arn": lb_arn}

    main_sql = q.ELB_DETAIL_MAIN.format(account_filter=ctx.account_filter)
    main_rows = db.query(main_sql, params={**lb_params, **ctx.params})
    if not main_rows:
        raise HTTPException(status_code=404, detail="Load Balancer not found or access denied")

    lb_data = main_rows[0]

    cost_sql = q.ELB_DETAIL_COST.format(account_filter=ctx.account_filter, start=ctx.start, end=ctx.end)
    cost_rows = db.query(cost_sql, params={"lb_arn": lb_arn, **ctx.params})
    financials = schemas.ELBFinancials(total_cost=0.0, hours_cost=0.0, lcu_cost=0.0, other_cost=0.0)
    if cost_rows:
        r = cost_rows[0]
        financials = schemas.ELBFinancials(
            total_cost=float(r.get("total_cost") or 0.0),
            hours_cost=float(r.get("hours_cost") or 0.0),
            lcu_cost=float(r.get("lcu_cost") or 0.0),
            other_cost=float(r.get("other_cost") or 0.0),
        )

    tg_sql = q.ELB_DETAIL_TGS.format(account_filter=ctx.account_filter)
    target_groups = db.query(tg_sql, params={**lb_params, **ctx.params})

    ls_sql = q.ELB_DETAIL_LISTENERS.format(account_filter=ctx.account_filter)
    listeners = db.query(ls_sql, params={**lb_params, **ctx.params})

    flags, savings = _compute_elb_finops_flags(lb_data, target_groups, listeners, financials.model_dump())

    return schemas.ELBMetadataDetail(
        load_balancer_arn=lb_data.get("load_balancer_arn", ""),
        load_balancer_name=lb_data.get("load_balancer_name", ""),
        load_balancer_type=lb_data.get("load_balancer_type", ""),
        scheme=lb_data.get("scheme", ""),
        lb_state=lb_data.get("lb_state", ""),
        region=lb_data.get("region", ""),
        account_name=lb_data.get("account_name", ""),
        vpc_id=lb_data.get("vpc_id", ""),
        dns_name=lb_data.get("dns_name", ""),
        age_days=int(lb_data.get("age_days") or 0),
        is_idle=bool(lb_data.get("is_idle")),
        deletion_protection_enabled=bool(lb_data.get("deletion_protection_enabled")),
        access_logs_enabled=bool(lb_data.get("access_logs_enabled")),
        cross_zone_load_balancing=bool(lb_data.get("cross_zone_load_balancing")),
        waf_enabled=bool(lb_data.get("waf_enabled")),
        waf_web_acl_arn=lb_data.get("waf_web_acl_arn", ""),
        has_http_listener=bool(lb_data.get("has_http_listener")),
        http_to_https_redirect=bool(lb_data.get("http_to_https_redirect")),
        has_deprecated_ssl_policy=bool(lb_data.get("has_deprecated_ssl_policy")),
        healthy_target_count=int(lb_data.get("healthy_target_count") or 0),
        unhealthy_target_count=int(lb_data.get("unhealthy_target_count") or 0),
        total_registered_targets=int(lb_data.get("total_registered_targets") or 0),
        financials=financials,
        tags=lb_data.get("tags") or {},
        target_groups=target_groups,
        listeners=listeners,
        finops_flags=flags,
        estimated_savings_potential=savings,
    )
