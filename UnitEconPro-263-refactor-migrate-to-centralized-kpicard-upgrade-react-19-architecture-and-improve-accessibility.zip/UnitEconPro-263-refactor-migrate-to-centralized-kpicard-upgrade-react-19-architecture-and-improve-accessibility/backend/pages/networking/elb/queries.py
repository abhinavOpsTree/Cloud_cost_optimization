"""
ELB (Elastic Load Balancing) SQL Queries
-----------------------------------------
Product code: AWSELB  (confirmed from CUR – NOT AmazonElasticLoadBalancing)

Real cost composition in data:
  - APS3-LoadBalancerUsage  → CLB hourly charges (~$33)
  - LoadBalancerUsage       → ALB hourly charges (~$16)
  - LCUUsage                → ALB LCU charges   (~$0.003)
  - DataTransfer-Out-Bytes  → egress            (~$0.04)

All other usage_type rows exist but have $0 cost (data transfer manifests).
"""

# ── 1. Daily Cost Trend ──────────────────────────────────────
ELB_COST_TREND = """
    SELECT
        toDate(usage_start_ts) AS date_obj,
        formatDateTime(date_obj, '%Y-%m-%d') AS date,
        ROUND(SUM(cost_unblended), 2) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AWSELB'
      {account_filter}
    GROUP BY date_obj
    ORDER BY date_obj ASC
"""

# ── 3. Breakdowns ────────────────────────────────────────────

ELB_BY_REGION = """
    SELECT
        region AS name,
        ROUND(SUM(cost_unblended), 2) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AWSELB'
      AND trimBoth(region) != ''
      {account_filter}
    GROUP BY region
    ORDER BY cost DESC
"""

ELB_BY_ACCOUNT = """
    SELECT
        account_name AS name,
        ROUND(SUM(cost_unblended), 2) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AWSELB'
      AND account_name IS NOT NULL AND trimBoth(account_name) != ''
      {account_filter}
    GROUP BY account_name
    ORDER BY cost DESC
"""

# Groups the many raw usage_type rows into 3 human-readable buckets.
# Data Transfer rows all exist with $0 cost but are included correctly.
ELB_BY_USAGE_TYPE = """
    SELECT
        CASE
            WHEN usage_type LIKE '%LoadBalancerUsage%' THEN 'LB Hours'
            WHEN usage_type LIKE '%LCU%' OR usage_type LIKE '%NLCU%' THEN 'LCU Charges'
            ELSE 'Data Transfer'
        END AS name,
        ROUND(SUM(cost_unblended), 2) AS cost,
        ROUND(SUM(usage_qty), 2) AS usage,
        CASE
            WHEN usage_type LIKE '%LoadBalancerUsage%' THEN 'Hours'
            ELSE 'Units'
        END AS unit
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AWSELB'
      {account_filter}
    GROUP BY name, unit
    HAVING cost > 0
    ORDER BY cost DESC
"""

# Classifies each LB by ARN prefix: /app/ = ALB, /net/ = NLB, /gwy/ = GWLB,
# everything else = Classic LB (no type prefix in the ARN, just a bare hash).
ELB_BY_FAMILY = """
    SELECT
        CASE
            WHEN resource_id LIKE '%/app/%' THEN 'Application LB (ALB)'
            WHEN resource_id LIKE '%/net/%' THEN 'Network LB (NLB)'
            WHEN resource_id LIKE '%/gwy/%' THEN 'Gateway LB (GWLB)'
            ELSE 'Classic LB (CLB)'
        END AS name,
        ROUND(SUM(cost_unblended), 2) AS cost,
        ROUND(SUMIf(usage_qty, usage_type LIKE '%LoadBalancerUsage%'), 2) AS usage,
        'Hours' AS unit
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AWSELB'
      AND resource_id != ''
      {account_filter}
    GROUP BY name
    ORDER BY cost DESC
"""

# ── 5. Idle ("Zombie") Load Balancers ───────────────────────
# LBs that have hourly charges (are running) but zero LCU/NLCU consumption
# (no traffic). These are pure waste — classic rightsizing candidates.
# Uses same ARN-based lb_name extraction as ELB_TOP_LOAD_BALANCERS.
ELB_IDLE_LBS = """
    SELECT
        resource_id,
        CASE
            WHEN resource_id LIKE '%/app/%'
              OR resource_id LIKE '%/net/%'
              OR resource_id LIKE '%/gwy/%'
            THEN splitByString('/', resource_id)[-2]
            ELSE splitByString('/', resource_id)[-1]
        END AS lb_name,
        argMax(region, usage_start_ts) AS region,
        argMax(account_name, usage_start_ts) AS account,
        ROUND(SUMIf(usage_qty, usage_type LIKE '%LoadBalancerUsage%'), 2) AS lb_hours,
        ROUND(SUM(cost_unblended), 2) AS total_cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AWSELB'
      AND resource_id != ''
      {account_filter}
    GROUP BY resource_id
    HAVING SUMIf(usage_qty, usage_type LIKE '%LCU%' OR usage_type LIKE '%NLCU%') = 0
       AND lb_hours > 0
    ORDER BY total_cost DESC
"""

# ── 6. Top Load Balancers Table ──────────────────────────────
# ARN formats:
#   ALB/NLB/GWLB: .../loadbalancer/app/<name>/<id>  → [-2] = friendly name
#   CLB:          .../loadbalancer/<hash>             → [-1] = hash (no friendly name in CUR)
ELB_TOP_LOAD_BALANCERS = """
    SELECT
        resource_id,
        CASE
            WHEN resource_id LIKE '%/app/%'
              OR resource_id LIKE '%/net/%'
              OR resource_id LIKE '%/gwy/%'
            THEN splitByString('/', resource_id)[-2]
            ELSE splitByString('/', resource_id)[-1]
        END AS lb_name,
        argMax(region, usage_start_ts) AS region,
        argMax(account_name, usage_start_ts) AS account,
        ROUND(SUMIf(usage_qty, usage_type LIKE '%LoadBalancerUsage%'), 2) AS lb_hours,
        ROUND(SUM(cost_unblended), 2) AS total_cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AWSELB'
      AND resource_id != ''
      {account_filter}
    GROUP BY resource_id
    ORDER BY total_cost DESC
    LIMIT 50
"""

ELB_SUMMARY = """
    WITH lb_stats AS (
        SELECT
            resource_id,
            SUMIf(usage_qty, usage_type LIKE '%LoadBalancerUsage%') AS lb_hours,
            SUMIf(usage_qty, usage_type LIKE '%LCU%' OR usage_type LIKE '%NLCU%') AS lcu_units
        FROM cost.service_costs
        WHERE product_code = 'AWSELB'
          AND resource_id != ''
          AND usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
          {account_filter}
        GROUP BY resource_id
    )
    SELECT
        ROUND(SUM(sc.cost_unblended), 2) AS total_cost,
        COUNTDistinct(sc.resource_id)    AS total_lbs,
        -- Idle: computed from CUR LCU data — not stale metadata is_idle flag
        COUNTDistinctIf(sc.resource_id, lb_stats.lb_hours > 0 AND lb_stats.lcu_units = 0) AS idle_lbs,
        COUNTDistinctIf(sc.resource_id,
            sc.resource_id NOT LIKE '%/app/%'
            AND sc.resource_id NOT LIKE '%/net/%'
            AND sc.resource_id NOT LIKE '%/gwy/%'
        ) AS classic_lbs,
        COUNTDistinctIf(sc.resource_id, sc.resource_id LIKE '%/app/%') AS alb_count,
        COUNTDistinctIf(sc.resource_id, sc.resource_id LIKE '%/net/%') AS nlb_count,
        COUNTDistinctIf(sc.resource_id, sc.resource_id LIKE '%/gwy/%') AS gwlb_count,
        COUNTDistinctIf(sc.resource_id,
            sc.resource_id LIKE '%/app/%'
            AND COALESCE(elb.waf_enabled, 0) = 0
            AND elb.scheme = 'internet-facing'
        ) AS albs_without_waf,
        ROUND(SUM(sc.cost_unblended) / GREATEST(COUNTDistinct(toDate(sc.usage_start_ts)), 1), 2) AS avg_daily_cost
    FROM cost.service_costs sc FINAL
    JOIN lb_stats ON lb_stats.resource_id = sc.resource_id
    LEFT JOIN cost.aws_elb_metadata elb FINAL
        ON elb.load_balancer_arn = sc.resource_id
    WHERE sc.product_code = 'AWSELB'
      AND sc.resource_id != ''
      AND sc.usage_start_ts >= '{start}' AND sc.usage_start_ts <= '{end}'
      AND ('{account_name}' = 'All' OR sc.account_name = '{account_name}')
"""

ELB_LIST = """
    SELECT
        resource_id AS load_balancer_arn,
        CASE
            WHEN resource_id LIKE '%/app/%' OR resource_id LIKE '%/net/%' OR resource_id LIKE '%/gwy/%'
            THEN splitByString('/', resource_id)[-2]
            ELSE splitByString('/', resource_id)[-1]
        END AS load_balancer_name,
        CASE
            WHEN resource_id LIKE '%/app/%' THEN 'application'
            WHEN resource_id LIKE '%/net/%' THEN 'network'
            WHEN resource_id LIKE '%/gwy/%' THEN 'gateway'
            ELSE 'classic'
        END AS load_balancer_type,
        argMax(region, usage_start_ts) AS region,
        argMax(account_name, usage_start_ts) AS account_name,
        ROUND(SUM(cost_unblended), 2) AS total_cost
    FROM (
        SELECT *
        FROM cost.service_costs
        WHERE product_code = 'AWSELB'
          AND resource_id != ''
          AND usage_start_ts >= '{start}'
          AND usage_start_ts <= '{end}'
          {account_filter}
    )
    GROUP BY resource_id
    ORDER BY total_cost DESC
    LIMIT {limit}
"""

GWLB_ENDPOINT_COSTS = """
    SELECT
        ep.vpc_endpoint_id,
        ep.vpc_id,
        ep.service_name,
        ep.region,
        ep.account_name,
        ep.endpoint_state,
        ep.age_days,
        ROUND(SUM(sc.cost_unblended), 4) AS total_endpoint_cost,
        ROUND(sumIf(sc.cost_unblended, sc.usage_type LIKE '%VpcEndpoint-Hours%'), 4) AS hourly_cost,
        ROUND(sumIf(sc.cost_unblended, sc.usage_type LIKE '%VpcEndpoint-Bytes%'), 4) AS data_cost
    FROM cost.aws_gwlb_endpoint_metadata ep FINAL
    LEFT JOIN cost.service_costs sc FINAL
        ON sc.resource_id = ep.vpc_endpoint_id
       AND sc.product_code = 'AmazonVPC'
       AND sc.usage_type LIKE '%VpcEndpoint%'
       AND sc.usage_start_ts >= '{start}'
       AND sc.usage_start_ts <= '{end}'
    WHERE 1=1 {account_filter}
    GROUP BY ep.vpc_endpoint_id, ep.vpc_id, ep.service_name, ep.region,
             ep.account_name, ep.endpoint_state, ep.age_days
    ORDER BY total_endpoint_cost DESC
"""

ELB_DETAIL_MAIN = """
    SELECT *
    FROM cost.aws_elb_metadata FINAL
    WHERE load_balancer_arn = {{lb_arn:String}}
      {account_filter}
    LIMIT 1
"""

ELB_DETAIL_TGS = """
    SELECT *
    FROM cost.aws_elb_target_group_metadata FINAL
    WHERE has(load_balancer_arns, {{lb_arn:String}})
      {account_filter}
"""

ELB_DETAIL_LISTENERS = """
    SELECT *
    FROM cost.aws_elb_listener_metadata FINAL
    WHERE load_balancer_arn = {{lb_arn:String}}
      {account_filter}
"""

ELB_DETAIL_COST = """
    SELECT
        ROUND(SUM(cost_unblended), 2) AS total_cost,
        ROUND(SUMIf(cost_unblended, usage_type LIKE '%LoadBalancerUsage%'), 2) AS hours_cost,
        ROUND(SUMIf(cost_unblended, usage_type LIKE '%LCU%' OR usage_type LIKE '%NLCU%'), 2) AS lcu_cost,
        ROUND(SUMIf(cost_unblended, usage_type NOT LIKE '%LoadBalancerUsage%' AND usage_type NOT LIKE '%LCU%' AND usage_type NOT LIKE '%NLCU%'), 2) AS other_cost
    FROM cost.service_costs
    WHERE product_code = 'AWSELB'
      AND resource_id = {{lb_arn:String}}
      AND usage_start_ts >= '{start}'
      AND usage_start_ts <= '{end}'
      {account_filter}
"""
