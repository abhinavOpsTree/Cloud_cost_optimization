from pydantic import BaseModel
from typing import Optional, List, Dict

class ELBSummary(BaseModel):
    total_cost: float
    total_lbs: int
    idle_lbs: int
    classic_lbs: int
    alb_count: int
    nlb_count: int
    gwlb_count: int
    albs_without_waf: int
    avg_daily_cost: float

class ELBListItem(BaseModel):
    load_balancer_arn: str
    load_balancer_name: str
    load_balancer_type: str
    region: str
    account_name: str
    total_cost: float

class GWLBEndpointCost(BaseModel):
    vpc_endpoint_id: str
    vpc_id: str
    service_name: str
    region: str
    account_name: str
    endpoint_state: str
    age_days: int
    total_endpoint_cost: float
    hourly_cost: float
    data_cost: float

class ELBFinancials(BaseModel):
    total_cost: float
    hours_cost: float
    lcu_cost: float
    other_cost: float

class ELBFinOpsFlag(BaseModel):
    flag: str
    severity: str
    evidence: str
    reason: str
    action: str

class ELBMetadataDetail(BaseModel):
    load_balancer_arn: str
    load_balancer_name: str
    load_balancer_type: str
    scheme: str
    lb_state: str
    region: str
    account_name: str
    vpc_id: str
    dns_name: str
    age_days: int
    is_idle: bool
    # Security
    deletion_protection_enabled: bool
    access_logs_enabled: bool
    cross_zone_load_balancing: bool
    waf_enabled: bool
    waf_web_acl_arn: str
    has_http_listener: bool
    http_to_https_redirect: bool
    has_deprecated_ssl_policy: bool
    # Targets
    healthy_target_count: int
    unhealthy_target_count: int
    total_registered_targets: int
    # Cost breakdown
    financials: ELBFinancials
    tags: Dict[str, str]
    target_groups: List[dict]
    listeners: List[dict]
    finops_flags: List[ELBFinOpsFlag]
    estimated_savings_potential: float
