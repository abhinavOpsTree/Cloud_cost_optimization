"""
VPC Network Page Routes
All endpoints for the VPC cost analytics page.
"""
import logging
from fastapi import APIRouter, HTTPException, Query

from core import database as db
from core.dependencies import DateCtx
from . import queries as q
from . import schemas

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v1/networking/vpc", tags=["Networking – VPC"])


@router.get("/summary", response_model=schemas.VPCSummary)
def get_vpc_summary(ctx: DateCtx):
    sql = q.VPC_SUMMARY.format(start=ctx.start, end=ctx.end, account_filter=ctx.account_filter)
    rows = db.query_safe(sql, ctx.params)
    if not rows:
        return schemas.VPCSummary(
            total_cost=0, vpc_only_cost=0, nat_only_cost=0, avg_daily_cost=0, total_resources=0,
            resources=schemas.VPCResourceBreakdown(network_interfaces=0, elastic_ips=0, nat_gateways=0, vpc_endpoints=0, vpn_connections=0),
            costs=schemas.VPCCostBreakdown(public_ip_cost=0, nat_gateway_cost=0, vpc_endpoint_cost=0, total_vpc_cost=0, total_nat_cost=0),
        )
    r = rows[0]
    return schemas.VPCSummary(
        total_cost=float(r.get("total_cost") or 0),
        vpc_only_cost=float(r.get("vpc_only_cost") or 0),
        nat_only_cost=float(r.get("nat_only_cost") or 0),
        avg_daily_cost=float(r.get("avg_daily_cost") or 0),
        total_resources=int(r.get("total_resources") or 0),
        resources=schemas.VPCResourceBreakdown(
            network_interfaces=int(r.get("network_interfaces") or 0),
            elastic_ips=int(r.get("elastic_ips") or 0),
            nat_gateways=int(r.get("nat_gateways") or 0),
            vpc_endpoints=int(r.get("vpc_endpoints") or 0),
            vpn_connections=int(r.get("vpn_connections") or 0),
        ),
        costs=schemas.VPCCostBreakdown(
            public_ip_cost=float(r.get("public_ip_cost") or 0),
            nat_gateway_cost=float(r.get("nat_gateway_cost") or 0),
            vpc_endpoint_cost=float(r.get("vpc_endpoint_cost") or 0),
            total_vpc_cost=float(r.get("vpc_only_cost") or 0),
            total_nat_cost=float(r.get("nat_only_cost") or 0),
        ),
    )


@router.get("/breakdown/public-ip", response_model=list[schemas.VPCPublicIPItem])
def get_vpc_public_ip_breakdown(ctx: DateCtx):
    sql = q.VPC_PUBLIC_IP_BREAKDOWN.format(start=ctx.start, end=ctx.end, account_filter=ctx.account_filter)
    rows = db.query_safe(sql, ctx.params)
    return [schemas.VPCPublicIPItem(name=r["name"], cost=r["cost"], ip_hours=r["ip_hours"]) for r in rows]


@router.get("/vpcs", response_model=list[schemas.VPCListItem])
def list_vpcs(
    ctx: DateCtx,
    limit: int = Query(default=100, ge=1, le=500, description="Max results"),
):
    """List all VPCs with cost. Drill into /{vpc_id}/metadata for full details."""
    sql = q.VPC_LIST.format(start=ctx.start, end=ctx.end, account_name=ctx.account_name, account_filter=ctx.account_filter, limit=limit)
    rows = db.query_safe(sql, ctx.params)
    return [
        schemas.VPCListItem(
            vpc_id=r.get("vpc_id", ""),
            vpc_name=r.get("vpc_name", ""),
            region=r.get("region", ""),
            account_name=r.get("account_name", ""),
            account_id=str(r.get("account_id", "")),
            total_cost=round(float(r.get("total_cost") or 0), 2),
        )
        for r in rows
    ]


# ════════════════════════════════════════════════════════
# METADATA ENDPOINT
# ════════════════════════════════════════════════════════

# Constants
EIP_IDLE_COST_PER_MONTH = 3.60      # 720 hours/month * $0.005/hour (commercial regions)
NAT_GATEWAY_HOURLY_COST = 0.045     # $0.045/hour commercial | us-gov-west-1: $0.054 | China: CNY pricing

def _compute_vpc_finops_flags(vpc: dict, nats: list, eips: list, financials: dict):
    flags   = []
    savings = 0.0

    active_nats     = [n for n in nats if n.get("state") == "available"]
    unattached_eips = [e for e in eips if not e.get("is_attached")]
    nat_hourly_cost = float(financials.get("nat_hourly_cost") or 0)

    # 1. Missing S3 Gateway Endpoint — highest ROI flag
    if active_nats and not vpc.get("has_s3_gateway_endpoint"):
        flags.append(schemas.VPCFinOpsFlag(
            flag="MISSING_S3_GATEWAY_ENDPOINT", severity="HIGH",
            evidence=f"VPC has {len(active_nats)} active NAT(s) but no S3 Gateway Endpoint.",
            reason="Private subnet traffic to S3 routes through NAT at $0.045/GB. S3 Gateway Endpoints are 100% free.",
            action=f"Create S3 Gateway Endpoint in {vpc['vpc_id']} and attach to all private route tables.",
        ))

    # 2. Missing DynamoDB Gateway Endpoint
    if active_nats and not vpc.get("has_dynamodb_gateway_endpoint"):
        flags.append(schemas.VPCFinOpsFlag(
            flag="MISSING_DYNAMODB_GATEWAY_ENDPOINT", severity="MEDIUM",
            evidence=f"VPC has {len(active_nats)} active NAT(s) but no DynamoDB Gateway Endpoint.",
            reason="DynamoDB traffic through NAT costs $0.045/GB. Gateway Endpoints are free.",
            action=f"Create DynamoDB Gateway Endpoint in {vpc['vpc_id']} and attach to all private route tables.",
        ))

    # 3. Unattached Elastic IPs
    for eip in unattached_eips:
        savings += EIP_IDLE_COST_PER_MONTH
        flags.append(schemas.VPCFinOpsFlag(
            flag="UNATTACHED_ELASTIC_IP", severity="HIGH",
            evidence=f"EIP {eip['public_ip']} ({eip['allocation_id']}) has no association.",
            reason=f"Unattached EIPs cost ~${EIP_IDLE_COST_PER_MONTH}/month each. Pure waste.",
            action=f"Release {eip['allocation_id']} via AWS Console or: aws ec2 release-address --allocation-id {eip['allocation_id']}",
        ))

    # 4. Zombie NAT — subnet has zero workload ENIs
    for nat in active_nats:
        if nat.get("subnet_active_eni_count", 0) == 0:
            # Use fixed monthly cost constant — nat_hourly_cost is date-range-dependent
            # and dividing by NAT count gives wrong per-NAT savings
            nat_saving = round(NAT_GATEWAY_HOURLY_COST * 720, 2)  # 720 hours/month
            savings += nat_saving
            flags.append(schemas.VPCFinOpsFlag(
                flag="ZOMBIE_NAT_GATEWAY", severity="HIGH",
                evidence=f"NAT {nat['nat_gateway_id']} subnet {nat['subnet_id']} has 0 workload ENIs.",
                reason=f"No workload resources in this subnet. You are paying ~$32.85/month for an idle NAT Gateway.",
                action=f"Verify no resources use this NAT, then delete: aws ec2 delete-nat-gateway --nat-gateway-id {nat['nat_gateway_id']}",
            ))

    # 5. Flow Logs disabled
    if not vpc.get("flow_logs_enabled"):
        flags.append(schemas.VPCFinOpsFlag(
            flag="FLOW_LOGS_DISABLED", severity="MEDIUM",
            evidence="VPC Flow Logs not enabled at VPC or subnet level.",
            reason="Without flow logs you cannot attribute NAT traffic to specific services or detect misrouted S3/DynamoDB calls.",
            action="Enable VPC Flow Logs to S3 in Parquet format for cost-efficient storage.",
            confidence="HIGH",
        ))

    # 6. Default VPC in use
    if vpc.get("is_default_vpc") and (vpc.get("nat_gateway_count", 0) > 0 or vpc.get("subnet_count", 0) > 3):
        flags.append(schemas.VPCFinOpsFlag(
            flag="DEFAULT_VPC_IN_USE", severity="LOW",
            evidence=f"Default VPC has {vpc.get('nat_gateway_count', 0)} NATs and {vpc.get('subnet_count', 0)} subnets.",
            reason="Default VPCs have no private subnets and poor security posture. Resources should be in custom VPCs.",
            action="Migrate workloads to a custom VPC with proper public/private subnet separation.",
            confidence="MEDIUM",
        ))

    return flags, round(savings, 2)


@router.get("/{vpc_id}/metadata", response_model=schemas.VPCMetadataDetail)
def get_vpc_metadata(
    vpc_id: str,
    ctx: DateCtx,
):
    """FinOps metadata for a specific VPC — architecture + financials + flags."""
    rows = db.query_safe(q.VPC_METADATA_BY_ID, params={
        "vpc_id": vpc_id,
        "start":  ctx.start,
        "end":    ctx.end,
        **ctx.params,
    })

    if not rows:
        raise HTTPException(status_code=404, detail=f"VPC '{vpc_id}' not found. Run metadata_only mode first to ingest VPC data.")

    r = rows[0]

    nat_rows = db.query_safe(q.VPC_NAT_GATEWAYS_BY_VPC, params={"vpc_id": vpc_id})
    eip_rows = db.query_safe(q.VPC_EIPS_BY_ACCOUNT,     params={"vpc_id": vpc_id})

    financials = {
        "total_vpc_cost":           round(float(r.get("total_vpc_cost_30d")       or 0), 4),
        "nat_hourly_cost":          round(float(r.get("nat_hourly_cost")          or 0), 4),
        "nat_data_processing_cost": round(float(r.get("nat_data_processing_cost") or 0), 4),
        "eip_cost":                 round(float(r.get("eip_cost")                 or 0), 4),
    }

    nats = [
        schemas.NATGatewayDetail(
            nat_gateway_id=n.get("nat_gateway_id", ""),
            subnet_id=n.get("subnet_id", ""),
            availability_zone=n.get("availability_zone", ""),
            state=n.get("state", ""),
            connectivity_type=n.get("connectivity_type", ""),
            elastic_ip_address=n.get("elastic_ip_address", ""),
            age_days=int(n.get("age_days") or 0),
            subnet_active_eni_count=int(n.get("subnet_active_eni_count") or 0),
        ) for n in nat_rows
    ]

    eips = [
        schemas.EIPDetail(
            allocation_id=e.get("allocation_id", ""),
            public_ip=e.get("public_ip", ""),
            is_attached=bool(e.get("is_attached")),
            network_interface_id=e.get("network_interface_id", ""),
        ) for e in eip_rows
    ]

    vpc_dict = {
        "vpc_id":                       r.get("vpc_id", ""),
        "has_s3_gateway_endpoint":      bool(r.get("has_s3_gateway_endpoint")),
        "has_dynamodb_gateway_endpoint": bool(r.get("has_dynamodb_gateway_endpoint")),
        "flow_logs_enabled":            bool(r.get("flow_logs_enabled")),
        "is_default_vpc":               bool(r.get("is_default_vpc")),
        "nat_gateway_count":            int(r.get("nat_gateway_count") or 0),
        "subnet_count":                 int(r.get("subnet_count") or 0),
    }

    flags, savings = _compute_vpc_finops_flags(vpc_dict, [n.model_dump() for n in nats], [e.model_dump() for e in eips], financials)

    def _fmt(val):
        if val and hasattr(val, "strftime"):
            return val.strftime("%Y-%m-%dT%H:%M:%SZ")
        return str(val) if val else None

    return schemas.VPCMetadataDetail(
        vpc_id=r.get("vpc_id", ""),
        vpc_name=r.get("vpc_name", ""),
        region=r.get("region", ""),
        account_name=r.get("account_name", ""),
        account_id=r.get("account_id", ""),
        financials=schemas.VPCFinancials(**financials),
        architecture=schemas.VPCArchitecture(
            cidr_block=r.get("cidr_block", ""),
            is_default_vpc=bool(r.get("is_default_vpc")),
            subnet_count=int(r.get("subnet_count") or 0),
            public_subnet_count=int(r.get("public_subnet_count") or 0),
            private_subnet_count=int(r.get("private_subnet_count") or 0),
            isolated_subnet_count=int(r.get("isolated_subnet_count") or 0),
            nat_gateway_count=int(r.get("nat_gateway_count") or 0),
            active_nat_gateway_count=int(r.get("active_nat_gateway_count") or 0),
            has_s3_gateway_endpoint=bool(r.get("has_s3_gateway_endpoint")),
            has_dynamodb_gateway_endpoint=bool(r.get("has_dynamodb_gateway_endpoint")),
            has_internet_gateway=bool(r.get("has_internet_gateway")),
            flow_logs_enabled=bool(r.get("flow_logs_enabled")),
            vpc_endpoint_count=int(r.get("vpc_endpoint_count") or 0),
        ),
        nat_gateways=nats,
        elastic_ips=eips,
        tags=r.get("tags") or {},
        estimated_savings_potential=savings,
        finops_flags=flags,
        metadata_last_synced=_fmt(r.get("ingested_at")) or "",
    )
