"""
VPC Network SQL Query Templates
Focus: Public IPv4 charges, NAT Gateways, Data Transfer, VPC Endpoints
All queries filter by product_code = 'AmazonVPC' and support date + account filtering.
Placeholders: {start}, {end}, {account_filter}

Key VPC Cost Components:
  1. Public IPv4 - In-Use addresses ($0.005/hour)
  2. Public IPv4 - Idle Elastic IPs ($0.005/hour)
  3. NAT Gateway - Hours + Data Processing
  4. Data Transfer - Inter-AZ, Inter-Region, Internet egress
  5. VPC Endpoints (PrivateLink) - Hourly + Data Processing
"""

# ── Summary: 4 stat cards ────────────────────────────────
VPC_SUMMARY = """
    SELECT
        ROUND(SUM(cost_unblended), 2) AS total_cost,
        ROUND(sumIf(cost_unblended, product_code = 'AmazonVPC'), 2) AS vpc_only_cost,
        ROUND(sumIf(cost_unblended, product_code = 'AmazonEC2'), 2) AS nat_only_cost,
        CASE
            WHEN COUNT(DISTINCT toDate(usage_start_ts)) > 0
            THEN ROUND(SUM(cost_unblended) / COUNT(DISTINCT toDate(usage_start_ts)), 2)
            ELSE 0
        END AS avg_daily_cost,
        COUNTDistinctIf(resource_id, product_code = 'AmazonVPC') AS total_resources,
        COUNTDistinctIf(resource_id, resource_id LIKE '%network-interface%') AS network_interfaces,
        COUNTDistinctIf(resource_id, resource_id LIKE '%elastic-ip%')        AS elastic_ips,
        COUNTDistinctIf(resource_id, resource_id LIKE '%natgateway%')        AS nat_gateways,
        COUNTDistinctIf(resource_id, resource_id LIKE '%vpc-endpoint%')      AS vpc_endpoints,
        COUNTDistinctIf(resource_id, resource_id LIKE '%vpn-connection%')    AS vpn_connections,
        ROUND(sumIf(cost_unblended, product_code = 'AmazonVPC' AND resource_id LIKE '%network-interface%'), 2) AS public_ip_cost,
        ROUND(sumIf(cost_unblended, resource_id LIKE '%natgateway%'), 2)        AS nat_gateway_cost,
        ROUND(sumIf(cost_unblended, resource_id LIKE '%vpc-endpoint%'), 2)      AS vpc_endpoint_cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND (product_code = 'AmazonVPC' OR (product_code = 'AmazonEC2' AND usage_type LIKE '%NatGateway%'))
      {account_filter}
"""

# ── Daily Cost Trend ──────────────────────────────────────
VPC_COST_TREND = """
    SELECT
        toDate(usage_start_ts) AS date_obj,
        formatDateTime(date_obj, '%Y-%m-%d') AS date,
        ROUND(SUM(cost_unblended), 2) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND (product_code = 'AmazonVPC' OR (product_code = 'AmazonEC2' AND usage_type LIKE '%NatGateway%'))
      {account_filter}
    GROUP BY date_obj
    ORDER BY date_obj ASC
"""

# ── Breakdown by Account ──────────────────────────────────
VPC_BY_ACCOUNT = """
    SELECT
        account_name AS name,
        ROUND(SUM(cost_unblended), 2) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND (product_code = 'AmazonVPC' OR (product_code = 'AmazonEC2' AND usage_type LIKE '%NatGateway%'))
      AND account_name IS NOT NULL
      {account_filter}
    GROUP BY account_name
    ORDER BY cost DESC
"""

# ── Breakdown by Region ───────────────────────────────────
VPC_BY_REGION = """
    SELECT
        region AS name,
        ROUND(SUM(cost_unblended), 2) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND (product_code = 'AmazonVPC' OR (product_code = 'AmazonEC2' AND usage_type LIKE '%NatGateway%'))
      AND trimBoth(region) != ''
      {account_filter}
    GROUP BY region
    ORDER BY cost DESC
"""

# ── Breakdown by Usage Type (Public IP vs NAT vs Transfer) ─
VPC_BY_USAGE_TYPE = """
    SELECT
        CASE
            WHEN usage_type LIKE '%PublicIPv4:InUseAddress%' THEN 'Public IPv4 - In-Use'
            WHEN usage_type LIKE '%PublicIPv4:IdleAddress%' THEN 'Public IPv4 - Idle'
            WHEN usage_type LIKE '%NatGateway-Hours%' THEN 'NAT Gateway - Hours'
            WHEN usage_type LIKE '%NatGateway-Bytes%' THEN 'NAT Gateway - Data Processing'
            WHEN usage_type LIKE '%DataTransfer-Out-Bytes%' THEN 'Data Transfer - Internet Out'
            WHEN usage_type LIKE '%DataTransfer-In-Bytes%' THEN 'Data Transfer - Internet In'
            WHEN usage_type LIKE '%DataTransfer-Regional-Bytes%' THEN 'Data Transfer - Cross-AZ'
            WHEN usage_type LIKE '%AWS-Out-Bytes%' THEN 'Data Transfer - Cross-Region Out'
            WHEN usage_type LIKE '%AWS-In-Bytes%' THEN 'Data Transfer - Cross-Region In'
            WHEN usage_type LIKE '%VpcEndpoint%' THEN 'VPC Endpoints'
            ELSE usage_type
        END AS name,
        ROUND(SUM(cost_unblended), 2) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND (product_code = 'AmazonVPC' OR (product_code = 'AmazonEC2' AND usage_type LIKE '%NatGateway%'))
      {account_filter}
    GROUP BY name
    HAVING cost > 0
    ORDER BY cost DESC
    LIMIT 10
"""

# ── Breakdown by Operation (IP allocation types) ──────────
VPC_BY_OPERATION = """
    SELECT
        CASE
            WHEN operation = 'RunInstances' THEN 'EC2 Public IP Addresses'
            WHEN operation = 'AssociateAddressVPC' THEN 'Elastic IP - In-Use'
            WHEN operation = 'AllocateAddressVPC' THEN 'Elastic IP - Idle'
            WHEN operation = 'DescribeNetworkInterfaces' THEN 'Service-Managed IPs'
            WHEN operation = 'NatGateway' THEN 'NAT Gateway'
            WHEN operation = 'CreateVpnConnection' THEN 'VPN Endpoints'
            WHEN operation = 'CreateAccelerator' THEN 'Global Accelerator'
            ELSE operation
        END AS name,
        ROUND(SUM(cost_unblended), 2) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND (product_code = 'AmazonVPC' OR (product_code = 'AmazonEC2' AND usage_type LIKE '%NatGateway%'))
      AND operation IS NOT NULL
      {account_filter}
    GROUP BY name
    HAVING cost > 0
    ORDER BY cost DESC
    LIMIT 10
"""

# ── Breakdown by Pricing Model ────────────────────────────
VPC_BY_PRICING_MODEL = """
    SELECT
        COALESCE(pricing_model, 'OnDemand') AS name,
        ROUND(SUM(cost_unblended), 2) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonVPC'
      {account_filter}
    GROUP BY pricing_model
    ORDER BY cost DESC
"""

VPC_LIST = """
    WITH eni_costs AS (
        SELECT
            e.vpc_id,
            toString(sc.account_id) AS account_id,
            ROUND(SUM(sc.cost_unblended), 2) AS total_cost
        FROM cost.service_costs sc FINAL
        JOIN cost.aws_eni_metadata e FINAL
            ON splitByChar('/', sc.resource_id)[-1] = e.eni_id
        WHERE sc.product_code = 'AmazonVPC'
          AND sc.usage_start_ts >= '{start}'
          AND sc.usage_start_ts <= '{end}'
          AND e.vpc_id != ''
          AND ('{account_name}' = 'All' OR sc.account_name = '{account_name}')
        GROUP BY e.vpc_id, sc.account_id
    ),
    eip_costs AS (
        SELECT
            e.vpc_id,
            toString(sc.account_id) AS account_id,
            ROUND(SUM(sc.cost_unblended), 2) AS total_cost
        FROM cost.service_costs sc FINAL
        JOIN cost.aws_eip_metadata e FINAL
            ON splitByChar('/', sc.resource_id)[-1] = e.allocation_id
        WHERE sc.product_code = 'AmazonVPC'
          AND sc.usage_start_ts >= '{start}'
          AND sc.usage_start_ts <= '{end}'
          AND e.vpc_id != ''
          AND ('{account_name}' = 'All' OR sc.account_name = '{account_name}')
        GROUP BY e.vpc_id, sc.account_id
    ),
    nat_costs AS (
        SELECT
            n.vpc_id,
            toString(sc.account_id) AS account_id,
            ROUND(SUM(sc.cost_unblended), 2) AS total_cost
        FROM cost.service_costs sc FINAL
        JOIN cost.aws_nat_gateway_metadata n FINAL
            ON splitByChar('/', sc.resource_id)[-1] = n.nat_gateway_id
        WHERE sc.product_code IN ('AmazonVPC', 'AmazonEC2')
          AND sc.usage_start_ts >= '{start}'
          AND sc.usage_start_ts <= '{end}'
          AND n.vpc_id != ''
          AND ('{account_name}' = 'All' OR sc.account_name = '{account_name}')
        GROUP BY n.vpc_id, sc.account_id
    ),
    vpc_costs AS (
        SELECT vpc_id, account_id, SUM(total_cost) AS total_cost
        FROM (SELECT * FROM eni_costs UNION ALL SELECT * FROM eip_costs UNION ALL SELECT * FROM nat_costs)
        GROUP BY vpc_id, account_id
    )
    SELECT
        vpc.vpc_id,
        vpc.vpc_name,
        vpc.region,
        vpc.account_name,
        vpc.account_id,
        COALESCE(vc.total_cost, 0) AS total_cost
    FROM (
        SELECT vpc_id, vpc_name, region, account_name, account_id
        FROM cost.aws_vpc_metadata FINAL
        WHERE 1=1
          {account_filter}
    ) AS vpc
    LEFT JOIN vpc_costs vc ON vpc.vpc_id = vc.vpc_id AND vpc.account_id = vc.account_id
    ORDER BY total_cost DESC, vpc.region ASC
    LIMIT {limit}
"""

# ── Special: Public IPv4 Breakdown ─────────────────────────
VPC_PUBLIC_IP_BREAKDOWN = """
    SELECT
        CASE
            WHEN usage_type LIKE '%Idle%' THEN 'Idle Elastic IPs'
            WHEN usage_type LIKE '%InUse%' AND operation = 'RunInstances' THEN 'EC2 Public IPs'
            WHEN usage_type LIKE '%InUse%' AND operation = 'AssociateAddressVPC' THEN 'In-Use Elastic IPs'
            WHEN usage_type LIKE '%InUse%' AND operation = 'DescribeNetworkInterfaces' THEN 'Service-Managed IPs'
            ELSE 'Other IPv4'
        END AS name,
        ROUND(SUM(cost_unblended), 2) AS cost,
        ROUND(SUM(usage_qty), 2) AS ip_hours
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonVPC'
      AND usage_type LIKE '%IPv4%'
      {account_filter}
    GROUP BY name
    HAVING cost > 0
    ORDER BY cost DESC
"""

# ── VPC Metadata Queries (uses named params via db.query(sql, params={...})) ──
# Costs attributed via ENI/EIP → VPC mapping for accurate per-VPC breakdown.
VPC_METADATA_BY_ID = """
    WITH vpc AS (
        SELECT *
        FROM cost.aws_vpc_metadata FINAL
        WHERE vpc_id = {vpc_id:String}
        ORDER BY version DESC
        LIMIT 1
    ),
    eni_costs AS (
        SELECT sum(sc.cost_unblended) AS total_cost
        FROM cost.service_costs sc FINAL
        JOIN cost.aws_eni_metadata e FINAL
            ON splitByChar('/', sc.resource_id)[-1] = e.eni_id
        WHERE sc.product_code = 'AmazonVPC'
          AND sc.usage_start_ts >= {start:DateTime}
          AND sc.usage_start_ts <= {end:DateTime}
          AND e.vpc_id = {vpc_id:String}
    ),
    eip_costs AS (
        SELECT sum(sc.cost_unblended) AS total_cost
        FROM cost.service_costs sc FINAL
        JOIN cost.aws_eip_metadata e FINAL
            ON splitByChar('/', sc.resource_id)[-1] = e.allocation_id
        WHERE sc.product_code = 'AmazonVPC'
          AND sc.usage_start_ts >= {start:DateTime}
          AND sc.usage_start_ts <= {end:DateTime}
          AND e.vpc_id = {vpc_id:String}
    ),
    nat_costs AS (
        -- NAT hourly charges: resource_id = arn:.../nat-xxx → joins on nat_gateway_id
        SELECT
            sumIf(sc.cost_unblended, sc.usage_type LIKE '%NatGateway-Hours%') AS nat_hourly_cost,
            sum(sc.cost_unblended)                                            AS total_cost
        FROM cost.service_costs sc FINAL
        JOIN cost.aws_nat_gateway_metadata n FINAL
            ON splitByChar('/', sc.resource_id)[-1] = n.nat_gateway_id
        WHERE sc.product_code IN ('AmazonVPC', 'AmazonEC2')
          AND sc.usage_start_ts >= {start:DateTime}
          AND sc.usage_start_ts <= {end:DateTime}
          AND n.vpc_id = {vpc_id:String}
    ),
    nat_data_costs AS (
        -- NAT data processing charges: resource_id = eni-xxx → must join through ENI metadata
        SELECT sum(sc.cost_unblended) AS nat_data_processing_cost
        FROM cost.service_costs sc FINAL
        JOIN cost.aws_eni_metadata e FINAL
            ON splitByChar('/', sc.resource_id)[-1] = e.eni_id
        WHERE sc.product_code = 'AmazonEC2'
          AND sc.usage_type LIKE '%NatGateway-Bytes%'
          AND sc.usage_start_ts >= {start:DateTime}
          AND sc.usage_start_ts <= {end:DateTime}
          AND e.vpc_id = {vpc_id:String}
    )
    SELECT
        v.*,
        COALESCE(e.total_cost, 0) + COALESCE(i.total_cost, 0) + COALESCE(n.total_cost, 0) + COALESCE(nd.nat_data_processing_cost, 0) AS total_vpc_cost_30d,
        COALESCE(n.nat_hourly_cost, 0)           AS nat_hourly_cost,
        COALESCE(nd.nat_data_processing_cost, 0) AS nat_data_processing_cost,
        COALESCE(i.total_cost, 0)                AS eip_cost
    FROM vpc v
    LEFT JOIN eni_costs e  ON 1=1
    LEFT JOIN eip_costs i  ON 1=1
    LEFT JOIN nat_costs n  ON 1=1
    LEFT JOIN nat_data_costs nd ON 1=1
"""

VPC_NAT_GATEWAYS_BY_VPC = """
    SELECT *
    FROM cost.aws_nat_gateway_metadata FINAL
    WHERE vpc_id = {vpc_id:String}
    ORDER BY age_days DESC
"""

VPC_EIPS_BY_ACCOUNT = """
    SELECT *
    FROM cost.aws_eip_metadata FINAL
    WHERE vpc_id = {vpc_id:String}
    ORDER BY is_attached ASC, public_ip ASC
"""
