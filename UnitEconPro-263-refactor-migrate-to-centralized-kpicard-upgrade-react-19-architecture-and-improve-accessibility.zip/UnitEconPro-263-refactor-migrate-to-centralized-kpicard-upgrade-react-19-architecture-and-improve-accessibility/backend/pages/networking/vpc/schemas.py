"""
VPC Response Schemas
"""
from pydantic import BaseModel
from typing import Optional, List, Dict


class VPCResourceBreakdown(BaseModel):
    network_interfaces:      int
    elastic_ips:             int
    nat_gateways:            int
    vpc_endpoints:           int
    vpn_connections:         int


class VPCCostBreakdown(BaseModel):
    public_ip_cost:          float
    nat_gateway_cost:        float
    vpc_endpoint_cost:       float
    total_vpc_cost:          float  # public_ip only (AmazonVPC product)
    total_nat_cost:          float  # NAT only (AmazonEC2 product)


class VPCSummary(BaseModel):
    total_cost:       float  # public_ip + nat combined
    vpc_only_cost:    float  # AmazonVPC product only
    nat_only_cost:    float  # AmazonEC2 NAT Gateway only
    avg_daily_cost:   float
    total_resources:  int
    resources:        VPCResourceBreakdown
    costs:            VPCCostBreakdown


class VPCTrendPoint(BaseModel):
    date: str
    cost: float


class VPCBreakdownItem(BaseModel):
    name: str
    cost: float


class VPCListItem(BaseModel):
    vpc_id:       str
    vpc_name:     str
    region:       str
    account_name: str
    account_id:   str
    total_cost:   float = 0.0


class VPCPublicIPItem(BaseModel):
    name: str
    cost: float
    ip_hours: float


# ── VPC Metadata Detail Schemas ───────────────────────────

class VPCFinancials(BaseModel):
    total_vpc_cost:             float  # accurate per-VPC cost via ENI/EIP → VPC mapping
    nat_hourly_cost:            float
    nat_data_processing_cost:   float
    eip_cost:                   float


class VPCArchitecture(BaseModel):
    cidr_block:                     str
    is_default_vpc:                 bool
    subnet_count:                   int
    public_subnet_count:            int
    private_subnet_count:           int
    isolated_subnet_count:          int
    nat_gateway_count:              int
    active_nat_gateway_count:       int
    has_s3_gateway_endpoint:        bool
    has_dynamodb_gateway_endpoint:  bool
    has_internet_gateway:           bool
    flow_logs_enabled:              bool
    vpc_endpoint_count:             int


class NATGatewayDetail(BaseModel):
    nat_gateway_id:         str
    subnet_id:              str
    availability_zone:      str
    state:                  str
    connectivity_type:      str
    elastic_ip_address:     str
    age_days:               int
    subnet_active_eni_count: int


class EIPDetail(BaseModel):
    allocation_id:          str
    public_ip:              str
    is_attached:            bool
    network_interface_id:   str


class VPCFinOpsFlag(BaseModel):
    flag:       str
    severity:   str
    evidence:   str
    reason:     str
    action:     str
    confidence: str = "HIGH"


class VPCMetadataDetail(BaseModel):
    vpc_id:                     str
    vpc_name:                   str
    region:                     str
    account_name:               str
    account_id:                 str
    financials:                 VPCFinancials
    architecture:               VPCArchitecture
    nat_gateways:               List[NATGatewayDetail]
    elastic_ips:                List[EIPDetail]
    tags:                       Dict[str, str]
    estimated_savings_potential: float
    finops_flags:               List[VPCFinOpsFlag]
    metadata_last_synced:       str
