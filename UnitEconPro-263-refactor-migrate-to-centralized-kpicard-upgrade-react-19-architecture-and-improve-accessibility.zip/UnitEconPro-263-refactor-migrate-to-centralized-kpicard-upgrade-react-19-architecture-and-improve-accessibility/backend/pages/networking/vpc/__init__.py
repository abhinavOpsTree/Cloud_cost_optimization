"""VPC (Virtual Private Cloud) Network Cost Analytics"""
