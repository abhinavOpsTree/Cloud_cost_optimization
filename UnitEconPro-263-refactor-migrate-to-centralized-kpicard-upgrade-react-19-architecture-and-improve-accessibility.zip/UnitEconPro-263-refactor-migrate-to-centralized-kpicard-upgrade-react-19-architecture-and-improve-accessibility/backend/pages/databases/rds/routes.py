"""
RDS Database Page Routes
Tier 1 – Audit-grade RDS cost analytics + FinOps metadata endpoint.
"""
import logging
from fastapi import APIRouter, HTTPException, Query
from core import database as db
from core.dependencies import DateCtx
from . import queries as q
from . import schemas

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v1/databases/rds", tags=["Databases – RDS"])


def _sentinel(val, default: float = -1.0) -> float:
    """Safe sentinel coercion. Never uses `or` — 0.0 is a valid measurement."""
    return float(val) if val is not None else default


# ══════════════════════════════════════════════════════════
# CORE ANALYTICS
# ══════════════════════════════════════════════════════════

@router.get("/summary", response_model=schemas.RDSSummary)
async def get_rds_summary(ctx: DateCtx):
    sql = q.RDS_SUMMARY.format(start=ctx.start, end=ctx.end, account_filter=ctx.account_filter)
    rows = db.query_safe(sql, ctx.params)
    if not rows:
        return schemas.RDSSummary(total_cost=0.0, avg_daily_cost=0.0, total_instances=0, total_snapshots=0, total_snapshot_cost=0.0, total_usage_hours=0.0)
    row = rows[0]
    return schemas.RDSSummary(
        total_cost=float(row.get("total_cost") or 0.0),
        avg_daily_cost=float(row.get("avg_daily_cost") or 0.0),
        total_instances=int(row.get("total_instances") or 0),
        total_snapshots=int(row.get("total_snapshots") or 0),
        total_snapshot_cost=float(row.get("total_snapshot_cost") or 0.0),
        total_usage_hours=float(row.get("total_usage_hours") or 0.0),
    )


@router.get("/instances", response_model=list[schemas.RDSInstance])
async def get_rds_instances(ctx: DateCtx):
    sql = q.RDS_TOP_INSTANCES.format(start=ctx.start, end=ctx.end, account_filter=ctx.account_filter)
    rows = db.query_safe(sql, ctx.params)
    return [
        schemas.RDSInstance(
            instance_id=r.get("instance_id") or "",
            region=r.get("region"),
            account=r.get("account"),
            instance_type=r.get("instance_type"),
            engine=r.get("engine"),
            usage_hours=float(r.get("usage_hours") or 0.0),
            total_cost=float(r.get("total_cost") or 0.0),
        )
        for r in rows
    ]


@router.get("/snapshots", response_model=list[schemas.RDSSnapshot])
async def get_rds_snapshots(ctx: DateCtx):
    """Top 50 RDS/Aurora snapshots by cost."""
    sql = q.RDS_TOP_SNAPSHOTS.format(start=ctx.start, end=ctx.end, account_filter=ctx.account_filter)
    rows = db.query_safe(sql, ctx.params)
    return [
        schemas.RDSSnapshot(
            snapshot_id=r.get("snapshot_id") or "",
            region=r.get("region"),
            account=r.get("account"),
            storage_gb=float(r.get("storage_gb") or 0.0),
            total_cost=float(r.get("total_cost") or 0.0),
            is_orphan=bool(r.get("is_orphan", True)),
        )
        for r in rows
    ]


# ══════════════════════════════════════════════════════════
# FLAG ENGINE
# ══════════════════════════════════════════════════════════

def _compute_finops_flags(meta: dict, financials: dict) -> tuple[list[schemas.RDSFinOpsFlag], float]:
    """
    12-flag engine. Evidence-backed flags only.
    Rightsizing flags require CloudWatch data (avg_cpu_pct >= 0).
    Static flags (EOL, Graviton, backup) fire without CW data.
    Aurora guard: storage flags skip if 'aurora' in engine.
    """
    flags   = []
    savings = 0.0

    engine           = meta.get("engine", "").lower()
    engine_version   = meta.get("engine_version", "")
    instance_class   = meta.get("instance_class", "")
    instance_family  = meta.get("instance_family", "")
    storage_type     = meta.get("storage_type", "")
    provisioned_iops = meta.get("provisioned_iops", 0)
    multi_az         = meta.get("multi_az", False)
    backup_days      = meta.get("backup_retention_period", 0)
    alloc_storage    = meta.get("allocated_storage_gb", 0)
    max_storage      = meta.get("max_allocated_storage_gb", 0)
    pi_enabled       = meta.get("performance_insights_enabled", False)
    pi_retention     = meta.get("performance_insights_retention", 0)
    tags             = meta.get("tags", {})
    env              = tags.get("Environment", "").lower()
    is_aurora        = "aurora" in engine
    is_serverless    = "serverless" in instance_class.lower() or engine == "aurora-serverless"

    # Use explicit float() — meta values from ClickHouse may be int -1 not float -1.0
    # Never use `or` on these — `or` treats -1.0 as truthy but 0.0 as falsy
    avg_cpu        = float(meta.get("avg_cpu_pct")        if meta.get("avg_cpu_pct")        is not None else -1.0)
    max_cpu        = float(meta.get("max_cpu_pct")        if meta.get("max_cpu_pct")        is not None else -1.0)
    avg_conn       = float(meta.get("avg_connections")    if meta.get("avg_connections")    is not None else -1.0)
    avg_read_iops  = float(meta.get("avg_read_iops")      if meta.get("avg_read_iops")      is not None else -1.0)
    avg_write_iops = float(meta.get("avg_write_iops")     if meta.get("avg_write_iops")     is not None else -1.0)
    cw_days        = int(meta.get("utilization_window_days") or 14)

    compute_cost  = float(financials.get("compute_cost") or 0.0)
    storage_cost  = float(financials.get("storage_cost") or 0.0)
    iops_cost     = float(financials.get("iops_cost")    or 0.0)
    backup_cost   = float(financials.get("backup_cost")  or 0.0)

    # 1. DOWNSIZE_CANDIDATE — requires CW evidence, skip serverless (no fixed instance to resize)
    # avg_conn removed from gate — connection poolers (HikariCP etc) hold 20+ connections
    # permanently even when zero queries run. CPU is the reliable signal.
    if not is_serverless and avg_cpu >= 0 and avg_cpu < 10 and max_cpu < 50:
        conn_str    = f"avg_connections={avg_conn:.1f}" if avg_conn >= 0 else "avg_connections=N/A"
        conn_reason = f" and {avg_conn:.1f} connections" if avg_conn >= 0 else ""
        compute_saving = round(compute_cost * 0.50, 2)
        savings += compute_saving
        flags.append(schemas.RDSFinOpsFlag(
            flag="DOWNSIZE_CANDIDATE", severity="HIGH",
            evidence=f"avg_cpu={avg_cpu:.1f}%, max_cpu={max_cpu:.1f}%, {conn_str} over {cw_days} days",
            reason=(f"{instance_class} averaging {avg_cpu:.1f}% CPU{conn_reason}. "
                    f"Peak CPU never exceeded {max_cpu:.1f}%. Safe to downsize one size — saves ~${compute_saving}/month."),
            action="Resize one instance class down during next maintenance window. Monitor for 7 days post-change.",
            confidence="HIGH",
        ))

    # 2. GRAVITON_MIGRATION_CANDIDATE — static, no CW needed, skip serverless (no instance class to change)
    if not is_serverless and instance_family and instance_family not in q.GRAVITON_FAMILIES:
        graviton_saving = round(compute_cost * 0.12, 2)
        savings += graviton_saving
        # Correct Graviton target per family — t7g does not exist, burstable Graviton is t4g
        _graviton_target = {
            "r3": "r7g", "r4": "r7g", "r5": "r7g", "r6i": "r7g",
            "m3": "m7g", "m4": "m7g", "m5": "m7g", "m6i": "m7g",
            "t2": "t4g", "t3": "t4g",
            "c4": "c7g", "c5": "c7g", "c6i": "c7g",
            "x1": "x2g", "x1e": "x2g",
        }
        target_family = _graviton_target.get(instance_family, instance_family[0] + "7g")
        flags.append(schemas.RDSFinOpsFlag(
            flag="GRAVITON_MIGRATION_CANDIDATE", severity="HIGH",
            evidence=f"instance_family={instance_family} (Intel/AMD x86)",
            reason=(f"{instance_family} family is Intel/AMD. Graviton equivalent is 10-15% cheaper "
                    f"with better performance. Zero code changes for managed RDS. Estimated saving: ~${graviton_saving}/month."),
            action=f"Modify instance class to Graviton equivalent (e.g. {instance_class.replace(instance_family, target_family)}) during next maintenance window.",
            confidence="HIGH",
        ))

    # 3. UPGRADE_STORAGE_TO_GP3 — Aurora guard
    if not is_aurora and storage_type in ["gp2", "io1", "io2"]:
        storage_saving = round(storage_cost * 0.25, 2)
        savings += storage_saving
        flags.append(schemas.RDSFinOpsFlag(
            flag="UPGRADE_STORAGE_TO_GP3", severity="HIGH",
            evidence=f"storage_type={storage_type}, allocated_storage_gb={alloc_storage}",
            reason=(f"Storage is {storage_type}. GP3 delivers equivalent performance at ~25% lower cost. "
                    f"Estimated saving: ~${storage_saving}/month."),
            action="Modify storage type to gp3 via modify-db-instance. No downtime required.",
            confidence="HIGH",
        ))

    # 4. OVERPROVISION_IOPS — requires CW evidence
    if (not is_aurora and storage_type in ["io1", "io2"] and provisioned_iops > 3000
            and avg_read_iops >= 0 and avg_write_iops >= 0):
        actual_iops   = avg_read_iops + avg_write_iops
        iops_util_pct = (actual_iops / provisioned_iops * 100) if provisioned_iops > 0 else 0
        if iops_util_pct < 40:
            iops_saving = round(iops_cost * 0.60, 2)
            savings += iops_saving
            flags.append(schemas.RDSFinOpsFlag(
                flag="OVERPROVISION_IOPS", severity="HIGH",
                evidence=(f"provisioned_iops={provisioned_iops}, avg_read_iops={avg_read_iops:.0f}, "
                          f"avg_write_iops={avg_write_iops:.0f}, utilization={iops_util_pct:.1f}%"),
                reason=(f"{provisioned_iops} IOPS provisioned. Actual usage is {actual_iops:.0f} combined IOPS "
                        f"({iops_util_pct:.1f}% utilization). Paying ~${iops_cost}/month for mostly unused IOPS."),
                action="Migrate storage to gp3. GP3 baseline includes 3,000 IOPS free. If more needed, provision on gp3 at $0.02/IOPS vs $0.065/IOPS on io1.",
                confidence="HIGH",
            ))

    # 5. EOL_ENGINE_VERSION — static
    is_eol = any(engine_version.startswith(p) for p in q.EOL_VERSIONS.get(engine, []))
    if is_eol:
        flags.append(schemas.RDSFinOpsFlag(
            flag="EOL_ENGINE_VERSION", severity="HIGH",
            evidence=f"engine={engine}, engine_version={engine_version}",
            reason=(f"{engine} {engine_version} is in AWS Extended Support. "
                    f"Extended Support charges $0.10-$0.20/vCPU/hr on top of instance cost."),
            action="Upgrade to latest stable engine version. Snapshot first. Test in staging.",
            confidence="HIGH",
        ))

    # 6. MULTI_AZ_DEV_WASTE — static
    if multi_az and env in ["dev", "development", "staging", "stage", "test", "qa"]:
        multi_az_saving = round((compute_cost + storage_cost) * 0.50, 2)
        savings += multi_az_saving
        flags.append(schemas.RDSFinOpsFlag(
            flag="MULTI_AZ_DEV_WASTE", severity="HIGH",
            evidence=f"multi_az=true, environment_tag={env}",
            reason=(f"Multi-AZ is enabled on a {env} environment. Multi-AZ doubles compute and storage cost. "
                    f"Estimated saving: ~${multi_az_saving}/month."),
            action="Disable Multi-AZ for non-production databases. Requires a brief failover and instance restart.",
            confidence="HIGH",
        ))

    # 7. IDLE_DB_RESTART_RISK — requires CW evidence
    if avg_conn >= 0 and avg_conn < 3 and avg_cpu >= 0 and avg_cpu < 2:
        flags.append(schemas.RDSFinOpsFlag(
            flag="IDLE_DB_RESTART_RISK", severity="MEDIUM",
            evidence=f"avg_connections={avg_conn:.1f}, avg_cpu={avg_cpu:.1f}% over {cw_days} days",
            reason=(f"Near-zero connections and CPU for {cw_days} days. "
                    f"WARNING: AWS automatically restarts stopped RDS instances after 7 days."),
            action="Verify if this database is actively needed. If not, create a final snapshot and DELETE the instance.",
            confidence="MEDIUM",
        ))

    # 8. EXCESS_BACKUP_RETENTION — static
    if backup_days > 14:
        # AWS free tier = 1x allocated storage total.
        # Each extra day beyond 14 ≈ 5% of allocated storage in incremental backup size.
        # Actual savings depend on DB churn rate — this is an estimate.
        recommended_days  = 14
        excess_days       = backup_days - recommended_days
        estimated_extra_gb = alloc_storage * 0.05 * excess_days
        backup_saving     = round(estimated_extra_gb * 0.095, 2)
        savings          += backup_saving
        flags.append(schemas.RDSFinOpsFlag(
            flag="EXCESS_BACKUP_RETENTION", severity="MEDIUM",
            evidence=f"backup_retention_period={backup_days}, allocated_storage_gb={alloc_storage}",
            reason=(f"{backup_days}-day retention. Reducing to {recommended_days} days could save "
                    f"~${backup_saving}/month (estimate based on 5%/day churn rate). "
                    f"Actual savings depend on your DB change rate."),
            action="Reduce backup retention to 7-14 days. Use AWS Backup + S3 Glacier for long-term archival at $0.004/GB.",
            confidence="MEDIUM",
        ))

    # 9. PERFORMANCE_INSIGHTS_COST — static
    if pi_enabled and pi_retention > 7:
        flags.append(schemas.RDSFinOpsFlag(
            flag="PERFORMANCE_INSIGHTS_COST", severity="MEDIUM",
            evidence=f"performance_insights_retention={pi_retention} days",
            reason=(f"Performance Insights retention is {pi_retention} days. "
                    f"First 7 days are free. {pi_retention - 7} paid days billed per vCPU per month."),
            action="Reduce PI retention to 7 days (free tier) unless long-term query analysis is actively used.",
            confidence="HIGH",
        ))

    # 10. STORAGE_AUTOSCALING_RISK — static
    if max_storage > 0:
        flags.append(schemas.RDSFinOpsFlag(
            flag="STORAGE_AUTOSCALING_RISK", severity="LOW",
            evidence=f"max_allocated_storage_gb={max_storage}, allocated_storage_gb={alloc_storage}",
            reason=(f"Storage autoscaling enabled with ceiling of {max_storage}GB. "
                    f"Storage can silently grow from {alloc_storage}GB to {max_storage}GB without approval."),
            action="Set a cost alert on RDS storage. Verify the autoscaling ceiling is intentional.",
            confidence="MEDIUM",
        ))

    # 11. PUBLICLY_ACCESSIBLE — static
    if meta.get("publicly_accessible", False):
        flags.append(schemas.RDSFinOpsFlag(
            flag="PUBLICLY_ACCESSIBLE", severity="HIGH",
            evidence="publicly_accessible=true",
            reason="Database is publicly accessible. Security risk and potential data transfer costs.",
            action="Disable public accessibility. Ensure application connects via VPC internal networking.",
            confidence="HIGH",
        ))

    # 12. MISSING_COST_TAG — static
    required = {"Environment", "Owner"}
    if not required.issubset(set(tags.keys())):
        missing = list(required - set(tags.keys()))
        flags.append(schemas.RDSFinOpsFlag(
            flag="MISSING_COST_TAG", severity="LOW",
            evidence=f"missing_tags={missing}",
            reason=f"Tags {missing} are missing. Prevents accurate cost allocation and chargeback.",
            action="Add missing tags to enable full showback and chargeback.",
            confidence="HIGH",
        ))

    return flags, round(savings, 2)


# ══════════════════════════════════════════════════════════
# METADATA ENDPOINT
# ══════════════════════════════════════════════════════════

@router.get("/instances/{db_instance_id}/metadata", response_model=schemas.RDSInstanceMetadataDetail)
async def get_rds_instance_metadata(
    db_instance_id: str,
    ctx: DateCtx,
):
    """FinOps metadata for a specific RDS instance — cost breakdown + CloudWatch utilization + flags."""
    short_id = db_instance_id.split(':')[-1] if ':' in db_instance_id else db_instance_id

    rows = db.query(
        q.RDS_INSTANCE_METADATA_BY_ID,
        params={
            "db_instance_id": short_id,
            "start":          ctx.start,
            "end":            ctx.end,
            "account_name":   ctx.account_name,
            "account_all":    1 if ctx.account_name == "All" else 0,
        }
    )

    if not rows:
        raise HTTPException(
            status_code=404,
            detail=f"RDS instance '{db_instance_id}' not found",
        )

    r = rows[0]

    financials_data = {
        "total_cost_30d":     float(r.get("total_cost_30d")     or 0.0),
        "compute_cost":       float(r.get("compute_cost")       or 0.0),
        "storage_cost":       float(r.get("storage_cost")       or 0.0),
        "iops_cost":          float(r.get("iops_cost")          or 0.0),
        "backup_cost":        float(r.get("backup_cost")        or 0.0),
        "data_transfer_cost": float(r.get("data_transfer_cost") or 0.0),
    }

    meta_flat = {
        "engine":                         r.get("engine", ""),
        "engine_version":                 r.get("engine_version", ""),
        "license_model":                  r.get("license_model", ""),
        "instance_class":                 r.get("instance_class", ""),
        "instance_family":                r.get("instance_family", ""),
        "db_instance_status":             r.get("db_instance_status", ""),
        "storage_type":                   r.get("storage_type", ""),
        "allocated_storage_gb":           int(r.get("allocated_storage_gb")     or 0),
        "max_allocated_storage_gb":       int(r.get("max_allocated_storage_gb") or 0),
        "provisioned_iops":               int(r.get("provisioned_iops")         or 0),
        "storage_throughput":             int(r.get("storage_throughput")       or 0),
        "storage_encrypted":              bool(r.get("storage_encrypted")),
        "multi_az":                       bool(r.get("multi_az")),
        "read_replica_count":             int(r.get("read_replica_count")       or 0),
        "source_db_instance_id":          r.get("source_db_instance_id", "") or "",
        "publicly_accessible":            bool(r.get("publicly_accessible")),
        "backup_retention_period":        int(r.get("backup_retention_period")  or 0),
        "backup_window":                  r.get("backup_window", ""),
        "maintenance_window":             r.get("maintenance_window", ""),
        "age_days":                       int(r.get("age_days")                 or 0),
        "deletion_protection":            bool(r.get("deletion_protection")),
        "auto_minor_version_upgrade":     bool(r.get("auto_minor_version_upgrade")),
        "performance_insights_enabled":   bool(r.get("performance_insights_enabled")),
        "performance_insights_retention": int(r.get("performance_insights_retention") or 0),
        "enhanced_monitoring_interval":   int(r.get("enhanced_monitoring_interval")   or 0),
        "ca_certificate_identifier":      r.get("ca_certificate_identifier", ""),
        "iam_db_auth_enabled":            bool(r.get("iam_db_auth_enabled")),
        "tags":                           r.get("tags") or {},
        "avg_cpu_pct":               _sentinel(r.get("avg_cpu_pct")),
        "max_cpu_pct":               _sentinel(r.get("max_cpu_pct")),
        "avg_connections":           _sentinel(r.get("avg_connections")),
        "max_connections":           _sentinel(r.get("max_connections")),
        "avg_freeable_memory_bytes": _sentinel(r.get("avg_freeable_memory_bytes")),
        "avg_read_iops":             _sentinel(r.get("avg_read_iops")),
        "avg_write_iops":            _sentinel(r.get("avg_write_iops")),
        "utilization_window_days":   int(r.get("utilization_window_days")     or 14),
    }

    finops_flags, estimated_savings_potential = _compute_finops_flags(meta_flat, financials_data)

    total = financials_data["total_cost_30d"]
    # Derive hours from actual date range — not hardcoded 720 (30 days)
    try:
        from datetime import datetime as _dt
        _start = _dt.fromisoformat(str(ctx.start))
        _end   = _dt.fromisoformat(str(ctx.end))
        _hours = max(1.0, (_end - _start).total_seconds() / 3600)
    except Exception:
        _hours = 720.0
    cost_per_hour = round(total / _hours, 4) if total > 0 else q.RDS_INSTANCE_HOURLY_PRICE.get(r.get("instance_class", ""), 0.0)

    def _fmt_dt(val):
        if val is None:
            return None
        if hasattr(val, "strftime"):
            # epoch (1970-01-01) means no metadata — treat as missing
            from datetime import datetime as _datetime
            if val <= _datetime(1970, 1, 2):
                return None
            return val.strftime("%Y-%m-%dT%H:%M:%SZ")
        return str(val) if val else None

    return schemas.RDSInstanceMetadataDetail(
        db_instance_id=r.get("db_instance_id") or db_instance_id,
        region=r.get("region") or "",
        account_name=r.get("account_name") or "",
        account_id=r.get("account_id") or "",
        availability_zone=r.get("availability_zone") or "",
        financials=schemas.RDSFinancials(**financials_data),
        metadata=schemas.RDSMetadata(
            engine=schemas.RDSEngine(
                engine=meta_flat["engine"],
                engine_version=meta_flat["engine_version"],
                license_model=meta_flat["license_model"],
                auto_minor_version_upgrade=meta_flat["auto_minor_version_upgrade"],
            ),
            compute=schemas.RDSCompute(
                instance_class=meta_flat["instance_class"],
                instance_family=meta_flat["instance_family"],
                db_instance_status=meta_flat["db_instance_status"],
            ),
            storage=schemas.RDSStorage(
                storage_type=meta_flat["storage_type"],
                allocated_storage_gb=meta_flat["allocated_storage_gb"],
                max_allocated_storage_gb=meta_flat["max_allocated_storage_gb"],
                provisioned_iops=meta_flat["provisioned_iops"],
                storage_throughput=meta_flat["storage_throughput"],
                storage_encrypted=meta_flat["storage_encrypted"],
            ),
            architecture=schemas.RDSArchitecture(
                multi_az=meta_flat["multi_az"],
                read_replica_count=meta_flat["read_replica_count"],
                source_db_instance_id=meta_flat["source_db_instance_id"],
                publicly_accessible=meta_flat["publicly_accessible"],
            ),
            backup=schemas.RDSBackup(
                backup_retention_period=meta_flat["backup_retention_period"],
                backup_window=meta_flat["backup_window"],
                maintenance_window=meta_flat["maintenance_window"],
            ),
            lifecycle=schemas.RDSLifecycle(
                instance_create_time=_fmt_dt(r.get("instance_create_time")),
                age_days=meta_flat["age_days"],
                deletion_protection=meta_flat["deletion_protection"],
            ),
            observability=schemas.RDSObservability(
                performance_insights_enabled=meta_flat["performance_insights_enabled"],
                performance_insights_retention=meta_flat["performance_insights_retention"],
                enhanced_monitoring_interval=meta_flat["enhanced_monitoring_interval"],
            ),
            security=schemas.RDSSecurity(
                storage_encrypted=meta_flat["storage_encrypted"],
                ca_certificate_identifier=meta_flat["ca_certificate_identifier"],
                iam_db_auth_enabled=meta_flat["iam_db_auth_enabled"],
                publicly_accessible=meta_flat["publicly_accessible"],
            ),
            utilization=schemas.RDSUtilization(
                avg_cpu_pct=meta_flat["avg_cpu_pct"],
                max_cpu_pct=meta_flat["max_cpu_pct"],
                avg_connections=meta_flat["avg_connections"],
                max_connections=meta_flat["max_connections"],
                avg_freeable_memory_bytes=meta_flat["avg_freeable_memory_bytes"],
                avg_read_iops=meta_flat["avg_read_iops"],
                avg_write_iops=meta_flat["avg_write_iops"],
                utilization_window_days=meta_flat["utilization_window_days"],
                utilization_last_updated=_fmt_dt(r.get("utilization_last_updated")),
            ),
            tags=meta_flat["tags"],
        ),
        cost_per_instance_hour=cost_per_hour,
        estimated_savings_potential=estimated_savings_potential,
        finops_flags=finops_flags,
        metadata_last_synced=_fmt_dt(r.get("ingested_at")) or "",
    )
