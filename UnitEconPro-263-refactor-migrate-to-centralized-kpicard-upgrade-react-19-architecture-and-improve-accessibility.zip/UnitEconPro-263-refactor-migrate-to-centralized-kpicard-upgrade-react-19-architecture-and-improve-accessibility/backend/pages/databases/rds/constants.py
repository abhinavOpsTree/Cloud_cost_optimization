"""
backend/pages/databases/rds/constants.py

Single source of truth for RDS FinOps constants shared across
queries.py, routes.py, and any future RDS modules in the backend.
"""

EOL_VERSIONS = {
    "mysql":             ["5.6", "5.7"],
    "aurora-mysql":      ["5.6", "5.7"],
    "postgres":          ["9.6", "10", "11"],
    "aurora-postgresql": ["9.6", "10", "11"],
    "mariadb":           ["10.3", "10.4", "10.5"],
    "oracle-ee":         ["12.1", "12.2"],
    "oracle-se2":        ["12.1", "12.2"],
    "sqlserver-se":      ["13.00"],
    "sqlserver-ee":      ["13.00"],
}

GRAVITON_FAMILIES = {
    "m6g", "m7g", "m8g",
    "r6g", "r7g", "r8g",
    "t4g", "x2g", "c6g", "c7g",
}

RDS_INSTANCE_HOURLY_PRICE = {
    "db.t3.micro":    0.017,
    "db.t3.small":    0.034,
    "db.t3.medium":   0.068,
    "db.t3.large":    0.136,
    "db.m5.large":    0.171,
    "db.m5.xlarge":   0.342,
    "db.m5.2xlarge":  0.684,
    "db.m6i.large":   0.171,
    "db.m6i.xlarge":  0.342,
    "db.m6g.large":   0.153,
    "db.m7g.large":   0.154,
    "db.r5.large":    0.240,
    "db.r5.xlarge":   0.480,
    "db.r5.2xlarge":  0.960,
    "db.r5.4xlarge":  1.920,
    "db.r6i.large":   0.240,
    "db.r6i.2xlarge": 0.960,
    "db.r6g.large":   0.216,
    "db.r7g.large":   0.230,
    "db.r7g.2xlarge": 0.922,
}
