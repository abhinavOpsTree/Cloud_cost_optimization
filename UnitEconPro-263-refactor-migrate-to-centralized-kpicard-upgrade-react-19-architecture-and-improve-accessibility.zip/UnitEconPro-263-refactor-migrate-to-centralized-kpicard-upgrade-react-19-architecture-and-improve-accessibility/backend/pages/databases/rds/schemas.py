"""
backend/pages/databases/rds/schemas.py
"""
from typing import Dict, List, Optional
from pydantic import BaseModel, Field


class RDSSummary(BaseModel):
    total_cost: float
    avg_daily_cost: float
    total_instances: int
    total_snapshots: int
    total_snapshot_cost: float
    total_usage_hours: float


class RDSTrendPoint(BaseModel):
    date: str
    cost: float


class RDSStoragePoint(BaseModel):
    date: str
    storage_gb: float


class RDSBreakdownItem(BaseModel):
    name: str
    cost: float
    usage: float = 0.0
    unit: str = ""


class RDSInstance(BaseModel):
    instance_id: str
    region: Optional[str] = None
    account: Optional[str] = None
    instance_type: Optional[str] = None
    engine: Optional[str] = None
    usage_hours: float
    total_cost: float


class RDSSnapshot(BaseModel):
    snapshot_id: str
    region: Optional[str] = None
    account: Optional[str] = None
    storage_gb: float
    total_cost: float
    is_orphan: bool


# ── Metadata detail schemas ───────────────────────────────

class RDSFinancials(BaseModel):
    total_cost_30d:      float
    compute_cost:        float
    storage_cost:        float
    iops_cost:           float
    backup_cost:         float
    data_transfer_cost:  float


class RDSEngine(BaseModel):
    engine:                     str
    engine_version:             str
    license_model:              str
    auto_minor_version_upgrade: bool


class RDSCompute(BaseModel):
    instance_class:     str
    instance_family:    str
    db_instance_status: str


class RDSStorage(BaseModel):
    storage_type:             str
    allocated_storage_gb:     int
    max_allocated_storage_gb: int
    provisioned_iops:         int
    storage_throughput:       int
    storage_encrypted:        bool


class RDSArchitecture(BaseModel):
    multi_az:               bool
    read_replica_count:     int
    source_db_instance_id:  str
    publicly_accessible:    bool


class RDSBackup(BaseModel):
    backup_retention_period: int
    backup_window:           str
    maintenance_window:      str


class RDSLifecycle(BaseModel):
    instance_create_time: Optional[str] = None
    age_days:             int
    deletion_protection:  bool


class RDSObservability(BaseModel):
    performance_insights_enabled:   bool
    performance_insights_retention: int
    enhanced_monitoring_interval:   int


class RDSSecurity(BaseModel):
    storage_encrypted:          bool
    ca_certificate_identifier:  str
    iam_db_auth_enabled:        bool
    publicly_accessible:        bool


class RDSUtilization(BaseModel):
    avg_cpu_pct:               float = Field(default=-1.0)
    max_cpu_pct:               float = Field(default=-1.0)
    avg_connections:           float = Field(default=-1.0)
    max_connections:           float = Field(default=-1.0)
    avg_freeable_memory_bytes: float = Field(default=-1.0)
    avg_read_iops:             float = Field(default=-1.0)
    avg_write_iops:            float = Field(default=-1.0)
    actual_iops_total:         Optional[float] = None
    iops_utilization_pct:      Optional[float] = None
    utilization_window_days:   int = 14
    utilization_last_updated:  Optional[str] = None


class RDSMetadata(BaseModel):
    engine:        RDSEngine
    compute:       RDSCompute
    storage:       RDSStorage
    architecture:  RDSArchitecture
    backup:        RDSBackup
    lifecycle:     RDSLifecycle
    observability: RDSObservability
    security:      RDSSecurity
    utilization:   RDSUtilization
    tags:          Dict[str, str] = {}


class RDSFinOpsFlag(BaseModel):
    flag:       str
    severity:   str
    evidence:   str
    reason:     str
    action:     str
    confidence: str = "HIGH"


class RDSInstanceMetadataDetail(BaseModel):
    db_instance_id:              str
    region:                      str
    account_name:                str
    account_id:                  str
    availability_zone:           str
    financials:                  RDSFinancials
    metadata:                    RDSMetadata
    cost_per_instance_hour:      float
    estimated_savings_potential: float
    finops_flags:                List[RDSFinOpsFlag]
    metadata_last_synced:        str
