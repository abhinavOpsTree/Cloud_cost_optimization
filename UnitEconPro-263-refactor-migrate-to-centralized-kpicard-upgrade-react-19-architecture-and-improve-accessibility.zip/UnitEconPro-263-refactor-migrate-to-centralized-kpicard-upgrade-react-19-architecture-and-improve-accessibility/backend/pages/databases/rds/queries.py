
RDS_SUMMARY = """
    SELECT
        ROUND(SUM(cost_unblended), 4) AS total_cost,
        CASE
            WHEN COUNT(DISTINCT toDate(usage_start_ts)) > 0
            THEN ROUND(SUM(cost_unblended) / COUNT(DISTINCT toDate(usage_start_ts)), 4)
            ELSE 0
        END AS avg_daily_cost,
        uniqExactIf(resource_id, resource_id LIKE '%:db:%') AS total_instances,
        uniqExactIf(resource_id, resource_id LIKE '%:snapshot:%' OR resource_id LIKE '%:cluster-snapshot:%') AS total_snapshots,
        ROUND(sumIf(cost_unblended, resource_id LIKE '%:snapshot:%' OR resource_id LIKE '%:cluster-snapshot:%'), 4) AS total_snapshot_cost,
        ROUND(sumIf(usage_qty, usage_type LIKE '%InstanceUsage%' OR usage_type LIKE '%Multi-AZUsage%'), 2) AS total_usage_hours
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonRDS'
      {account_filter}
"""

RDS_COST_TREND = """
    SELECT
        toDate(usage_start_ts) AS date_obj,
        formatDateTime(date_obj, '%Y-%m-%d') AS date,
        ROUND(SUM(cost_unblended), 4) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonRDS'
      {account_filter}
    GROUP BY date_obj
    ORDER BY date_obj ASC
"""

RDS_STORAGE_TREND = """
    SELECT
        toDate(usage_start_ts) AS date_obj,
        formatDateTime(date_obj, '%Y-%m-%d') AS date,
        ROUND(SUM(usage_qty), 2) AS storage_gb
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonRDS'
      AND (usage_type LIKE '%Storage%' OR usage_type LIKE '%Backup%')
      {account_filter}
    GROUP BY date_obj
    ORDER BY date_obj ASC
"""


RDS_BY_ENGINE = """
    SELECT
        CASE
            WHEN usage_type LIKE '%Aurora%' THEN 'Aurora'
            WHEN usage_type LIKE '%PostgreSQL%' THEN 'PostgreSQL'
            WHEN usage_type LIKE '%MySQL%' THEN 'MySQL'
            WHEN usage_type LIKE '%MariaDB%' THEN 'MariaDB'
            WHEN usage_type LIKE '%Oracle%' THEN 'Oracle'
            WHEN usage_type LIKE '%SQL%' THEN 'SQL Server'
            WHEN (usage_type LIKE '%Backup%' OR usage_type LIKE '%ChargedBackup%') AND resource_id = '' THEN 'RDS Backup (Unattributed)'
            ELSE 'RDS (Unknown Engine)'
        END AS name,
        ROUND(SUM(cost_unblended), 4) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}'
      AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonRDS'
      {account_filter}
    GROUP BY name
    ORDER BY cost DESC
"""

# Accurate engine breakdown via metadata JOIN.
# Uses CTE to union both instance ARNs (:db:) and cluster ARNs (:cluster:)
# so Aurora storage/backup costs billed at cluster level are correctly attributed.
# Falls back to RDS_BY_ENGINE (usage_type detection) when metadata table is empty.
RDS_BY_ENGINE_WITH_METADATA = """
    WITH cur_costs AS (
        SELECT
            splitByChar(':', resource_id)[-1]   AS short_name,
            CAST(account_id AS String)           AS account_id,
            account_name,
            cost_unblended
        FROM cost.service_costs
        WHERE product_code = 'AmazonRDS'
          AND (
              resource_id LIKE '%:db:%'
              OR resource_id LIKE '%:cluster:%'
          )
          AND resource_id NOT LIKE '%:cluster-snapshot:%'
          AND resource_id NOT LIKE '%:snapshot:%'
          AND usage_start_ts >= '{start}'
          AND usage_start_ts <= '{end}'
          {account_filter_c}
    ),
    meta_mapping AS (
        -- Instance-level costs match on db_instance_id
        -- account_filter pushed down to avoid scanning all accounts' metadata
        SELECT db_instance_id AS resource_name, account_id, engine
        FROM cost.aws_rds_metadata FINAL
        WHERE 1=1 {account_filter}
        UNION ALL
        -- Cluster-level costs (Aurora storage/backup) match on db_cluster_identifier
        SELECT db_cluster_identifier AS resource_name, account_id, engine
        FROM cost.aws_rds_metadata FINAL
        WHERE db_cluster_identifier IS NOT NULL
          AND db_cluster_identifier != ''
          {account_filter}
    )
    SELECT
        COALESCE(NULLIF(m.engine, ''), 
            CASE WHEN c.short_name = '' THEN 'RDS Backup (Unattributed)' ELSE 'RDS (Unknown/Deleted)' END
        ) AS name,
        ROUND(SUM(c.cost_unblended), 4)             AS cost
    FROM cur_costs c
    LEFT JOIN meta_mapping m
      ON c.short_name = m.resource_name
      AND c.account_id = m.account_id
    GROUP BY name
    ORDER BY cost DESC
"""

RDS_BY_INSTANCE_TYPE = """
    SELECT
        instance_type AS name,
        ROUND(SUM(cost_unblended), 4) AS cost,
        ROUND(SUM(usage_qty), 2) AS usage,
        'Hours' AS unit
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonRDS'
      AND instance_type IS NOT NULL
      AND trimBoth(instance_type) != ''
      {account_filter}
    GROUP BY instance_type
    ORDER BY cost DESC
"""

RDS_BY_REGION = """
    SELECT
        region AS name,
        ROUND(SUM(cost_unblended), 4) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonRDS'
      AND trimBoth(region) != ''
      {account_filter}
    GROUP BY region
    ORDER BY cost DESC
"""

RDS_BY_ACCOUNT = """
    SELECT
        account_name AS name,
        ROUND(SUM(cost_unblended), 4) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonRDS'
      AND account_name IS NOT NULL
      {account_filter}
    GROUP BY account_name
    ORDER BY cost DESC
"""

RDS_BY_OPERATION = """
    SELECT
        operation AS name,
        ROUND(SUM(cost_unblended), 4) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonRDS'
      AND operation IS NOT NULL
      AND trimBoth(operation) != ''
      {account_filter}
    GROUP BY operation
    ORDER BY cost DESC
"""

RDS_BY_USAGE_TYPE = """
    SELECT
        CASE
            WHEN usage_type LIKE '%Aurora%' AND usage_type LIKE '%Backup%' THEN 'Aurora Backup'
            WHEN usage_type LIKE '%Aurora%' AND usage_type LIKE '%Storage%' THEN 'Aurora Storage'
            WHEN usage_type LIKE '%Aurora%' AND usage_type LIKE '%Instance%' THEN 'Aurora Instance'
            WHEN usage_type LIKE '%Aurora%' THEN 'Aurora Other'
            WHEN usage_type LIKE '%BackupUsage%' THEN 'RDS Backup Storage'
            WHEN usage_type LIKE '%InstanceUsage%' THEN 'RDS Instance Usage'
            WHEN usage_type LIKE '%StorageUsage%' THEN 'RDS Storage'
            WHEN usage_type LIKE '%PIOPS%' THEN 'Provisioned IOPS'
            WHEN usage_type LIKE '%Multi-AZ%' THEN 'Multi-AZ'
            ELSE 'Other'
        END AS name,
        ROUND(SUM(cost_unblended), 4) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonRDS'
      {account_filter}
    GROUP BY name
    ORDER BY cost DESC
"""

RDS_BY_PRICING_MODEL = """
    SELECT
        pricing_model AS name,
        ROUND(SUM(cost_unblended), 4) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonRDS'
      AND pricing_model IS NOT NULL
      AND trimBoth(pricing_model) != ''
      {account_filter}
    GROUP BY pricing_model
    ORDER BY cost DESC
"""


RDS_TOP_INSTANCES = """
    SELECT
        resource_id AS instance_id,
        argMax(region, usage_start_ts) AS region,
        argMax(account_name, usage_start_ts) AS account,
        argMaxIf(instance_type, usage_start_ts, instance_type != '' AND trimBoth(instance_type) != '') AS instance_type,
        CASE
            WHEN argMax(usage_type, usage_start_ts) LIKE '%Aurora%'
              OR argMax(usage_type, usage_start_ts) LIKE '%aurora%' THEN 'Aurora'
            WHEN argMax(usage_type, usage_start_ts) LIKE '%PostgreSQL%' THEN 'PostgreSQL'
            WHEN argMax(usage_type, usage_start_ts) LIKE '%MySQL%' THEN 'MySQL'
            WHEN argMax(usage_type, usage_start_ts) LIKE '%MariaDB%' THEN 'MariaDB'
            WHEN argMax(usage_type, usage_start_ts) LIKE '%Oracle%' THEN 'Oracle'
            WHEN argMax(usage_type, usage_start_ts) LIKE '%SQL%' THEN 'SQL Server'
            WHEN countIf(usage_type LIKE '%Aurora%') > 0 THEN 'Aurora'
            WHEN countIf(usage_type LIKE '%PostgreSQL%') > 0 THEN 'PostgreSQL'
            WHEN countIf(usage_type LIKE '%MySQL%') > 0 THEN 'MySQL'
            WHEN countIf(usage_type LIKE '%MariaDB%') > 0 THEN 'MariaDB'
            WHEN countIf(usage_type LIKE '%Oracle%') > 0 THEN 'Oracle'
            WHEN countIf(usage_type LIKE '%SQL%') > 0 THEN 'SQL Server'
            ELSE 'RDS'
        END AS engine,
        ROUND(sumIf(usage_qty, usage_type LIKE '%InstanceUsage%' OR usage_type LIKE '%Multi-AZUsage%'), 2) AS usage_hours,
        ROUND(SUM(cost_unblended), 4) AS total_cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonRDS'
      AND resource_id LIKE '%:db:%'
      {account_filter}
    GROUP BY resource_id
    ORDER BY total_cost DESC, resource_id ASC
    LIMIT 50
"""

RDS_TOP_SNAPSHOTS = """
    WITH active_db_names AS (
        -- Extract the DB/cluster name (last segment of ARN) from all active instances.
        -- Intentionally uses a fixed 90-day lookback (not the query date range).
        -- Reason: a snapshot is orphaned if its source DB hasn't existed recently,
        -- regardless of what historical period the user is querying.
        SELECT DISTINCT splitByChar(':', resource_id)[-1] AS db_name
        FROM cost.service_costs
        WHERE product_code = 'AmazonRDS'
          AND usage_start_ts >= now() - INTERVAL 90 DAY
          AND (resource_id LIKE '%:db:%' OR resource_id LIKE '%:cluster:%')
          AND resource_id NOT LIKE '%:cluster-snapshot:%'
    )
    SELECT
        resource_id AS snapshot_id,
        argMax(region, usage_start_ts) AS region,
        argMax(account_name, usage_start_ts) AS account,
        ROUND(SUM(usage_qty), 2) AS storage_gb,
        ROUND(SUM(cost_unblended), 4) AS total_cost,
        -- Orphan: snapshot name does not match any active DB name seen in last 90 days
        NOT (splitByChar(':', resource_id)[-1] IN (SELECT db_name FROM active_db_names)) AS is_orphan
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonRDS'
      AND (
          resource_id LIKE '%:snapshot:%'
          OR resource_id LIKE '%:cluster-snapshot:%'
      )
      {account_filter}
    GROUP BY resource_id
    ORDER BY total_cost DESC
    LIMIT 50
"""


from .constants import EOL_VERSIONS, GRAVITON_FAMILIES, RDS_INSTANCE_HOURLY_PRICE

# Uses ClickHouse named params {key:Type} — call via db.query(sql, params={...}), NOT .format()
RDS_INSTANCE_METADATA_BY_ID = """
    WITH cur_costs AS (
        SELECT
            -- CUR resource_id is a full ARN: arn:aws:rds:region:account:db:name
            -- Metadata table stores short name (DBInstanceIdentifier)
            -- Extract last segment to match
            splitByChar(':', resource_id)[-1]                                           AS db_instance_id,
            sumIf(cost_unblended, position(usage_type, 'InstanceUsage') > 0
                               OR position(usage_type, 'Multi-AZUsage') > 0)            AS compute_cost,
            sumIf(cost_unblended, position(usage_type, 'StorageUsage') > 0)             AS storage_cost,
            sumIf(cost_unblended, position(usage_type, 'PIOPS') > 0)                    AS iops_cost,
            sumIf(cost_unblended, position(usage_type, 'BackupUsage') > 0)              AS backup_cost,
            sumIf(cost_unblended, position(usage_type, 'DataTransfer') > 0)             AS data_transfer_cost,
            sum(cost_unblended)                                                         AS total_cost_30d
        FROM cost.service_costs
        WHERE product_code  = 'AmazonRDS'
          AND resource_id   LIKE '%:db:%'
          AND splitByChar(':', resource_id)[-1] = {db_instance_id:String}
          AND ({account_all:UInt8} = 1 OR account_name = {account_name:String})
          AND usage_start_ts >= {start:DateTime}
          AND usage_start_ts <= {end:DateTime}
        GROUP BY splitByChar(':', resource_id)[-1]
    )
    SELECT
        coalesce(m.db_instance_id, c.db_instance_id)  AS db_instance_id,
        coalesce(m.region, '')                         AS region,
        coalesce(m.account_name, '')                   AS account_name,
        coalesce(m.account_id, '')                     AS account_id,
        coalesce(m.availability_zone, '')              AS availability_zone,
        coalesce(c.total_cost_30d,     0) AS total_cost_30d,
        coalesce(c.compute_cost,       0) AS compute_cost,
        coalesce(c.storage_cost,       0) AS storage_cost,
        coalesce(c.iops_cost,          0) AS iops_cost,
        coalesce(c.backup_cost,        0) AS backup_cost,
        coalesce(c.data_transfer_cost, 0) AS data_transfer_cost,
        coalesce(m.engine, '')                         AS engine,
        coalesce(m.engine_version, '')                 AS engine_version,
        coalesce(m.license_model, '')                  AS license_model,
        coalesce(m.auto_minor_version_upgrade, 0)      AS auto_minor_version_upgrade,
        coalesce(m.instance_class, '')                 AS instance_class,
        coalesce(m.instance_family, '')                AS instance_family,
        coalesce(m.db_instance_status, '')             AS db_instance_status,
        coalesce(m.storage_type, '')                   AS storage_type,
        coalesce(m.allocated_storage_gb, 0)            AS allocated_storage_gb,
        coalesce(m.max_allocated_storage_gb, 0)        AS max_allocated_storage_gb,
        coalesce(m.provisioned_iops, 0)                AS provisioned_iops,
        coalesce(m.storage_throughput, 0)              AS storage_throughput,
        coalesce(m.storage_encrypted, 0)               AS storage_encrypted,
        coalesce(m.multi_az, 0)                        AS multi_az,
        coalesce(m.read_replica_count, 0)              AS read_replica_count,
        coalesce(m.source_db_instance_id, '')          AS source_db_instance_id,
        coalesce(m.publicly_accessible, 0)             AS publicly_accessible,
        coalesce(m.backup_retention_period, 0)         AS backup_retention_period,
        coalesce(m.backup_window, '')                  AS backup_window,
        coalesce(m.maintenance_window, '')             AS maintenance_window,
        m.instance_create_time,
        coalesce(m.age_days, 0)                        AS age_days,
        coalesce(m.deletion_protection, 0)             AS deletion_protection,
        coalesce(m.performance_insights_enabled, 0)    AS performance_insights_enabled,
        coalesce(m.performance_insights_retention, 0)  AS performance_insights_retention,
        coalesce(m.enhanced_monitoring_interval, 0)    AS enhanced_monitoring_interval,
        coalesce(m.ca_certificate_identifier, '')      AS ca_certificate_identifier,
        coalesce(m.iam_db_auth_enabled, 0)             AS iam_db_auth_enabled,
        coalesce(m.db_subnet_group, '')                AS db_subnet_group,
        coalesce(m.tags, map())                        AS tags,
        m.avg_cpu_pct                              AS avg_cpu_pct,
        m.max_cpu_pct                              AS max_cpu_pct,
        m.avg_connections                          AS avg_connections,
        m.max_connections                          AS max_connections,
        m.avg_freeable_memory_bytes                AS avg_freeable_memory_bytes,
        m.avg_read_iops                            AS avg_read_iops,
        m.avg_write_iops                           AS avg_write_iops,
        m.utilization_window_days,
        m.utilization_last_updated,
        -- ingested_at: null when no metadata row exists — route checks for null
        if(m.db_instance_id != '', m.ingested_at, NULL) AS ingested_at
    FROM cur_costs c
    LEFT JOIN (
        SELECT *
        FROM cost.aws_rds_metadata FINAL
        WHERE db_instance_id = {db_instance_id:String}
          AND ({account_all:UInt8} = 1 OR account_name = {account_name:String})
        ORDER BY version DESC
        LIMIT 1
    ) m ON c.db_instance_id = m.db_instance_id
"""
