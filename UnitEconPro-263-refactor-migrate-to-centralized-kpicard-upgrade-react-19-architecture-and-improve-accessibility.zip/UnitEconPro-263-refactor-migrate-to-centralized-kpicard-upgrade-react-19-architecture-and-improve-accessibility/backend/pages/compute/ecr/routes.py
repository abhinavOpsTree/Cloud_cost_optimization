"""
ECR Container Registry Page Routes
Tier 1 – 100% exact, audit-grade ECR cost analytics.
"""
from typing import Optional
from fastapi import APIRouter, Depends

from core import database as db
from core.dependencies import DateCtx, date_range_params
from pages.settings.routes import get_all_thresholds
from . import queries as q
from . import schemas

router = APIRouter(prefix="/api/v1/compute/ecr", tags=["Compute – ECR"])


@router.get("/summary", response_model=schemas.ECRSummary)
async def get_ecr_summary(ctx: DateCtx):
    """6 stat cards: Total Cost, Avg Daily, Repositories, Storage GB, Storage Cost, Transfer Cost."""
    sql = q.ECR_SUMMARY.format(start=ctx.start, end=ctx.end, account_filter=ctx.account_filter)
    rows = db.query_safe(sql, ctx.params)

    if not rows:
        return schemas.ECRSummary(
            total_cost=0.0, avg_daily_cost=0.0, active_repositories=0,
            storage_cost=0.0, transfer_cost=0.0
        )

    row = rows[0]
    return schemas.ECRSummary(
        total_cost=float(row.get("total_cost") or 0),
        avg_daily_cost=float(row.get("avg_daily_cost") or 0),
        active_repositories=row.get("active_repositories") or 0,
        storage_cost=float(row.get("storage_cost") or 0),
        transfer_cost=float(row.get("transfer_cost") or 0),
    )


def _status(value: float, warn_threshold: float, error_threshold: float) -> str:
    """Assign OK / Warning / Error based on user-configured thresholds."""
    if value > error_threshold:
        return "Error"
    if value > warn_threshold:
        return "Warning"
    return "OK"


@router.get("/repositories", response_model=list[schemas.ECRRepository])
async def get_ecr_repositories(ctx: DateCtx):
    """Top 50 repositories by cost. Costs from CUR + operational metadata from ECR API snapshot."""
    sql = q.ECR_TOP_REPOSITORIES.format(start=ctx.start, end=ctx.end, account_filter=ctx.account_filter)
    rows = db.query_safe(sql, ctx.params)

    if not rows:
        return []

    # Read user-configured thresholds from the settings table
    thresholds = get_all_thresholds()

    results = []
    for r in rows:
        storage_gb = float(r.get("storage_gb") or 0)
        transfer_gb = float(r.get("transfer_gb") or 0)
        total_cost = float(r.get("total_cost") or 0)

        # Per-repo cost breakdowns — always floats from CUR sub-query, never NULL
        storage_cost = float(r.get("storage_cost") or 0)
        transfer_cost = float(r.get("transfer_cost") or 0)
        scan_cost = float(r.get("scan_cost") or 0)

        results.append(
            schemas.ECRRepository(
                repository_name=r.get("repository_name") or "",
                region=r.get("region"),
                account_name=r.get("account_name"),
                aws_account_id=str(r.get("aws_account_id")) if r.get("aws_account_id") else None,
                storage_gb=storage_gb,
                transfer_gb=transfer_gb,
                storage_cost=storage_cost,
                transfer_cost=transfer_cost,
                scan_cost=scan_cost,
                total_cost=total_cost,
                cost_status=_status(total_cost, thresholds.ecr_cost_warning, thresholds.ecr_cost_error),
                storage_status=_status(storage_gb, thresholds.ecr_storage_warning, thresholds.ecr_storage_error),
                transfer_status=_status(transfer_gb, thresholds.ecr_transfer_warning, thresholds.ecr_transfer_error),
            )
        )
    return results


@router.get("/repositories/{repository_name:path}/metadata", response_model=schemas.ECRRepositoryMetadata)
async def get_ecr_repository_metadata(
    repository_name: str,
    ctx: DateCtx
):
    """Operational metadata merged with cost fields for a specific repo."""
    
    sql = q.ECR_REPOSITORY_METADATA.format(
        start=ctx.start,
        end=ctx.end,
        account_filter=ctx.account_filter
    )
    params = {"repository_name": repository_name, **ctx.params}

    rows = db.query(sql, params=params)

    if not rows:
        # Return an empty schema instead of None (JSON null). 
        # This allows the frontend to distinguish "metadata pending/syncing" from "API broke".
        return schemas.ECRRepositoryMetadata(
            repository_name=repository_name,
            storage_gb=0.0,
            transfer_gb=0.0,
            total_cost=0.0
        )

    r = rows[0]
    thresholds = get_all_thresholds()
    
    storage_gb = float(r.get("storage_gb") or 0)
    transfer_gb = float(r.get("transfer_gb") or 0)
    total_cost = float(r.get("total_cost") or 0)

    lpe_raw = r.get("lifecycle_policy_enabled")
    lifecycle_policy_enabled = bool(lpe_raw) if lpe_raw is not None else None

    return schemas.ECRRepositoryMetadata(
        repository_name=r.get("repository_name") or repository_name,
        region=r.get("region"),
        account_name=r.get("account_name"),
        aws_account_id=str(r.get("aws_account_id")) if r.get("aws_account_id") else None,
        storage_gb=storage_gb,
        transfer_gb=transfer_gb,
        storage_cost=float(r.get("storage_cost") or 0),
        transfer_cost=float(r.get("transfer_cost") or 0),
        scan_cost=float(r.get("scan_cost") or 0),
        total_cost=total_cost,
        cost_status=_status(total_cost, thresholds.ecr_cost_warning, thresholds.ecr_cost_error),
        storage_status=_status(storage_gb, thresholds.ecr_storage_warning, thresholds.ecr_storage_error),
        transfer_status=_status(transfer_gb, thresholds.ecr_transfer_warning, thresholds.ecr_transfer_error),
        image_count=r.get("image_count"),
        untagged_images=r.get("untagged_images"),
        latest_push=r.get("latest_push") or None,
        critical_vulnerabilities=r.get("critical_vulnerabilities"),
        high_vulnerabilities=r.get("high_vulnerabilities"),
        lifecycle_policy_enabled=lifecycle_policy_enabled
    )

