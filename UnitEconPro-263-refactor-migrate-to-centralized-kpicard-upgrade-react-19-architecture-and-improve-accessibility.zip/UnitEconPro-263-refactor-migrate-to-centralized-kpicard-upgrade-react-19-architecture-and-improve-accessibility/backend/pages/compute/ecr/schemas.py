"""
ECR Page — Pydantic response models
"""
from pydantic import BaseModel
from typing import Optional
from datetime import datetime


class ECRSummary(BaseModel):
    total_cost: float
    avg_daily_cost: float
    active_repositories: int
    storage_cost: float
    transfer_cost: float


class ECRTrendPoint(BaseModel):
    date: str
    cost: float


class ECRStoragePoint(BaseModel):
    date: str
    storage_gb: float


class ECRBreakdownItem(BaseModel):
    name: str
    cost: float


class ECRRepository(BaseModel):
    repository_name: str
    region: Optional[str] = None
    # Renamed from 'account' → 'account_name' to be consistent with DB columns,
    # extractor, and every other part of the codebase.
    account_name: Optional[str] = None
    aws_account_id: Optional[str] = None  # For frontend composite key: aws_account_id + repository_name
    storage_gb: float
    transfer_gb: float
    # These come from CUR sub-query (not LEFT JOIN), so they are always floats
    storage_cost: float = 0.0
    transfer_cost: float = 0.0
    scan_cost: float = 0.0
    total_cost: float
    cost_status: str = "OK"
    storage_status: str = "OK"
    transfer_status: str = "OK"


class ECRRepositoryMetadata(ECRRepository):
    """Operational metadata merged with cost data for a single ECR repository"""
    image_count: Optional[int] = None
    untagged_images: Optional[int] = None
    latest_push: Optional[datetime] = None
    critical_vulnerabilities: Optional[int] = None
    high_vulnerabilities: Optional[int] = None
    lifecycle_policy_enabled: Optional[bool] = None
