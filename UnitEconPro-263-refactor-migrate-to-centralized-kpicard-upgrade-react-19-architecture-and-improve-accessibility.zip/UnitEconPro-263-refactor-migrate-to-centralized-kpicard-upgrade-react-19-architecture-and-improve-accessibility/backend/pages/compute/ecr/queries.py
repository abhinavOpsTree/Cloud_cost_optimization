"""
ECR SQL Query Templates – Tier 1 (100% exact, audit-grade)
All queries filter by product_code = 'AmazonECR' and support {start}, {end}, {account_filter}.

Usage types in CUR:
  Storage:      *TimedStorage-ByteHrs  (e.g. APS3-TimedStorage-ByteHrs)
  DataTransfer: *DataTransfer* | *AWS-Out* | *AWS-In*
  Requests:     Not present in current data
"""

ECR_SUMMARY = """
    SELECT
        ROUND(SUM(cost_unblended), 2) AS total_cost,
        CASE
            WHEN COUNT(DISTINCT toDate(usage_start_ts)) > 0
            THEN ROUND(SUM(cost_unblended) / COUNT(DISTINCT toDate(usage_start_ts)), 2)
            ELSE 0
        END AS avg_daily_cost,
        uniqExactIf(resource_id, resource_id LIKE '%:repository/%') AS active_repositories,
        ROUND(SUM(CASE WHEN usage_type LIKE '%Storage%' THEN cost_unblended ELSE 0 END), 2) AS storage_cost,
        ROUND(SUM(CASE WHEN usage_type LIKE '%DataTransfer%' OR usage_type LIKE '%AWS-Out%' OR usage_type LIKE '%AWS-In%' THEN cost_unblended ELSE 0 END), 2) AS transfer_cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonECR'
      {account_filter}
"""

ECR_COST_TREND = """
    SELECT
        toDate(usage_start_ts) AS date_obj,
        formatDateTime(date_obj, '%Y-%m-%d') AS date,
        ROUND(SUM(cost_unblended), 2) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonECR'
      {account_filter}
    GROUP BY date_obj
    ORDER BY date_obj ASC
"""

ECR_STORAGE_TREND = """
    SELECT
        toDate(usage_start_ts) AS date_obj,
        formatDateTime(date_obj, '%Y-%m-%d') AS date,
        -- usage_qty is in GB-months per day (~actual_GB / 30.44).
        -- Multiply by 30.44 to recover the actual GB stored that day.
        ROUND(SUM(usage_qty) * 30.44, 2) AS storage_gb
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonECR'
      AND usage_type LIKE '%Storage%'
      {account_filter}
    GROUP BY date_obj
    ORDER BY date_obj ASC
"""

ECR_BY_USAGE_TYPE = """
    SELECT
        CASE
            WHEN usage_type LIKE '%Storage%' THEN 'Storage'
            WHEN usage_type LIKE '%DataTransfer%' OR usage_type LIKE '%AWS-Out%' OR usage_type LIKE '%AWS-In%' THEN 'Data Transfer'
            ELSE 'Other'
        END AS name,
        ROUND(SUM(cost_unblended), 2) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonECR'
      {account_filter}
    GROUP BY name
    ORDER BY cost DESC
"""

ECR_BY_REGION = """
    SELECT
        region AS name,
        ROUND(SUM(cost_unblended), 2) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonECR'
      AND trimBoth(region) != ''
      {account_filter}
    GROUP BY region
    ORDER BY cost DESC
"""

ECR_BY_ACCOUNT = """
    SELECT
        account_name AS name,
        ROUND(SUM(cost_unblended), 2) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonECR'
      AND account_name IS NOT NULL
      {account_filter}
    GROUP BY account_name
    ORDER BY cost DESC
"""

ECR_TOP_REPOSITORIES = """
    SELECT
        substring(resource_id, position(resource_id, ':repository/') + 12) AS repository_name,
        argMax(region, usage_start_ts)       AS region,
        argMax(account_name, usage_start_ts) AS account_name,
        argMax(account_id, usage_start_ts)   AS aws_account_id,
        ROUND(
            SUM(CASE WHEN usage_type LIKE '%Storage%' THEN usage_qty ELSE 0 END)
            / NULLIF(COUNT(DISTINCT toDate(usage_start_ts)), 0)
            * 30.44, 2
        ) AS storage_gb,
        ROUND(SUM(CASE WHEN usage_type LIKE '%DataTransfer%' OR usage_type LIKE '%AWS-Out%' OR usage_type LIKE '%AWS-In%' THEN usage_qty ELSE 0 END), 2) AS transfer_gb,
        ROUND(SUM(CASE WHEN usage_type LIKE '%Storage%' THEN cost_unblended ELSE 0 END), 2) AS storage_cost,
        ROUND(SUM(CASE WHEN usage_type LIKE '%DataTransfer%' OR usage_type LIKE '%AWS-Out%' OR usage_type LIKE '%AWS-In%' THEN cost_unblended ELSE 0 END), 2) AS transfer_cost,
        ROUND(SUM(CASE WHEN usage_type LIKE '%Scan%' THEN cost_unblended ELSE 0 END), 2) AS scan_cost,
        ROUND(SUM(cost_unblended), 2)        AS total_cost
    FROM (
        SELECT *
        FROM cost.service_costs
        WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
          AND product_code = 'AmazonECR'
          AND resource_id LIKE '%:repository/%'
          {account_filter}
    )
    GROUP BY resource_id
    ORDER BY total_cost DESC
    LIMIT 50
"""

ECR_REPOSITORY_METADATA = """
    SELECT
        c.repository_name,
        c._final_region AS region,
        c._final_account_name AS account_name,
        c.aws_account_id,
        c.storage_gb,
        c.transfer_gb,
        c.storage_cost,
        c.transfer_cost,
        c.scan_cost,
        c.total_cost,
        m.image_count,
        m.untagged_images,
        m.latest_push,
        m.critical_vulnerabilities,
        m.high_vulnerabilities,
        m.lifecycle_policy_enabled
    FROM (
        SELECT
            substring(resource_id, position(resource_id, ':repository/') + 12) AS repository_name,
            argMax(region, usage_start_ts)       AS _final_region,
            argMax(account_name, usage_start_ts) AS _final_account_name,
            argMax(account_id, usage_start_ts)   AS aws_account_id,
            ROUND(SUM(CASE WHEN usage_type LIKE '%Storage%' THEN usage_qty ELSE 0 END) / NULLIF(COUNT(DISTINCT toDate(usage_start_ts)), 0), 2) AS storage_gb,
            ROUND(SUM(CASE WHEN usage_type LIKE '%DataTransfer%' OR usage_type LIKE '%AWS-Out%' OR usage_type LIKE '%AWS-In%' THEN usage_qty ELSE 0 END), 2) AS transfer_gb,
            ROUND(SUM(CASE WHEN usage_type LIKE '%Storage%' THEN cost_unblended ELSE 0 END), 2) AS storage_cost,
            ROUND(SUM(CASE WHEN usage_type LIKE '%DataTransfer%' OR usage_type LIKE '%AWS-Out%' OR usage_type LIKE '%AWS-In%' THEN cost_unblended ELSE 0 END), 2) AS transfer_cost,
            ROUND(SUM(CASE WHEN usage_type LIKE '%Scan%' THEN cost_unblended ELSE 0 END), 2) AS scan_cost,
            ROUND(SUM(cost_unblended), 2)        AS total_cost
        FROM cost.service_costs
        WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
          AND product_code = 'AmazonECR'
          AND resource_id LIKE concat('%:repository/', {{repository_name:String}})
          {account_filter}
        GROUP BY resource_id
    ) AS c
    LEFT JOIN (
        SELECT
            repository_name,
            account_name,
            region,
            image_count,
            untagged_images,
            latest_push,
            critical_vulnerabilities,
            high_vulnerabilities,
            lifecycle_policy_enabled
        FROM cost.aws_ecr_metadata FINAL
        WHERE repository_name = {{repository_name:String}}
    ) AS m
        ON  c.repository_name              = m.repository_name
        AND lower(trim(c._final_account_name))   = lower(trim(m.account_name))
        AND lower(trim(c._final_region))         = lower(trim(m.region))
"""

