"""
ECS Elastic Container Service Page Routes
Tier 1 – 100% exact, audit-grade ECS cluster cost analytics.
"""
from fastapi import APIRouter
from core import database as db
from core.dependencies import DateCtx
from . import queries as q
from . import schemas

router = APIRouter(prefix="/api/v1/compute/ecs", tags=["Compute – ECS"])


def _f(row: dict, key: str, fallback: float = 0.0) -> float:
    try:
        v = row.get(key)
        return float(v) if v is not None else fallback
    except (TypeError, ValueError):
        return fallback

@router.get("/summary", response_model=schemas.ECSSummary)
async def get_ecs_summary(ctx: DateCtx):
    """6 stat cards: Total Cost, Avg Daily, Total Clusters, Fargate vCPU-Hours, Fargate GB-Hours, Fargate vs EC2 Cost."""
    sql = q.ECS_SUMMARY.format(start=ctx.start, end=ctx.end, account_filter=ctx.account_filter)
    rows = db.query_safe(sql, ctx.params)
    if not rows:
        return schemas.ECSSummary(
            total_cost=0.0, avg_daily_cost=0.0, total_clusters=0,
            fargate_cost=0.0, ec2_launch_type_cost=0.0, data_transfer_cost=0.0,
        )
    r = rows[0]
    return schemas.ECSSummary(
        total_cost=           _f(r, "total_cost"),
        avg_daily_cost=       _f(r, "avg_daily_cost"),
        total_clusters=       int(r.get("total_clusters") or 0),
        fargate_cost=         _f(r, "fargate_cost"),
        ec2_launch_type_cost= _f(r, "ec2_launch_type_cost"),
        data_transfer_cost=   _f(r, "data_transfer_cost"),
    )


@router.get("/clusters", response_model=list[schemas.ECSCluster])
async def get_ecs_clusters(ctx: DateCtx):
    """Top 50 ECS clusters by total cost. Includes Fargate/EC2 cost split."""
    sql = q.ECS_TOP_CLUSTERS.format(start=ctx.start, end=ctx.end, account_filter=ctx.account_filter)
    rows = db.query_safe(sql, ctx.params)
    return [
        schemas.ECSCluster(
            cluster_name=         r.get("cluster_name") or "",
            region=               r.get("region"),
            account_name=         r.get("account_name"),
            aws_account_id=       r.get("aws_account_id"),
            fargate_cost=         _f(r, "fargate_cost"),
            ec2_launch_type_cost= _f(r, "ec2_launch_type_cost"),
            data_transfer_cost=   _f(r, "data_transfer_cost"),
            total_cost=           _f(r, "total_cost"),
        )
        for r in rows
    ]


@router.get("/clusters/{cluster_name:path}/metadata", response_model=schemas.ECSClusterMetadata)
async def get_ecs_cluster_metadata(cluster_name: str, ctx: DateCtx):
    """Operational metadata merged with cost fields for a specific ECS cluster."""
    sql = q.ECS_CLUSTER_METADATA.format(
        start=ctx.start, end=ctx.end, account_filter=ctx.account_filter,
    )
    rows = db.query(sql, params={"cluster_name": cluster_name, **ctx.params})

    if not rows:
        return schemas.ECSClusterMetadata(
            cluster_name=cluster_name,
            fargate_cost=0.0, ec2_launch_type_cost=0.0, data_transfer_cost=0.0, total_cost=0.0,
        )

    r = rows[0]
    total_cost = _f(r, "total_cost")
    return schemas.ECSClusterMetadata(
        cluster_name=                  r.get("cluster_name") or cluster_name,
        region=                        r.get("region"),
        account_name=                  r.get("account_name"),
        aws_account_id=                r.get("aws_account_id"),
        fargate_cost=                  _f(r, "fargate_cost"),
        ec2_launch_type_cost=          _f(r, "ec2_launch_type_cost"),
        data_transfer_cost=            _f(r, "data_transfer_cost"),
        total_cost=                    total_cost,
        cluster_status=                r.get("cluster_status"),
        active_services_count=         r.get("active_services_count"),
        running_tasks_count=           r.get("running_tasks_count"),
        pending_tasks_count=           r.get("pending_tasks_count"),
        registered_container_instances=r.get("registered_container_instances"),
        fargate_task_count=            r.get("fargate_task_count"),
        ec2_task_count=                r.get("ec2_task_count"),
        has_fargate_spot=              bool(r["has_fargate_spot"]) if r.get("has_fargate_spot") is not None else None,
        capacity_providers=            r.get("capacity_providers") or [],
        default_capacity_provider=     r.get("default_capacity_provider"),
        metadata_last_synced=          r.get("metadata_last_synced"),
    )
