"""
ECS SQL Query Templates – Tier 1 (100% exact, audit-grade)
All queries filter by product_code = 'AmazonECS' and support {start}, {end}, {account_filter}.
"""

ECS_SUMMARY = """
    SELECT
        ROUND(SUM(cost_unblended), 2) AS total_cost,
        CASE
            WHEN COUNT(DISTINCT toDate(usage_start_ts)) > 0
            THEN ROUND(SUM(cost_unblended) / COUNT(DISTINCT toDate(usage_start_ts)), 2)
            ELSE 0
        END AS avg_daily_cost,
        uniqExactIf(
            COALESCE(
                nullIf(splitByString('/', splitByString(':task/', resource_id)[2])[1], ''),
                nullIf(splitByString('/', splitByString(':cluster/', resource_id)[2])[1], '')
            ),
            resource_id LIKE '%:task/%' OR resource_id LIKE '%:cluster/%'
        ) AS total_clusters,
        ROUND(SUM(CASE WHEN usage_type LIKE '%Fargate%' OR usage_type LIKE '%EphemeralStorage%' THEN cost_unblended ELSE 0 END), 2) AS fargate_cost,
        ROUND(SUM(CASE WHEN usage_type LIKE '%ECS-TaskHours%' THEN cost_unblended ELSE 0 END), 2) AS ec2_launch_type_cost,
        ROUND(SUM(CASE WHEN usage_type LIKE '%DataTransfer%' THEN cost_unblended ELSE 0 END), 2) AS data_transfer_cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonECS'
      {account_filter}
"""

ECS_COST_TREND = """
    SELECT
        toDate(usage_start_ts) AS date_obj,
        formatDateTime(date_obj, '%Y-%m-%d') AS date,
        ROUND(SUM(cost_unblended), 2) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonECS'
      {account_filter}
    GROUP BY date_obj
    ORDER BY date_obj ASC
"""

ECS_FARGATE_TREND = """
    SELECT
        toDate(usage_start_ts) AS date_obj,
        formatDateTime(date_obj, '%Y-%m-%d') AS date,
        ROUND(SUM(CASE WHEN usage_type LIKE '%Fargate-vCPU-Hours%' THEN cost_unblended ELSE 0 END), 2) AS vcpu_cost,
        ROUND(SUM(CASE WHEN usage_type LIKE '%Fargate-GB-Hours%' THEN cost_unblended ELSE 0 END), 2) AS memory_cost,
        ROUND(SUM(CASE WHEN usage_type LIKE '%Fargate%' THEN cost_unblended ELSE 0 END), 2) AS total_fargate_cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonECS'
      {account_filter}
    GROUP BY date_obj
    ORDER BY date_obj ASC
"""

ECS_BY_ACCOUNT = """
    SELECT
        account_name AS name,
        ROUND(SUM(cost_unblended), 2) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonECS'
      AND account_name IS NOT NULL
      {account_filter}
    GROUP BY account_name
    ORDER BY cost DESC
"""

ECS_BY_REGION = """
    SELECT
        region AS name,
        ROUND(SUM(cost_unblended), 2) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonECS'
      AND trimBoth(region) != ''
      {account_filter}
    GROUP BY region
    ORDER BY cost DESC
"""

ECS_BY_LAUNCH_TYPE = """
    SELECT
        CASE
            WHEN usage_type LIKE '%Fargate%' THEN 'Fargate'
            WHEN usage_type LIKE '%ECS-TaskHours%' THEN 'External (ECS Anywhere)'
            ELSE 'EC2 Launch Type'
        END AS name,
        ROUND(SUM(cost_unblended), 2) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonECS'
      {account_filter}
    GROUP BY name
    ORDER BY cost DESC
"""

ECS_BY_USAGE_TYPE = """
    SELECT
        usage_type AS name,
        ROUND(SUM(cost_unblended), 2) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonECS'
      AND trimBoth(usage_type) != ''
      {account_filter}
    GROUP BY usage_type
    ORDER BY cost DESC
"""

ECS_BY_PRICING_MODEL = """
    SELECT
        COALESCE(nullIf(trim(pricing_model), ''), 'OnDemand') AS name,
        ROUND(SUM(cost_unblended), 2) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonECS'
      {account_filter}
    GROUP BY name
    ORDER BY cost DESC
"""

ECS_TOP_CLUSTERS = """
    SELECT
        COALESCE(
            nullIf(splitByString('/', splitByString(':task/', resource_id)[2])[1], ''),
            nullIf(splitByString('/', splitByString(':cluster/', resource_id)[2])[1], ''),
            'unknown'
        ) AS cluster_name,
        argMax(region, usage_start_ts)       AS region,
        argMax(account_name, usage_start_ts) AS account_name,
        toString(argMax(account_id, usage_start_ts)) AS aws_account_id,
        ROUND(SUM(CASE WHEN usage_type LIKE '%Fargate%' OR usage_type LIKE '%EphemeralStorage%' THEN cost_unblended ELSE 0 END), 2) AS fargate_cost,
        ROUND(SUM(CASE WHEN usage_type NOT LIKE '%Fargate%' AND usage_type NOT LIKE '%EphemeralStorage%' AND usage_type NOT LIKE '%DataTransfer%' THEN cost_unblended ELSE 0 END), 2) AS ec2_launch_type_cost,
        ROUND(SUM(CASE WHEN usage_type LIKE '%DataTransfer%' THEN cost_unblended ELSE 0 END), 2) AS data_transfer_cost,
        ROUND(SUM(cost_unblended), 2) AS total_cost
    FROM (
        SELECT *
        FROM cost.service_costs
        WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
          AND product_code = 'AmazonECS'
          AND trimBoth(resource_id) != ''
          {account_filter}
    )
    GROUP BY cluster_name
    HAVING total_cost > 0
    ORDER BY total_cost DESC
    LIMIT 50
"""

ECS_CLUSTER_METADATA = """
    WITH cost_data AS (
        SELECT
            COALESCE(
                nullIf(splitByString('/', splitByString(':task/', resource_id)[2])[1], ''),
                nullIf(splitByString('/', splitByString(':cluster/', resource_id)[2])[1], ''),
                'unknown'
            ) AS cluster_name,
            argMax(region, usage_start_ts)       AS region,
            argMax(account_name, usage_start_ts) AS account_name,
            toString(argMax(account_id, usage_start_ts)) AS aws_account_id,
            ROUND(SUM(CASE WHEN usage_type LIKE '%Fargate%' OR usage_type LIKE '%EphemeralStorage%' THEN cost_unblended ELSE 0 END), 2) AS fargate_cost,
            ROUND(SUM(CASE WHEN usage_type NOT LIKE '%Fargate%' AND usage_type NOT LIKE '%EphemeralStorage%' AND usage_type NOT LIKE '%DataTransfer%' THEN cost_unblended ELSE 0 END), 2) AS ec2_launch_type_cost,
            ROUND(SUM(CASE WHEN usage_type LIKE '%DataTransfer%' THEN cost_unblended ELSE 0 END), 2) AS data_transfer_cost,
            ROUND(SUM(cost_unblended), 2) AS total_cost
        FROM (
            SELECT *
            FROM cost.service_costs
            WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
              AND product_code = 'AmazonECS'
              AND trimBoth(resource_id) != ''
              AND (
                  splitByString('/', splitByString(':task/', resource_id)[2])[1] = {{cluster_name:String}}
                  OR splitByString('/', splitByString(':cluster/', resource_id)[2])[1] = {{cluster_name:String}}
              )
              {account_filter}
        )
        GROUP BY cluster_name
    ),
    metadata AS (
        SELECT
            cluster_name, account_id, account_name, region,
            cluster_status, active_services_count, running_tasks_count,
            pending_tasks_count, registered_container_instances,
            fargate_task_count, ec2_task_count, has_fargate_spot,
            capacity_providers, default_capacity_provider,
            ingested_at AS metadata_last_synced
        FROM cost.aws_ecs_metadata FINAL
        WHERE cluster_name = {{cluster_name:String}}
        ORDER BY ingested_at DESC
        LIMIT 1
    )
    SELECT
        c.cluster_name, c.region, c.account_name, c.aws_account_id,
        c.fargate_cost, c.ec2_launch_type_cost, c.data_transfer_cost, c.total_cost,
        m.cluster_status, m.active_services_count, m.running_tasks_count,
        m.pending_tasks_count, m.registered_container_instances,
        m.fargate_task_count, m.ec2_task_count, m.has_fargate_spot,
        m.capacity_providers, m.default_capacity_provider, m.metadata_last_synced
    FROM cost_data c
    LEFT JOIN metadata m ON c.cluster_name = m.cluster_name
        AND c.aws_account_id = m.account_id
        AND c.region = m.region
"""
