"""
ECS Page — Pydantic response models
"""
from pydantic import BaseModel, computed_field
from typing import Optional, List
from datetime import datetime


class ECSSummary(BaseModel):
    total_cost: float
    avg_daily_cost: float
    total_clusters: int
    fargate_cost: float
    ec2_launch_type_cost: float
    data_transfer_cost: float
    data_transfer_cost: float


class ECSTrendPoint(BaseModel):
    date: str
    cost: float


class ECSFargateTrendPoint(BaseModel):
    date: str
    vcpu_cost: float
    memory_cost: float
    total_fargate_cost: float


class ECSBreakdownItem(BaseModel):
    name: str
    cost: float


class ECSCluster(BaseModel):
    cluster_name: str
    region: Optional[str] = None
    account_name: Optional[str] = None
    aws_account_id: Optional[str] = None
    fargate_cost: float = 0.0
    ec2_launch_type_cost: float = 0.0
    data_transfer_cost: float = 0.0
    total_cost: float

    @computed_field
    @property
    def launch_type(self) -> str:
        if self.fargate_cost > 0 and self.ec2_launch_type_cost == 0:
            return "Fargate"
        if self.ec2_launch_type_cost > 0 and self.fargate_cost == 0:
            return "EC2"
        if self.fargate_cost > 0 and self.ec2_launch_type_cost > 0:
            return "Mixed"
        return "Unknown"

    @computed_field
    @property
    def fargate_pct(self) -> Optional[float]:
        if self.total_cost <= 0:
            return None
        return round(self.fargate_cost / self.total_cost * 100, 1)


class ECSClusterMetadata(BaseModel):
    cluster_name: str
    region: Optional[str] = None
    account_name: Optional[str] = None
    aws_account_id: Optional[str] = None
    fargate_cost: float = 0.0
    ec2_launch_type_cost: float = 0.0
    data_transfer_cost: float = 0.0
    total_cost: float = 0.0
    cluster_status: Optional[str] = None
    active_services_count: Optional[int] = None
    running_tasks_count: Optional[int] = None
    pending_tasks_count: Optional[int] = None
    registered_container_instances: Optional[int] = None
    fargate_task_count: Optional[int] = None
    ec2_task_count: Optional[int] = None
    has_fargate_spot: Optional[bool] = None
    capacity_providers: Optional[List[str]] = None
    default_capacity_provider: Optional[str] = None
    metadata_last_synced: Optional[datetime] = None

    @computed_field
    @property
    def launch_type(self) -> str:
        if self.fargate_task_count and self.fargate_task_count > 0 and (not self.ec2_task_count or self.ec2_task_count == 0):
            return "Fargate"
        if self.ec2_task_count and self.ec2_task_count > 0 and (not self.fargate_task_count or self.fargate_task_count == 0):
            return "EC2"
        if self.fargate_task_count and self.ec2_task_count and self.fargate_task_count > 0 and self.ec2_task_count > 0:
            return "Mixed"
        if self.fargate_cost > 0 and self.ec2_launch_type_cost == 0:
            return "Fargate"
        if self.ec2_launch_type_cost > 0 and self.fargate_cost == 0:
            return "EC2"
        return "Unknown"

    @computed_field
    @property
    def fargate_pct(self) -> Optional[float]:
        if self.total_cost <= 0:
            return None
        return round(self.fargate_cost / self.total_cost * 100, 1)

    @computed_field
    @property
    def cost_flags(self) -> List[str]:
        flags: List[str] = []
        if self.pending_tasks_count and self.pending_tasks_count > 0:
            flags.append("pending_tasks_stuck")
        if self.ec2_launch_type_cost > 0 and self.fargate_cost == 0:
            flags.append("ec2_launch_type_rightsizing_opportunity")
        if self.has_fargate_spot is False and self.fargate_cost > 0:
            flags.append("fargate_spot_not_enabled")
        if self.registered_container_instances == 0 and self.ec2_launch_type_cost > 0:
            flags.append("ec2_instances_draining_or_idle")
        return flags
