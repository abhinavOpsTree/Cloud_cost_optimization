"""
EC2 Page — Pydantic response models
"""
from pydantic import BaseModel, computed_field
from typing import Optional, Dict, List
from datetime import datetime


class EC2Summary(BaseModel):
    total_cost: float
    avg_daily_cost: float
    total_instances: int


class EC2TrendPoint(BaseModel):
    date: str
    cost: float


class EC2BreakdownItem(BaseModel):
    name: str
    cost: float


class EC2Instance(BaseModel):
    instance_id: str
    instance_name: Optional[str] = None
    instance_type: Optional[str] = None
    region: Optional[str] = None
    account: Optional[str] = None
    total_cost: float
    usage_hours: float


class EC2Gap(BaseModel):
    """A contiguous period where the instance had no billing rows."""
    gap_start: str      # "2026-02-01 10:00:00"
    gap_end: str        # "2026-02-05 14:00:00"
    duration_days: float  # e.g., 4.2


class EC2LifecycleInstance(BaseModel):
    instance_id: Optional[str] = None
    instance_name: Optional[str] = None
    instance_type: Optional[str] = None
    region: Optional[str] = None
    account: Optional[str] = None
    first_seen: str
    terminated_at: Optional[str] = None
    inferred_state: Optional[str] = None
    instance_age_days: Optional[int] = None
    active_days: int
    stopped_days: int
    avg_weekday_hours: Optional[float] = None
    avg_weekend_hours: Optional[float] = None
    total_hours: float
    total_cost: float
    gaps: list[EC2Gap] = []


# ── EC2 FinOps Metadata Models ────────────────────────────────────────────────

class EC2InstanceMetadata(BaseModel):
    """FinOps metadata for one EC2 instance. All Optional — empty before first ingestion."""
    instance_id:         Optional[str]            = None
    region:              Optional[str]            = None
    availability_zone:   Optional[str]            = None
    account_name:        Optional[str]            = None
    aws_account_id:      Optional[str]            = None
    platform:            Optional[str]            = None
    architecture:        Optional[str]            = None
    last_launch_time:    Optional[str]            = None
    ebs_optimized:       Optional[bool]           = None
    detailed_monitoring: Optional[bool]           = None
    has_public_ip:       Optional[bool]           = None
    attached_ebs_count:  Optional[int]            = None
    root_volume_type:    Optional[str]            = None
    root_volume_size_gb: Optional[int]            = None
    tags:                Optional[Dict[str, str]] = None

    inferred_state:      Optional[str]            = None
    terminated_at:       Optional[str]            = None
    pricing_model:       Optional[str]            = None
    instance_type:       Optional[str]            = None
    criticality:         Optional[str]            = None
    insight:             Optional[str]            = None

    # CloudWatch free metrics (14-day window)
    cpu_avg_pct:         Optional[float]          = None
    cpu_max_pct:         Optional[float]          = None
    cpu_p95_pct:         Optional[float]          = None
    net_in_mbps:         Optional[float]          = None
    net_out_mbps:        Optional[float]          = None
    rightsizing_signal:  Optional[str]            = None
    utilization_days:    Optional[int]            = None
    utilization_updated: Optional[str]            = None

    @computed_field
    @property
    def graviton_migration_candidate(self) -> Optional[bool]:
        if self.architecture is None:
            return None
        return self.architecture == "x86_64"

    @computed_field
    @property
    def cost_flags(self) -> List[str]:
        flags = []
        if self.detailed_monitoring is True:
            flags.append("detailed_monitoring_enabled")
        if self.has_public_ip is True:
            flags.append("public_ip_cost")
        if self.root_volume_type == "gp2":
            flags.append("gp2_upgrade_available")
        if (self.inferred_state == "Stopped"
                and self.attached_ebs_count is not None and self.attached_ebs_count > 0):
            flags.append("stopped_with_ebs_cost")
        if self.platform == "windows":
            flags.append("windows_license_premium")
        return flags


class EC2CostFlagsSummary(BaseModel):
    """Cost optimisation opportunities summary — powers the opportunities panel."""
    dedicated_tenancy_count:           int   = 0
    detailed_monitoring_count:         int   = 0
    public_ip_count:                   int   = 0
    gp2_volume_count:                  int   = 0
    windows_instance_count:            int   = 0
    stopped_with_ebs_count:            int   = 0
    spot_instance_count:               int   = 0
    on_demand_instance_count:          int   = 0
    graviton_instance_count:           int   = 0
    x86_instance_count:                int   = 0
    estimated_gp2_to_gp3_savings_usd:  float = 0.0
    estimated_public_ip_cost_usd:      float = 0.0
    estimated_monitoring_savings_usd:  float = 0.0
