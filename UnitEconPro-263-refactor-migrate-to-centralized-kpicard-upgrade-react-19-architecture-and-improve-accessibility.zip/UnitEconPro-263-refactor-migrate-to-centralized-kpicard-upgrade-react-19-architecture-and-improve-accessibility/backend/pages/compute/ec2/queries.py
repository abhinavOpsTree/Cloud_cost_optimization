"""
EC2 SQL Query Templates
All queries filter by product_code = 'AmazonEC2' and support date + account filtering.
Placeholders: {start}, {end}, {account_filter}

4 targeted fixes applied after review:
  1. Division-by-zero guard in EC2_SUMMARY
  2. trimBoth(region) filter in EC2_BY_REGION
  3. argMax for EC2_TOP_INSTANCES (handles resized instances)
  4. Group by date_obj in EC2_COST_TREND
"""

EC2_SUMMARY = """
    SELECT
        ROUND(SUM(cost_unblended), 2) AS total_cost,
        CASE
            WHEN COUNT(DISTINCT toDate(usage_start_ts)) > 0
            THEN ROUND(SUM(cost_unblended) / COUNT(DISTINCT toDate(usage_start_ts)), 2)
            ELSE 0
        END AS avg_daily_cost,
        -- Only count actual EC2 instances (i-xxx); NAT gateways use ARN resource_ids
        COUNT(DISTINCT IF(resource_id LIKE 'i-%', resource_id, NULL)) AS total_instances
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonEC2'
      {account_filter}
"""

EC2_COST_TREND = """
    SELECT
        toDate(usage_start_ts) AS date_obj,
        formatDateTime(date_obj, '%Y-%m-%d') AS date,
        ROUND(SUM(cost_unblended), 2) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonEC2'
      {account_filter}
    GROUP BY date_obj
    ORDER BY date_obj ASC
"""

EC2_BY_ACCOUNT = """
    SELECT
        account_name AS name,
        ROUND(SUM(cost_unblended), 2) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonEC2'
      AND account_name IS NOT NULL
      {account_filter}
    GROUP BY account_name
    ORDER BY cost DESC
"""

EC2_BY_REGION = """
    SELECT
        region AS name,
        ROUND(SUM(cost_unblended), 2) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonEC2'
      AND trimBoth(region) != ''
      {account_filter}
    GROUP BY region
    ORDER BY cost DESC
"""

# ── Breakdown: by Availability Zone ──────────────────────
EC2_BY_AZ = """
    SELECT
        availability_zone AS name,
        ROUND(SUM(cost_unblended), 2) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonEC2'
      AND trimBoth(availability_zone) != ''
      {account_filter}
    GROUP BY availability_zone
    ORDER BY cost DESC
"""

EC2_BY_INSTANCE_FAMILY = """
    SELECT
        trim(instance_family) AS name,
        ROUND(SUM(cost_unblended), 2) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonEC2'
      AND instance_family IS NOT NULL
      AND trim(instance_family) != ''
      {account_filter}
    GROUP BY name
    ORDER BY cost DESC
"""

EC2_BY_INSTANCE_TYPE = """
    SELECT
        trim(instance_type) AS name,
        ROUND(SUM(cost_unblended), 2) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonEC2'
      AND instance_type IS NOT NULL
      AND trim(instance_type) != ''
      {account_filter}
    GROUP BY name
    ORDER BY cost DESC
"""

EC2_BY_INSTANCE_TYPE_FAMILY = """
    SELECT
        trim(instance_type_family) AS name,
        ROUND(SUM(cost_unblended), 2) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonEC2'
      AND instance_type_family IS NOT NULL
      AND trim(instance_type_family) != ''
      {account_filter}
    GROUP BY name
    ORDER BY cost DESC
"""


EC2_BY_PRICING_MODEL = """
    SELECT
        trim(pricing_model) AS name,
        ROUND(SUM(cost_unblended), 2) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonEC2'
      AND pricing_model IS NOT NULL
      AND trim(pricing_model) != ''
      {account_filter}
    GROUP BY name
    ORDER BY cost DESC
"""


# ── Lifecycle: per-instance running history + waste detection ──────────
#
# No date filter on the core lifecycle fields — first_seen, last_seen,
# active_days, stopped_days must reflect the FULL CUR history of the instance,
# not a clipped window.  A lookback_days cap keeps the query fast.
#
# Placeholders:
#   {lookback_start}   — today − lookback_days  (computed in Python, not from DateCtx)
#   {account_filter}   — optional AND account_name = '...'
#   {instance_filter}  — optional AND resource_id = 'i-xxx'
#   {limit}
EC2_LIFECYCLE = """
    SELECT
        sc.resource_id                                                                             AS instance_id,
        COALESCE(
            nullIf(argMaxIf(sc.tag_name, sc.usage_start_ts, trimBoth(coalesce(sc.tag_name, '')) != ''), ''),
            nullIf(argMax(sc.tags_map['Name'], sc.usage_start_ts), ''),
            nullIf(anyIf(m.tags['Name'], m.tags['Name'] != ''), ''),
            'Unnamed'
        ) AS instance_name,
        nullIf(argMaxIf(sc.instance_type,          sc.usage_start_ts, trimBoth(coalesce(sc.instance_type,          '')) != ''), '') AS instance_type,
        nullIf(argMaxIf(sc.region,                 sc.usage_start_ts, trimBoth(coalesce(sc.region,                 '')) != ''), '') AS region,
        nullIf(argMaxIf(sc.account_name,           sc.usage_start_ts, trimBoth(coalesce(sc.account_name,           '')) != ''), '') AS account,
        nullIf(argMaxIf(sc.pricing_model,          sc.usage_start_ts, trimBoth(coalesce(sc.pricing_model,          '')) != ''), '') AS pricing_model,
        nullIf(argMaxIf(sc.autoscaling_group_name, sc.usage_start_ts, trimBoth(coalesce(sc.autoscaling_group_name, '')) != ''), '') AS asg_name,
        toString(MIN(sc.usage_start_ts))                                                           AS first_seen,
        toString(MAX(sc.usage_end_ts))                                                             AS last_seen,
        formatDateTime(MAX(toDate(sc.usage_start_ts)), '%Y-%m-%d')                                 AS last_seen_date,
        COUNT(DISTINCT toDate(sc.usage_start_ts))                                                  AS active_days,
        greatest(
            dateDiff('day',
                toDate(MIN(sc.usage_start_ts)),
                toDate(MAX(sc.usage_start_ts))
            ) + 1 - COUNT(DISTINCT toDate(sc.usage_start_ts)),
            0
        )                                                                                          AS stopped_days,
        ROUND(SUM(IF(
            sc.usage_type LIKE '%BoxUsage%'
            OR sc.usage_type LIKE '%SpotUsage%'
            OR sc.usage_type LIKE '%HeavyUsage%'
            OR sc.usage_type LIKE '%DedicatedUsage%',
            sc.usage_qty, 0
        )), 1)                                                                                     AS total_hours,
        ROUND(SUM(sc.cost_unblended), 4)                                                          AS total_cost
    FROM cost.service_costs AS sc FINAL
    LEFT JOIN cost.aws_ec2_metadata AS m ON m.instance_id = sc.resource_id
    WHERE sc.usage_start_ts >= '{lookback_start}'
      AND sc.product_code   = 'AmazonEC2'
      AND sc.operation      LIKE 'RunInstances%'
      AND sc.resource_id    LIKE 'i-%'
      {account_filter}
      {instance_filter}
    GROUP BY sc.resource_id
    ORDER BY stopped_days DESC, total_cost DESC
    LIMIT {limit}
"""

# Variant: single-instance lookup with NO date filter.
# Safe to use without a date bound because the resource_id = '...' equality
# filter lets ClickHouse skip every row that doesn't match — full partition
# pruning still applies via the primary index on resource_id.
# Use this ONLY when instance_id is provided by the caller.
EC2_LIFECYCLE_SINGLE = """
    WITH daily AS (
        SELECT
            toDate(usage_start_ts) AS usage_date,
            toDayOfWeek(usage_date) AS dow,
            SUM(usage_qty) AS daily_hours
        FROM cost.service_costs
        WHERE product_code = 'AmazonEC2'
          AND operation LIKE 'RunInstances%'
          AND usage_type LIKE '%BoxUsage%'
          AND resource_id = {{instance_id:String}}
        GROUP BY usage_date
    )
    SELECT
        sc.resource_id                                                                             AS instance_id,
        COALESCE(
            nullIf(argMaxIf(sc.tag_name, sc.usage_start_ts, trimBoth(coalesce(sc.tag_name, '')) != ''), ''),
            nullIf(argMax(sc.tags_map['Name'], sc.usage_start_ts), ''),
            nullIf(anyIf(m.tags['Name'], m.tags['Name'] != ''), ''),
            'Unnamed'
        ) AS instance_name,
        nullIf(argMaxIf(sc.instance_type,          sc.usage_start_ts, trimBoth(coalesce(sc.instance_type,          '')) != ''), '') AS instance_type,
        nullIf(argMaxIf(sc.region,                 sc.usage_start_ts, trimBoth(coalesce(sc.region,                 '')) != ''), '') AS region,
        nullIf(argMaxIf(sc.account_name,           sc.usage_start_ts, trimBoth(coalesce(sc.account_name,           '')) != ''), '') AS account,
        nullIf(argMaxIf(sc.pricing_model,          sc.usage_start_ts, trimBoth(coalesce(sc.pricing_model,          '')) != ''), '') AS pricing_model,
        nullIf(argMaxIf(sc.autoscaling_group_name, sc.usage_start_ts, trimBoth(coalesce(sc.autoscaling_group_name, '')) != ''), '') AS asg_name,
        toString(MIN(sc.usage_start_ts))                                                           AS first_seen,
        toString(MAX(sc.usage_end_ts))                                                             AS last_seen,
        formatDateTime(MAX(toDate(sc.usage_start_ts)), '%Y-%m-%d')                                 AS last_seen_date,
        COUNT(DISTINCT toDate(sc.usage_start_ts))                                                  AS active_days,
        greatest(
            dateDiff('day',
                toDate(MIN(sc.usage_start_ts)),
                toDate(MAX(sc.usage_start_ts))
            ) + 1 - COUNT(DISTINCT toDate(sc.usage_start_ts)),
            0
        )                                                                                          AS stopped_days,
        ROUND(SUM(IF(
            sc.usage_type LIKE '%BoxUsage%'
            OR sc.usage_type LIKE '%SpotUsage%'
            OR sc.usage_type LIKE '%HeavyUsage%'
            OR sc.usage_type LIKE '%DedicatedUsage%',
            sc.usage_qty, 0
        )), 1)                                                                                     AS total_hours,
        ROUND(SUM(sc.cost_unblended), 4)                                                          AS total_cost,
        ROUND((SELECT avgIf(daily_hours, dow BETWEEN 1 AND 5) FROM daily), 1)                     AS avg_weekday_hours,
        ROUND((SELECT avgIf(daily_hours, dow IN (6, 7)) FROM daily), 1)                           AS avg_weekend_hours,
        -- Real state from metadata — ground truth
        anyIf(m.instance_state, m.instance_state != '')                                           AS instance_state
    FROM cost.service_costs AS sc FINAL
    LEFT JOIN cost.aws_ec2_metadata AS m FINAL ON m.instance_id = sc.resource_id
    WHERE sc.product_code   = 'AmazonEC2'
      AND sc.operation      LIKE 'RunInstances%'
      AND sc.resource_id    = {{instance_id:String}}
      {account_filter}
    GROUP BY sc.resource_id
    ORDER BY stopped_days DESC, total_cost DESC
    LIMIT {limit}
"""

# Active dates for one instance — bounded by lookback window (list mode)
EC2_LIFECYCLE_ACTIVE_DATES = """
    SELECT
        usage_start_ts AS start_ts,
        usage_end_ts AS end_ts
    FROM cost.service_costs
    WHERE usage_start_ts >= '{lookback_start}'
      AND product_code = 'AmazonEC2'
      AND operation    LIKE 'RunInstances%'
      AND resource_id  = {{instance_id:String}}
    ORDER BY usage_start_ts ASC
"""

# Active dates for one instance — NO date bound (single-instance mode)
EC2_LIFECYCLE_ACTIVE_DATES_FULL = """
    SELECT
        usage_start_ts AS start_ts,
        usage_end_ts AS end_ts
    FROM cost.service_costs
    WHERE product_code = 'AmazonEC2'
      AND operation    LIKE 'RunInstances%'
      AND resource_id  = {{instance_id:String}}
    ORDER BY usage_start_ts ASC
"""

EC2_TOP_INSTANCES = """
    SELECT
        sc.resource_id AS instance_id,
        COALESCE(
            nullIf(argMaxIf(sc.tag_name, sc.usage_start_ts, trimBoth(coalesce(sc.tag_name, '')) != ''), ''),
            nullIf(argMax(sc.tags_map['Name'], sc.usage_start_ts), ''),
            nullIf(anyIf(m.tags['Name'], m.tags['Name'] != ''), ''),
            'Unnamed'
        ) AS instance_name,
        nullIf(argMaxIf(sc.instance_type, sc.usage_start_ts, trimBoth(coalesce(sc.instance_type, '')) != ''), '') AS instance_type,
        nullIf(argMaxIf(sc.region,        sc.usage_start_ts, trimBoth(coalesce(sc.region,        '')) != ''), '') AS region,
        nullIf(argMaxIf(sc.account_name,  sc.usage_start_ts, trimBoth(coalesce(sc.account_name,  '')) != ''), '') AS account,
        ROUND(SUM(sc.cost_unblended), 2) AS total_cost,
        ROUND(SUM(IF(
            sc.usage_type LIKE '%BoxUsage%'
            OR sc.usage_type LIKE '%SpotUsage%'
            OR sc.usage_type LIKE '%HeavyUsage%'
            OR sc.usage_type LIKE '%DedicatedUsage%',
            sc.usage_qty, 0
        )), 2) AS usage_hours
    FROM (
        SELECT *
        FROM cost.service_costs
        WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
          AND product_code = 'AmazonEC2'
          AND resource_id LIKE 'i-%'
          {account_filter}
    ) sc
    LEFT JOIN cost.aws_ec2_metadata AS m FINAL ON m.instance_id = sc.resource_id
    GROUP BY sc.resource_id
    HAVING total_cost > 0 OR usage_hours > 0
    ORDER BY total_cost DESC
    LIMIT 50
"""

EC2_INSTANCE_STATES_BY_IDS = """
    SELECT instance_id, instance_state
    FROM cost.aws_ec2_metadata FINAL
    WHERE instance_id IN ({ids})
    LIMIT 1 BY instance_id
"""

EC2_INSTANCE_METADATA = """
    WITH meta AS (
        SELECT
            account_id, account_name, region, availability_zone, instance_id,
            instance_state, instance_lifecycle, platform, architecture, launch_time,
            tenancy, ebs_optimized, detailed_monitoring, has_public_ip,
            attached_ebs_count, root_volume_type, root_volume_size_gb, tags,
            instance_type,
            cpu_avg_pct, cpu_max_pct, cpu_p95_pct,
            net_in_mbps, net_out_mbps,
            rightsizing_signal, utilization_days,
            toString(utilization_updated) AS utilization_updated,
            ingested_at AS metadata_last_synced
        FROM cost.aws_ec2_metadata FINAL
        WHERE instance_id = {{instance_id:String}}
          {account_filter}
        ORDER BY ingested_at DESC
        LIMIT 1
    ),
    daily AS (
        SELECT
            toDate(usage_start_ts) AS usage_date,
            toDayOfWeek(usage_date) AS dow,
            SUM(usage_qty) AS daily_hours
        FROM cost.service_costs
        WHERE product_code = 'AmazonEC2'
          AND usage_type LIKE '%BoxUsage%'
          AND usage_start_ts >= '{start}'
          AND usage_start_ts <= '{end}'
          AND (resource_id = {{instance_id:String}} OR resource_id LIKE concat('%', {{instance_id:String}}))
        GROUP BY usage_date
    ),
    usage AS (
        SELECT
            uniqExactIf(usage_date, daily_hours > 0)         AS active_days,
            ROUND(avgIf(daily_hours, dow BETWEEN 1 AND 5), 1) AS avg_weekday_hours,
            ROUND(avgIf(daily_hours, dow IN (6, 7)), 1)        AS avg_weekend_hours,
            (count() = 0)                              AS no_cur_data
        FROM daily
    ),
    crit AS (
        SELECT criticality, insight
        FROM cost.ec2_criticality_view
        WHERE instance_id = {{instance_id:String}}
        LIMIT 1
    )
    SELECT
        m.*,
        u.active_days,
        u.avg_weekday_hours,
        u.avg_weekend_hours,
        u.no_cur_data,
        crit.criticality,
        crit.insight
    FROM meta m
    CROSS JOIN usage u
    LEFT JOIN crit ON 1=1
"""

EC2_BULK_METADATA = """
    WITH meta AS (
        SELECT
            account_id, account_name, region, availability_zone, instance_id,
            instance_state, instance_lifecycle, platform, architecture, launch_time,
            tenancy, ebs_optimized, detailed_monitoring, has_public_ip,
            attached_ebs_count, root_volume_type, root_volume_size_gb, tags,
            ingested_at AS metadata_last_synced
        FROM cost.aws_ec2_metadata FINAL
        WHERE (account_id = {{account_id:String}} OR {{account_id:String}} = '')
          AND (region     = {{region:String}}     OR {{region:String}}     = '')
        ORDER BY ingested_at DESC
        LIMIT 1 BY instance_id
    )
    SELECT
        m.*,
        c.active_days,
        c.avg_weekday_hours,
        c.avg_weekend_hours,
        c.no_cur_data,
        c.criticality,
        c.insight
    FROM meta m
    LEFT JOIN cost.ec2_criticality_view c ON m.instance_id = c.instance_id
"""

EC2_COST_FLAGS_SUMMARY = """
    SELECT
        countIf(tenancy NOT IN ('default', ''))           AS dedicated_tenancy_count,
        countIf(detailed_monitoring = 1)                  AS detailed_monitoring_count,
        countIf(has_public_ip = 1)                        AS public_ip_count,
        countIf(root_volume_type = 'gp2')                 AS gp2_volume_count,
        countIf(platform = 'windows')                     AS windows_instance_count,
        countIf(instance_state = 'stopped' AND attached_ebs_count > 0) AS stopped_with_ebs_count,
        countIf(instance_lifecycle = 'spot')              AS spot_instance_count,
        countIf(instance_lifecycle = 'on-demand')         AS on_demand_instance_count,
        countIf(architecture = 'arm64')                   AS graviton_instance_count,
        countIf(architecture = 'x86_64')                  AS x86_instance_count,
        ROUND(SUM(CASE WHEN root_volume_type = 'gp2' THEN root_volume_size_gb * 0.10 * 0.20 ELSE 0 END), 2)
                                                           AS estimated_gp2_to_gp3_savings_usd,
        ROUND(countIf(has_public_ip = 1) * 0.005 * 730, 2) AS estimated_public_ip_cost_usd,
        ROUND(countIf(detailed_monitoring = 1) * 3.50, 2)   AS estimated_monitoring_savings_usd
    FROM cost.aws_ec2_metadata FINAL
    WHERE (account_id = {{account_id:String}} OR {{account_id:String}} = '')
      AND (region     = {{region:String}}     OR {{region:String}}     = '')
"""
