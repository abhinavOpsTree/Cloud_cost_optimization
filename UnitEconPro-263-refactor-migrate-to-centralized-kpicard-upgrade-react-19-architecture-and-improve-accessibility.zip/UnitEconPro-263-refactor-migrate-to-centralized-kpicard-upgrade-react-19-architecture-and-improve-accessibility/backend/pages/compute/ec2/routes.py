"""
EC2 Compute Page Routes
All endpoints for the EC2 cost analytics page.
"""
from datetime import datetime, timedelta
from typing import Annotated, List, Optional

from fastapi import APIRouter, Depends, Query

from core import database as db
from core.dependencies import DateCtx, date_range_params
from . import queries as q
from . import schemas

router = APIRouter(prefix="/api/v1/compute/ec2", tags=["Compute – EC2"])


@router.get("/summary", response_model=schemas.EC2Summary)
async def get_ec2_summary(ctx: DateCtx):
    """4 stat cards: Total Cost, Avg Daily Cost, Total Instances, Usage Hours."""
    sql = q.EC2_SUMMARY.format(start=ctx.start, end=ctx.end, account_filter=ctx.account_filter)
    rows = db.query_safe(sql, ctx.params)

    if not rows:
        return schemas.EC2Summary(
            total_cost=0, avg_daily_cost=0,
            total_instances=0
        )

    row = rows[0]
    return schemas.EC2Summary(
        total_cost=float(row.get("total_cost") or 0),
        avg_daily_cost=float(row.get("avg_daily_cost") or 0),
        total_instances=row.get("total_instances") or 0,
    )


@router.get("/instances", response_model=list[schemas.EC2Instance])
async def get_ec2_instances(ctx: DateCtx):
    """Top 50 EC2 instances by cost."""
    sql = q.EC2_TOP_INSTANCES.format(start=ctx.start, end=ctx.end, account_filter=ctx.account_filter)
    rows = db.query_safe(sql, ctx.params)
    return [
        schemas.EC2Instance(
            instance_id=r.get("instance_id") or "",
            instance_name=r.get("instance_name"),
            instance_type=r.get("instance_type"),
            region=r.get("region"),
            account=r.get("account"),
            total_cost=float(r.get("total_cost") or 0),
            usage_hours=float(r.get("usage_hours") or 0),
        )
        for r in rows
    ]


@router.get("/lifecycle", response_model=list[schemas.EC2LifecycleInstance])
async def get_ec2_lifecycle(
    account: Annotated[
        str,
        Query(description="Account name to filter by, or 'All' for all accounts."),
    ] = "All",
    instance_id: Annotated[
        str | None,
        Query(description="Filter by a specific instance ID, e.g. i-0abc1234"),
    ] = None,
    include_gaps: Annotated[
        bool,
        Query(description="When true, include the list of stop periods per instance"),
    ] = False,
    lookback_days: Annotated[
        int,
        Query(ge=7, le=365, description="How many days of CUR history to scan (default 90)"),
    ] = 90,
    limit: Annotated[
        int,
        Query(ge=1, le=500, description="Max number of instances to return (default 100)"),
    ] = 100,
    state: Annotated[
        str | None,
        Query(description="Filter by inferred state: Active, Stopped, or Terminated"),
    ] = None,
):
    """
    EC2 instance lifecycle view — true launch date, real stopped_days, full gaps.

    Two modes depending on whether instance_id is supplied:

    LIST MODE (no instance_id):
      Uses `lookback_days` to bound the scan — keeps ClickHouse fast by pruning
      date partitions. Only instances with billing activity in that window appear.
      Default 90 days. Increase to 365 for deeper history.

    SINGLE-INSTANCE MODE (instance_id provided):
      Drops the date filter entirely — returns the FULL lifetime history of that
      instance from its absolute first billing row to the last. Fast because
      resource_id equality lets ClickHouse skip all other rows.

    Examples:
      /lifecycle                                      → top 100 worst offenders, last 90d
      /lifecycle?lookback_days=365                    → last year of data
      /lifecycle?instance_id=i-0abc1234&include_gaps=true  → full lifetime + all gaps
    """
    account         = " ".join(account.split())
    account_escaped = account.replace("'", "''")
    acct_filter     = "" if account == "All" else f"AND account_name = '{account_escaped}'"

    today = datetime.now().date()

    if instance_id:
        # ── Single-instance: full history, no date bound ──────────────────
        sql = q.EC2_LIFECYCLE_SINGLE.format(
            account_filter=acct_filter,
            limit=limit,
        )
        rows = db.query(sql, params={"instance_id": instance_id})

        result = []
        for r in rows:
            inferred, last_seen_date = _infer_state(r, today)
            if state and inferred != state:
                continue
            gaps: list[schemas.EC2Gap] = []
            if include_gaps:
                gaps = _detect_gaps_full(instance_id=str(r["instance_id"]))
            result.append(_build_lifecycle_row(r, gaps, inferred, last_seen_date))
        return result

    else:
        # ── List mode: bounded by lookback_days for performance ───────────
        lookback_start = (datetime.now() - timedelta(days=lookback_days)).strftime("%Y-%m-%d 00:00:00")
        sql = q.EC2_LIFECYCLE.format(
            lookback_start=lookback_start,
            account_filter=acct_filter,
            instance_filter="",
            limit=limit,
        )
        rows = db.query_safe(sql, ctx.params)

        # Cheap bulk state lookup — one IN-query for all instance_ids
        # avoids a JOIN on the large service_costs scan above
        instance_state_map = {}
        if rows:
            ids_sql = "'" + "','".join(str(r["instance_id"]) for r in rows) + "'"
            state_rows = db.query_safe(q.EC2_INSTANCE_STATES_BY_IDS.format(ids=ids_sql))
            instance_state_map = {r["instance_id"]: r["instance_state"] for r in state_rows}

        result = []
        for r in rows:
            r["instance_state"] = instance_state_map.get(str(r["instance_id"]), "")
            inferred, last_seen_date = _infer_state(r, today)
            if state and inferred != state:
                continue
            gaps: list[schemas.EC2Gap] = []
            if include_gaps:
                gaps = _detect_gaps(
                    instance_id=str(r["instance_id"]),
                    lookback_start=lookback_start,
                )
            result.append(_build_lifecycle_row(r, gaps, inferred, last_seen_date))
        return result


def _infer_state(r: dict, today) -> tuple[str, str]:
    """Return (state, last_seen_date_str) using real instance_state from metadata.
    Falls back to CUR billing recency only when metadata has no record.
    """
    raw = r.get("last_seen_date") or ""

    # Ground truth from describe_instances via aws_ec2_metadata
    real_state = (r.get("instance_state") or "").lower()
    if real_state == "running":
        return "Active", raw
    if real_state in ("stopped", "stopping"):
        return "Stopped", raw
    if real_state in ("terminated", "shutting-down"):
        return "Terminated", raw

    # Fallback: metadata not yet ingested for this instance
    days_since = (today - datetime.strptime(raw, "%Y-%m-%d").date()).days if raw else 999
    if days_since <= 2:
        return "Active", raw
    elif days_since <= 7:
        return "Stopped", raw
    else:
        return "Terminated", raw


def _build_lifecycle_row(
    r: dict,
    gaps: list[schemas.EC2Gap],
    inferred_state: str | None = None,
    last_seen_date: str | None = None,
) -> schemas.EC2LifecycleInstance:
    today = datetime.now().date()
    first_seen_str = str(r["first_seen"])
    try:
        first_date = datetime.strptime(first_seen_str[:10], "%Y-%m-%d").date()
        instance_age_days = (today - first_date).days
    except ValueError:
        instance_age_days = None

    return schemas.EC2LifecycleInstance(
        instance_id=str(r.get("instance_id") or ""),
        instance_name=r.get("instance_name"),
        instance_type=r.get("instance_type"),
        region=r.get("region"),
        account=r.get("account"),
        first_seen=first_seen_str,
        terminated_at=str(r["last_seen"]) if inferred_state == "Terminated" else None,
        inferred_state=inferred_state,
        instance_age_days=instance_age_days,
        active_days=int(r["active_days"]),
        stopped_days=int(r["stopped_days"]),
        avg_weekday_hours=round(_safe_float(r.get("avg_weekday_hours")), 1) if r.get("avg_weekday_hours") is not None else None,
        avg_weekend_hours=round(_safe_float(r.get("avg_weekend_hours")), 1) if r.get("avg_weekend_hours") is not None else None,
        total_hours=float(r["total_hours"]),
        total_cost=float(r["total_cost"]),
        gaps=gaps,
    )


def _detect_gaps_full(instance_id: str) -> list[schemas.EC2Gap]:
    """
    Full-history gap detection — no date bound.
    Used only in single-instance mode where resource_id equality keeps it fast.
    """
    sql = q.EC2_LIFECYCLE_ACTIVE_DATES_FULL.format()
    return _gaps_from_rows(db.query(sql, params={"instance_id": instance_id}))


def _detect_gaps(instance_id: str, lookback_start: str) -> list[schemas.EC2Gap]:
    """
    Bounded gap detection — used in list mode with lookback_start date filter.
    Missing day = CUR had no RunInstances row = instance was stopped.
    """
    sql = q.EC2_LIFECYCLE_ACTIVE_DATES.format(lookback_start=lookback_start)
    return _gaps_from_rows(db.query(sql, params={"instance_id": instance_id}))


def _gaps_from_rows(rows: list[dict]) -> list[schemas.EC2Gap]:
    """
    Core gap algorithm shared by both bounded and unbounded gap detection.
    Receives a list of {"start_ts": datetime, "end_ts": datetime} rows, returns contiguous gap objects.
    """
    if len(rows) < 2:
        return []

    # Sort safely by start time
    active = sorted(rows, key=lambda r: r["start_ts"])

    gaps: list[schemas.EC2Gap] = []
    current_end = active[0]["end_ts"]

    for i in range(1, len(active)):
        start = active[i]["start_ts"]
        end = active[i]["end_ts"]

        # gap threshold >= 1 hour (3600 seconds) to filter out jitter/billing slight overlaps
        gap_seconds = (start - current_end).total_seconds()
        if gap_seconds >= 3600:
            duration_days = round(gap_seconds / 86400.0, 1)
            gaps.append(schemas.EC2Gap(
                gap_start=current_end.strftime("%Y-%m-%d %H:%M:%S"),
                gap_end=start.strftime("%Y-%m-%d %H:%M:%S"),
                duration_days=duration_days,
            ))

        if end > current_end:
            current_end = end

    return gaps


# ── EC2 FinOps Metadata Endpoints ─────────────────────────────────────────────

def _to_bool(val):
    return bool(val) if val is not None else None

def _safe_float(val):
    import math
    if val is None:
        return 0.0
    try:
        f = float(val)
        return 0.0 if math.isnan(f) else f
    except (TypeError, ValueError):
        return 0.0


def _row_to_metadata(r: dict, lc: dict = None) -> schemas.EC2InstanceMetadata:
    today = datetime.now().date()
    inferred = None
    if lc:
        inferred, _ = _infer_state(lc, today)

    return schemas.EC2InstanceMetadata(
        instance_id=r.get("instance_id"),
        region=r.get("region"),
        availability_zone=r.get("availability_zone"),
        account_name=r.get("account_name"),
        aws_account_id=str(r.get("account_id")) if r.get("account_id") else None,
        platform=r.get("platform"),
        architecture=r.get("architecture"),
        last_launch_time=r.get("launch_time").strftime("%Y-%m-%d %H:%M:%S") if r.get("launch_time") else None,
        ebs_optimized=_to_bool(r.get("ebs_optimized")),
        detailed_monitoring=_to_bool(r.get("detailed_monitoring")),
        has_public_ip=_to_bool(r.get("has_public_ip")),
        attached_ebs_count=r.get("attached_ebs_count"),
        root_volume_type=r.get("root_volume_type"),
        root_volume_size_gb=r.get("root_volume_size_gb"),
        tags=r.get("tags") or {},
        inferred_state=inferred,
        terminated_at=str(lc["last_seen"]) if lc and inferred == "Terminated" else None,
        pricing_model=lc.get("pricing_model") if lc else None,
        instance_type=r.get("instance_type") or None,
        no_cur_data=_to_bool(r.get("no_cur_data")),
        criticality=r.get("criticality") or "Evaluating",
        insight=r.get("insight"),
        cpu_avg_pct=r.get("cpu_avg_pct") if r.get("cpu_avg_pct", -1) >= 0 else None,
        cpu_max_pct=r.get("cpu_max_pct") if r.get("cpu_max_pct", -1) >= 0 else None,
        cpu_p95_pct=r.get("cpu_p95_pct") if r.get("cpu_p95_pct", -1) >= 0 else None,
        net_in_mbps=r.get("net_in_mbps")  if r.get("net_in_mbps",  -1) >= 0 else None,
        net_out_mbps=r.get("net_out_mbps") if r.get("net_out_mbps", -1) >= 0 else None,
        rightsizing_signal=r.get("rightsizing_signal") or None,
        utilization_days=r.get("utilization_days") or None,
        utilization_updated=str(r.get("utilization_updated")) if r.get("utilization_updated") else None,
    )


@router.get("/instances/{instance_id}/metadata", response_model=schemas.EC2InstanceMetadata)
async def get_ec2_instance_metadata(
    instance_id: str,
    ctx: DateCtx,
):
    """FinOps metadata for a single EC2 instance."""
    sql = q.EC2_INSTANCE_METADATA.format(account_filter=ctx.account_filter, start=ctx.start, end=ctx.end)
    rows = db.query(sql, params={"instance_id": instance_id, **ctx.params})
    if not rows:
        return schemas.EC2InstanceMetadata()

    lc_sql = q.EC2_LIFECYCLE_SINGLE.format(account_filter=ctx.account_filter, limit=1)
    lc_rows = db.query(lc_sql, params={"instance_id": instance_id, **ctx.params})
    lc = lc_rows[0] if lc_rows else None

    return _row_to_metadata(rows[0], lc)
