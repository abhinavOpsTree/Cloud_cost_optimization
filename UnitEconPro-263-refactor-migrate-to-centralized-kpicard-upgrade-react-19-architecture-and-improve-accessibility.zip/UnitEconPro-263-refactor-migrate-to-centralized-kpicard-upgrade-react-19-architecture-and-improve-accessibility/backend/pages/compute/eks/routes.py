"""
EKS Kubernetes Service Page Routes
Tier 1 – 100% exact, audit-grade EKS cluster cost analytics.
"""
from fastapi import APIRouter, Depends, Query

from core import database as db
from core.dependencies import DateCtx, date_range_params
from pages.settings.routes import get_all_thresholds
from . import queries as q
from . import schemas

router = APIRouter(prefix="/api/v1/compute/eks", tags=["Compute – EKS"])


def _status(value: float, warn_threshold: float, error_threshold: float) -> str:
    """Assign OK / Warning / Error based on user-configured thresholds."""
    if value > error_threshold:
        return "Error"
    if value > warn_threshold:
        return "Warning"
    return "OK"


@router.get("/summary", response_model=schemas.EKSSummary)
async def get_eks_summary(ctx: DateCtx):
    """4 stat cards: Total Cost, Avg Daily, Total Clusters, Cluster Hours."""
    sql = q.EKS_SUMMARY.format(start=ctx.start, end=ctx.end, account_filter=ctx.account_filter)
    rows = db.query_safe(sql, ctx.params)

    if not rows:
        return schemas.EKSSummary(
            total_cost=0.0, avg_daily_cost=0.0, total_clusters=0
        )

    row = rows[0]
    return schemas.EKSSummary(
        total_cost=float(row.get("total_cost") or 0.0),
        avg_daily_cost=float(row.get("avg_daily_cost") or 0.0),
        total_clusters=int(row.get("total_clusters") or 0),
    )


@router.get("/clusters", response_model=list[schemas.EKSCluster])
async def get_eks_clusters(ctx: DateCtx):
    """Top 50 clusters by cost."""
    sql = q.EKS_TOP_CLUSTERS.format(start=ctx.start, end=ctx.end, account_filter=ctx.account_filter)
    rows = db.query_safe(sql, ctx.params)
    
    thresholds = get_all_thresholds()
    
    return [
        schemas.EKSCluster(
            cluster_name=r.get("cluster_name") or "",
            region=r.get("region"),
            account_name=r.get("account_name"),
            aws_account_id=r.get("aws_account_id"),
            cluster_hours=float(r.get("cluster_hours") or 0.0),
            total_cost=float(r.get("total_cost") or 0.0),
            cost_status=_status(
                float(r.get("total_cost") or 0.0),
                thresholds.eks_cost_warning,
                thresholds.eks_cost_error
            )
        )
        for r in rows
    ]


@router.get("/clusters/{cluster_name:path}/metadata", response_model=schemas.EKSClusterMetadata)
async def get_eks_cluster_metadata(
    cluster_name: str,
    ctx: DateCtx
):
    """Operational metadata merged with cost fields for a specific cluster."""
    
    sql = q.EKS_CLUSTER_METADATA.format(
        start=ctx.start,
        end=ctx.end,
        account_filter=ctx.account_filter
    )
    params = {"cluster_name": cluster_name, **ctx.params}

    rows = db.query(sql, params=params)

    if not rows:
        # Return an empty schema instead of None (JSON null).
        # This allows the frontend to distinguish "metadata pending/syncing" from "API broke".
        return schemas.EKSClusterMetadata(
            cluster_name=cluster_name,
            cluster_hours=0.0,
            total_cost=0.0
        )

    r = rows[0]
    thresholds = get_all_thresholds()
    
    total_cost = float(r.get("total_cost") or 0)

    return schemas.EKSClusterMetadata(
        cluster_name=r.get("cluster_name") or cluster_name,
        region=r.get("region"),
        account_name=r.get("account_name"),
        aws_account_id=r.get("aws_account_id"),
        cluster_hours=float(r.get("cluster_hours") or 0),
        total_cost=total_cost,
        cost_status=_status(total_cost, thresholds.eks_cost_warning, thresholds.eks_cost_error),
        kubernetes_version=r.get("kubernetes_version"),
        cluster_status=r.get("cluster_status"),
        nodegroup_count=r.get("nodegroup_count"),
        fargate_profiles_count=r.get("fargate_profiles_count"),
        total_nodes=r.get("total_nodes"),
        has_spot_nodes=bool(r.get("has_spot_nodes")) if r.get("has_spot_nodes") is not None else None,
        has_degraded_nodegroup=bool(r.get("has_degraded_nodegroup")) if r.get("has_degraded_nodegroup") is not None else None,
        node_instance_types=r.get("node_instance_types") or [],
        addon_count=r.get("addon_count"),
        has_degraded_addon=bool(r.get("has_degraded_addon")) if r.get("has_degraded_addon") is not None else None,
        metadata_last_synced=r.get("metadata_last_synced")
    )



