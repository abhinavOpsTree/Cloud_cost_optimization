"""
EKS Page — Pydantic response models
"""
from pydantic import BaseModel
from typing import Optional
from datetime import datetime


class EKSSummary(BaseModel):
    total_cost: float
    avg_daily_cost: float
    total_clusters: int


class EKSTrendPoint(BaseModel):
    date: str
    cost: float


class EKSBreakdownItem(BaseModel):
    name: str
    cost: float


class EKSCluster(BaseModel):
    cluster_name: str
    region: Optional[str] = None
    account_name: Optional[str] = None
    aws_account_id: Optional[str] = None
    cluster_hours: float
    total_cost: float
    cost_status: str = "OK"


class EKSClusterMetadata(BaseModel):
    """Operational metadata merged with cost fields for a single EKS cluster"""
    cluster_name: str
    region: Optional[str] = None
    account_name: Optional[str] = None
    aws_account_id: Optional[str] = None
    cluster_hours: float = 0.0
    total_cost: float = 0.0
    cost_status: str = "OK"
    kubernetes_version: Optional[str] = None
    cluster_status: Optional[str] = None
    nodegroup_count: Optional[int] = None
    fargate_profiles_count: Optional[int] = None
    total_nodes: Optional[int] = None
    has_spot_nodes: Optional[bool] = None
    has_degraded_nodegroup: Optional[bool] = None
    node_instance_types: Optional[list[str]] = None
    addon_count: Optional[int] = None
    has_degraded_addon: Optional[bool] = None
    metadata_last_synced: Optional[datetime] = None
