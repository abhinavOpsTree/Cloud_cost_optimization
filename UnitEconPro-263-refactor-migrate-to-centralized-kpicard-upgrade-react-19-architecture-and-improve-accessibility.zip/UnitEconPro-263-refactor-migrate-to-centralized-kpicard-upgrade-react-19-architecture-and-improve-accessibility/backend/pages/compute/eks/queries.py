"""
EKS SQL Query Templates – Tier 1 (100% exact, audit-grade)
All queries filter by product_code = 'AmazonEKS' and support {start}, {end}, {account_filter}.

Note: This implementation covers EKS Control Plane costs only.
Worker node costs (EC2) would require separate EC2 API queries filtered by cluster tags.
"""

EKS_SUMMARY = """
    SELECT
        ROUND(SUM(cost_unblended), 2) AS total_cost,
        CASE
            WHEN COUNT(DISTINCT toDate(usage_start_ts)) > 0
            THEN ROUND(SUM(cost_unblended) / COUNT(DISTINCT toDate(usage_start_ts)), 2)
            ELSE 0
        END AS avg_daily_cost,
        COUNT(DISTINCT resource_id) AS total_clusters
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonEKS'
      {account_filter}
"""

EKS_COST_TREND = """
    SELECT
        toDate(usage_start_ts) AS date_obj,
        formatDateTime(date_obj, '%Y-%m-%d') AS date,
        ROUND(SUM(cost_unblended), 2) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonEKS'
      {account_filter}
    GROUP BY date_obj
    ORDER BY date_obj ASC
"""

EKS_BY_CLUSTER = """
    SELECT
        splitByString('/', resource_id)[-1] AS name,
        ROUND(SUM(cost_unblended), 2) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonEKS'
      AND resource_id != ''
      {account_filter}
    GROUP BY resource_id
    ORDER BY cost DESC
"""

EKS_BY_REGION = """
    SELECT
        region AS name,
        ROUND(SUM(cost_unblended), 2) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonEKS'
      AND trimBoth(region) != ''
      {account_filter}
    GROUP BY region
    ORDER BY cost DESC
"""

EKS_BY_ACCOUNT = """
    SELECT
        account_name AS name,
        ROUND(SUM(cost_unblended), 2) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonEKS'
      AND account_name IS NOT NULL
      {account_filter}
    GROUP BY account_name
    ORDER BY cost DESC
"""

EKS_TOP_CLUSTERS = """
    SELECT
        splitByString('/', resource_id)[-1] AS cluster_name,
        argMax(region, usage_start_ts) AS region,
        argMax(account_name, usage_start_ts) AS account_name,
        toString(argMax(account_id, usage_start_ts)) AS aws_account_id,
        ROUND(SUM(usage_qty), 2) AS cluster_hours,
        ROUND(SUM(cost_unblended), 2) AS total_cost
    FROM (
        SELECT *
        FROM cost.service_costs
        WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
          AND product_code = 'AmazonEKS'
          AND resource_id != ''
          {account_filter}
    )
    GROUP BY resource_id
    ORDER BY total_cost DESC
    LIMIT 50
"""

EKS_CLUSTER_METADATA = """
    WITH cost_data AS (
        SELECT
            splitByString('/', resource_id)[-1] AS cluster_name,
            argMax(region, usage_start_ts) AS region,
            argMax(account_name, usage_start_ts) AS account_name,
            toString(argMax(account_id, usage_start_ts)) AS aws_account_id,
            ROUND(SUM(usage_qty), 2) AS cluster_hours,
            ROUND(SUM(cost_unblended), 2) AS total_cost
        FROM (
            SELECT *
            FROM cost.service_costs
            WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
              AND product_code = 'AmazonEKS'
              AND resource_id != ''
              AND splitByString('/', resource_id)[-1] = {{cluster_name:String}}
              {account_filter}
        )
        GROUP BY resource_id
    ),
    metadata AS (
        SELECT
            cluster_name,
            region,
            account_id,
            account_name,
            kubernetes_version,
            cluster_status,
            nodegroup_count,
            fargate_profiles_count,
            total_nodes,
            has_spot_nodes,
            has_degraded_nodegroup,
            node_instance_types,
            addon_count,
            has_degraded_addon,
            ingested_at AS metadata_last_synced
        FROM cost.aws_eks_metadata FINAL
        WHERE cluster_name = {{cluster_name:String}}
        ORDER BY ingested_at DESC
        LIMIT 1
    )
    SELECT
        c.cluster_name,
        c.region,
        c.account_name,
        c.aws_account_id,
        c.cluster_hours,
        c.total_cost,
        m.kubernetes_version,
        m.cluster_status,
        m.nodegroup_count,
        m.fargate_profiles_count,
        m.total_nodes,
        m.has_spot_nodes,
        m.has_degraded_nodegroup,
        m.node_instance_types,
        m.addon_count,
        m.has_degraded_addon,
        m.metadata_last_synced
    FROM cost_data c
    LEFT JOIN metadata m ON c.cluster_name = m.cluster_name AND c.aws_account_id = m.account_id AND c.region = m.region
"""

# ══════════════════════════════════════════════════════════
# GRAFANA DASHBOARD PANELS (Additional Breakdowns)
# ══════════════════════════════════════════════════════════


EKS_BY_OPERATION = """
    SELECT
        operation AS name,
        ROUND(SUM(cost_unblended), 2) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonEKS'
      AND operation IS NOT NULL
      {account_filter}
    GROUP BY operation
    ORDER BY cost DESC
"""

EKS_BY_USAGE_TYPE = """
    SELECT
        usage_type AS name,
        ROUND(SUM(cost_unblended), 2) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonEKS'
      AND usage_type IS NOT NULL
      {account_filter}
    GROUP BY usage_type
    ORDER BY cost DESC
"""

EKS_BY_PRICING_MODEL = """
    SELECT
        COALESCE(pricing_model, 'OnDemand') AS name,
        ROUND(SUM(cost_unblended), 2) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonEKS'
      {account_filter}
    GROUP BY pricing_model
    ORDER BY cost DESC
"""
