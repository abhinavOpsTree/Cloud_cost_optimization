from pydantic import BaseModel, field_validator
from datetime import datetime
from typing import Optional


VALID_SERVICES = {"ecr", "ec2", "ebs", "s3", "rds", "eks", "vpc", "elb"}


class PermissionUpsert(BaseModel):
    account_id: str
    service: str
    enabled: bool

    @field_validator("service")
    @classmethod
    def service_must_be_known(cls, v: str) -> str:
        v = v.lower().strip()
        if v not in VALID_SERVICES:
            raise ValueError(f"Unknown service '{v}'. Valid: {sorted(VALID_SERVICES)}")
        return v


class PermissionResponse(BaseModel):
    account_id: str
    service: str
    enabled: bool
    updated_at: Optional[datetime] = None
