"""
Service Metadata Permissions API
---------------------------------
Controls which metadata extractors (ECR, EC2, etc.) are allowed to run
for a given AWS account. The permissions table uses an OPT-IN model:
  - No row  = metadata is DISABLED (safe default — never runs without explicit consent).
  - row with enabled=1  = metadata ENABLED for that account + service.
  - row with enabled=0  = metadata explicitly DISABLED.
"""

from fastapi import APIRouter, HTTPException
from core.database import get_client
from datetime import datetime, timezone
from typing import List
import logging
from . import schemas

router = APIRouter(
    prefix="/api/v1/permissions",
    tags=["Permissions"],
)

logger = logging.getLogger(__name__)


# ── Helper ──────────────────────────────────────────────────────────────────
def _row_to_response(row: tuple) -> schemas.PermissionResponse:
    return schemas.PermissionResponse(
        account_id=str(row[0]),
        service=str(row[1]),
        enabled=bool(row[2]),
        updated_at=row[3],
    )


# ── GET  /api/v1/permissions  ────────────────────────────────────────────────
@router.get("/", response_model=List[schemas.PermissionResponse])
async def list_permissions():
    """List every permission row across all accounts."""
    client = get_client()
    try:
        rows = client.query(
            "SELECT account_id, service, enabled, updated_at "
            "FROM cost.account_service_permissions FINAL "
            "ORDER BY account_id, service"
        ).result_rows
        return [_row_to_response(r) for r in rows]
    except Exception as e:
        logger.error(f"[Permissions] list_permissions failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ── GET  /api/v1/permissions/{account_id}  ───────────────────────────────────
@router.get("/{account_id}", response_model=List[schemas.PermissionResponse])
async def list_account_permissions(account_id: str):
    """List all service permissions for a specific account."""
    client = get_client()
    try:
        rows = client.query(
            "SELECT account_id, service, enabled, updated_at "
            "FROM cost.account_service_permissions FINAL "
            "WHERE account_id = {account_id:String} "
            "ORDER BY service",
            parameters={"account_id": account_id},
        ).result_rows
        return [_row_to_response(r) for r in rows]
    except Exception as e:
        logger.error(f"[Permissions] list_account_permissions failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ── POST  /api/v1/permissions  (upsert) ─────────────────────────────────────
@router.post("/", response_model=schemas.PermissionResponse, status_code=201)
async def upsert_permission(request: schemas.PermissionUpsert):
    """
    Create or update a permission row.
    ReplacingMergeTree deduplicates on (account_id, service) and keeps the
    row with the latest updated_at — so an INSERT acts as an upsert.
    """
    client = get_client()
    try:
        client.command(
            "INSERT INTO cost.account_service_permissions "
            "(account_id, service, enabled, updated_at) VALUES "
            "({account_id:String}, {service:String}, {enabled:UInt8}, now())",
            parameters={
                "account_id": request.account_id,
                "service":    request.service,
                "enabled":    1 if request.enabled else 0,
            },
        )
        logger.info(
            f"[Permissions] {request.service.upper()} {'ENABLED' if request.enabled else 'DISABLED'} "
            f"for account '{request.account_id}'"
        )
        # Return constructed response — SELECT FINAL after INSERT is unreliable with
        # ReplacingMergeTree because the async merge may not have run yet.
        return schemas.PermissionResponse(
            account_id=request.account_id,
            service=request.service,
            enabled=request.enabled,
            updated_at=datetime.now(timezone.utc),
        )
    except Exception as e:
        logger.error(f"[Permissions] upsert_permission failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# ── DELETE  /api/v1/permissions/{account_id}/{service}  ───────────────────────
@router.delete("/{account_id}/{service}")
async def delete_permission(account_id: str, service: str):
    """
    Soft-delete: sets enabled=0 for the given account+service.
    The row is preserved for audit; ReplacingMergeTree keeps the latest version.
    """
    service = service.lower().strip()
    if service not in schemas.VALID_SERVICES:
        raise HTTPException(status_code=400, detail=f"Unknown service '{service}'.")

    client = get_client()
    try:
        client.command(
            "INSERT INTO cost.account_service_permissions "
            "(account_id, service, enabled, updated_at) VALUES "
            "({account_id:String}, {service:String}, 0, now())",
            parameters={"account_id": account_id, "service": service},
        )
        logger.info(f"[Permissions] {service.upper()} DISABLED (soft-delete) for account '{account_id}'")
        return {"account_id": account_id, "service": service, "enabled": False}
    except Exception as e:
        logger.error(f"[Permissions] delete_permission failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))
