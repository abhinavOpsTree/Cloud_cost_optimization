from fastapi import APIRouter, HTTPException, Query
from typing import Annotated
from .schemas import BudgetCreate, BudgetStatus, BudgetForecast
from .service import create_budget, get_budget_status, get_budget_status_by_name, get_budget_forecast, get_budget_forecast_by_name, delete_budget

router = APIRouter(prefix="/api/v1/budget", tags=["Budget"])

AccountParam = Annotated[str, Query(description="Account name (e.g. opstree, tripare-production)")]


@router.post("/", response_model=dict, status_code=201)
def create_budget_endpoint(account_name: AccountParam, payload: BudgetCreate):
    """Create or update budget. Pass account_name as query param, only budget_amount in body."""
    return create_budget(
        account_name=account_name,
        budget_amount=payload.budget_amount,
    )


@router.get("/{account_name}", response_model=BudgetStatus)
def get_status_endpoint(account_name: str):
    """Budget vs MTD spend for an account. Always current month."""
    result = get_budget_status_by_name(account_name)
    if not result:
        raise HTTPException(status_code=404, detail=f"No budget set for account '{account_name}' this month.")
    return result


@router.get("/{account_name}/forecast", response_model=BudgetForecast)
def get_forecast_endpoint(account_name: str):
    """Budget vs forecast for current month."""
    result = get_budget_forecast_by_name(account_name)
    if not result:
        raise HTTPException(status_code=404, detail=f"No budget set for account '{account_name}' this month.")
    return result


@router.delete("/{account_name}", status_code=200)
def delete_budget_endpoint(account_name: str):
    """Delete budget for an account for the current month."""
    deleted = delete_budget(account_name)
    if not deleted:
        raise HTTPException(status_code=404, detail=f"No budget set for account '{account_name}' this month.")
    return {"message": f"Budget for '{account_name}' deleted successfully."}
