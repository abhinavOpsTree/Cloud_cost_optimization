"""
Budget service — stores budgets in ClickHouse, computes MTD/forecast comparisons,
fires rows into cost.alert_events when thresholds are crossed.
"""
import math
import logging
from datetime import datetime, timezone
from core import database as db

logger = logging.getLogger(__name__)

# Thresholds per spec
_BUDGET_INFO_PCT     = 80.0   # 80% → INFO (log only)
_BUDGET_WARNING_PCT  = 95.0   # 95% → WARNING
_BUDGET_CRITICAL_PCT = 100.0  # 100% → CRITICAL


_MTD_SQL = """
SELECT ROUND(SUM(cost_unblended), 2) AS mtd_cost
FROM cost.service_costs
WHERE usage_start_ts >= toStartOfMonth(now())
  AND usage_start_ts < today() + 1
  AND account_name = {account_name:String}
"""

_FORECAST_SQL = """
WITH
    days_elapsed AS (
        SELECT dateDiff('day', toStartOfMonth(today()), today()) AS n
    ),
    -- Single scan of last 4 months — feeds both avg_daily and weekend factor.
    hist_base AS (
        SELECT
            toDate(usage_start_ts)              AS date,
            toDayOfWeek(toDate(usage_start_ts)) AS dow,
            SUM(cost_unblended)                 AS daily_cost
        FROM cost.service_costs
        WHERE usage_start_ts >= date_sub(MONTH, 4, toStartOfMonth(today()))
          AND usage_start_ts <  toStartOfMonth(today())
          AND account_name = {account_name:String}
        GROUP BY date
    ),
    -- Merged CTE: avg_daily and weekend factor in one pass over hist_base.
    hist_and_factor AS (
        SELECT
            COALESCE(SUM(daily_cost) / GREATEST(COUNT(*), 1), 0) AS avg_daily,
            COALESCE(
                if(
                    isNaN(avgIf(daily_cost, dow IN (6, 7)))
                    OR isNaN(avgIf(daily_cost, dow NOT IN (6, 7)))
                    OR avgIf(daily_cost, dow NOT IN (6, 7)) = 0,
                    NULL,
                    avgIf(daily_cost, dow IN (6, 7)) / avgIf(daily_cost, dow NOT IN (6, 7))
                ),
                1.0
            ) AS factor
        FROM hist_base
    ),
    mtd AS (
        SELECT
            SUM(cost_unblended)                                                       AS mtd_cost,
            SUM(cost_unblended) / GREATEST(dateDiff('day', toStartOfMonth(today()), today()), 1) AS true_daily_rate
        FROM cost.service_costs
        WHERE usage_start_ts >= toStartOfMonth(now())
          AND usage_start_ts <  today() + 1
          AND account_name = {account_name:String}
    ),
    remaining_days AS (
        SELECT
            countIf(toDayOfWeek(date) IN (6,7))     AS weekend_remaining,
            countIf(toDayOfWeek(date) NOT IN (6,7)) AS weekday_remaining
        FROM (
            SELECT date_add(DAY, number, toStartOfMonth(now())) AS date
            FROM numbers(0, 31)
            WHERE toMonth(date) = toMonth(now())
              AND date >= today()
        )
    )
-- All single-row CTEs materialised once via CROSS JOIN — no scalar subquery re-executions.
SELECT
    ROUND(m.mtd_cost, 2) AS mtd_cost,
    ROUND(m.true_daily_rate, 2) AS daily_run_rate,
    ROUND(
        m.mtd_cost
        + COALESCE(r.weekday_remaining, 0) *
          CASE WHEN de.n < 7
               THEN COALESCE(if(isNaN(hf.avg_daily) OR hf.avg_daily = 0, NULL, hf.avg_daily), m.true_daily_rate)
               ELSE m.true_daily_rate END
        + COALESCE(r.weekend_remaining, 0) *
          CASE WHEN de.n < 7
               THEN COALESCE(if(isNaN(hf.avg_daily) OR hf.avg_daily = 0, NULL, hf.avg_daily), m.true_daily_rate)
               ELSE m.true_daily_rate END * hf.factor,
    2) AS predicted_month_cost
FROM mtd m
CROSS JOIN hist_and_factor hf
CROSS JOIN days_elapsed de
CROSS JOIN remaining_days r
SETTINGS allow_experimental_analyzer=1
"""


def _current_month() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m")


def _get_mtd(account_name: str) -> float:
    rows = db.query(_MTD_SQL, params={"account_name": account_name})
    return float(rows[0]["mtd_cost"] or 0) if rows else 0.0


def _get_forecast(account_name: str) -> dict:
    rows = db.query(_FORECAST_SQL, params={"account_name": account_name})
    if not rows:
        return {"mtd_cost": 0.0, "daily_run_rate": 0.0, "predicted_month_cost": 0.0}
    r = rows[0]
    def _safe(v): f = float(v or 0); return 0.0 if math.isnan(f) or math.isinf(f) else f
    return {
        "mtd_cost":             _safe(r.get("mtd_cost")),
        "daily_run_rate":       _safe(r.get("daily_run_rate")),
        "predicted_month_cost": _safe(r.get("predicted_month_cost")),
    }


def _upsert_alert(account_id: str, account_name: str, year_month: str,
                  severity: str, mtd_cost: float, budget_amount: float) -> None:
    """Single upsert — one alert per account per month, always reflects latest MTD and budget."""
    alert_id = f"budget-{account_id}-{year_month}"
    now      = datetime.now(timezone.utc).replace(tzinfo=None)
    pct_used = round(mtd_cost / budget_amount * 100, 2) if budget_amount else 0

    # Preserve original fired_at so sorting key stays the same → ReplacingMergeTree deduplicates
    existing = db.query(
        "SELECT fired_at FROM cost.alert_events WHERE alert_id = {alert_id:String} ORDER BY updated_at DESC LIMIT 1",
        params={"alert_id": alert_id}
    )
    fired_at = existing[0]["fired_at"].replace(tzinfo=None) if existing else now

    db.query(
        """
        INSERT INTO cost.alert_events
        (alert_id, account_id, account_name, service, severity,
         cost_today, mean_cost, std_dev, upper_threshold, z_score,
         pct_above_mean, status, signal_type, fired_at, acknowledged_at, resolved_at, updated_at)
        VALUES
        ({alert_id:String}, {account_id:String}, {account_name:String},
         'budget', {severity:String},
         {cost_today:Float64}, {budget_amount:Float64}, 0.0,
         {budget_amount:Float64}, {pct_used:Float64},
         {pct_used:Float64}, 'OPEN', 'budget_breach',
         {fired_at:DateTime}, NULL, NULL, {updated_at:DateTime})
        """,
        params={
            "alert_id":     alert_id,
            "account_id":   account_id,
            "account_name": account_name,
            "severity":     severity,
            "cost_today":   mtd_cost,
            "budget_amount":budget_amount,
            "pct_used":     pct_used,
            "fired_at":     fired_at,
            "updated_at":   now,
        }
    )
    logger.info(f"[Budget] {account_name} upserted alert: MTD=${mtd_cost:.2f} ({pct_used}% of ${budget_amount:.0f}) severity={severity}")


def _resolve_alert(account_id: str, year_month: str) -> None:
    alert_id = f"budget-{account_id}-{year_month}"
    now = datetime.now(timezone.utc).replace(tzinfo=None)
    db.query(
        """
        INSERT INTO cost.alert_events
        (alert_id, account_id, account_name, service, severity,
         cost_today, mean_cost, std_dev, upper_threshold, z_score,
         pct_above_mean, status, fired_at, resolved_at, updated_at)
        SELECT alert_id, account_id, account_name, service, severity,
               cost_today, mean_cost, std_dev, upper_threshold, z_score,
               pct_above_mean, 'RESOLVED', fired_at,
               {now:DateTime}, {now:DateTime}
        FROM cost.alert_events FINAL
        WHERE alert_id = {alert_id:String}
          AND status = 'OPEN'
        """,
        params={"alert_id": alert_id, "now": now}
    )


# ── Public service functions ──────────────────────────────────────────────────

def create_budget(account_name: str, budget_amount: float) -> dict:
    year_month = _current_month()
    now = datetime.now(timezone.utc).replace(tzinfo=None)

    # Auto-resolve aws_account_id from accounts table
    acc_rows = db.query(
        "SELECT aws_account_id FROM cost.accounts FINAL "
        "WHERE account_name = {account_name:String} AND is_deleted = 0 LIMIT 1",
        params={"account_name": account_name}
    )
    account_id = acc_rows[0]["aws_account_id"] if acc_rows else account_name

    # Auto-resolve any existing open budget alert — budget amount changed so old alert is stale
    _resolve_alert(account_id, year_month)

    db.query(
        """
        INSERT INTO cost.account_budgets
        (account_id, account_name, year_month, budget_amount, updated_at)
        VALUES ({account_id:String}, {account_name:String}, {year_month:String},
                {budget_amount:Float64}, {updated_at:DateTime})
        """,
        params={
            "account_id":    account_id,
            "account_name":  account_name,
            "year_month":    year_month,
            "budget_amount": budget_amount,
            "updated_at":    now,
        }
    )
    return {"account_id": account_id, "account_name": account_name, "year_month": year_month, "budget_amount": budget_amount}


def delete_budget(account_name: str) -> bool:
    year_month = _current_month()
    rows = db.query(
        "SELECT account_id FROM cost.account_budgets FINAL "
        "WHERE account_name = {account_name:String} AND year_month = {year_month:String} LIMIT 1",
        params={"account_name": account_name, "year_month": year_month}
    )
    if not rows:
        return False
    account_id = rows[0]["account_id"]
    # Resolve any open alert before deleting
    _resolve_alert(account_id, year_month)
    db.query(
        "ALTER TABLE cost.account_budgets DELETE "
        "WHERE account_name = {account_name:String} AND year_month = {year_month:String}",
        params={"account_name": account_name, "year_month": year_month}
    )
    return True


def get_budget_status_by_name(account_name: str) -> dict:
    year_month = _current_month()
    rows = db.query(
        "SELECT account_id FROM cost.account_budgets FINAL "
        "WHERE account_name = {account_name:String} AND year_month = {year_month:String} LIMIT 1",
        params={"account_name": account_name, "year_month": year_month}
    )
    if not rows:
        return None
    return get_budget_status(rows[0]["account_id"])


def get_budget_status(account_id: str, year_month: str = None) -> dict:
    if not year_month:
        year_month = _current_month()

    rows = db.query(
        "SELECT account_id, account_name, year_month, budget_amount FROM cost.account_budgets FINAL "
        "WHERE account_id = {account_id:String} AND year_month = {year_month:String} LIMIT 1",
        params={"account_id": account_id, "year_month": year_month}
    )
    if not rows:
        return None

    b = rows[0]
    budget_amount = float(b["budget_amount"])
    account_name  = b["account_name"]
    mtd_cost      = _get_mtd(account_name)
    pct_used      = round(mtd_cost / budget_amount * 100, 2) if budget_amount else 0

    if mtd_cost >= budget_amount:
        _upsert_alert(account_id, account_name, year_month, "CRITICAL", mtd_cost, budget_amount)
    elif pct_used >= _BUDGET_WARNING_PCT:
        _upsert_alert(account_id, account_name, year_month, "WARNING", mtd_cost, budget_amount)
    elif pct_used >= _BUDGET_INFO_PCT:
        _upsert_alert(account_id, account_name, year_month, "WARNING", mtd_cost, budget_amount)
    else:
        _resolve_alert(account_id, year_month)

    return {
        "budget_amount": budget_amount,
        "mtd_cost":      mtd_cost,
        "pct_used":      pct_used,
    }


def get_budget_forecast_by_name(account_name: str) -> dict:
    year_month = _current_month()
    rows = db.query(
        "SELECT account_id FROM cost.account_budgets FINAL "
        "WHERE account_name = {account_name:String} AND year_month = {year_month:String} LIMIT 1",
        params={"account_name": account_name, "year_month": year_month}
    )
    if not rows:
        return None
    return get_budget_forecast(rows[0]["account_id"])


def get_budget_forecast(account_id: str) -> dict:
    year_month = _current_month()

    rows = db.query(
        "SELECT account_id, account_name, year_month, budget_amount FROM cost.account_budgets FINAL "
        "WHERE account_id = {account_id:String} AND year_month = {year_month:String} LIMIT 1",
        params={"account_id": account_id, "year_month": year_month}
    )
    if not rows:
        return None

    b = rows[0]
    budget_amount = float(b["budget_amount"])
    account_name  = b["account_name"]
    fc            = _get_forecast(account_name)
    mtd_cost      = fc["mtd_cost"]
    forecast      = fc["predicted_month_cost"]

    forecast_vs_budget_pct = round((forecast / budget_amount - 1) * 100, 2) if budget_amount else 0

    if mtd_cost >= budget_amount:
        _upsert_alert(account_id, account_name, year_month, "CRITICAL", mtd_cost, budget_amount)
    elif forecast >= budget_amount * (_BUDGET_WARNING_PCT / 100):
        _upsert_alert(account_id, account_name, year_month, "WARNING", mtd_cost, budget_amount)
    elif forecast >= budget_amount * (_BUDGET_INFO_PCT / 100):
        _upsert_alert(account_id, account_name, year_month, "WARNING", mtd_cost, budget_amount)
    else:
        _resolve_alert(account_id, year_month)

    return {
        "budget_amount":          budget_amount,
        "forecast_month_cost":    forecast,
        "forecast_vs_budget_pct": forecast_vs_budget_pct,
    }
