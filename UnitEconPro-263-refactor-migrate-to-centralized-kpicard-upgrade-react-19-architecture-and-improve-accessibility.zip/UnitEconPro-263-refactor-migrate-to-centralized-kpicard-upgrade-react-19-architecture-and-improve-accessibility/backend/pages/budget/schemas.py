from pydantic import BaseModel, field_validator
from typing import Optional


class BudgetCreate(BaseModel):
    budget_amount: float

    @field_validator("budget_amount")
    @classmethod
    def must_be_positive(cls, v: float) -> float:
        if v <= 0:
            raise ValueError("budget_amount must be greater than 0")
        return v


class BudgetStatus(BaseModel):
    budget_amount: float
    mtd_cost: float
    pct_used: float


class BudgetForecast(BaseModel):
    budget_amount: float
    forecast_month_cost: float
    forecast_vs_budget_pct: float
