"""
S3 Storage Page Routes
"""
from fastapi import APIRouter, Query
from core import database as db
from core.dependencies import DateCtx
from . import queries as q
from . import schemas

router = APIRouter(prefix="/api/v1/storage/s3", tags=["Storage – S3"])



@router.get("/summary", response_model=schemas.S3Summary)
async def get_s3_summary(ctx: DateCtx):
    sql = q.S3_SUMMARY.format(start=ctx.start, end=ctx.end, account_filter=ctx.account_filter)
    rows = db.query_safe(sql, ctx.params)
    if not rows:
        return schemas.S3Summary(total_cost=0.0, avg_daily_cost=0.0, total_buckets=0, total_storage_gb=0.0)
    row = rows[0]
    return schemas.S3Summary(
        total_cost=float(row.get("total_cost") or 0.0),
        avg_daily_cost=float(row.get("avg_daily_cost") or 0.0),
        total_buckets=int(row.get("total_buckets") or 0),
        total_storage_gb=float(row.get("total_storage_gb") or 0.0),
    )


@router.get("/buckets", response_model=list[schemas.S3Bucket])
async def get_s3_buckets(ctx: DateCtx):
    sql = q.S3_TOP_BUCKETS.format(start=ctx.start, end=ctx.end, account_filter=ctx.account_filter)
    rows = db.query_safe(sql, ctx.params)
    return [
        schemas.S3Bucket(
            bucket_name=r.get("bucket_name") or "",
            region=r.get("region"),
            account=r.get("account"),
            avg_storage_gb=float(r.get("avg_storage_gb") or 0.0),
            request_count=float(r.get("request_count") or 0.0),
            transfer_gb=float(r.get("transfer_gb") or 0.0),
            total_cost=float(r.get("total_cost") or 0.0),
        )
        for r in rows
    ]


@router.get("/buckets/{bucket_name}/metadata", response_model=schemas.S3BucketMetadataDetail)
async def get_s3_bucket_metadata(
    bucket_name: str,
    ctx: DateCtx,
):
    """
    Cost + metadata for a single bucket.
    Exact same pattern as GET /compute/eks/clusters/{cluster_name}/metadata.
    Returns empty object (not 404) if bucket has no data yet.
    """
    is_all = not ctx.account_filter
    params = {
        "bucket_name":  bucket_name,
        "start":        ctx.start,
        "end":          ctx.end,
        "account_all":  1 if is_all else 0,
        "account_name": "" if is_all else ctx.account_filter.split("'")[1],
    }
    rows = db.query_safe(q.S3_BUCKET_METADATA_BY_NAME, params=params)

    if not rows:
        return schemas.S3BucketMetadataDetail(bucket_name=bucket_name)

    r                = rows[0]
    billed_gb_months = float(r.get("billed_gb_months") or 0)
    avg_storage_gb   = float(r.get("avg_storage_gb")   or 0)
    total_cost       = float(r.get("total_cost")       or 0)
    storage_cost     = float(r.get("storage_cost")     or 0)

    # cost_per_gb_month = storage_cost / billed_gb_months
    # This gives the exact AWS rate ($0.023 for Standard)
    cost_per_gb_month = round(storage_cost / billed_gb_months, 4) if billed_gb_months > 0 else None

    flags = _compute_finops_flags(r, cost_per_gb_month, avg_storage_gb)

    potential_savings = 0.0
    if "VERSIONING_WASTE_RISK" in flags or "MULTIPART_WASTE_RISK" in flags:
        potential_savings += storage_cost * 0.30
    if "STORAGE_CLASS_CANDIDATE" in flags:
        potential_savings += storage_cost * 0.50

    return schemas.S3BucketMetadataDetail(
        bucket_name                 = r.get("bucket_name", bucket_name),
        region                      = r.get("region"),
        account_name                = r.get("account_name"),
        account_id                  = str(r.get("account_id", "")),
        total_cost                  = total_cost,
        billed_gb_months            = billed_gb_months,
        avg_storage_gb              = avg_storage_gb,
        storage_cost                = storage_cost,
        request_cost                = float(r.get("request_cost")  or 0),
        transfer_cost               = float(r.get("transfer_cost") or 0),
        cost_per_gb_month           = cost_per_gb_month,
        estimated_savings_potential = round(potential_savings, 2),
        versioning_status           = r.get("versioning_status"),
        has_lifecycle_rules         = bool(r.get("has_lifecycle_rules", 0)) if r.get("versioning_status") is not None else None,
        clears_incomplete_multipart = bool(r.get("clears_incomplete_multipart", 0)) if r.get("versioning_status") is not None else None,
        is_public                   = bool(r.get("is_public", 0)) if r.get("versioning_status") is not None else None,
        encryption_type             = r.get("encryption_type"),
        tags                        = r.get("tags") or {},
        metadata_last_synced        = r.get("metadata_last_synced"),
        finops_flags                = flags,
    )




def _compute_finops_flags(r: dict, cost_per_gb: float | None, avg_storage_gb: float = 0.0) -> list[str]:
    flags = []
    if r.get("is_public"):
        flags.append("PUBLIC_BUCKET")
    if r.get("encryption_type") in (None, "None", ""):
        flags.append("NO_ENCRYPTION")

    
    if not r.get("has_lifecycle_rules"):
        flags.append("MISSING_LIFECYCLE")
    if not r.get("clears_incomplete_multipart"):
        flags.append("MULTIPART_WASTE_RISK")

   
    versioning = r.get("versioning_status", "Disabled")
    has_lc     = r.get("has_lifecycle_rules", 0)
    if versioning == "Enabled" and not has_lc:
        flags.append("VERSIONING_WASTE_RISK")

  
    # Benchmark: AWS S3 Standard = $0.023/GB/month. Flag if 2x above benchmark.
    if cost_per_gb is not None and cost_per_gb > 0.05 and avg_storage_gb > 0.1:
        flags.append("STORAGE_CLASS_CANDIDATE")

    request_cost = float(r.get("request_cost") or 0)
    storage_cost = float(r.get("storage_cost") or 0)
    if request_cost > storage_cost and request_cost > 0.10:
        flags.append("HIGH_REQUEST_COST")

    return flags


