"""
S3 Storage Page — Pydantic response models
"""
from pydantic import BaseModel
from typing import Optional, Dict, List


class S3Summary(BaseModel):
    total_cost: float
    avg_daily_cost: float
    total_buckets: int
    total_storage_gb: float


class S3TrendPoint(BaseModel):
    date: str
    cost: float


class S3StoragePoint(BaseModel):
    date: str
    storage_gb: float


class S3BreakdownItem(BaseModel):
    name: str
    cost: float
    usage: float = 0.0
    unit: str = ""


class S3Bucket(BaseModel):
    bucket_name: str
    region: Optional[str] = None
    account: Optional[str] = None
    avg_storage_gb: float       # average GB stored during the period (raw_gb_hours / hours)
    request_count: float
    transfer_gb: float
    total_cost: float




class S3Financials(BaseModel):
    total_cost_30d:              float
    storage_gb:                  float
    storage_cost:                float
    request_cost:                float
    transfer_cost:               float
    cost_per_gb:                 Optional[float] = None  # None if storage_gb = 0
    estimated_savings_potential: float = 0.0


class S3BucketMetadataDetail(BaseModel):
    """Cost + metadata for one bucket — returned by GET /buckets/{bucket_name}/metadata."""
    bucket_name:                 str
    region:                      Optional[str]            = None
    account_name:                Optional[str]            = None
    account_id:                  Optional[str]            = None
    # Financials
    total_cost:                  float = 0.0
    billed_gb_months:            float = 0.0   # AWS CUR GB-Months (usage_qty for TimedStorage)
    avg_storage_gb:              float = 0.0   # billed_gb_months / months_in_range = physical avg GB
    storage_cost:                float = 0.0
    request_cost:                float = 0.0
    transfer_cost:               float = 0.0
    cost_per_gb_month:           Optional[float] = None   # storage_cost / billed_gb_months = $/GB-Month
    estimated_savings_potential: float = 0.0
    # Metadata
    versioning_status:           Optional[str]            = None
    has_lifecycle_rules:         Optional[bool]           = None
    clears_incomplete_multipart: Optional[bool]           = None
    is_public:                   Optional[bool]           = None
    encryption_type:             Optional[str]            = None
    tags:                        Dict[str, str]           = {}
    metadata_last_synced:        Optional[str]            = None
    finops_flags:                List[str]                = []


class S3BucketMetadata(BaseModel):
    versioning_status:           str   # Enabled | Suspended | Disabled
    has_lifecycle_rules:         bool
    clears_incomplete_multipart: bool
    is_public:                   bool
    encryption_type:             str   # SSE-S3 | SSE-KMS | DSSE-KMS | None


class S3BucketDetail(BaseModel):
    bucket_name:  str
    region:       str
    account_name: str
    account_id:   str
    financials:   S3Financials
    metadata:     Optional[S3BucketMetadata] = None  # None if Boto3 not yet run
    finops_flags: List[str] = []
    tags:         Dict[str, str] = {}


class S3MetadataSummaryResponse(BaseModel):
    total_buckets:       int
    total_cost_30d:      float
    avg_daily_cost:      float
    total_storage_gb:    float
    public_bucket_count: int
    unencrypted_count:   int
    no_lifecycle_count:  int
    buckets:             List[S3BucketDetail]
