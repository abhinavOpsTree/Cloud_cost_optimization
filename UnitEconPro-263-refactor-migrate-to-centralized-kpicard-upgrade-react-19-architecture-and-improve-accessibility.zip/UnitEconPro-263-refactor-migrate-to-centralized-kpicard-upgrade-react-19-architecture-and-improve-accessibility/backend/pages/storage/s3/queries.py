"""
S3 SQL Query Templates – Tier 1 (100% exact, audit-grade)
All queries filter by product_code = 'AmazonS3' and support {start}, {end}, {account_filter}.

Focus: Per-bucket cost (exact via resource_id), categorized usage types (Storage/Requests/Transfer).
"""


S3_SUMMARY = """
    SELECT
        ROUND(SUM(cost_unblended), 2) AS total_cost,
        CASE
            WHEN COUNT(DISTINCT toDate(usage_start_ts)) > 0
            THEN ROUND(SUM(cost_unblended) / COUNT(DISTINCT toDate(usage_start_ts)), 2)
            ELSE 0
        END AS avg_daily_cost,
        COUNT(DISTINCT resource_id) AS total_buckets,
        ROUND(
            SUM(CASE WHEN usage_type LIKE '%Storage%' THEN usage_qty ELSE 0 END)
            / greatest(dateDiff('day', toDateTime('{start}'), toDateTime('{end}')) / 30.0, 1.0)
        , 2) AS total_storage_gb
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonS3'
      {account_filter}
"""

S3_COST_TREND = """
    SELECT
        toDate(usage_start_ts) AS date_obj,
        formatDateTime(date_obj, '%Y-%m-%d') AS date,
        ROUND(SUM(cost_unblended), 2) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonS3'
      {account_filter}
    GROUP BY date_obj
    ORDER BY date_obj ASC
"""

S3_STORAGE_TREND = """
    SELECT
        toDate(usage_start_ts) AS date_obj,
        formatDateTime(date_obj, '%Y-%m-%d') AS date,
        ROUND(SUM(usage_qty), 2) AS storage_gb
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonS3'
      AND usage_type LIKE '%Storage%'
      {account_filter}
    GROUP BY date_obj
    ORDER BY date_obj ASC
"""



# Simple bucket cost breakdown — used by analytics/breakdown?service=s3&dimension=bucket
# Returns name + cost only (no storage math needed here)
S3_BY_BUCKET = """
    SELECT
        CASE
            WHEN resource_id LIKE 'arn:aws:s3:::%' THEN splitByString(':::', resource_id)[-1]
            ELSE resource_id
        END AS name,
        ROUND(SUM(cost_unblended), 2) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonS3'
      AND resource_id != ''
      AND trimBoth(region) != ''
      AND region != 'global'
      {account_filter}
    GROUP BY resource_id
    HAVING cost > 0
    ORDER BY cost DESC
    LIMIT 50
"""

S3_BY_REGION = """
    SELECT
        region AS name,
        ROUND(SUM(cost_unblended), 2) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonS3'
      AND trimBoth(region) != ''
      {account_filter}
    GROUP BY region
    ORDER BY cost DESC
"""

S3_BY_ACCOUNT = """
    SELECT
        account_name AS name,
        ROUND(SUM(cost_unblended), 2) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonS3'
      AND account_name IS NOT NULL
      {account_filter}
    GROUP BY account_name
    ORDER BY cost DESC
"""

S3_BY_OPERATION = """
    SELECT
        operation AS name,
        ROUND(SUM(cost_unblended), 2) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonS3'
      AND operation IS NOT NULL
      AND operation != ''
      {account_filter}
    GROUP BY operation
    ORDER BY cost DESC
"""

S3_BY_USAGE_TYPE = """
    SELECT
        CASE
            WHEN usage_type LIKE '%TimedStorage%' OR usage_type LIKE '%Storage%' THEN 'Storage'
            WHEN usage_type LIKE '%Requests%' OR usage_type LIKE '%Request%' THEN 'Requests'
            WHEN usage_type LIKE '%DataTransfer%' OR usage_type LIKE '%Transfer%' OR usage_type LIKE '%AWS-Out%' THEN 'Data Transfer'
            ELSE 'Other'
        END AS name,
        ROUND(SUM(cost_unblended), 2) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonS3'
      {account_filter}
    GROUP BY name
    ORDER BY cost DESC
"""

S3_BY_PRICING_MODEL = """
    SELECT
        COALESCE(pricing_model, 'OnDemand') AS name,
        ROUND(SUM(cost_unblended), 2) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonS3'
      {account_filter}
    GROUP BY pricing_model
    ORDER BY cost DESC
"""


S3_TOP_BUCKETS = """
    SELECT
        bucket_name,
        region,
        account,
        avg_storage_gb,
        request_count,
        transfer_gb,
        total_cost
    FROM (
        SELECT
            CASE
                WHEN resource_id LIKE 'arn:aws:s3:::%' THEN splitByString(':::', resource_id)[-1]
                ELSE resource_id
            END AS bucket_name,
            argMax(region, usage_start_ts)       AS region,
            argMax(account_name, usage_start_ts) AS account,
            -- billed_gb_months: AWS CUR usage_qty for TimedStorage is already in GB-Months
            ROUND(sumIf(usage_qty, usage_type LIKE '%TimedStorage%'), 2) AS billed_gb_months,
            -- avg_storage_gb: GB-Months / months in range = average physical GB stored
            ROUND(
                sumIf(usage_qty, usage_type LIKE '%TimedStorage%')
                / greatest(dateDiff('day', toDateTime('{start}'), toDateTime('{end}')) / 30.0, 1.0)
            , 2) AS avg_storage_gb,
            ROUND(SUM(CASE WHEN usage_type LIKE '%Requests%' OR usage_type LIKE '%Request%' THEN usage_qty ELSE 0 END), 2) AS request_count,
            ROUND(SUM(CASE WHEN usage_type LIKE '%DataTransfer%' OR usage_type LIKE '%-Out-Bytes%' OR usage_type LIKE '%-In-Bytes%' THEN usage_qty ELSE 0 END), 2) AS transfer_gb,
            ROUND(SUM(cost_unblended), 2) AS total_cost
        FROM cost.service_costs
        WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
          AND product_code = 'AmazonS3'
          AND resource_id != ''
          {account_filter}
        GROUP BY resource_id
    )
    WHERE total_cost > 0
      AND trimBoth(region) != ''
      AND region != 'global'
    ORDER BY total_cost DESC
    LIMIT 50
"""


S3_BY_REQUEST_TYPE = """
    SELECT
        CASE
            WHEN usage_type LIKE '%Tier1%' THEN 'Tier 1 (PUT/LIST)'
            WHEN usage_type LIKE '%Tier2%' THEN 'Tier 2 (GET/SELECT)'
            ELSE 'Other'
        END AS name,
        ROUND(SUM(cost_unblended), 2) AS cost,
        ROUND(SUM(usage_qty), 2) AS usage,
        'Requests' AS unit
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonS3'
      AND usage_type LIKE '%Request%'
      {account_filter}
    GROUP BY name
    ORDER BY cost DESC
"""

S3_BY_TRANSFER_DIRECTION = """
    SELECT
        CASE
            WHEN usage_type LIKE '%Out-Bytes%' OR usage_type LIKE '%AWS-Out%' THEN 'Outbound (Egress)'
            WHEN usage_type LIKE '%In-Bytes%' OR usage_type LIKE '%AWS-In%' THEN 'Inbound (Ingress)'
            ELSE 'Other'
        END AS name,
        ROUND(SUM(cost_unblended), 2) AS cost,
        ROUND(SUM(usage_qty), 2) AS usage,
        'GB' AS unit
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonS3'
      AND (usage_type LIKE '%Transfer%' OR usage_type LIKE '%Bytes%')
      {account_filter}
    GROUP BY name
    ORDER BY cost DESC
"""

S3_BUCKET_DETAIL_JOIN = """
SELECT
    f.bucket_name,
    f.acct_name   AS account_name,
    f.acct_id     AS account_id,
    f.region,
    f.total_cost_30d,
    f.storage_gb,
    f.storage_cost,
    f.request_cost,
    f.transfer_cost,
    m.versioning_status,
    m.has_lifecycle_rules,
    m.clears_incomplete_multipart,
    m.is_public,
    m.encryption_type,
    m.tags
FROM (
    SELECT
        resource_id                                                             AS bucket_name,
        argMax(account_name, usage_start_ts)                                    AS acct_name,
        toString(argMax(account_id, usage_start_ts))                            AS acct_id,
        argMax(region, usage_start_ts)                                          AS region,
        round(SUM(cost_unblended), 4)                                           AS total_cost_30d,
        round(sumIf(usage_qty,      usage_type LIKE '%TimedStorage%'), 2) AS storage_gb,
        round(sumIf(cost_unblended, usage_type LIKE '%TimedStorage%'), 4)       AS storage_cost,
        round(sumIf(cost_unblended,
            usage_type LIKE '%Requests-Tier1%'
            OR usage_type LIKE '%Requests-Tier2%'
            OR usage_type LIKE '%Requests-INT%'), 4)                            AS request_cost,
        round(sumIf(cost_unblended, usage_type LIKE '%DataTransfer%' OR usage_type LIKE '%-Out-Bytes%' OR usage_type LIKE '%-In-Bytes%'), 4)        AS transfer_cost
    FROM cost.service_costs
    WHERE product_code   = 'AmazonS3'
      AND cost_unblended > 0
      AND usage_start_ts >= now() - INTERVAL 30 DAY
      AND resource_id    != ''
      AND ({account_all:UInt8} = 1 OR account_name = {account_name:String})
    GROUP BY resource_id
) f
LEFT JOIN (
    SELECT *
    FROM cost.aws_s3_metadata FINAL
) m ON f.bucket_name = m.bucket_name AND f.acct_id = m.account_id
ORDER BY f.total_cost_30d DESC
LIMIT {limit:UInt16}
"""

S3_METADATA_SUMMARY_COUNTS = """
SELECT
    countIf(is_public = 1)            AS public_bucket_count,
    countIf(encryption_type = 'None') AS unencrypted_count,
    countIf(has_lifecycle_rules = 0)  AS no_lifecycle_count
FROM cost.aws_s3_metadata FINAL
WHERE ({account_all:UInt8} = 1 OR account_name = {account_name:String})
"""


S3_BUCKET_METADATA_BY_NAME = """
    WITH cost_data AS (
        SELECT
            resource_id                                                             AS bucket_name,
            argMax(region, usage_start_ts)                                          AS region,
            argMax(account_name, usage_start_ts)                                    AS acct_name,
            toString(argMax(account_id, usage_start_ts))                            AS acct_id,
            round(SUM(cost_unblended), 4)                                           AS total_cost,
            -- billed_gb_months: AWS CUR usage_qty for TimedStorage is already in GB-Months
            round(sumIf(usage_qty, usage_type LIKE '%TimedStorage%'), 2)            AS billed_gb_months,
            -- avg_storage_gb: GB-Months / months in range = average physical GB stored
            round(
                sumIf(usage_qty, usage_type LIKE '%TimedStorage%')
                / greatest(dateDiff('day', toDateTime({start:String}), toDateTime({end:String})) / 30.0, 1.0)
            , 2)                                                                    AS avg_storage_gb,
            round(sumIf(cost_unblended, usage_type LIKE '%TimedStorage%'), 4)       AS storage_cost,
            round(sumIf(cost_unblended,
                usage_type LIKE '%Requests-Tier1%'
                OR usage_type LIKE '%Requests-Tier2%'
                OR usage_type LIKE '%Requests-INT%'), 4)                            AS request_cost,
            round(sumIf(cost_unblended, usage_type LIKE '%DataTransfer%' OR usage_type LIKE '%-Out-Bytes%' OR usage_type LIKE '%-In-Bytes%'), 4) AS transfer_cost
        FROM cost.service_costs
        WHERE product_code   = 'AmazonS3'
          AND cost_unblended > 0
          AND usage_start_ts >= {start:String}
          AND usage_start_ts <= {end:String}
          AND resource_id    = {bucket_name:String}
          AND ({account_all:UInt8} = 1 OR account_name = {account_name:String})
        GROUP BY resource_id
    ),
    meta AS (
        SELECT
            bucket_name,
            versioning_status,
            has_lifecycle_rules,
            clears_incomplete_multipart,
            is_public,
            encryption_type,
            tags,
            formatDateTime(ingested_at, '%Y-%m-%d %H:%i:%S') AS metadata_last_synced
        FROM cost.aws_s3_metadata FINAL
        WHERE bucket_name = {bucket_name:String}
        ORDER BY ingested_at DESC
        LIMIT 1
    )
    SELECT
        c.bucket_name,
        c.region,
        c.acct_name        AS account_name,
        c.acct_id          AS account_id,
        c.total_cost,
        c.billed_gb_months,
        c.avg_storage_gb,
        c.storage_cost,
        c.request_cost,
        c.transfer_cost,
        m.versioning_status, m.has_lifecycle_rules, m.clears_incomplete_multipart,
        m.is_public, m.encryption_type, m.tags, m.metadata_last_synced
    FROM cost_data c
    LEFT JOIN meta m ON c.bucket_name = m.bucket_name
"""


S3_SINGLE_BUCKET_METADATA = """
SELECT
    bucket_name,
    account_id,
    account_name,
    region,
    versioning_status,
    has_lifecycle_rules,
    clears_incomplete_multipart,
    is_public,
    encryption_type,
    tags,
    formatDateTime(ingested_at, '%Y-%m-%d %H:%i:%S') AS metadata_last_synced
FROM cost.aws_s3_metadata FINAL
WHERE bucket_name = {bucket_name:String}
ORDER BY ingested_at DESC
LIMIT 1
"""

