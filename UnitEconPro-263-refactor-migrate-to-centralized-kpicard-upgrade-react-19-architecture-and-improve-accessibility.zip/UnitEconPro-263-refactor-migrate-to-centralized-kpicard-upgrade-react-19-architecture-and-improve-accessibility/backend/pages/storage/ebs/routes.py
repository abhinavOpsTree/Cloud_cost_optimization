
import logging
from fastapi import APIRouter, HTTPException, Query
from core import database as db
from core.dependencies import DateCtx, date_range_params
from . import queries as q
from . import schemas

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v1/storage/ebs", tags=["Storage – EBS"])

@router.get("/summary", response_model=schemas.EBSSummary)
async def get_ebs_summary(ctx: DateCtx):
    """6 stat cards: Total Cost, Avg Daily, Volumes, Snapshots, Storage GB, Snapshot GB."""
    sql = q.EBS_SUMMARY.format(start=ctx.start, end=ctx.end, account_filter=ctx.account_filter)
    rows = db.query_safe(sql, ctx.params)
    if not rows:
        return schemas.EBSSummary(
            total_cost=0.0, avg_daily_cost=0.0,
            total_volumes=0, total_snapshots=0,
            total_storage_gb=0.0, total_snapshot_gb=0.0
        )
    row = rows[0]
    return schemas.EBSSummary(
        total_cost=float(row.get("total_cost") or 0.0),
        avg_daily_cost=float(row.get("avg_daily_cost") or 0.0),
        total_volumes=int(row.get("total_volumes") or 0),
        total_snapshots=int(row.get("total_snapshots") or 0),
        total_storage_gb=float(row.get("total_storage_gb") or 0.0),
        total_snapshot_gb=float(row.get("total_snapshot_gb") or 0.0),
    )


@router.get("/volumes", response_model=list[schemas.EBSVolume])
async def get_ebs_volumes(ctx: DateCtx):
    """Top 50 EBS volumes by cost with type, region, storage."""
    sql = q.EBS_TOP_VOLUMES.format(start=ctx.start, end=ctx.end, account_filter=ctx.account_filter)
    rows = db.query_safe(sql, ctx.params)
    return [
        schemas.EBSVolume(
            volume_id=r.get("volume_id") or "",
            region=r.get("region"),
            account=r.get("account"),
            volume_type=r.get("volume_type"),
            storage_gb=float(r.get("storage_gb") or 0.0),
            total_cost=float(r.get("total_cost") or 0.0),
        )
        for r in rows
    ]


@router.get("/snapshots", response_model=list[schemas.EBSSnapshot])
async def get_ebs_snapshots(ctx: DateCtx):
    """Top 50 EBS snapshots by cost."""
    sql = q.EBS_TOP_SNAPSHOTS.format(start=ctx.start, end=ctx.end, account_filter=ctx.account_filter)
    rows = db.query_safe(sql, ctx.params)
    return [
        schemas.EBSSnapshot(
            snapshot_id=r.get("snapshot_id") or "",
            region=r.get("region"),
            account=r.get("account"),
            snapshot_gb=float(r.get("snapshot_gb") or 0.0),
            total_cost=float(r.get("total_cost") or 0.0),
        )
        for r in rows
    ]


def _compute_finops_flags(meta: dict, financials: dict) -> tuple:
    """
    Returns (flags: list[str], estimated_savings_potential: float)

    Flag trigger conditions:
      ORPHAN_VOLUME              state == "available"
      DELETE_ON_TERMINATION_RISK state == "in-use" AND delete_on_termination == False
      MIGRATE_GP3_CANDIDATE      volume_type == "gp2"
      SNAPSHOT_WASTE             snapshot_count > 10 AND last_snapshot_age_days > 90
      NO_RECENT_BACKUP           last_snapshot_age_days > 90 OR snapshot_count == 0
      UNENCRYPTED                encrypted == False
      MISSING_COST_TAG           tags missing Environment or Owner
    """
    flags = []
    savings = 0.0

    state                  = meta.get("state", "")
    volume_type            = meta.get("volume_type", "")
    delete_on_termination  = meta.get("delete_on_termination", False)
    snapshot_count         = meta.get("snapshot_count", 0)
    last_snapshot_age_days = meta.get("last_snapshot_age_days", -1)
    encrypted              = meta.get("encrypted", False)
    tags                   = meta.get("tags", {})
    storage_cost           = financials.get("storage_cost", 0.0)
    snapshot_cost          = financials.get("snapshot_cost", 0.0)

    if state == "available":
        flags.append("ORPHAN_VOLUME")
        savings += storage_cost

    if state == "in-use" and not delete_on_termination:
        flags.append("DELETE_ON_TERMINATION_RISK")

    if volume_type == "gp2":
        flags.append("MIGRATE_GP3_CANDIDATE")
        savings += round(storage_cost * 0.20, 2)

    if snapshot_count > 10 and last_snapshot_age_days > 90:
        flags.append("SNAPSHOT_WASTE")
        savings += round(snapshot_cost * 0.30, 2)

    if last_snapshot_age_days > 90 or snapshot_count == 0:
        flags.append("NO_RECENT_BACKUP")

    if not encrypted:
        flags.append("UNENCRYPTED")

    if not {"Environment", "Owner"}.issubset(set(tags.keys())):
        flags.append("MISSING_COST_TAG")

    return flags, round(savings, 2)


@router.get("/volumes/{volume_id}/metadata", response_model=schemas.EBSVolumeMetadataDetail)
async def get_ebs_volume_metadata(
    volume_id: str,
    ctx: DateCtx,
):
    """FinOps metadata for a specific EBS volume — cost breakdown + operational flags."""
    # Extract account_name from ctx.account_filter if present
    # ctx.account_filter is either "" or "AND account_name = 'opstree'"
    account_name = ""
    is_all_accounts = ctx.account_filter == ""
    
    if not is_all_accounts:
        # Parse account name from "AND account_name = 'opstree'"
        import re
        match = re.search(r"account_name = '([^']+)'", ctx.account_filter)
        if match:
            account_name = match.group(1)
    
    # Look up account_id using only named parameters (no f-string mixing)
    # Add usage_start_ts filter to leverage partition pruning and avoid full table scan
    lookup_sql = """
        SELECT DISTINCT CAST(account_id AS String) AS account_id
        FROM cost.service_costs
        WHERE resource_id = {volume_id:String}
          AND product_code = 'AmazonEBS'
          AND usage_start_ts >= now() - INTERVAL 90 DAY
          AND ({is_all:UInt8} = 1 OR account_name = {account_name:String})
        LIMIT 1
    """
    lookup_rows = db.query(
        lookup_sql,
        params={
            "volume_id": volume_id,
            "is_all": 1 if is_all_accounts else 0,
            "account_name": account_name,
        }
    )
    if not lookup_rows:
        raise HTTPException(
            status_code=404,
            detail=f"Volume '{volume_id}' not found in cost data (last 90 days)"
        )
    account_id = lookup_rows[0]["account_id"]

    rows = db.query(
        q.EBS_VOLUME_METADATA_BY_ID,
        params={
            "volume_id":  volume_id,
            "start":      ctx.start,
            "end":        ctx.end,
            "account_id": account_id,
        }
    )

    if not rows:
        raise HTTPException(
            status_code=404,
            detail=f"Volume '{volume_id}' metadata not found (account_id={account_id})"
        )

    r = rows[0]

    financials_data = {
        "total_cost_30d":   float(r.get("total_cost_30d") or 0.0),
        "billed_gb_months": float(r.get("billed_gb_months") or 0.0),
        "storage_cost":     float(r.get("storage_cost") or 0.0),
        "iops_cost":        float(r.get("iops_cost") or 0.0),
        "throughput_cost":  float(r.get("throughput_cost") or 0.0),
        "snapshot_cost":    float(r.get("snapshot_cost") or 0.0),
    }

    metadata_data = {
        "volume_type":            r.get("volume_type") or "",
        "size_gb":                int(r.get("size_gb") or 0),
        "state":                  r.get("state") or "",
        "attached_instance_id":   r.get("attached_instance_id") or None,
        "attached_device":        r.get("attached_device") or None,
        "iops":                   int(r.get("iops") or 0),
        "throughput":             int(r.get("throughput") or 0),
        "encrypted":              bool(r.get("encrypted")),
        "multi_attach_enabled":   bool(r.get("multi_attach_enabled")),
        "delete_on_termination":  bool(r.get("delete_on_termination")),
        "snapshot_count":         int(r.get("snapshot_count") or 0),
        "last_snapshot_age_days": int(r.get("last_snapshot_age_days") or -1),
        "age_days":               int(r.get("age_days") or 0),
        "tags":                   r.get("tags") or {},
    }

    # cost_per_gb_month — derived from actual CUR data, fallback to static pricing
    billed_gb_months = financials_data["billed_gb_months"]
    storage_cost     = financials_data["storage_cost"]
    if billed_gb_months > 0:
        cost_per_gb_month = round(storage_cost / billed_gb_months, 4)
    else:
        cost_per_gb_month = q.EBS_PRICE_PER_GB.get(metadata_data["volume_type"], 0.08)

    finops_flags, estimated_savings_potential = _compute_finops_flags(
        metadata_data, financials_data
    )

    ingested_at = r.get("ingested_at")
    metadata_last_synced = (
        ingested_at.strftime("%Y-%m-%dT%H:%M:%SZ")
        if ingested_at and hasattr(ingested_at, "strftime")
        else str(ingested_at or "")
    )

    return schemas.EBSVolumeMetadataDetail(
        volume_id=r.get("volume_id") or volume_id,
        region=r.get("region") or "",
        account_name=r.get("account_name") or "",
        account_id=r.get("account_id") or "",
        availability_zone=r.get("availability_zone") or "",
        financials=schemas.EBSFinancials(**financials_data),
        metadata=schemas.EBSMetadata(**metadata_data),
        cost_per_gb_month=cost_per_gb_month,
        estimated_savings_potential=estimated_savings_potential,
        finops_flags=finops_flags,
        metadata_last_synced=metadata_last_synced,
    )
