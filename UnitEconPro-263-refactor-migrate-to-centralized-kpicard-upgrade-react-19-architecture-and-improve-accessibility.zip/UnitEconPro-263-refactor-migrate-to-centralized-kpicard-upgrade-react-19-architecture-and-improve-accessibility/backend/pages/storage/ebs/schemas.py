"""
EBS Storage Page — Pydantic response models
Covers volumes, snapshots, cost analytics, and Grafana dashboard parity.
"""
from pydantic import BaseModel
from typing import Dict, List, Optional


class EBSSummary(BaseModel):
    total_cost: float
    avg_daily_cost: float
    total_volumes: int
    total_snapshots: int
    total_storage_gb: float
    total_snapshot_gb: float


class EBSTrendPoint(BaseModel):
    date: str
    cost: float


class EBSStoragePoint(BaseModel):
    date: str
    volume_gb: float
    snapshot_gb: float


class EBSBreakdownItem(BaseModel):
    name: str
    cost: float
    usage: float = 0.0
    unit: str = ""


class EBSVolume(BaseModel):
    volume_id: str
    region: Optional[str] = None
    account: Optional[str] = None
    volume_type: Optional[str] = None
    storage_gb: float
    total_cost: float


class EBSSnapshot(BaseModel):
    snapshot_id: str
    region: Optional[str] = None
    account: Optional[str] = None
    snapshot_gb: float
    total_cost: float


# ── Metadata endpoint schemas ───────────────────────────────────────────────

class EBSFinancials(BaseModel):
    total_cost_30d:     float
    billed_gb_months:   float
    storage_cost:       float
    iops_cost:          float
    throughput_cost:    float
    snapshot_cost:      float


class EBSMetadata(BaseModel):
    volume_type:            str
    size_gb:                int
    state:                  str
    attached_instance_id:   Optional[str] = None
    attached_device:        Optional[str] = None
    iops:                   int
    throughput:             int
    encrypted:              bool
    multi_attach_enabled:   bool
    delete_on_termination:  bool
    snapshot_count:         int
    last_snapshot_age_days: int     # -1 = no snapshots ever
    age_days:               int
    tags:                   Dict[str, str] = {}


class EBSVolumeMetadataDetail(BaseModel):
    volume_id:                   str
    region:                      str
    account_name:                str
    account_id:                  str
    availability_zone:           str
    financials:                  EBSFinancials
    metadata:                    EBSMetadata
    cost_per_gb_month:           float
    estimated_savings_potential: float
    finops_flags:                List[str]
    metadata_last_synced:        str
