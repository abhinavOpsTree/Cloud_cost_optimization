
EBS_SUMMARY = """
    SELECT
        ROUND(SUM(cost_unblended), 2) AS total_cost,
        CASE
            WHEN COUNT(DISTINCT toDate(usage_start_ts)) > 0
            THEN ROUND(SUM(cost_unblended) / COUNT(DISTINCT toDate(usage_start_ts)), 2)
            ELSE 0
        END AS avg_daily_cost,
        uniqExactIf(resource_id, position(usage_type, 'Volume') > 0) AS total_volumes,
        uniqExactIf(resource_id, position(usage_type, 'Snapshot') > 0) AS total_snapshots,
        ROUND(sumIf(usage_qty, position(usage_type, 'Volume') > 0), 2) AS total_storage_gb,
        ROUND(sumIf(usage_qty, position(usage_type, 'Snapshot') > 0), 2) AS total_snapshot_gb
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonEBS'
      {account_filter}
"""

EBS_COST_TREND = """
    SELECT
        toDate(usage_start_ts) AS date_obj,
        formatDateTime(date_obj, '%Y-%m-%d') AS date,
        ROUND(SUM(cost_unblended), 2) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonEBS'
      {account_filter}
    GROUP BY date_obj
    ORDER BY date_obj ASC
"""

EBS_STORAGE_TREND = """
    SELECT
        toDate(usage_start_ts) AS date_obj,
        formatDateTime(date_obj, '%Y-%m-%d') AS date,
        ROUND(sumIf(usage_qty, position(usage_type, 'Volume') > 0), 2) AS volume_gb,
        ROUND(sumIf(usage_qty, position(usage_type, 'Snapshot') > 0), 2) AS snapshot_gb
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonEBS'
      {account_filter}
    GROUP BY date_obj
    ORDER BY date_obj ASC
"""


EBS_BY_VOLUME_TYPE = """
    SELECT
        CASE
            WHEN usage_type LIKE '%VolumeUsage.gp3%' THEN 'gp3'
            WHEN usage_type LIKE '%VolumeUsage.gp2%' THEN 'gp2'
            WHEN usage_type LIKE '%VolumeUsage.io1%' THEN 'io1'
            WHEN usage_type LIKE '%VolumeUsage.io2%' THEN 'io2'
            WHEN usage_type LIKE '%VolumeUsage.st1%' THEN 'st1'
            WHEN usage_type LIKE '%VolumeUsage.sc1%' THEN 'sc1'
            WHEN usage_type LIKE '%VolumeUsage%' THEN 'standard'
            WHEN usage_type LIKE '%Snapshot%' THEN 'Snapshot'
            ELSE 'Other'
        END AS name,
        ROUND(SUM(cost_unblended), 2) AS cost,
        ROUND(SUM(usage_qty), 2) AS usage,
        'GB' AS unit
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonEBS'
      {account_filter}
    GROUP BY name
    ORDER BY cost DESC
"""

EBS_BY_REGION = """
    SELECT
        region AS name,
        ROUND(SUM(cost_unblended), 2) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonEBS'
      AND trimBoth(region) != ''
      {account_filter}
    GROUP BY region
    ORDER BY cost DESC
"""

EBS_BY_ACCOUNT = """
    SELECT
        account_name AS name,
        ROUND(SUM(cost_unblended), 2) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonEBS'
      AND account_name IS NOT NULL
      {account_filter}
    GROUP BY account_name
    ORDER BY cost DESC
"""

EBS_BY_OPERATION = """
    SELECT
        operation AS name,
        ROUND(SUM(cost_unblended), 2) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonEBS'
      AND operation IS NOT NULL
      AND operation != ''
      {account_filter}
    GROUP BY operation
    ORDER BY cost DESC
"""

EBS_BY_PRODUCT_FAMILY = """
    SELECT
        product_family AS name,
        ROUND(SUM(cost_unblended), 2) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonEBS'
      AND product_family IS NOT NULL
      AND product_family != ''
      {account_filter}
    GROUP BY product_family
    ORDER BY cost DESC
"""

EBS_BY_PRICING_MODEL = """
    SELECT
        COALESCE(pricing_model, 'OnDemand') AS name,
        ROUND(SUM(cost_unblended), 2) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonEBS'
      {account_filter}
    GROUP BY pricing_model
    ORDER BY cost DESC
"""

EBS_BY_USAGE_TYPE = """
    SELECT
        CASE
            WHEN position(usage_type, 'Volume') > 0 THEN 'Volume Storage'
            WHEN position(usage_type, 'Snapshot') > 0 THEN 'Snapshot Storage'
            ELSE 'Other'
        END AS name,
        ROUND(SUM(cost_unblended), 2) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonEBS'
      {account_filter}
    GROUP BY name
    ORDER BY cost DESC
"""


EBS_TOP_VOLUMES = """
    -- CTE computes argMaxIf ONCE per resource_id, then the outer CASE reads the string.
    -- Avoids evaluating argMaxIf 6 times per row (one per WHEN branch).
    WITH base AS (
        SELECT
            resource_id,
            argMax(region, usage_start_ts)                                          AS region,
            argMax(account_name, usage_start_ts)                                    AS account,
            argMaxIf(usage_type, usage_start_ts, usage_type LIKE '%VolumeUsage%')   AS vt_raw,
            sumIf(usage_qty, usage_type LIKE '%VolumeUsage%')                       AS storage_gb_raw,
            SUM(cost_unblended)                                                     AS total_cost_raw
        FROM cost.service_costs
        WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
          AND product_code = 'AmazonEBS'
          AND resource_id != ''
          AND usage_type LIKE '%Volume%'
          {account_filter}
        GROUP BY resource_id
    )
    SELECT
        resource_id                                     AS volume_id,
        region,
        account,
        CASE
            WHEN vt_raw LIKE '%gp3%' THEN 'gp3'
            WHEN vt_raw LIKE '%gp2%' THEN 'gp2'
            WHEN vt_raw LIKE '%io1%' THEN 'io1'
            WHEN vt_raw LIKE '%io2%' THEN 'io2'
            WHEN vt_raw LIKE '%st1%' THEN 'st1'
            WHEN vt_raw LIKE '%sc1%' THEN 'sc1'
            ELSE 'standard'
        END                                             AS volume_type,
        -- storage_gb: VolumeUsage rows only (GB-based); excludes IOPS/Throughput (count-based)
        ROUND(storage_gb_raw, 2)                        AS storage_gb,
        -- total_cost: ALL row types so io1/io2 IOPS charges are included in ranking
        ROUND(total_cost_raw, 2)                        AS total_cost
    FROM base
    ORDER BY total_cost DESC
    LIMIT 50
"""

EBS_TOP_SNAPSHOTS = """
    SELECT
        resource_id AS snapshot_id,
        argMax(region, usage_start_ts) AS region,
        argMax(account_name, usage_start_ts) AS account,
        ROUND(SUM(usage_qty), 2) AS snapshot_gb,
        ROUND(SUM(cost_unblended), 2) AS total_cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonEBS'
      AND resource_id != ''
      AND usage_type LIKE '%Snapshot%'
      {account_filter}
    GROUP BY resource_id
    ORDER BY total_cost DESC, resource_id ASC
    LIMIT 50
"""

EBS_PRICE_PER_GB = {
    "gp2":      0.10,
    "gp3":      0.08,
    "io1":      0.125,
    "io2":      0.125,
    "st1":      0.045,
    "sc1":      0.015,
    "standard": 0.05,
}

EBS_VOLUME_METADATA_BY_ID = """
    WITH cur_costs AS (
        SELECT
            resource_id                                                             AS volume_id,
            sumIf(cost_unblended, usage_type LIKE '%EBS:VolumeUsage%')             AS storage_cost,
            sumIf(cost_unblended, usage_type LIKE '%EBS:VolumeP-IOPS%')            AS iops_cost,
            sumIf(cost_unblended, usage_type LIKE '%EBS:VolumeP-Throughput%')      AS throughput_cost,
            sumIf(cost_unblended, usage_type LIKE '%EBS:SnapshotUsage%')           AS snapshot_cost,
            sum(cost_unblended)                                                     AS total_cost_30d,
            sum(usage_qty)                                                          AS billed_gb_months
        FROM cost.service_costs
        WHERE product_code          = 'AmazonEBS'
          AND resource_id           = {volume_id:String}
          AND CAST(account_id AS String) = {account_id:String}
          AND usage_start_ts       >= {start:DateTime}
          AND usage_start_ts       <= {end:DateTime}
        GROUP BY resource_id
    ),
    meta AS (
        SELECT *
        FROM cost.aws_ebs_metadata FINAL
        WHERE volume_id  = {volume_id:String}
          AND account_id = {account_id:String}
        ORDER BY version DESC
        LIMIT 1
    )
    SELECT
        m.volume_id,
        m.region,
        m.account_name,
        m.account_id,
        m.availability_zone,
        coalesce(c.total_cost_30d,   0) AS total_cost_30d,
        coalesce(c.billed_gb_months, 0) AS billed_gb_months,
        coalesce(c.storage_cost,     0) AS storage_cost,
        coalesce(c.iops_cost,        0) AS iops_cost,
        coalesce(c.throughput_cost,  0) AS throughput_cost,
        coalesce(c.snapshot_cost,    0) AS snapshot_cost,
        m.volume_type,
        m.size_gb,
        m.state,
        m.attached_instance_id,
        m.attached_device,
        m.iops,
        m.throughput,
        m.encrypted,
        m.multi_attach_enabled,
        m.delete_on_termination,
        m.snapshot_count,
        m.last_snapshot_age_days,
        m.age_days,
        m.tags,
        m.ingested_at
    FROM meta m
    LEFT JOIN cur_costs c ON m.volume_id = c.volume_id
"""
