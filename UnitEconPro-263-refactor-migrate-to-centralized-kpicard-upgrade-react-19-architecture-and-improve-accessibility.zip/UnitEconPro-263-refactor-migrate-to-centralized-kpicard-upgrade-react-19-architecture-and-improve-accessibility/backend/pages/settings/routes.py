"""
Global Settings API — GET / PUT alert thresholds.

Thresholds are stored in cost.app_settings (ClickHouse) as key-value pairs.
The ECR repositories endpoint reads these to assign Warning/Error statuses.
"""
from fastapi import APIRouter

from core import database as db
from . import schemas

router = APIRouter(prefix="/api/v1/settings", tags=["Settings"])

# The 8 threshold keys we manage
THRESHOLD_KEYS = [
    "ecr_cost_warning", "ecr_cost_error",
    "ecr_storage_warning", "ecr_storage_error",
    "ecr_transfer_warning", "ecr_transfer_error",
    "eks_cost_warning", "eks_cost_error",
]


def get_all_thresholds() -> schemas.AlertThresholds:
    """Read all threshold settings from ClickHouse, with safe defaults."""
    rows = db.query("SELECT setting_key, setting_value FROM cost.app_settings FINAL")
    kv = {r["setting_key"]: r["setting_value"] for r in rows}

    defaults = schemas.AlertThresholds()
    return schemas.AlertThresholds(
        ecr_cost_warning=float(kv.get("ecr_cost_warning", defaults.ecr_cost_warning)),
        ecr_cost_error=float(kv.get("ecr_cost_error", defaults.ecr_cost_error)),
        ecr_storage_warning=float(kv.get("ecr_storage_warning", defaults.ecr_storage_warning)),
        ecr_storage_error=float(kv.get("ecr_storage_error", defaults.ecr_storage_error)),
        ecr_transfer_warning=float(kv.get("ecr_transfer_warning", defaults.ecr_transfer_warning)),
        ecr_transfer_error=float(kv.get("ecr_transfer_error", defaults.ecr_transfer_error)),
        eks_cost_warning=float(kv.get("eks_cost_warning", defaults.eks_cost_warning)),
        eks_cost_error=float(kv.get("eks_cost_error", defaults.eks_cost_error)),
    )


@router.get("/", response_model=schemas.AlertThresholds)
async def get_settings():
    """Return current alert threshold values."""
    return get_all_thresholds()


@router.put("/", response_model=schemas.AlertThresholds)
async def update_settings(body: schemas.AlertThresholdsUpdate):
    """
    Update one or more threshold values.
    Only send the fields you want to change — others stay untouched.
    """
    updates = body.model_dump(exclude_none=True)

    for key, value in updates.items():
        if key in THRESHOLD_KEYS:
            db.query(f"""
                INSERT INTO cost.app_settings (setting_key, setting_value, updated_at)
                VALUES ('{key}', '{value}', now())
            """)

    return get_all_thresholds()
