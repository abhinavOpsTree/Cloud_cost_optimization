"""
Settings Page — Pydantic response models
"""
from pydantic import BaseModel
from typing import Optional


class AlertThresholds(BaseModel):
    ecr_cost_warning: float = 20
    ecr_cost_error: float = 50
    ecr_storage_warning: float = 100
    ecr_storage_error: float = 300
    ecr_transfer_warning: float = 50
    ecr_transfer_error: float = 150
    eks_cost_warning: float = 50
    eks_cost_error: float = 200


class AlertThresholdsUpdate(BaseModel):
    """Partial update — only send the fields you want to change."""
    ecr_cost_warning: Optional[float] = None
    ecr_cost_error: Optional[float] = None
    ecr_storage_warning: Optional[float] = None
    ecr_storage_error: Optional[float] = None
    ecr_transfer_warning: Optional[float] = None
    ecr_transfer_error: Optional[float] = None
    eks_cost_warning: Optional[float] = None
    eks_cost_error: Optional[float] = None
