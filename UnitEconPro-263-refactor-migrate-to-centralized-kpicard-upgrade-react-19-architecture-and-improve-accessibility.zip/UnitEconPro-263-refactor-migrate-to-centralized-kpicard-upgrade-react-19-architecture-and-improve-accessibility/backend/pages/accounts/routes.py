from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel
from typing import List, Optional
import boto3
from boto3 import Session
from botocore.config import Config
from botocore.exceptions import ClientError
import uuid
from datetime import datetime
from core.database import get_client
from core.security import encrypt_string, decrypt_string
from core.config import ENVIRONMENT
import logging

router = APIRouter(
    prefix="/api/v1/accounts",
    tags=["Accounts"],
    responses={404: {"description": "Not found"}},
)

logger = logging.getLogger(__name__)

class AccountCreateRequest(BaseModel):
    account_name: str
    access_key_id: str
    secret_access_key: str
    athena_database: str
    athena_table: str
    athena_bucket: str
    aws_region: Optional[str] = "us-east-1"

class AccountResponse(BaseModel):
    account_id: str
    aws_account_id: str
    account_name: str
    athena_database: str
    athena_table: str
    athena_bucket: str
    aws_region: str
    status: str
    last_validated: Optional[datetime] = None
    last_error: Optional[str] = ""
    created_at: datetime
    updated_at: datetime


@router.post("/", response_model=AccountResponse)
async def create_account(request: AccountCreateRequest):
    """
    Onboard a new AWS account. Validates credentials with STS AND does a dry-run check before saving.
    """
    # 0. Sanitize S3 Bucket URI
    bucket = request.athena_bucket.strip()
    if not bucket.startswith("s3://"):
        bucket = f"s3://{bucket}"
    if not bucket.endswith("/"):
        bucket = f"{bucket}/"
    request.athena_bucket = bucket

    # 1. Validate credentials with AWS STS
    try:
        sts_client = boto3.client(
            'sts',
            aws_access_key_id=request.access_key_id,
            aws_secret_access_key=request.secret_access_key,
            region_name=request.aws_region,
            config=Config(
                connect_timeout=5,
                read_timeout=5,
                retries={'max_attempts': 0}
            )
        )
        identity = sts_client.get_caller_identity()
        aws_account_id = identity.get('Account', 'UNKNOWN')

    except ClientError as e:
        # ALLOW MOCK/TEST CREDS TO PASS FOR LOCAL DEV
        if ENVIRONMENT != "production":
            logger.warning(f"STS verification failed: {e}. Bypassing for local development mode.")
            aws_account_id = 'UNKNOWN'  # placeholder for dev
        else:
            logger.error(f"Failed to validate AWS credentials: {e}")
            raise HTTPException(status_code=401, detail="Invalid AWS Credentials provided.")
    except Exception as e:
        logger.error(f"Unexpected error during STS validation: {e}")
        raise HTTPException(status_code=500, detail="Internal server error during credential validation.")

    # 2. Dry Run - Validate actual S3 access
    try:
        s3_client = boto3.client(
            's3',
            aws_access_key_id=request.access_key_id,
            aws_secret_access_key=request.secret_access_key,
            region_name=request.aws_region,
            config=Config(connect_timeout=5, read_timeout=5, retries={'max_attempts': 0})
        )
        bucket_name = request.athena_bucket.replace("s3://", "").strip("/")
        # If there are subdirectories, split to just get the root bucket name
        if "/" in bucket_name:
            bucket_name = bucket_name.split("/")[0]
        s3_client.head_bucket(Bucket=bucket_name)

    except ClientError as e:
        if ENVIRONMENT != "production":
            logger.warning(f"S3 Dry-run failed: {e}. Bypassing for local development mode.")
        else:
            logger.error(f"Failed S3 permissions dry runner: {e}")
            raise HTTPException(status_code=403, detail=f"IAM Permission Error: Access denied to S3 bucket {request.athena_bucket}. Please check IAM policies.")

    # 3. Encrypt Secret
    try:
        encrypted_secret = encrypt_string(request.secret_access_key)
    except Exception as e:
        logger.error(f"Failed to encrypt secret: {e}")
        raise HTTPException(status_code=500, detail="Failed to secure credentials.")

    # 4. Save to ClickHouse
    client = get_client()

    # Crucial Fix: If this AWS account already exists, reuse its exact UUID
    # so that ClickHouse's ReplacingMergeTree can deduplicate the old record automatically!
    existing_rows = client.query(
        "SELECT account_id FROM cost.accounts"
        " WHERE aws_account_id = {aws_account_id:String}"
        " AND is_deleted = 0"
        " ORDER BY updated_at DESC LIMIT 1",
        parameters={"aws_account_id": aws_account_id},
    ).result_rows

    if existing_rows:
        account_uuid = existing_rows[0][0]
        logger.info(f"Updating existing account: {aws_account_id} with UUID {account_uuid}")
    else:
        account_uuid = str(uuid.uuid4())
        logger.info(f"Creating new account UUID: {account_uuid} for AWS {aws_account_id}")

    now = datetime.utcnow()

    try:
        client.insert(
            table="cost.accounts",
            data=[[
                account_uuid,
                request.account_name,
                aws_account_id,
                request.access_key_id,
                encrypted_secret,
                request.athena_database,
                request.athena_table,
                request.athena_bucket,
                request.aws_region,
                "ACTIVE",
                now,
                "",
                now,
                now,
                0,
            ]],
            column_names=[
                "account_id", "account_name", "aws_account_id",
                "access_key_id", "secret_access_key",
                "athena_database", "athena_table", "athena_bucket",
                "aws_region", "status", "last_validated", "last_error",
                "created_at", "updated_at", "is_deleted",
            ],
        )
    except Exception as e:
        logger.error(f"Failed to save account to database: {e}")
        raise HTTPException(status_code=500, detail=f"Database error while saving account: {str(e)}")

    # 5. Auto-sync to account_map so this account appears in Grafana/UI dropdowns immediately
    if aws_account_id and aws_account_id != 'UNKNOWN':
        try:
            # Check if this AWS account ID already exists in the map to prevent duplicates in UI
            map_count = client.query(
                "SELECT count() FROM cost.account_map"
                " WHERE account_id = {account_id:String}",
                parameters={"account_id": aws_account_id},
            ).result_rows[0][0]

            if map_count == 0:
                client.insert(
                    table="cost.account_map",
                    data=[[aws_account_id, request.account_name, now, now]],
                    column_names=["account_id", "account_name", "created_at", "updated_at"],
                )
                logger.info(f"Auto-synced account {aws_account_id} → account_map as '{request.account_name}'")
            else:
                logger.info(f"Account {aws_account_id} already exists in account_map. Skipped insertion to prevent duplicates.")
        except Exception as e:
            logger.warning(f"Failed to sync to account_map (non-fatal): {e}")

    return AccountResponse(
        account_id=account_uuid,
        aws_account_id=aws_account_id,
        account_name=request.account_name,
        athena_database=request.athena_database,
        athena_table=request.athena_table,
        athena_bucket=request.athena_bucket,
        aws_region=request.aws_region,
        status='ACTIVE',
        last_validated=now,
        last_error="",
        created_at=now,
        updated_at=now,
    )


@router.get("/", response_model=List[AccountResponse])
async def list_accounts():
    """
    Get all active accounts for the UI.
    """
    client = get_client()
    # No user input in this query — static SQL is safe as-is
    query = """
    SELECT account_id, account_name, aws_account_id, athena_database, athena_table, athena_bucket, aws_region, status, last_validated, last_error, created_at, updated_at
    FROM cost.accounts FINAL
    WHERE is_deleted = 0
    ORDER BY updated_at DESC
    LIMIT 1 BY account_id
    """

    try:
        results = client.query(query).result_rows
        accounts = []
        for row in results:
            accounts.append(AccountResponse(
                account_id=str(row[0]),
                account_name=str(row[1]),
                aws_account_id=str(row[2]),
                athena_database=str(row[3]),
                athena_table=str(row[4]),
                athena_bucket=str(row[5]),
                aws_region=str(row[6]),
                status=str(row[7]),
                last_validated=row[8],
                last_error=str(row[9]),
                created_at=row[10],
                updated_at=row[11],
            ))
        return accounts
    except Exception as e:
        logger.error(f"Failed to query accounts: {e}")
        return []


@router.delete("/{account_id}")
async def delete_account(account_id: str):
    """
    Soft-delete an account using a lightweight mutation.
    Uses ALTER TABLE UPDATE instead of re-inserting the full row,
    which avoids fragile positional column reconstruction.
    """
    client = get_client()

    # Verify the account exists before attempting the mutation
    exists_rows = client.query(
        "SELECT count() FROM cost.accounts FINAL"
        " WHERE account_id = {account_id:String} AND is_deleted = 0",
        parameters={"account_id": account_id},
    ).result_rows
    if not exists_rows or exists_rows[0][0] == 0:
        raise HTTPException(status_code=404, detail="Account not found.")

    try:
        now_str = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
        # ALTER TABLE UPDATE is the correct pattern for ReplacingMergeTree soft-deletes —
        # avoids re-inserting the full row and breaking if the schema ever changes.
        client.command(
            "ALTER TABLE cost.accounts"
            " UPDATE is_deleted = 1, status = 'DELETED', updated_at = {now:DateTime}"
            " WHERE account_id = {account_id:String}",
            parameters={"account_id": account_id, "now": now_str},
        )
        return {"message": "Account deleted successfully."}

    except Exception as e:
        logger.error(f"Failed to delete account: {e}")
        raise HTTPException(status_code=500, detail="Database error while deleting account.")


@router.post("/{account_id}/validate")
async def validate_account(account_id: str):
    """
    Validate the credentials of an existing account via STS.
    Updates the account's status, last_error, and last_validated fields.
    """
    client = get_client()
    now_str = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")

    # 1. Fetch account details — parameterized, account_id is user-supplied via URL path
    try:
        results = client.query(
            "SELECT access_key_id, secret_access_key, aws_region"
            " FROM cost.accounts FINAL"
            " WHERE account_id = {account_id:String} AND is_deleted = 0",
            parameters={"account_id": account_id},
        ).result_rows
        if not results:
            raise HTTPException(status_code=404, detail="Account not found.")

        row = results[0]
        access_key = row[0]
        enc_secret  = row[1]
        region      = row[2]

        if access_key == 'STS_MANAGED':
            # For STS managed roles from environment, we simulate success for now
            # In a real environment, you'd test the base environment role
            status, error_msg = 'ACTIVE', ''
        else:
            try:
                secret_key = decrypt_string(enc_secret)

                sts_client = boto3.client(
                    'sts',
                    aws_access_key_id=access_key,
                    aws_secret_access_key=secret_key,
                    region_name=region,
                    config=Config(connect_timeout=5, read_timeout=5, retries={'max_attempts': 0})
                )
                sts_client.get_caller_identity()
                status, error_msg = 'ACTIVE', ''
                logger.info(f"Account {account_id} validation successful.")
            except Exception as cred_e:
                status    = 'ERROR'
                error_msg = str(cred_e)
                logger.warning(f"Account {account_id} validation failed: {cred_e}")

        # 2. Update status — parameterized; error_msg is from AWS SDK, not user input,
        #    but we still parameterize it to be safe and avoid any quoting issues.
        client.command(
            "ALTER TABLE cost.accounts"
            " UPDATE status = {status:String},"
            "        last_error = {last_error:String},"
            "        last_validated = {last_validated:DateTime}"
            " WHERE account_id = {account_id:String}",
            parameters={
                "status":         status,
                "last_error":     error_msg,
                "last_validated": now_str,
                "account_id":     account_id,
            },
        )

        if status == 'ERROR':
            raise HTTPException(status_code=400, detail=f"Validation failed: {error_msg}")

        return {"message": "Account validated successfully.", "status": "ACTIVE"}

    except HTTPException as h:
        raise h
    except Exception as e:
        logger.error(f"Failed to validate account {account_id}: {e}")
        raise HTTPException(status_code=500, detail="Database error during validation.")
