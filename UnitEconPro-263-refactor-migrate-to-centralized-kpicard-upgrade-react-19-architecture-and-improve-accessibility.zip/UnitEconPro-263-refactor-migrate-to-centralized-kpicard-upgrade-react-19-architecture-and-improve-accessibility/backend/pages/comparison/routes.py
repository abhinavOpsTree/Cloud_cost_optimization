"""
Period-over-Period Cost Comparison — FastAPI Routes

Endpoints:
  GET /api/v1/comparison/summary   — overall two-period comparison
  GET /api/v1/comparison/detail    — same, scoped to one service
  GET /api/v1/comparison/dates     — available dates for the date picker
"""
from datetime import datetime
from fastapi import APIRouter, HTTPException, Query
from typing import Annotated, Optional

from . import service as svc
from .schemas import ComparisonResponse, AvailableDatesResponse

router = APIRouter(prefix="/api/v1/comparison", tags=["Comparison"])


def _validate_dates(start_date: str, end_date: str):
    """Validate date format and ordering before querying."""
    fmt = "%Y-%m-%d"
    try:
        a = datetime.strptime(start_date, fmt).date()
        b = datetime.strptime(end_date, fmt).date()
    except ValueError:
        raise HTTPException(
            status_code=400,
            detail=f"Invalid date format. Use YYYY-MM-DD. Got: start_date='{start_date}', end_date='{end_date}'"
        )
    if a > b:
        raise HTTPException(
            status_code=400,
            detail=f"start_date must be before or equal to end_date. Got: start_date='{start_date}', end_date='{end_date}'"
        )


@router.get("/summary", response_model=ComparisonResponse)
async def comparison_summary(
    start_date: Annotated[str, Query(description="Start date of the comparison period. Format: YYYY-MM-DD", openapi_examples={"example": {"value": "2026-04-07"}})],
    end_date: Annotated[str, Query(description="End date of the comparison period. Format: YYYY-MM-DD", openapi_examples={"example": {"value": "2026-04-10"}})],
    account: Annotated[str, Query(description="Account name to filter by, or 'All' for all accounts.")] = "All",
):
    """
    Compare total AWS costs between selected period and prior period of equal length.
    """
    _validate_dates(start_date, end_date)
    try:
        return svc.build_comparison(start_date=start_date, end_date=end_date, account_name=account)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/detail", response_model=ComparisonResponse)
async def comparison_detail(
    start_date: Annotated[str, Query(description="Start date of the comparison period. Format: YYYY-MM-DD", openapi_examples={"example": {"value": "2026-04-07"}})],
    end_date: Annotated[str, Query(description="End date of the comparison period. Format: YYYY-MM-DD", openapi_examples={"example": {"value": "2026-04-10"}})],
    account: Annotated[str, Query(description="Account name to filter by, or 'All' for all accounts.")] = "All",
    service: Annotated[Optional[str], Query(description="AWS service product code (e.g. AmazonEC2, AmazonS3). Omit for all services.")] = None,
):
    """
    Compare costs for a specific service between selected period and prior period of equal length.
    """
    _validate_dates(start_date, end_date)
    try:
        return svc.build_comparison(
            start_date=start_date, end_date=end_date,
            account_name=account,
            product_code=service if service and service.lower() != "all" else None
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/dates", response_model=AvailableDatesResponse)
async def available_dates(
    account: Annotated[str, Query(description="Account name to filter by, or 'All' for all accounts.")] = "All",
):
    """
    Return all dates that have cost data.
    Used to populate the date picker in the frontend.
    """
    try:
        return svc.get_available_dates(account_name=account)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
