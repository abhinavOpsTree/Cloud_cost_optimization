"""
Hourly Cost Pattern Classifier
Pure Python — no DB calls. Classifies a 24-hour cost array into one of 5 shapes.

Patterns:
  No Activity — all hours are zero
  Flat        — cost is stable all day (stddev < 15% of mean)
  Spiky       — one or more hours are extreme outliers (> mean + 2×stddev)
  U-curve     — morning AND evening both clearly higher than midday (>1.3x)
  V-curve     — morning dominates, midday low, evening partially recovers
  Irregular   — none of the above patterns match
"""
from typing import List


def classify(hourly_costs: List[float]) -> str:
    # Pad to 24 hours
    costs = list(hourly_costs) + [0.0] * (24 - len(hourly_costs))
    costs = costs[:24]

    total = sum(costs)
    if total == 0:
        return "No Activity"           # Fix 5: was "Flat" — wrong label for zero days

    mean = total / 24
    variance = sum((c - mean) ** 2 for c in costs) / 24
    std_dev = variance ** 0.5

    # Flat: very low variance relative to mean
    if mean > 0 and (std_dev / mean) < 0.15:
        return "Flat"

    # Spiky: at least one hour is a strong outlier
    if any(c > mean + 2 * std_dev for c in costs):
        return "Spiky"

    morning = sum(costs[0:8])  / 8
    midday  = sum(costs[8:16]) / 8
    evening = sum(costs[16:24]) / 8

    # Fix 5: strict thresholds — U-curve requires BOTH edges clearly above midday
    if morning > midday * 1.3 and evening > midday * 1.3:
        return "U-curve"

    # Fix 5: V-curve — morning dominates, mutually exclusive from U-curve
    if morning > midday * 1.2 and morning > evening * 1.2 and evening > midday:
        return "V-curve"

    return "Irregular"
