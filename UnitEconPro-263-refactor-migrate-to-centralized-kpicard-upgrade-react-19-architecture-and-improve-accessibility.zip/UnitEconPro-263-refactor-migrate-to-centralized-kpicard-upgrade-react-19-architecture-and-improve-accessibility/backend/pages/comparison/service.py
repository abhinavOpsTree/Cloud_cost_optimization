"""
Day-over-Day Cost Comparison — Orchestration Service
Fetches data for two days, merges, ranks drivers, classifies patterns.

Security: all user-supplied values are passed as ClickHouse bind parameters,
never interpolated into SQL strings.
"""
from core import database as db
from . import queries as q
from . import pattern_analyzer
from .schemas import (
    ComparisonResponse, HourlyPoint, DriverItem,
    ServiceBreakdown, AvailableDatesResponse
)


def _build_params(
    account_name: str,
    product_code: str,
    day: str = None,
    day_a: str = None,
    day_b: str = None,
) -> dict:
    """
    Build the ClickHouse params dict for all comparison queries.
    account_all=1 means 'no account filter' — avoids any string injection.
    service_all=1 means 'no service filter'.
    """
    return {
        "account_name": account_name if account_name and account_name != "All" else "",
        "account_all":  1 if (not account_name or account_name == "All") else 0,
        "product_code": product_code or "",
        "service_all":  1 if not product_code else 0,
        "day":          day or "",
        "day_a":        day_a or "",
        "day_b":        day_b or "",
    }


def _hourly_map(rows) -> dict:
    return {int(r["hour"]): float(r["cost"]) for r in rows}


def _hourly_list(cost_map: dict) -> list:
    return [cost_map.get(h, 0.0) for h in range(24)]


def build_comparison(
    day_a: str,
    day_b: str,
    account_name: str = "All",
    product_code: str = None
) -> ComparisonResponse:

    # ── Hourly costs for both days ────────────────────────────────────
    hourly_a_rows = db.query(
        q.COMPARISON_HOURLY,
        params=_build_params(account_name, product_code, day=day_a)
    )
    hourly_b_rows = db.query(
        q.COMPARISON_HOURLY,
        params=_build_params(account_name, product_code, day=day_b)
    )

    map_a = _hourly_map(hourly_a_rows)
    map_b = _hourly_map(hourly_b_rows)

    cost_a = round(sum(map_a.values()), 4)
    cost_b = round(sum(map_b.values()), 4)
    delta  = round(cost_b - cost_a, 4)
    pct_change = round(((cost_b - cost_a) / cost_a) * 100, 2) if cost_a else 0.0

    # ── Pattern classification ────────────────────────────────────────
    pattern_a = pattern_analyzer.classify(_hourly_list(map_a))
    pattern_b = pattern_analyzer.classify(_hourly_list(map_b))

    # ── Hourly merge for chart ────────────────────────────────────────
    hourly = [
        HourlyPoint(hour=h, cost_a=map_a.get(h, 0.0), cost_b=map_b.get(h, 0.0))
        for h in range(24)
    ]

    # ── Top drivers ───────────────────────────────────────────────────
    driver_rows = db.query(
        q.COMPARISON_TOP_DRIVERS,
        params=_build_params(account_name, product_code, day_a=day_a, day_b=day_b)
    )
    top_drivers = [
        DriverItem(
            service=r["service"],
            operation=r["operation"],
            cost_a=float(r["cost_a"]),
            cost_b=float(r["cost_b"]),
            delta=float(r["delta"])
        )
        for r in driver_rows
    ]

    # ── Per-service breakdown (only when not drilling into one service) ──
    by_service = []
    available_services = []

    if not product_code:
        svc_a_rows = db.query(
            q.COMPARISON_DAILY_BY_SERVICE,
            params=_build_params(account_name, None, day=day_a)
        )
        svc_b_rows = db.query(
            q.COMPARISON_DAILY_BY_SERVICE,
            params=_build_params(account_name, None, day=day_b)
        )

        svc_a = {r["service"]: float(r["cost"]) for r in svc_a_rows}
        svc_b = {r["service"]: float(r["cost"]) for r in svc_b_rows}
        all_services = sorted(set(svc_a) | set(svc_b))
        available_services = all_services

        for service_name in all_services:
            ca  = svc_a.get(service_name, 0.0)
            cb  = svc_b.get(service_name, 0.0)
            d   = round(cb - ca, 4)
            pct = round(((cb - ca) / ca) * 100, 2) if ca else None
            by_service.append(ServiceBreakdown(
                service=service_name, cost_a=ca, cost_b=cb, delta=d, pct_change=pct
            ))

        by_service.sort(key=lambda x: abs(x.delta), reverse=True)

    return ComparisonResponse(
        day_a=day_a,
        day_b=day_b,
        cost_a=cost_a,
        cost_b=cost_b,
        delta=delta,
        pct_change=pct_change,
        pattern_a=pattern_a,
        pattern_b=pattern_b,
        top_drivers=top_drivers,
        hourly=hourly,
        by_service=by_service,
        available_services=available_services
    )


def get_available_dates(account_name: str = "All") -> AvailableDatesResponse:
    rows = db.query(
        q.COMPARISON_AVAILABLE_DATES,
        params=_build_params(account_name, None)
    )
    return AvailableDatesResponse(dates=[r["date"] for r in rows])
