"""
Day-over-Day Cost Comparison — SQL Queries
All queries use ClickHouse named parameters {name:Type} — zero string formatting
for user-supplied values. account_name and product_code are passed via params dict.
"""

# Total cost for a single day, broken down by service
COMPARISON_DAILY_BY_SERVICE = """
    SELECT
        product_code AS service,
        ROUND(SUM(cost_unblended), 4) AS cost
    FROM cost.service_costs
    WHERE toDate(usage_start_ts) = {day:String}
      AND cost_unblended > 0
      AND ({account_all:UInt8} OR account_name = {account_name:String})
      AND ({service_all:UInt8} OR product_code = {product_code:String})
    GROUP BY product_code
    ORDER BY cost DESC
"""

# Hourly cost for a single day (0–23)
COMPARISON_HOURLY = """
    SELECT
        toHour(usage_start_ts) AS hour,
        ROUND(SUM(cost_unblended), 4) AS cost
    FROM cost.service_costs
    WHERE toDate(usage_start_ts) = {day:String}
      AND cost_unblended > 0
      AND ({account_all:UInt8} OR account_name = {account_name:String})
      AND ({service_all:UInt8} OR product_code = {product_code:String})
    GROUP BY hour
    ORDER BY hour ASC
"""

# Top cost drivers: (service, operation) ranked by absolute delta between two days
COMPARISON_TOP_DRIVERS = """
    WITH day_a AS (
        SELECT
            product_code AS service,
            operation,
            ROUND(SUM(cost_unblended), 4) AS cost
        FROM cost.service_costs
        WHERE toDate(usage_start_ts) = {day_a:String}
          AND cost_unblended > 0
          AND ({account_all:UInt8} OR account_name = {account_name:String})
          AND ({service_all:UInt8} OR product_code = {product_code:String})
        GROUP BY product_code, operation
    ),
    day_b AS (
        SELECT
            product_code AS service,
            operation,
            ROUND(SUM(cost_unblended), 4) AS cost
        FROM cost.service_costs
        WHERE toDate(usage_start_ts) = {day_b:String}
          AND cost_unblended > 0
          AND ({account_all:UInt8} OR account_name = {account_name:String})
          AND ({service_all:UInt8} OR product_code = {product_code:String})
        GROUP BY product_code, operation
    ),
    all_keys AS (
        SELECT service, operation FROM day_a
        UNION DISTINCT
        SELECT service, operation FROM day_b
    )
    SELECT
        k.service    AS service,
        k.operation  AS operation,
        ROUND(COALESCE(a.cost, 0), 4)                        AS cost_a,
        ROUND(COALESCE(b.cost, 0), 4)                        AS cost_b,
        ROUND(COALESCE(b.cost, 0) - COALESCE(a.cost, 0), 4) AS delta
    FROM all_keys k
    LEFT JOIN day_a a ON k.service = a.service AND k.operation = a.operation
    LEFT JOIN day_b b ON k.service = b.service AND k.operation = b.operation
    ORDER BY abs(delta) DESC
    LIMIT 10
"""

# All distinct dates that have cost data — for the date picker
COMPARISON_AVAILABLE_DATES = """
    SELECT DISTINCT
        toString(toDate(usage_start_ts)) AS date
    FROM cost.service_costs
    WHERE cost_unblended > 0
      AND ({account_all:UInt8} OR account_name = {account_name:String})
    ORDER BY date DESC
    LIMIT 365
"""
