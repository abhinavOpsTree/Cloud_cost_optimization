"""
Day-over-Day Cost Comparison — Pydantic Schemas
"""
from pydantic import BaseModel
from typing import Optional, List


class HourlyPoint(BaseModel):
    hour: int
    cost_a: float
    cost_b: float


class DriverItem(BaseModel):
    service: str
    operation: str
    cost_a: float
    cost_b: float
    delta: float


class ServiceBreakdown(BaseModel):
    service: str
    cost_a: float
    cost_b: float
    delta: float
    pct_change: Optional[float] = None


class ComparisonResponse(BaseModel):
    day_a: str
    day_b: str
    cost_a: float
    cost_b: float
    delta: float
    pct_change: float
    pattern_a: str                      # "Flat" | "Spiky" | "U-curve" | "V-curve"
    pattern_b: str
    top_drivers: List[DriverItem]
    hourly: List[HourlyPoint]
    by_service: List[ServiceBreakdown]
    available_services: List[str]


class AvailableDatesResponse(BaseModel):
    dates: List[str]
