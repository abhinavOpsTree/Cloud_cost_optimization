"""
Unified Analytics Endpoints
----------------------------
Two generic endpoints that accept a `service` query param so the frontend
doesn't need to call a different URL per service:

  GET /api/v1/analytics/trend?service=ec2
  GET /api/v1/analytics/breakdown?service=ec2&dimension=region

Supported services: ec2 | ecr | eks | ecs | s3 | ebs | rds | vpc | elb | cloudwatch | data-transfer
"""
import math
import logging
from enum import Enum
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel

from core import database as db
from core.dependencies import AccountCtx, AccountRange, DateCtx, account_only_params, date_range_params

# ── per-service query modules ────────────────────────────
from pages.compute.ec2 import queries as ec2_q
from pages.compute.ecr import queries as ecr_q
from pages.compute.eks import queries as eks_q
from pages.compute.ecs import queries as ecs_q
from pages.storage.s3 import queries as s3_q
from pages.storage.ebs import queries as ebs_q
from pages.databases.rds import queries as rds_q
from pages.networking.vpc import queries as vpc_q
from pages.networking.elb import queries as elb_q
from pages.networking.datatransfer import queries as dt_q
from pages.monitoring.cloudwatch import queries as cw_q

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v1/analytics", tags=["Unified"])


def _safe(v: object) -> float:
    """Guard against NaN/Inf that ClickHouse returns when dividing by zero in empty windows."""
    f = float(v or 0)
    return 0.0 if not math.isfinite(f) else f


# ═══════════════════════════════════════════════════════════
#  Response schemas
# ═══════════════════════════════════════════════════════════

class TrendPoint(BaseModel):
    date: str
    cost: float


class BreakdownItem(BaseModel):
    name: str
    cost: float
    usage: Optional[float] = None
    unit: Optional[str] = None


class ServiceFinancials(BaseModel):
    yesterday_cost: float
    last_week_cost: float
    this_week_cost: float
    last_month_cost: float
    mtd_cost: float
    daily_run_rate: float
    predicted_week_cost: float
    predicted_month_cost: float


class ServiceName(str, Enum):
    ec2           = "ec2"
    ecr           = "ecr"
    eks           = "eks"
    ecs           = "ecs"
    s3            = "s3"
    ebs           = "ebs"
    rds           = "rds"
    vpc           = "vpc"
    elb           = "elb"
    cloudwatch    = "cloudwatch"
    data_transfer = "data-transfer"


# Fix: ecs was missing from _PRODUCT_CODE — caused KeyError at runtime
# when /analytics/trend?service=ecs or /analytics/financials?service=ecs was called.
_PRODUCT_CODE: dict[ServiceName, str] = {
    ServiceName.ec2:        "AmazonEC2",
    ServiceName.ecr:        "AmazonECR",
    ServiceName.eks:        "AmazonEKS",
    ServiceName.ecs:        "AmazonECS",
    ServiceName.s3:         "AmazonS3",
    ServiceName.ebs:        "AmazonEBS",
    ServiceName.rds:        "AmazonRDS",
    ServiceName.vpc:        "AmazonVPC",
    ServiceName.elb:        "AWSELB",
    ServiceName.cloudwatch: "AmazonCloudWatch",
    # data_transfer intentionally omitted — uses usage_type filter, not product_code
}


# ── Generic trend SQL ────────────────────────────────────
# Fix: {start} and {end} are now ClickHouse bound parameters ({start:DateTime},
# {end:DateTime}) instead of Python-interpolated strings. Callers pass
# params={"start": ctx.start, "end": ctx.end, "product_code": ..., **ctx.params}.
# Double braces on {product_code:String} survive str.format(account_filter=...).
_TREND_SQL = """
    SELECT
        toDate(usage_start_ts) AS date_obj,
        formatDateTime(date_obj, '%Y-%m-%d') AS date,
        ROUND(SUM(cost_unblended), 2) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= {{start:DateTime}} AND usage_start_ts <= {{end:DateTime}}
      AND product_code = {{product_code:String}}
      {account_filter}
    GROUP BY date_obj
    ORDER BY date_obj ASC
"""

# Trend SQL for data-transfer — filters by usage_type rather than product_code
# Fix: bound DateTime params instead of interpolated strings.
_DT_TREND_SQL = """
    SELECT
        toDate(usage_start_ts) AS date_obj,
        formatDateTime(date_obj, '%Y-%m-%d') AS date,
        ROUND(SUM(cost_unblended), 2) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= {{start:DateTime}} AND usage_start_ts <= {{end:DateTime}}
      AND usage_type LIKE '%Bytes%'
      {account_filter}
    GROUP BY date_obj
    ORDER BY date_obj ASC
"""


# ── Per-service breakdown map  {service → {dimension → sql}} ────────────────
_BREAKDOWN: dict[ServiceName, dict[str, str]] = {
    ServiceName.ec2: {
        "account":              ec2_q.EC2_BY_ACCOUNT,
        "region":               ec2_q.EC2_BY_REGION,
        "availability-zone":    ec2_q.EC2_BY_AZ,
        "instance-family":      ec2_q.EC2_BY_INSTANCE_FAMILY,
        "instance-type":        ec2_q.EC2_BY_INSTANCE_TYPE,
        "instance-type-family": ec2_q.EC2_BY_INSTANCE_TYPE_FAMILY,
        "pricing-model":        ec2_q.EC2_BY_PRICING_MODEL,
    },
    ServiceName.ecr: {
        "usage-type": ecr_q.ECR_BY_USAGE_TYPE,
        "region":     ecr_q.ECR_BY_REGION,
        "account":    ecr_q.ECR_BY_ACCOUNT,
    },
    ServiceName.eks: {
        "cluster":       eks_q.EKS_BY_CLUSTER,
        "region":        eks_q.EKS_BY_REGION,
        "account":       eks_q.EKS_BY_ACCOUNT,
        "operation":     eks_q.EKS_BY_OPERATION,
        "usage-type":    eks_q.EKS_BY_USAGE_TYPE,
        "pricing-model": eks_q.EKS_BY_PRICING_MODEL,
    },
    ServiceName.s3: {
        "bucket":             s3_q.S3_BY_BUCKET,
        "region":             s3_q.S3_BY_REGION,
        "account":            s3_q.S3_BY_ACCOUNT,
        "operation":          s3_q.S3_BY_OPERATION,
        "usage-type":         s3_q.S3_BY_USAGE_TYPE,
        "pricing-model":      s3_q.S3_BY_PRICING_MODEL,
        "request-type":       s3_q.S3_BY_REQUEST_TYPE,
        "transfer-direction": s3_q.S3_BY_TRANSFER_DIRECTION,
    },
    ServiceName.ebs: {
        "volume-type":    ebs_q.EBS_BY_VOLUME_TYPE,
        "region":         ebs_q.EBS_BY_REGION,
        "account":        ebs_q.EBS_BY_ACCOUNT,
        "operation":      ebs_q.EBS_BY_OPERATION,
        "product-family": ebs_q.EBS_BY_PRODUCT_FAMILY,
        "usage-type":     ebs_q.EBS_BY_USAGE_TYPE,
        "pricing-model":  ebs_q.EBS_BY_PRICING_MODEL,
    },
    ServiceName.rds: {
        "engine":        rds_q.RDS_BY_ENGINE,
        "instance-type": rds_q.RDS_BY_INSTANCE_TYPE,
        "region":        rds_q.RDS_BY_REGION,
        "account":       rds_q.RDS_BY_ACCOUNT,
        "operation":     rds_q.RDS_BY_OPERATION,
        "usage-type":    rds_q.RDS_BY_USAGE_TYPE,
        "pricing-model": rds_q.RDS_BY_PRICING_MODEL,
    },
    ServiceName.vpc: {
        "account":       vpc_q.VPC_BY_ACCOUNT,
        "region":        vpc_q.VPC_BY_REGION,
        "usage-type":    vpc_q.VPC_BY_USAGE_TYPE,
        "operation":     vpc_q.VPC_BY_OPERATION,
        "pricing-model": vpc_q.VPC_BY_PRICING_MODEL,
    },
    ServiceName.elb: {
        "region":     elb_q.ELB_BY_REGION,
        "account":    elb_q.ELB_BY_ACCOUNT,
        "usage-type": elb_q.ELB_BY_USAGE_TYPE,
        "family":     elb_q.ELB_BY_FAMILY,
    },
    # ECS breakdown queries moved to ecs/queries.py — inline SQL removed.
    # The two inline strings that were here caused inconsistency with every
    # other service that uses its own queries module.
    ServiceName.ecs: {
        "region":        ecs_q.ECS_BY_REGION,
        "account":       ecs_q.ECS_BY_ACCOUNT,
        "launch-type":   ecs_q.ECS_BY_LAUNCH_TYPE,
        "usage-type":    ecs_q.ECS_BY_USAGE_TYPE,
        "pricing-model": ecs_q.ECS_BY_PRICING_MODEL,
    },
    ServiceName.cloudwatch: {
        "cost-group":  cw_q.CW_BY_GROUP,
        "region":      cw_q.CW_BY_REGION,
        "account":     cw_q.CW_BY_ACCOUNT,
        "operation":   cw_q.CW_BY_OPERATION,
        "log-prefix":  cw_q.CW_BY_LOG_PREFIX,
        "eks-cluster": cw_q.CW_BY_EKS_CLUSTER,
    },
    ServiceName.data_transfer: {
        "direction":    dt_q.DT_BY_DIRECTION,
        "service":      dt_q.DT_BY_SERVICE,
        "region":       dt_q.DT_BY_REGION,
        "account":      dt_q.DT_BY_ACCOUNT,
        "usage-type":   dt_q.DT_BY_USAGE_TYPE,
        "inter-region": dt_q.DT_INTER_REGION,
    },
}


# ── Service Financials SQL ───────────────────────────────
# Fix (OPT 1): hist_base scanned once — feeds both hist avg and weekend factor.
#
# Fix (OPT 2): effective_rate CTE dropped entirely. It contained three scalar
# subqueries — (SELECT n FROM days_elapsed), (SELECT avg_daily FROM hist),
# (SELECT true_daily_rate FROM mtd) — which re-executed those CTEs on every
# reference under ClickHouse's default CTE inlining (allow_experimental_analyzer=0).
# The CASE expression is now computed directly in the final SELECT after CROSS JOIN,
# where all single-row CTEs are already materialised as columns.
#
# NOTE: {product_filter} and {account_filter} are the only Python-interpolated
# fragments — they are hardcoded SQL snippets (not user input), so this is safe.
# All other filtering uses ClickHouse bound parameters passed via params={}.
_SERVICE_FINANCIALS_SQL = """
WITH
    days_elapsed AS (
        SELECT dateDiff('day', toStartOfMonth(today()), today()) AS n
    ),

    -- Single scan of last 4 months — feeds both avg_daily and weekend factor.
    hist_base AS (
        SELECT
            toDate(usage_start_ts)              AS date,
            toDayOfWeek(toDate(usage_start_ts)) AS dow,
            SUM(cost_unblended)                 AS daily_cost
        FROM cost.service_costs
        WHERE usage_start_ts >= date_sub(MONTH, 4, toStartOfMonth(today()))
          AND usage_start_ts <  toStartOfMonth(today())
          {product_filter}
          {account_filter}
        GROUP BY date
    ),

    -- Merged CTE: computes avg_daily and weekend factor in a single pass over hist_base.
    -- Previously split into hist + weekend_factor_calc — two separate CTEs both reading
    -- hist_base. Under ClickHouse's default CTE inlining (allow_experimental_analyzer=0),
    -- each reference to hist_base inlines the full subquery, causing hist_base to be
    -- scanned twice (4 months of data × 2). Merging into one CTE eliminates the duplicate scan.
    hist_and_factor AS (
        SELECT
            COALESCE(SUM(daily_cost) / GREATEST(COUNT(*), 1), 0) AS avg_daily,
            COALESCE(
                if(
                    isNaN(avgIf(daily_cost, dow IN (6, 7))) OR isNaN(avgIf(daily_cost, dow NOT IN (6, 7))) OR avgIf(daily_cost, dow NOT IN (6, 7)) = 0,
                    NULL,
                    avgIf(daily_cost, dow IN (6, 7)) / avgIf(daily_cost, dow NOT IN (6, 7))
                ),
                1.0
            ) AS factor
        FROM hist_base
    ),

    mtd AS (
        SELECT
            SUM(cost_unblended)                                                       AS mtd_cost,
            MAX(toDate(usage_start_ts))                                               AS last_data_date,
            SUM(cost_unblended) / GREATEST(dateDiff('day', toStartOfMonth(today()), today()), 1) AS true_daily_rate
        FROM cost.service_costs
        WHERE usage_start_ts >= toStartOfMonth(now())
          AND usage_start_ts <  today() + 1
          {product_filter}
          {account_filter}
    ),

    remaining_days AS (
        SELECT
            countIf(toDayOfWeek(date) IN (6, 7))     AS weekend_remaining,
            countIf(toDayOfWeek(date) NOT IN (6, 7)) AS weekday_remaining
        FROM (
            SELECT date_add(DAY, number, toStartOfMonth(now())) AS date
            FROM numbers(0, 31)
            WHERE toMonth(date) = toMonth(now())
              AND date >= today()
        )
    ),

    -- Period costs — all computed in one scan via sumIf.
    -- Raw timestamp comparisons (no toDate() wrapping) allow partition pruning.
    period_costs AS (
        SELECT
            ROUND(sumIf(cost_unblended,
                usage_start_ts >= yesterday()
                AND usage_start_ts < today()), 2)                                  AS yesterday_cost,
            ROUND(sumIf(cost_unblended,
                usage_start_ts >= toMonday(today()) - 7
                AND usage_start_ts < toMonday(today())), 2)                        AS last_week_cost,
            ROUND(sumIf(cost_unblended,
                usage_start_ts >= toMonday(today())
                AND usage_start_ts < today() + 1), 2)                             AS this_week_cost,
            ROUND(sumIf(cost_unblended,
                usage_start_ts >= toStartOfMonth(today() - 32)
                AND usage_start_ts < toStartOfMonth(today())), 2)                  AS last_month_cost
        FROM cost.service_costs
        WHERE usage_start_ts >= toStartOfMonth(today() - 32)
          AND usage_start_ts < today() + 1
          {product_filter}
          {account_filter}
    )

-- All single-row CTEs materialised once via CROSS JOIN.
-- hf = hist_and_factor (merged CTE — one scan of hist_base instead of two).
-- SETTINGS allow_experimental_analyzer=1 enables ClickHouse's new query analyser
-- (stable since 23.8) which materialises CTEs instead of inlining them, eliminating
-- duplicate scans for hist_base, mtd, and period_costs.
SELECT
    COALESCE(p.yesterday_cost,  0)           AS yesterday_cost,
    COALESCE(p.last_week_cost,  0)           AS last_week_cost,
    COALESCE(p.this_week_cost,  0)           AS this_week_cost,
    COALESCE(p.last_month_cost, 0)           AS last_month_cost,
    ROUND(COALESCE(m.mtd_cost,        0), 2) AS mtd_cost,
    ROUND(COALESCE(m.true_daily_rate, 0), 2) AS daily_run_rate,
    ROUND(
        (5 * CASE WHEN de.n < 7
                  THEN COALESCE(if(isNaN(hf.avg_daily) OR hf.avg_daily = 0, NULL, hf.avg_daily), m.true_daily_rate)
                  ELSE m.true_daily_rate END) +
        (2 * CASE WHEN de.n < 7
                  THEN COALESCE(if(isNaN(hf.avg_daily) OR hf.avg_daily = 0, NULL, hf.avg_daily), m.true_daily_rate)
                  ELSE m.true_daily_rate END * hf.factor),
    2) AS predicted_week_cost,
    ROUND(
        COALESCE(m.mtd_cost, 0)
        + COALESCE(r.weekday_remaining, 0) *
          CASE WHEN de.n < 7
               THEN COALESCE(if(isNaN(hf.avg_daily) OR hf.avg_daily = 0, NULL, hf.avg_daily), m.true_daily_rate)
               ELSE m.true_daily_rate END
        + COALESCE(r.weekend_remaining, 0) *
          CASE WHEN de.n < 7
               THEN COALESCE(if(isNaN(hf.avg_daily) OR hf.avg_daily = 0, NULL, hf.avg_daily), m.true_daily_rate)
               ELSE m.true_daily_rate END * hf.factor,
    2) AS predicted_month_cost
FROM period_costs p
CROSS JOIN mtd m
CROSS JOIN hist_and_factor hf
CROSS JOIN days_elapsed de
CROSS JOIN remaining_days r
SETTINGS allow_experimental_analyzer=1
"""


# ═══════════════════════════════════════════════════════════
#  Endpoints
_SERVICE_FINANCIALS_SQL = """
WITH
    product_filter AS (
        SELECT 1
    ),
    days_elapsed AS (
        SELECT dateDiff('day', toStartOfMonth(today()), today()) AS n
    ),
    hist AS (
        SELECT
            COALESCE(SUM(cost_unblended) / GREATEST(COUNT(DISTINCT toDate(usage_start_ts)), 1), 0) AS avg_daily
        FROM cost.service_costs
        WHERE usage_start_ts >= date_sub(MONTH, 4, toStartOfMonth(today()))
          AND usage_start_ts <  toStartOfMonth(today())
          {product_filter}
          {account_filter}
    ),
    historical_daily_totals AS (
        SELECT
            toDate(usage_start_ts) AS date,
            SUM(cost_unblended) AS daily_cost,
            toDayOfWeek(date) AS day_of_week
        FROM cost.service_costs
        WHERE usage_start_ts >= date_sub(MONTH, 4, toStartOfMonth(today()))
          AND usage_start_ts <  toStartOfMonth(today())
          {product_filter}
          {account_filter}
        GROUP BY date
    ),
    weekend_factor_calc AS (
        SELECT
            if(isNaN(avgIf(daily_cost, day_of_week IN (6,7))), NULL, avgIf(daily_cost, day_of_week IN (6,7))) AS avg_weekend,
            if(isNaN(avgIf(daily_cost, day_of_week NOT IN (6,7))), NULL, avgIf(daily_cost, day_of_week NOT IN (6,7))) AS avg_weekday,
            COALESCE(avg_weekend / NULLIF(avg_weekday, 0), 1.0) AS factor
        FROM historical_daily_totals
    ),
    mtd AS (
        SELECT
            SUM(cost_unblended) AS mtd_cost,
            MAX(toDate(usage_start_ts)) AS last_data_date,
            SUM(cost_unblended) / GREATEST(COUNT(DISTINCT toDate(usage_start_ts)), 1) AS true_daily_rate
        FROM cost.service_costs
        WHERE usage_start_ts >= toStartOfMonth(now())
          AND usage_start_ts <  today() + 1
          {product_filter}
          {account_filter}
    ),
    remaining_days AS (
        SELECT
            countIf(toDayOfWeek(date) IN (6,7))     AS weekend_remaining,
            countIf(toDayOfWeek(date) NOT IN (6,7)) AS weekday_remaining
        FROM (
            SELECT date_add(DAY, number, toStartOfMonth(now())) AS date
            FROM numbers(0, 31)
            WHERE toMonth(date) = toMonth(now())
              AND date > (SELECT last_data_date FROM mtd)
        )
    ),
    effective_rate AS (
        SELECT
            CASE
                WHEN (SELECT n FROM days_elapsed) < 7
                THEN COALESCE(
                    if(isNaN((SELECT avg_daily FROM hist)), NULL, (SELECT avg_daily FROM hist)),
                    (SELECT true_daily_rate FROM mtd)
                )
                ELSE (SELECT true_daily_rate FROM mtd)
            END AS daily_rate
    ),
    yesterday AS (
        SELECT ROUND(SUM(cost_unblended), 2) AS cost
        FROM cost.service_costs
        WHERE usage_start_ts >= yesterday() AND usage_start_ts < today()
          {product_filter}
          {account_filter}
    ),
    this_week AS (
        SELECT ROUND(SUM(cost_unblended), 2) AS cost
        FROM cost.service_costs
        WHERE usage_start_ts >= toMonday(today()) AND usage_start_ts < today() + 1
          {product_filter}
          {account_filter}
    ),
    last_week AS (
        SELECT ROUND(SUM(cost_unblended), 2) AS cost
        FROM cost.service_costs
        WHERE usage_start_ts >= toMonday(today()) - 7
          AND usage_start_ts < toMonday(today())
          {product_filter}
          {account_filter}
    ),
    last_month AS (
        SELECT ROUND(SUM(cost_unblended), 2) AS cost
        FROM cost.service_costs
        WHERE usage_start_ts >= toStartOfMonth(today() - 32)
          AND usage_start_ts < toStartOfMonth(today())
          {product_filter}
          {account_filter}
    )
SELECT
    COALESCE((SELECT cost FROM yesterday), 0)    AS yesterday_cost,
    COALESCE((SELECT cost FROM last_week), 0)    AS last_week_cost,
    COALESCE((SELECT cost FROM this_week), 0)    AS this_week_cost,
    COALESCE((SELECT cost FROM last_month), 0)   AS last_month_cost,
    ROUND(COALESCE((SELECT mtd_cost FROM mtd), 0), 2)          AS mtd_cost,
    ROUND(COALESCE((SELECT true_daily_rate FROM mtd), 0), 2)   AS daily_run_rate,
    ROUND(
        (5 * (SELECT daily_rate FROM effective_rate)) +
        (2 * (SELECT daily_rate FROM effective_rate) * (SELECT factor FROM weekend_factor_calc)),
    2) AS predicted_week_cost,
    ROUND(
        COALESCE((SELECT mtd_cost FROM mtd), 0)
        + COALESCE((SELECT weekday_remaining FROM remaining_days), 0) * (SELECT daily_rate FROM effective_rate)
        + COALESCE((SELECT weekend_remaining FROM remaining_days), 0) * (SELECT daily_rate FROM effective_rate) * (SELECT factor FROM weekend_factor_calc),
    2) AS predicted_month_cost
"""


@router.get("/financials", response_model=ServiceFinancials)
async def get_service_financials(
    service: ServiceName = Query(..., description="AWS service name"),
    account: str = Query(default="All", description="Account name to filter by, or 'All' for all accounts."),
):
    """
    Financial summary for a specific service:
    yesterday, last week, this week, last month, MTD, daily run rate,
    predicted week cost, predicted month cost.

    Example: /api/v1/analytics/financials?service=ec2&account=opstree
    """
    import math

    def _safe(v):
        f = float(v or 0)
        return 0.0 if math.isnan(f) or math.isinf(f) else f

    account = " ".join(account.split()).replace("'", "''")
    account_filter = "" if account == "All" else f"AND account_name = '{account}'"

    if service == ServiceName.data_transfer:
        product_filter = "AND usage_type LIKE '%Bytes%'"
    else:
        product_filter = f"AND product_code = '{_PRODUCT_CODE[service]}'"

    sql = _SERVICE_FINANCIALS_SQL.format(
        product_filter=product_filter,
        account_filter=account_filter,
    )

    rows = db.query_safe(sql)
    if not rows:
        return ServiceFinancials(
            yesterday_cost=0.0, last_week_cost=0.0, this_week_cost=0.0,
            last_month_cost=0.0, mtd_cost=0.0, daily_run_rate=0.0,
            predicted_week_cost=0.0, predicted_month_cost=0.0,
        )

    r = rows[0]
    return ServiceFinancials(
        yesterday_cost=      _safe(r.get("yesterday_cost")),
        last_week_cost=      _safe(r.get("last_week_cost")),
        this_week_cost=      _safe(r.get("this_week_cost")),
        last_month_cost=     _safe(r.get("last_month_cost")),
        mtd_cost=            _safe(r.get("mtd_cost")),
        daily_run_rate=      _safe(r.get("daily_run_rate")),
        predicted_week_cost= _safe(r.get("predicted_week_cost")),
        predicted_month_cost=_safe(r.get("predicted_month_cost")),
    )


@router.get("/trend", response_model=list[TrendPoint])
async def get_service_trend(
    ctx: DateCtx,
    service: ServiceName = Query(..., description="AWS service name (ec2 | ecr | eks | ecs | s3 | ebs | rds | vpc | elb | cloudwatch | data-transfer)"),
):
    """
    Daily cost trend for any supported AWS service.

    Examples:
      /api/v1/analytics/trend?service=ec2&start_date=2026-01-01&end_date=2026-02-20
      /api/v1/analytics/trend?service=rds
    """
    # data-transfer spans multiple product_codes — uses usage_type pattern instead
    if service == ServiceName.data_transfer:
        sql = _DT_TREND_SQL.format(account_filter=ctx.account_filter)
        params = {"start": ctx.start, "end": ctx.end, **ctx.params}
    else:
        sql = _TREND_SQL.format(account_filter=ctx.account_filter)
        params = {"start": ctx.start, "end": ctx.end, "product_code": _PRODUCT_CODE[service], **ctx.params}
    try:
        rows = db.query_safe(sql, params)
    except Exception as e:
        logger.warning(f"Trend query failed for service={service}: {e}")
        return []
    return [TrendPoint(date=r["date"], cost=r["cost"]) for r in rows]


@router.get("/breakdown", response_model=list[BreakdownItem], response_model_exclude_none=True)
async def get_service_breakdown(
    ctx: DateCtx,
    service: ServiceName = Query(..., description="AWS service name (ec2 | ecr | eks | ecs | s3 | ebs | rds | vpc | elb | cloudwatch | data-transfer)"),
    dimension: str = Query(..., description="Dimension to group costs by — valid values depend on service"),
):
    """
    Cost breakdown for any service + dimension combination.

    Examples:
      /api/v1/analytics/breakdown?service=ec2&dimension=region&start_date=2026-01-01&end_date=2026-02-20
      /api/v1/analytics/breakdown?service=s3&dimension=bucket
      /api/v1/analytics/breakdown?service=rds&dimension=engine

    Invalid dimension returns 422 with the list of valid options for that service.
    """
    dim_map = _BREAKDOWN[service]
    if dimension not in dim_map:
        valid = sorted(dim_map.keys())
        raise HTTPException(
            status_code=422,
            detail={
                "error": f"Invalid dimension '{dimension}' for service '{service.value}'.",
                "valid_dimensions": valid,
            },
        )

    # RDS engine dimension: use metadata JOIN for accuracy, fall back to usage_type detection
    if service == ServiceName.rds and dimension == "engine":
        rows = db.query_safe(rds_q.RDS_BY_ENGINE_WITH_METADATA.format(
            start=ctx.start, end=ctx.end,
            account_filter_c=ctx.account_filter,
            account_filter=ctx.account_filter,
        ), ctx.params)
        if not rows or all(r.get("name", "") in ("", "RDS (Unknown/Deleted)") for r in rows):
            logger.warning(
                "RDS_BY_ENGINE_WITH_METADATA returned no useful engine names "
                "(account=%s, start=%s, end=%s) — falling back to usage_type detection. "
                "If this fires consistently, consider skipping the metadata query.",
                ctx.account_name, ctx.start, ctx.end,
            )
            rows = db.query_safe(rds_q.RDS_BY_ENGINE.format(
                start=ctx.start, end=ctx.end, account_filter=ctx.account_filter,
            ), ctx.params)
    else:
        sql = dim_map[dimension].format(start=ctx.start, end=ctx.end, account_filter=ctx.account_filter)
        rows = db.query_safe(sql, ctx.params)

    return [
        BreakdownItem(
            name=r["name"],
            cost=r["cost"],
            usage=r.get("usage"),
            unit=r.get("unit"),
        )
        for r in rows
    ]
