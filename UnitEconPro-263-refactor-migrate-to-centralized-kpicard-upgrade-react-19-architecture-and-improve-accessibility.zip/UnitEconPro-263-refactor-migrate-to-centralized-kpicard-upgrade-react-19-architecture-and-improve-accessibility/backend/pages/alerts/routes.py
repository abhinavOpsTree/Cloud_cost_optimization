from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import List, Optional
from core.database import query as db_query

router = APIRouter(prefix="/api/v1/alerts", tags=["Alerts"])

NO_BASELINE = -1.0

_SEVERITY_TAG = {
    "CRITICAL":    "High",
    "NO_BASELINE": "High",
    "HIGH":        "High",
    "WARNING":     "Medium",
    "INFO":        "Low",
}


def _tag(severity: str) -> str:
    return _SEVERITY_TAG.get(severity, "Medium")


def _description(service: str, cost_today: float, mean_cost: float, severity: str, upper_threshold: float = 0.0) -> str:
    if service == 'budget':
        pct = round(cost_today / upper_threshold * 100, 1) if upper_threshold > 0 else 0
        return f"MTD spend ${cost_today:.2f} is {pct}% of ${upper_threshold:.0f} budget"
    if mean_cost <= NO_BASELINE:
        return f"New service detected: ${cost_today:.2f}"
    return f"Spiked to ${cost_today:.2f} (mean ${mean_cost:.2f})"


def _fmt_dt(dt) -> Optional[str]:
    return str(dt) if dt else None


# ── Schemas ───────────────────────────────────────────────────────────────────

class DashboardAlert(BaseModel):
    alert_id: str
    service: str
    tag: str
    description: str
    fired_at: str
    last_updated: str


class AlertItem(BaseModel):
    alert_id: str
    service: str
    severity: str
    status: str
    cost_today: float
    mean_cost: float
    upper_threshold: float
    z_score: float
    pct_above_mean: float
    fired_at: str
    updated_at: str


class AlertDetail(BaseModel):
    alert_id: str
    service: str
    severity: str
    status: str
    cost_today: float
    mean_cost: float
    std_dev: float
    upper_threshold: float
    z_score: float
    pct_above_mean: float
    fired_at: str
    updated_at: str
    resolved_at: Optional[str] = None
    days_open: int
    dollar_impact: float
    previous_alert_count: int


# ── Dashboard: minimal card feed ──────────────────────────────────────────────

@router.get("/dashboard", response_model=List[DashboardAlert])
async def get_dashboard_alerts(account_name: Optional[str] = None):
    """Minimal alert feed for dashboard cards."""
    rows = db_query("""
        SELECT alert_id, service, severity, cost_today, mean_cost, upper_threshold, fired_at, updated_at
        FROM cost.alert_events
        WHERE status = 'OPEN'
          AND ({account_name:String} = '' OR account_name = {account_name:String})
        ORDER BY updated_at DESC
        LIMIT 1 BY alert_id
    """, {"account_name": account_name or ""})
    rows = sorted(rows, key=lambda r: (0 if r['severity']=='CRITICAL' else 1 if r['severity']=='HIGH' else 2 if r['severity']=='WARNING' else 3, -float(r['cost_today'])))

    return [
        {
            "alert_id":    r["alert_id"],
            "service":     r["service"],
            "tag":         _tag(r["severity"]),
            "description": _description(r["service"], float(r["cost_today"]), float(r["mean_cost"]), r["severity"], float(r["upper_threshold"])),
            "fired_at":    str(r["fired_at"]).split(" ")[0],
            "last_updated": str(r["updated_at"]).split(" ")[0],
        }
        for r in rows
    ]


# ── Alert history for account + service ──────────────────────────────────────

@router.get("/by-account/{account_name}/service/{service}", response_model=List[AlertItem])
async def get_alerts_by_service(account_name: str, service: str):
    """Full alert history (all statuses) for a specific account and service."""
    rows = db_query("""
        SELECT
            alert_id, service, severity, status,
            cost_today, mean_cost, upper_threshold, z_score, pct_above_mean,
            fired_at, updated_at
        FROM cost.alert_events FINAL
        WHERE account_name = {account_name:String}
          AND service = {service:String}
        ORDER BY fired_at DESC
        LIMIT 50
    """, {"account_name": account_name, "service": service})

    return [
        {
            "alert_id":       r["alert_id"],
            "service":        r["service"],
            "severity":       r["severity"],
            "status":         r["status"],
            "cost_today":     float(r["cost_today"]),
            "mean_cost":      float(r["mean_cost"]),
            "upper_threshold": float(r["upper_threshold"]),
            "z_score":        float(r["z_score"]),
            "pct_above_mean": float(r["pct_above_mean"]),
            "fired_at":       _fmt_dt(r["fired_at"]),
            "updated_at":     _fmt_dt(r["updated_at"]),
        }
        for r in rows
    ]


# ── Full detail for a single alert ───────────────────────────────────────────

@router.get("/{alert_id}", response_model=AlertDetail)
async def get_alert_detail(alert_id: str):
    """Full detail + context: days open, dollar impact, repeat count."""
    rows = db_query("""
        SELECT
            alert_id, account_id, service, severity, status,
            cost_today, mean_cost, std_dev, upper_threshold, z_score, pct_above_mean,
            fired_at, updated_at, resolved_at
        FROM cost.alert_events FINAL
        WHERE alert_id = {alert_id:String}
    """, {"alert_id": alert_id})

    if not rows:
        raise HTTPException(status_code=404, detail="Alert not found")

    r = rows[0]
    cost_today = float(r["cost_today"])
    mean_cost  = float(r["mean_cost"])

    history = db_query("""
        SELECT count() AS cnt
        FROM cost.alert_events FINAL
        WHERE account_id = {account_id:String}
          AND service   = {service:String}
          AND alert_id != {alert_id:String}
          AND fired_at >= now() - INTERVAL 30 DAY
    """, {"account_id": r["account_id"], "service": r["service"], "alert_id": alert_id})

    days_open_rows = db_query("""
        SELECT dateDiff('day', fired_at, now()) AS days_open
        FROM cost.alert_events FINAL
        WHERE alert_id = {alert_id:String}
    """, {"alert_id": alert_id})

    return {
        "alert_id":            r["alert_id"],
        "service":             r["service"],
        "severity":            r["severity"],
        "status":              r["status"],
        "cost_today":          cost_today,
        "mean_cost":           mean_cost,
        "std_dev":             float(r["std_dev"]),
        "upper_threshold":     float(r["upper_threshold"]),
        "z_score":             float(r["z_score"]),
        "pct_above_mean":      float(r["pct_above_mean"]),
        "fired_at":            _fmt_dt(r["fired_at"]),
        "updated_at":          _fmt_dt(r["updated_at"]),
        "resolved_at":         _fmt_dt(r.get("resolved_at")),
        "days_open":           int(days_open_rows[0]["days_open"]) if days_open_rows else 0,
        "dollar_impact":       round(cost_today - mean_cost, 2) if mean_cost > 0 else cost_today,
        "previous_alert_count": int(history[0]["cnt"]) if history else 0,
    }
