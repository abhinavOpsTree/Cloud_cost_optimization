"""
Alert Rules API — Client-level threshold configuration (Issue #42)

Priority resolution during detection:
  service-specific → account-wide ALL → global default (sensitivity=2.0, min_impact=$10)
"""
from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel, field_validator
from typing import Optional, Annotated
from datetime import datetime, timezone
import uuid

from core.database import query as db_query, query_safe

router = APIRouter(prefix="/api/v1/alerts/rules", tags=["Alert Rules"])

AccountParam = Annotated[str, Query(description="Account name (e.g. opstree, tripare-dev)")]


# ── Schemas ───────────────────────────────────────────────────────────────────

class AlertRuleCreate(BaseModel):
    service: str        # product_code like 'AmazonEC2', or 'ALL' for account-wide
    sensitivity: float  # z-score multiplier, e.g. 2.0 = alert at 2 stddevs above mean
    min_impact: float   # minimum dollar impact to trigger alert, e.g. 10.0
    enabled: bool = True

    @field_validator("sensitivity")
    @classmethod
    def sensitivity_range(cls, v):
        if not 0.5 <= v <= 10.0:
            raise ValueError("sensitivity must be between 0.5 and 10.0")
        return v

    @field_validator("min_impact")
    @classmethod
    def min_impact_positive(cls, v):
        if v < 0:
            raise ValueError("min_impact must be >= 0")
        return v


class AlertRuleResponse(BaseModel):
    rule_id: str
    account_id: str
    service: str
    sensitivity: float
    min_impact: float
    enabled: bool
    created_at: str
    updated_at: str


# ── Endpoints ─────────────────────────────────────────────────────────────────

@router.get("/", response_model=list[AlertRuleResponse])
def get_rules(account_name: AccountParam):
    """Get all alert rules for an account."""
    rows = db_query(
        "SELECT rule_id, account_id, service, sensitivity, min_impact, enabled, created_at, updated_at "
        "FROM cost.alert_rules FINAL "
        "WHERE account_id = (SELECT aws_account_id FROM cost.accounts FINAL WHERE account_name = {account_name:String} AND is_deleted=0 LIMIT 1) "
        "AND enabled = 1 ORDER BY service",
        {"account_name": account_name}
    )
    return [
        AlertRuleResponse(
            rule_id=r["rule_id"],
            account_id=r["account_id"],
            service=r["service"],
            sensitivity=float(r["sensitivity"]),
            min_impact=float(r["min_impact"]),
            enabled=bool(r["enabled"]),
            created_at=str(r["created_at"]),
            updated_at=str(r["updated_at"]),
        )
        for r in rows
    ]


@router.post("/", response_model=AlertRuleResponse, status_code=201)
def create_rule(account_name: AccountParam, payload: AlertRuleCreate):
    """
    Create or update an alert rule. Pass account_name as query param.
    Use service='ALL' for account-wide default.
    """
    # Auto-resolve aws_account_id from account name
    acc_rows = db_query(
        "SELECT aws_account_id FROM cost.accounts FINAL WHERE account_name = {account_name:String} AND is_deleted=0 LIMIT 1",
        {"account_name": account_name}
    )
    if not acc_rows:
        raise HTTPException(status_code=404, detail=f"Account '{account_name}' not found")
    account_id = acc_rows[0]["aws_account_id"]

    now = datetime.now(timezone.utc).replace(tzinfo=None)
    existing = db_query(
        "SELECT rule_id FROM cost.alert_rules FINAL WHERE account_id = {account_id:String} AND service = {service:String} LIMIT 1",
        {"account_id": account_id, "service": payload.service}
    )
    rule_id = existing[0]["rule_id"] if existing else str(uuid.uuid4())

    db_query(
        "INSERT INTO cost.alert_rules (rule_id, account_id, service, sensitivity, min_impact, enabled, created_at, updated_at) "
        "VALUES ({rule_id:String}, {account_id:String}, {service:String}, {sensitivity:Float32}, "
        "{min_impact:Float64}, {enabled:UInt8}, {created_at:DateTime}, {updated_at:DateTime})",
        {
            "rule_id":     rule_id,
            "account_id":  account_id,
            "service":     payload.service,
            "sensitivity": payload.sensitivity,
            "min_impact":  payload.min_impact,
            "enabled":     1 if payload.enabled else 0,
            "created_at":  now,
            "updated_at":  now,
        }
    )
    return AlertRuleResponse(
        rule_id=rule_id,
        account_id=account_id,
        service=payload.service,
        sensitivity=payload.sensitivity,
        min_impact=payload.min_impact,
        enabled=payload.enabled,
        created_at=str(now),
        updated_at=str(now),
    )


@router.delete("/{rule_id}", status_code=200)
def delete_rule(rule_id: str):
    """Disable an alert rule (soft delete via enabled=0)."""
    existing = db_query(
        "SELECT rule_id, account_id, service, sensitivity, min_impact, created_at "
        "FROM cost.alert_rules FINAL WHERE rule_id = {rule_id:String} LIMIT 1",
        {"rule_id": rule_id}
    )
    if not existing:
        raise HTTPException(status_code=404, detail=f"Rule '{rule_id}' not found")

    r = existing[0]
    now = datetime.now(timezone.utc).replace(tzinfo=None)
    db_query(
        "INSERT INTO cost.alert_rules (rule_id, account_id, service, sensitivity, min_impact, enabled, created_at, updated_at) "
        "VALUES ({rule_id:String}, {account_id:String}, {service:String}, {sensitivity:Float32}, "
        "{min_impact:Float64}, 0, {created_at:DateTime}, {updated_at:DateTime})",
        {
            "rule_id":     rule_id,
            "account_id":  r["account_id"],
            "service":     r["service"],
            "sensitivity": float(r["sensitivity"]),
            "min_impact":  float(r["min_impact"]),
            "created_at":  r["created_at"],
            "updated_at":  now,
        }
    )
    return {"message": f"Rule '{rule_id}' disabled successfully"}
