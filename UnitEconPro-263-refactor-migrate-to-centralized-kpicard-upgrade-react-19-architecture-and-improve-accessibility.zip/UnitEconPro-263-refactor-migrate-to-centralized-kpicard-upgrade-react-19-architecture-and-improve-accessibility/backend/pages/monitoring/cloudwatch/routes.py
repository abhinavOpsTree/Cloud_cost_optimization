"""
CloudWatch Page Routes
-----------------------
Endpoints for CloudWatch cost analytics.
/trend and /breakdown are served by the unified analytics router.
"""
from fastapi import APIRouter, Depends

from core import database as db
from core.dependencies import DateCtx, date_range_params
from . import queries as q
from . import schemas

router = APIRouter(prefix="/api/v1/monitoring/cloudwatch", tags=["Monitoring – CloudWatch"])


@router.get("/summary", response_model=schemas.CWSummary)
async def get_cloudwatch_summary(ctx: DateCtx):
    """4 stat cards: Total Cost, Avg Daily Cost, Total Log GB Ingested, Total Alarms."""
    sql = q.CW_SUMMARY.format(start=ctx.start, end=ctx.end, account_filter=ctx.account_filter)
    rows = db.query_safe(sql, ctx.params)

    if not rows:
        return schemas.CWSummary(
            total_cost=0, avg_daily_cost=0,
            total_log_gb=0, total_alarms=0,
        )

    row = rows[0]
    return schemas.CWSummary(
        total_cost=float(row.get("total_cost") or 0),
        avg_daily_cost=float(row.get("avg_daily_cost") or 0),
        total_log_gb=float(row.get("total_log_gb") or 0),
        total_alarms=float(row.get("total_alarms") or 0),
        total_api_calls=int(row.get("total_api_calls") or 0),
    )


@router.get("/eks-clusters", response_model=list[schemas.CWClusterCost])
async def get_cloudwatch_eks_clusters(ctx: DateCtx):
    """EKS cluster log cost breakdown — data table.
    Extracts cluster name from /aws/eks/<cluster>/... ARN paths."""
    sql = q.CW_BY_EKS_CLUSTER.format(start=ctx.start, end=ctx.end, account_filter=ctx.account_filter)
    rows = db.query_safe(sql, ctx.params)
    return [
        schemas.CWClusterCost(
            cluster_name=r.get("name") or "",
            cost=float(r.get("cost") or 0),
            gb_ingested=float(r.get("usage") or 0),
        )
        for r in rows
    ]


@router.get("/log-groups", response_model=list[schemas.CWLogGroup])
async def get_cloudwatch_log_groups(ctx: DateCtx):
    """Top 20 log groups by ingestion cost — data table."""
    sql = q.CW_TOP_LOG_GROUPS.format(start=ctx.start, end=ctx.end, account_filter=ctx.account_filter)
    rows = db.query_safe(sql, ctx.params)
    return [
        schemas.CWLogGroup(
            log_group_name=r.get("log_group_name") or "",
            region=r.get("region"),
            account=r.get("account"),
            gb_ingested=float(r.get("gb_ingested") or 0),
            total_cost=float(r.get("total_cost") or 0),
        )
        for r in rows
    ]
