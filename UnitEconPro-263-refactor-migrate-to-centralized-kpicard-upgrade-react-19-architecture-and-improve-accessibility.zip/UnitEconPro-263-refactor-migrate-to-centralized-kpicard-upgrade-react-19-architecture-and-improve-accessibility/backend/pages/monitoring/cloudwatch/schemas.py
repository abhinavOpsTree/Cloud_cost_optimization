from pydantic import BaseModel
from typing import Optional


class CWSummary(BaseModel):
    total_cost: float
    avg_daily_cost: float
    total_log_gb: float
    total_alarms: float
    total_api_calls: int = 0


class CWClusterCost(BaseModel):
    cluster_name: str
    cost: float
    gb_ingested: float


class CWLogGroup(BaseModel):
    log_group_name: str
    region: Optional[str] = None
    account: Optional[str] = None
    gb_ingested: float
    total_cost: float
