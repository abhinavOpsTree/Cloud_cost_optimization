"""
CloudWatch SQL Queries
-----------------------
Product code: AmazonCloudWatch  (confirmed from CUR)

Real cost composition in this data:
  VendedLog-Bytes        → Log ingestion (dominant cost ~$27)
  TimedStorage-ByteHrs   → Log storage (~$1)
  CW:MetricMonitorUsage  → Custom metrics (~$0.81)
  CW:AlarmMonitorUsage   → Alarms (~$0.79)
  DataProcessing-Bytes   → Log filter processing (negligible)
  CW:Requests            → API calls ($0.00 in this data)

Log group resource_id format:
  arn:aws:logs:<region>:<account>:log-group:<name>
  e.g. arn:aws:logs:ap-south-1:702037529261:log-group:/aws/eks/ot-bp/cluster
"""

# ── 1. Summary ───────────────────────────────────────────────
CW_SUMMARY = """
    SELECT
        ROUND(SUM(cost_unblended), 2) AS total_cost,
        ROUND(SUM(cost_unblended) / GREATEST(COUNT(DISTINCT toDate(usage_start_ts)), 1), 2) AS avg_daily_cost,
        ROUND(SUMIf(usage_qty, usage_type LIKE '%VendedLog-Bytes%'
                            OR usage_type LIKE '%DataProcessing-Bytes%'), 2) AS total_log_gb,
        ROUND(SUMIf(usage_qty, usage_type LIKE '%AlarmMonitorUsage%'), 2) AS total_alarms,
        -- API call count: CW:Requests rows (may be 0 cost but track usage volume)
        toInt64(ROUND(SUMIf(usage_qty, usage_type LIKE '%Requests%'), 0)) AS total_api_calls
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonCloudWatch'
      {account_filter}
"""

# ── 2. Daily Cost Trend ──────────────────────────────────────
CW_COST_TREND = """
    SELECT
        toDate(usage_start_ts) AS date_obj,
        formatDateTime(date_obj, '%Y-%m-%d') AS date,
        ROUND(SUM(cost_unblended), 2) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonCloudWatch'
      {account_filter}
    GROUP BY date_obj
    ORDER BY date_obj ASC
"""

# ── 3. Breakdowns ────────────────────────────────────────────

# Groups all raw usage_types into 5 human-readable cost categories.
CW_BY_GROUP = """
    SELECT
        CASE
            WHEN usage_type LIKE '%VendedLog-Bytes%'
              OR usage_type LIKE '%DataProcessing-Bytes%' THEN 'Log Ingestion'
            WHEN usage_type LIKE '%TimedStorage-Byte%'    THEN 'Log Storage'
            WHEN usage_type LIKE '%MetricMonitorUsage%'   THEN 'Custom Metrics'
            WHEN usage_type LIKE '%AlarmMonitorUsage%'    THEN 'Alarms'
            WHEN usage_type LIKE '%Requests%'             THEN 'API Calls'
            ELSE 'Other'
        END AS name,
        ROUND(SUM(cost_unblended), 2) AS cost,
        ROUND(SUM(usage_qty), 2) AS usage,
        CASE
            WHEN usage_type LIKE '%VendedLog-Bytes%'
              OR usage_type LIKE '%DataProcessing-Bytes%' THEN 'GB'
            WHEN usage_type LIKE '%AlarmMonitorUsage%'    THEN 'Alarms'
            ELSE 'Units'
        END AS unit
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonCloudWatch'
      {account_filter}
    GROUP BY name, unit
    HAVING cost > 0
    ORDER BY cost DESC
"""

CW_BY_REGION = """
    SELECT
        region AS name,
        ROUND(SUM(cost_unblended), 2) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonCloudWatch'
      AND trimBoth(region) != ''
      {account_filter}
    GROUP BY region
    ORDER BY cost DESC
"""

CW_BY_ACCOUNT = """
    SELECT
        account_name AS name,
        ROUND(SUM(cost_unblended), 2) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonCloudWatch'
      AND account_name IS NOT NULL AND trimBoth(account_name) != ''
      {account_filter}
    GROUP BY account_name
    ORDER BY cost DESC
"""

# Groups by the raw CloudWatch operation value (PutLogEvents, MetricStorage, etc.)
# Gives granular breakdown beyond the 5 high-level groups in CW_BY_GROUP.
CW_BY_OPERATION = """
    SELECT
        operation AS name,
        ROUND(SUM(cost_unblended), 2) AS cost,
        ROUND(SUM(usage_qty), 2) AS usage,
        'Units' AS unit
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonCloudWatch'
      AND operation IS NOT NULL AND trimBoth(operation) != ''
      {account_filter}
    GROUP BY name
    HAVING cost > 0
    ORDER BY cost DESC
"""

# Groups log ingestion + storage cost by the originating AWS service,
# derived from the log group path embedded in the resource_id ARN.
# e.g. arn:...:log-group:/aws/eks/cluster → 'EKS / Container Insights'
CW_BY_LOG_PREFIX = """
    SELECT
        CASE
            WHEN resource_id LIKE '%/aws/eks/%'
              OR resource_id LIKE '%/aws/containerinsights/%' THEN 'EKS / Container Insights'
            WHEN resource_id LIKE '%/aws/lambda/%'             THEN 'Lambda'
            WHEN resource_id LIKE '%/aws/ecs/%'               THEN 'ECS'
            WHEN resource_id LIKE '%/aws/rds/%'               THEN 'RDS'
            WHEN resource_id LIKE '%/aws/apigateway/%'         THEN 'API Gateway'
            ELSE 'Other'
        END AS name,
        ROUND(SUM(cost_unblended), 2) AS cost,
        ROUND(SUM(usage_qty), 2) AS usage,
        'GB' AS unit
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonCloudWatch'
      AND (usage_type LIKE '%VendedLog-Bytes%'
        OR usage_type LIKE '%DataProcessing-Bytes%'
        OR usage_type LIKE '%TimedStorage%')
      {account_filter}
    GROUP BY name
    ORDER BY cost DESC
"""

# Extracts the EKS cluster name from the log group ARN path.
# ARN format: arn:aws:logs:region:acct:log-group:/aws/eks/<cluster>/<name>
#   splitByString('/', resource_id) is 1-indexed in ClickHouse:
#   [1]=arn-prefix, [2]=aws, [3]=eks, [4]=<cluster-name>, [5]=...
# Same index works for /aws/containerinsights/<cluster>/<name>.
CW_BY_EKS_CLUSTER = """
    SELECT
        splitByString('/', resource_id)[4] AS name,
        ROUND(SUM(cost_unblended), 2) AS cost,
        ROUND(SUM(usage_qty), 2) AS usage,
        'GB' AS unit
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonCloudWatch'
      AND (usage_type LIKE '%VendedLog-Bytes%'
        OR usage_type LIKE '%DataProcessing-Bytes%'
        OR usage_type LIKE '%TimedStorage%')
      AND (resource_id LIKE '%/aws/eks/%'
        OR resource_id LIKE '%/aws/containerinsights/%')
      {account_filter}
    GROUP BY name
    HAVING name != ''
    ORDER BY cost DESC
    LIMIT 20
"""

# ── 5. Top Log Groups Table ──────────────────────────────────
# Extracts log group name from ARN: arn:...:log-group:/aws/eks/...
#   splitByString('log-group:', resource_id)[2] → '/aws/eks/...' (ClickHouse 1-indexed)
# Only log ingestion rows have meaningful log group resource_ids.
CW_TOP_LOG_GROUPS = """
    SELECT
        splitByString('log-group:', resource_id)[2] AS log_group_name,
        argMax(region, usage_start_ts) AS region,
        argMax(account_name, usage_start_ts) AS account,
        ROUND(SUM(usage_qty), 2) AS gb_ingested,
        ROUND(SUM(cost_unblended), 2) AS total_cost
    FROM cost.service_costs
    WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
      AND product_code = 'AmazonCloudWatch'
      AND (usage_type LIKE '%VendedLog-Bytes%' OR usage_type LIKE '%DataProcessing-Bytes%')
      AND resource_id LIKE '%log-group:%'
      {account_filter}
    GROUP BY log_group_name
    HAVING log_group_name != ''
    ORDER BY total_cost DESC
    LIMIT 20
"""
