"""
Dashboard Page Routes
5 active endpoints for the main dashboard page + 1 combined endpoint.
/breakdown/account is commented out — re-enable in both routes and queries if needed.
"""
import asyncio
import math
from fastapi import APIRouter, Query
from datetime import datetime, timedelta
from typing import Annotated
import logging

from core import database as db
from core.dependencies import AccountCtx, DateCtx, date_range_params
from . import queries as q
from . import schemas

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v1/dashboard", tags=["Dashboard"])

AccountParam = Annotated[str, Query(description="Account name to filter by, or 'All' for all accounts.")]


# ── 1. Summary ───────────────────────────────────────────
@router.get("/summary", response_model=schemas.DashboardSummary)
async def get_summary(ctx: DateCtx):
    """Stat cards: Total Cost, Avg Daily Cost, Active Services, Active Regions.
    total_accounts and total_resources are excluded from the response (commented out in schema + query).
    """
    sql = q.SUMMARY_METRICS.format(account_filter=ctx.account_filter)
    start_dt = datetime.strptime(ctx.start[:10], "%Y-%m-%d")
    end_dt   = datetime.strptime(ctx.end[:10],   "%Y-%m-%d")
    days_in_range = max((end_dt - start_dt).days + 1, 1)
    rows = await asyncio.to_thread(
        db.query, sql, {"start": ctx.start, "end": ctx.end, "days_in_range": days_in_range, **ctx.params}
    )

    if not rows:
        return schemas.DashboardSummary(
            total_cost=0,
            avg_daily_cost=0,
            active_services=0,
            active_regions=0,
        )

    row = rows[0]
    return schemas.DashboardSummary(
        total_cost=row["total_cost"] or 0,
        avg_daily_cost=row["avg_daily_cost"] or 0,
        active_services=row["active_services"] or 0,
        active_regions=row["active_regions"] or 0,
    )


# ── 2. Cost Trend ────────────────────────────────────────
@router.get("/trend", response_model=list[schemas.TrendPoint])
async def get_trend(ctx: DateCtx):
    """Daily cost for the selected period + previous period overlay.

    Fires two parallel ClickHouse queries via asyncio.gather — each scans only
    its own date window. This halves disk I/O vs the old COST_TREND_COMBINED
    approach which scanned prev_start → end (2× the range) and used sumIf +
    HAVING to split. Both queries run on separate pool connections concurrently;
    wall-clock time ≈ max(t_current, t_prev) ≈ one query.
    """
    start_dt = datetime.strptime(ctx.start[:10], "%Y-%m-%d")
    end_dt   = datetime.strptime(ctx.end[:10],   "%Y-%m-%d")
    delta    = max((end_dt - start_dt).days, 1)

    prev_start = (start_dt - timedelta(days=delta)).strftime("%Y-%m-%d") + " 00:00:00"
    prev_end   = (end_dt   - timedelta(days=delta)).strftime("%Y-%m-%d") + " 23:59:59"

    sql = q.COST_TREND_SIMPLE.format(account_filter=ctx.account_filter)

    current_rows, prev_rows = await asyncio.gather(
        asyncio.to_thread(db.query, sql, {"start": ctx.start,   "end": ctx.end,  **ctx.params}),
        asyncio.to_thread(db.query, sql, {"start": prev_start,  "end": prev_end, **ctx.params}),
    )

    # Build a lookup of prev-period cost by date position (index) so we can
    # align it to the current-period date. Prev rows are ordered ASC by date,
    # same as current rows — positional alignment is correct.
    prev_by_index = {i: float(r["cost"] or 0) for i, r in enumerate(prev_rows)}

    result = []
    for i, row in enumerate(current_rows):
        raw_prev  = prev_by_index.get(i)
        # Treat 0 as None so the frontend renders a gap rather than a flat zero line.
        prev_cost = raw_prev if raw_prev else None
        result.append(schemas.TrendPoint(
            date=row["date"],
            cost=float(row["cost"] or 0),
            previous_period_cost=prev_cost,
        ))
    return result


# ── 3. Service Breakdown ─────────────────────────────────
@router.get("/breakdown/service", response_model=list[schemas.BreakdownItem])
async def get_service_breakdown(ctx: DateCtx):
    """Top 10 services by cost — for bar chart."""
    rows = await asyncio.to_thread(
        db.query,
        q.SERVICE_BREAKDOWN.format(account_filter=ctx.account_filter),
        {"start": ctx.start, "end": ctx.end, **ctx.params},
    )
    return [schemas.BreakdownItem(name=r["name"], cost=r["cost"]) for r in rows]


# ── 4. Account Breakdown — commented out ─────────────────
# Not called by the UI. Re-enable by uncommenting this block
# and uncommenting ACCOUNT_BREAKDOWN in queries.py.
#
# @router.get("/breakdown/account", response_model=list[schemas.BreakdownItem])
# async def get_account_breakdown(ctx: DateCtx):
#     """Cost split by account — for pie chart."""
#     rows = await asyncio.to_thread(
#         db.query,
#         q.ACCOUNT_BREAKDOWN.format(
#             start=ctx.start,
#             end=ctx.end,
#             account_filter=ctx.account_filter,
#         ),
#     )
#     return [schemas.BreakdownItem(name=r["name"], cost=r["cost"]) for r in rows]


# ── 5. Period Comparison ─────────────────────────────────
@router.get("/comparison", response_model=schemas.PeriodComparison)
async def get_comparison(ctx: AccountCtx):
    """Yesterday, last week, this week, last month costs.

    Uses a single PERIOD_COMPARISON query (one ClickHouse round-trip) instead
    of the old 4 serial COST_FOR_PERIOD calls.

    Week logic matches Grafana:
      Last Week = toMonday(today()) - 7  →  toMonday(today()) - 1  (Mon-Sun)
      This Week = toMonday(today())      →  today()                (Mon-Today)
    """
    today = datetime.now().date()

    yesterday        = today - timedelta(days=1)
    this_monday      = today - timedelta(days=today.weekday())   # Python: Monday=0
    last_monday      = this_monday - timedelta(days=7)
    month_start      = today.replace(day=1)
    last_month_start = (month_start - timedelta(days=1)).replace(day=1)

    sql = q.PERIOD_COMPARISON.format(account_filter=ctx.account_filter)
    rows = await asyncio.to_thread(
        db.query_safe, sql, {
            "yesterday":        str(yesterday),
            "last_monday":      str(last_monday),
            "this_monday":      str(this_monday),
            "today":            str(today),
            "last_month_start": str(last_month_start),
            **ctx.params,
        }
    )

    if not rows:
        return schemas.PeriodComparison(
            yesterday_cost=0,
            last_week_cost=0,
            this_week_cost=0,
            last_month_cost=0,
        )

    row = rows[0]
    return schemas.PeriodComparison(
        yesterday_cost=float(row.get("yesterday_cost") or 0),
        last_week_cost=float(row.get("last_week_cost") or 0),
        this_week_cost=float(row.get("this_week_cost") or 0),
        last_month_cost=float(row.get("last_month_cost") or 0),
    )


# ── 6. Forecast ──────────────────────────────────────────
@router.get("/forecast", response_model=schemas.Forecast)
async def get_forecast(ctx: AccountCtx):
    """
    End-of-Month projection based on MTD run-rate deviation.

    Algorithm (identical to AWS Cost Explorer / Datadog):
      1. Sum actual spend from the 1st of the current month to today (MTD).
      2. Divide by days elapsed → current daily run rate.
      3. predicted_month_cost = MTD + (daily_rate × days remaining in month).
      4. predicted_week_cost  = daily_rate × 7  (next 7 rolling days).

    Uses DateCtx for consistent account filtering with all other endpoints.
    """
    def _safe(val) -> float:
        v = float(val or 0.0)
        return 0.0 if (math.isnan(v) or math.isinf(v)) else v

    try:
        sql  = q.DASHBOARD_FORECAST.format(account_filter=ctx.account_filter)
        rows = await asyncio.to_thread(db.query, sql, ctx.params)
    except Exception as e:
        logger.warning(f"Forecast query failed, returning zeros: {e}")
        rows = []

    if not rows:
        return schemas.Forecast(
            predicted_week_cost=0.0,
            predicted_month_cost=0.0,
            mtd_cost=0.0,
            daily_run_rate=0.0,
        )

    r = rows[0]
    return schemas.Forecast(
        predicted_week_cost=_safe(r.get("predicted_week_cost")),
        predicted_month_cost=_safe(r.get("predicted_month_cost")),
        mtd_cost=_safe(r.get("mtd_cost")),
        daily_run_rate=_safe(r.get("daily_run_rate")),
    )


# ── 7. Combined — all dashboard data in one request ──────
# Commented out — frontend not yet updated to use this endpoint.
# Re-enable when frontend is ready to switch from 5 individual calls to /all.
#
# from pydantic import BaseModel as _BaseModel
#
# class DashboardAll(_BaseModel):
#     summary:    schemas.DashboardSummary
#     trend:      List[schemas.TrendPoint]
#     breakdown:  List[schemas.BreakdownItem]
#     comparison: schemas.PeriodComparison
#     forecast:   schemas.Forecast
#
#
# @router.get("/all", response_model=DashboardAll)
# async def get_all(ctx: DateCtx):
#     """
#     Combined dashboard endpoint — returns summary, trend, breakdown, comparison,
#     and forecast in a single HTTP round-trip.
#     All 5 ClickHouse queries run concurrently via asyncio.gather.
#     Example: /api/v1/dashboard/all?start_date=2026-04-29&end_date=2026-05-29&account=opstree
#     """
#     def _safe(val) -> float:
#         v = float(val or 0.0)
#         return 0.0 if (math.isnan(v) or math.isinf(v)) else v
#
#     start_dt = datetime.strptime(ctx.start[:10], "%Y-%m-%d")
#     end_dt   = datetime.strptime(ctx.end[:10],   "%Y-%m-%d")
#     days_in_range = max((end_dt - start_dt).days + 1, 1)
#     delta         = max((end_dt - start_dt).days, 1)
#
#     prev_start = (start_dt - timedelta(days=delta)).strftime("%Y-%m-%d") + " 00:00:00"
#     prev_end   = (end_dt   - timedelta(days=delta)).strftime("%Y-%m-%d") + " 23:59:59"
#
#     today            = datetime.now().date()
#     yesterday        = today - timedelta(days=1)
#     this_monday      = today - timedelta(days=today.weekday())
#     last_monday      = this_monday - timedelta(days=7)
#     month_start      = today.replace(day=1)
#     last_month_start = (month_start - timedelta(days=1)).replace(day=1)
#
#     trend_sql      = q.COST_TREND_SIMPLE.format(account_filter=ctx.account_filter)
#     summary_sql    = q.SUMMARY_METRICS.format(account_filter=ctx.account_filter)
#     breakdown_sql  = q.SERVICE_BREAKDOWN.format(account_filter=ctx.account_filter)
#     comparison_sql = q.PERIOD_COMPARISON.format(account_filter=ctx.account_filter)
#     forecast_sql   = q.DASHBOARD_FORECAST.format(account_filter=ctx.account_filter)
#
#     (
#         summary_rows, current_trend_rows, prev_trend_rows,
#         breakdown_rows, comparison_rows, forecast_rows,
#     ) = await asyncio.gather(
#         asyncio.to_thread(db.query, summary_sql,    {"start": ctx.start, "end": ctx.end, "days_in_range": days_in_range, **ctx.params}),
#         asyncio.to_thread(db.query, trend_sql,      {"start": ctx.start,  "end": ctx.end,  **ctx.params}),
#         asyncio.to_thread(db.query, trend_sql,      {"start": prev_start, "end": prev_end, **ctx.params}),
#         asyncio.to_thread(db.query, breakdown_sql,  {"start": ctx.start, "end": ctx.end, **ctx.params}),
#         asyncio.to_thread(db.query_safe, comparison_sql, {
#             "yesterday": str(yesterday), "last_monday": str(last_monday),
#             "this_monday": str(this_monday), "today": str(today),
#             "last_month_start": str(last_month_start), **ctx.params,
#         }),
#         asyncio.to_thread(db.query, forecast_sql, ctx.params),
#     )
#
#     sr = summary_rows[0] if summary_rows else {}
#     summary = schemas.DashboardSummary(
#         total_cost=float(sr.get("total_cost") or 0),
#         avg_daily_cost=float(sr.get("avg_daily_cost") or 0),
#         active_services=int(sr.get("active_services") or 0),
#         active_regions=int(sr.get("active_regions") or 0),
#     )
#     prev_by_index = {i: float(r["cost"] or 0) for i, r in enumerate(prev_trend_rows)}
#     trend = [
#         schemas.TrendPoint(
#             date=row["date"], cost=float(row["cost"] or 0),
#             previous_period_cost=prev_by_index.get(i) or None,
#         )
#         for i, row in enumerate(current_trend_rows)
#     ]
#     breakdown = [schemas.BreakdownItem(name=r["name"], cost=r["cost"]) for r in breakdown_rows]
#     cr = comparison_rows[0] if comparison_rows else {}
#     comparison = schemas.PeriodComparison(
#         yesterday_cost=float(cr.get("yesterday_cost") or 0),
#         last_week_cost=float(cr.get("last_week_cost") or 0),
#         this_week_cost=float(cr.get("this_week_cost") or 0),
#         last_month_cost=float(cr.get("last_month_cost") or 0),
#     )
#     fr = forecast_rows[0] if forecast_rows else {}
#     forecast = schemas.Forecast(
#         predicted_week_cost=_safe(fr.get("predicted_week_cost")),
#         predicted_month_cost=_safe(fr.get("predicted_month_cost")),
#         mtd_cost=_safe(fr.get("mtd_cost")),
#         daily_run_rate=_safe(fr.get("daily_run_rate")),
#     )
#     return DashboardAll(
#         summary=summary, trend=trend, breakdown=breakdown,
#         comparison=comparison, forecast=forecast,
#     )
