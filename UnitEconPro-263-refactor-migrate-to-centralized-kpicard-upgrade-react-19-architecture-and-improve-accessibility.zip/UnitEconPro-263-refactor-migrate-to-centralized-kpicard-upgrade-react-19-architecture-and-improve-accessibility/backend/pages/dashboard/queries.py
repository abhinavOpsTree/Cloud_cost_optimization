"""
Dashboard Page SQL Queries
"""

TABLE = "cost.service_costs"


# ── 1. Summary Metrics ───────────────────────────────────
# total_accounts and total_resources commented out — not shown in UI.
# uniqIf used instead of uniqExactIf for active_regions — HyperLogLog is
# ~2% error but 20-40% faster on large tables. Exact count not needed for a stat card.
#
# Fix: {start}/{end} are ClickHouse bound parameters. Callers pass
#   params={"start": ctx.start, "end": ctx.end, "days_in_range": N, **ctx.params}
#
# Perf: avg_daily_cost uses bound {days_in_range:UInt32} instead of
# COUNT(DISTINCT toDate(usage_start_ts)) — turns an O(n) distinct aggregation
# into a division by a constant. 2-5× faster on large tables.
SUMMARY_METRICS = """
    SELECT
        ROUND(SUM(cost_unblended), 2) AS total_cost,
        ROUND(SUM(cost_unblended) / GREATEST({{days_in_range:UInt32}}, 1), 2) AS avg_daily_cost,
        COUNT(DISTINCT product_code) AS active_services,
        -- total_accounts: COUNT(DISTINCT account_id) AS total_accounts,
        uniqIf(region, region != '') AS active_regions
        -- total_resources: uniqExactIf(resource_id, resource_id != '') AS total_resources
    FROM cost.service_costs
    WHERE usage_start_ts >= {{start:DateTime}} AND usage_start_ts <= {{end:DateTime}}
    {account_filter}
"""


# ── 2. Cost Trend — two parallel queries, each scanning only its own window ──
# Replaces COST_TREND_COMBINED which scanned prev_start → end (2× the date
# range) and used sumIf + HAVING to split. That approach read 60 days of
# partitions for a 30-day view — the HAVING guard filtered output rows but
# the full double-width window was already read from disk.
#
# Two parallel queries each scan only their own 30-day window. With the
# connection pool in database.py, both run on separate ClickHouse connections
# concurrently via asyncio.gather. Wall-clock time ≈ max(t1, t2) ≈ one query,
# but total I/O is halved.
#
# Bound params: {start:DateTime}, {end:DateTime}, optional {account_name:String}
COST_TREND_SIMPLE = """
    SELECT
        toDate(usage_start_ts)               AS date_obj,
        formatDateTime(date_obj, '%Y-%m-%d') AS date,
        ROUND(SUM(cost_unblended), 2)        AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= {{start:DateTime}}
      AND usage_start_ts <= {{end:DateTime}}
    {account_filter}
    GROUP BY date_obj
    ORDER BY date_obj ASC
"""


# ── 3. Service Breakdown ─────────────────────────────────
# Fix: bound DateTime params instead of interpolated strings.
SERVICE_BREAKDOWN = """
    SELECT
        product_code AS name,
        ROUND(SUM(cost_unblended), 2) AS cost
    FROM cost.service_costs
    WHERE usage_start_ts >= {{start:DateTime}} AND usage_start_ts <= {{end:DateTime}}
    {account_filter}
    GROUP BY product_code
    ORDER BY cost DESC
    LIMIT 10
"""


# ── 4. Account Breakdown — commented out, not called by UI ───────────────────
# Re-enable by uncommenting here and in routes.py get_account_breakdown().
# ACCOUNT_BREAKDOWN = """
#     SELECT
#         account_name AS name,
#         ROUND(SUM(cost_unblended), 2) AS cost
#     FROM cost.service_costs
#     WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
#       AND account_name IS NOT NULL
#       AND account_name != ''
#     {account_filter}
#     GROUP BY account_name
#     ORDER BY cost DESC
# """


# ── 5. Period Comparison — single query replaces 4 serial round-trips ────────
# Old approach called COST_FOR_PERIOD 4 times (4 separate ClickHouse queries).
# This single query uses sumIf() to compute all 4 periods in one scan.
#
# Fix: all date strings are now ClickHouse bound parameters instead of
# Python-interpolated strings. Callers must pass:
#   params={
#     "yesterday": str(yesterday), "last_monday": str(last_monday),
#     "last_sunday": str(last_sunday), "this_monday": str(this_monday),
#     "today": str(today), "last_month_start": str(last_month_start),
#     "last_month_end": str(last_month_end), **ctx.params
#   }
#
# Fix (BUG 2): Upper bound AND usage_start_ts <= {today:Date} + INTERVAL 1 DAY
# prevents a full table scan beyond today.
#
# Fix (OPT 4): No toDate() wrapping on usage_start_ts — raw timestamp
# comparisons allow ClickHouse to use partition pruning.
PERIOD_COMPARISON = """
    SELECT
        ROUND(sumIf(cost_unblended,
            usage_start_ts >= {{yesterday:Date}}
            AND usage_start_ts < {{yesterday:Date}} + INTERVAL 1 DAY), 2)           AS yesterday_cost,
        ROUND(sumIf(cost_unblended,
            usage_start_ts >= {{last_monday:Date}}
            AND usage_start_ts < {{last_monday:Date}} + INTERVAL 7 DAY), 2)         AS last_week_cost,
        ROUND(sumIf(cost_unblended,
            usage_start_ts >= {{this_monday:Date}}
            AND usage_start_ts < {{today:Date}} + INTERVAL 1 DAY), 2)               AS this_week_cost,
        ROUND(sumIf(cost_unblended,
            usage_start_ts >= {{last_month_start:Date}}
            AND usage_start_ts < {{last_month_start:Date}} + INTERVAL 1 MONTH), 2)  AS last_month_cost
    FROM cost.service_costs
    WHERE usage_start_ts >= {{last_month_start:Date}}
      AND usage_start_ts < {{today:Date}} + INTERVAL 1 DAY
    {account_filter}
"""

# ── Old single-period query — kept commented for reference ───────────────────
# COST_FOR_PERIOD = """
#     SELECT ROUND(SUM(cost_unblended), 2)
#     FROM cost.service_costs
#     WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
#     {account_filter}
# """


# ── 6. Forecast — optimised: hist_base scanned once, not twice ───────────────
# Fix (OPT 1): single hist_base CTE feeds both hist (avg_daily) and
# weekend_factor_calc — one scan instead of two.
#
# Fix (BUG 4 / OPT 2): effective_rate CTE dropped entirely. It contained three
# scalar subqueries — (SELECT n FROM days_elapsed), (SELECT avg_daily FROM hist),
# (SELECT true_daily_rate FROM mtd) — which re-executed those CTEs on every
# reference under ClickHouse's default CTE inlining (allow_experimental_analyzer=0).
# The CASE expression is now computed directly in the final SELECT after CROSS JOIN,
# where all single-row CTEs are already materialised as columns. Zero re-executions.
#
# NOTE: {account_filter} appears twice (hist_base + mtd). Python's str.format()
# with named placeholders substitutes all occurrences in one call.
DASHBOARD_FORECAST = """
WITH
    -- Days elapsed in current month
    days_elapsed AS (
        SELECT dateDiff('day', toStartOfMonth(today()), today()) AS n
    ),

    -- Single scan of last 4 months — feeds both avg_daily and weekend factor.
    hist_base AS (
        SELECT
            toDate(usage_start_ts)              AS date,
            toDayOfWeek(toDate(usage_start_ts)) AS dow,
            SUM(cost_unblended)                 AS daily_cost
        FROM cost.service_costs
        WHERE usage_start_ts >= date_sub(MONTH, 4, toStartOfMonth(today()))
          AND usage_start_ts <  toStartOfMonth(today())
          {account_filter}
        GROUP BY date
    ),

    -- Merged CTE: computes avg_daily and weekend factor in a single pass over hist_base.
    -- Previously split into hist + weekend_factor_calc — two separate CTEs both reading
    -- hist_base. Under ClickHouse's default CTE inlining (allow_experimental_analyzer=0),
    -- each reference to hist_base inlines the full subquery, causing hist_base to be
    -- scanned twice (4 months of data × 2). Merging into one CTE eliminates the duplicate scan.
    hist_and_factor AS (
        SELECT
            SUM(daily_cost) / GREATEST(COUNT(*), 1) AS avg_daily,
            COALESCE(
                if(
                    isNaN(avgIf(daily_cost, dow IN (6, 7))) OR isNaN(avgIf(daily_cost, dow NOT IN (6, 7))) OR avgIf(daily_cost, dow NOT IN (6, 7)) = 0,
                    NULL,
                    avgIf(daily_cost, dow IN (6, 7)) / avgIf(daily_cost, dow NOT IN (6, 7))
                ),
                1.0
            ) AS factor
        FROM hist_base
    ),

    -- Current month MTD
    mtd AS (
        SELECT
            SUM(cost_unblended)                                                    AS mtd_cost,
            MAX(toDate(usage_start_ts))                                            AS last_data_date,
            SUM(cost_unblended) / GREATEST(dateDiff('day', toStartOfMonth(today()), today()), 1) AS true_daily_rate
        FROM cost.service_costs
        WHERE usage_start_ts >= toStartOfMonth(now())
          AND usage_start_ts <  today() + 1
          {account_filter}
    ),

    -- Remaining days in month split by weekday/weekend.
    -- Uses yesterday() as the data-lag boundary instead of a scalar subquery
    -- on mtd.last_data_date — eliminates a CTE re-execution under ClickHouse's
    -- default CTE inlining. yesterday() is correct for all standard ingestion
    -- pipelines where data lands with a 1-day lag.
    remaining_days AS (
        SELECT
            countIf(toDayOfWeek(date) IN (6, 7))     AS weekend_remaining,
            countIf(toDayOfWeek(date) NOT IN (6, 7)) AS weekday_remaining
        FROM (
            SELECT date_add(DAY, number, toStartOfMonth(now())) AS date
            FROM numbers(0, 31)
            WHERE toMonth(date) = toMonth(now())
              AND date >= today()
        )
    )

-- All single-row CTEs materialised once via CROSS JOIN.
-- hf = hist_and_factor (merged CTE — one scan of hist_base instead of two).
SELECT
    ROUND(m.mtd_cost,        2) AS mtd_cost,
    ROUND(m.true_daily_rate, 2) AS daily_run_rate,
    ROUND(
        (5 * CASE WHEN de.n < 7
                  THEN COALESCE(if(isNaN(hf.avg_daily) OR hf.avg_daily = 0, NULL, hf.avg_daily), m.true_daily_rate)
                  ELSE m.true_daily_rate END) +
        (2 * CASE WHEN de.n < 7
                  THEN COALESCE(if(isNaN(hf.avg_daily) OR hf.avg_daily = 0, NULL, hf.avg_daily), m.true_daily_rate)
                  ELSE m.true_daily_rate END * hf.factor),
    2) AS predicted_week_cost,
    ROUND(
        m.mtd_cost
        + COALESCE(r.weekday_remaining, 0) *
          CASE WHEN de.n < 7
               THEN COALESCE(if(isNaN(hf.avg_daily) OR hf.avg_daily = 0, NULL, hf.avg_daily), m.true_daily_rate)
               ELSE m.true_daily_rate END
        + COALESCE(r.weekend_remaining, 0) *
          CASE WHEN de.n < 7
               THEN COALESCE(if(isNaN(hf.avg_daily) OR hf.avg_daily = 0, NULL, hf.avg_daily), m.true_daily_rate)
               ELSE m.true_daily_rate END * hf.factor,
    2) AS predicted_month_cost
FROM mtd m
CROSS JOIN hist_and_factor hf
CROSS JOIN days_elapsed de
CROSS JOIN remaining_days r
SETTINGS allow_experimental_analyzer=1
"""
