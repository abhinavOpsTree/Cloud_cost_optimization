"""
Dashboard Page Pydantic Models
Request/Response schemas for dashboard endpoints
"""
from pydantic import BaseModel
from typing import Optional


# ── Response: Summary ────────────────────────────────────
class DashboardSummary(BaseModel):
    total_cost: float
    avg_daily_cost: float
    active_services: int
    # total_accounts and total_resources commented out — not displayed in UI
    # total_accounts: int
    # total_resources: int
    active_regions: int


# ── Response: Trend ──────────────────────────────────────
class TrendPoint(BaseModel):
    date: str
    cost: float
    previous_period_cost: Optional[float] = None


# ── Response: Breakdown ──────────────────────────────────
class BreakdownItem(BaseModel):
    name: Optional[str] = "Unknown"  # Optional — null account_name won't crash Pydantic
    cost: float


# ── Response: Comparison ─────────────────────────────────
class PeriodComparison(BaseModel):
    yesterday_cost: float
    last_week_cost: float
    this_week_cost: float
    last_month_cost: float


# ── Response: Forecast ───────────────────────────────────
class Forecast(BaseModel):
    predicted_week_cost: float    # current daily run-rate × 7
    predicted_month_cost: float   # MTD + (daily run-rate × days remaining in month)
    mtd_cost: float               # actual spend from 1st of month to today
    daily_run_rate: float         # avg daily cost this calendar month
