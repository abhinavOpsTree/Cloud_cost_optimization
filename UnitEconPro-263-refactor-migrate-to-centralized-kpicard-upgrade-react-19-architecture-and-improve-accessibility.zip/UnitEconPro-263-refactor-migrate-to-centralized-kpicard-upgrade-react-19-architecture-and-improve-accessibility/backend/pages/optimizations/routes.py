"""
Optimization Endpoint — Engine 1 (CUR Waste Hunter) + Engine 2 (AWS ML Hub)

Engine 1 queries run instantly against local ClickHouse (CUR data).
Engine 2 reads from the aws_hub table populated by the background sync worker.
"""
from typing import Annotated, List

from fastapi import APIRouter, Query, BackgroundTasks

from core import database as db
from . import queries as q
from . import schemas

router = APIRouter(prefix="/api/v1/optimizations", tags=["Optimizations"])


def _build_recs(sql: str, engine: str, opt_type: str,
                title_fn, desc_fn: callable,
                action_type: str, severity: str) -> List[schemas.OptimizationRecommendation]:
    """
    Execute a single Engine 1 SQL query and map rows into the unified schema.
    Rows are dicts (project-wide db.query() convention).
    """
    rows = db.query(sql)
    recs = []
    for r in rows:
        res_id   = str(r.get("resource_id") or "")
        account  = str(r.get("account_name") or "")
        region   = str(r.get("region") or "")
        savings  = float(r.get("estimated_monthly_savings") or 0)
        old_type = str(r.get("old_instance_type") or "")

        recs.append(schemas.OptimizationRecommendation(
            id=f"{opt_type}-{res_id}",
            engine=engine,
            type=opt_type,
            title=title_fn(old_type),
            description=desc_fn(res_id),
            severity=severity,
            estimated_monthly_savings=savings,
            resource_id=res_id,
            account_name=account,
            region=region,
            action_type=action_type,
        ))
    return recs


@router.get("/", response_model=schemas.OptimizationsResponse)
async def get_optimizations(
    account: Annotated[
        str,
        Query(description="Account name to filter by, or 'All' for all accounts."),
    ] = "All",
):
    """
    Unified Optimization Recommendations endpoint.

    Engine 1 (CUR Waste Hunter) — runs instantly from local ClickHouse:
      - Idle Elastic/Public IPs
      - Legacy gp2 EBS volumes (recommend gp3)
      - Old-generation EC2 instances (t2/m4/c4)
      - Zombie NAT Gateways
      - Idle Load Balancers
      - Unattached EBS Volumes (orphaned storage)
      - Stopped EC2 with Active EBS (long-stopped trap)

    Engine 2 (AWS Cost Optimization Hub ML) — reads from aws_hub table
    pre-populated by the background sync worker (POST /sync):
      - Rightsizing recommendations
      - Graviton migration opportunities
      - Savings Plans / Reserved Instance opportunities
    """
    account = " ".join(account.split())
    account_filter = "" if account == "All" else f"AND account_name = '{account}'"

    all_recs: List[schemas.OptimizationRecommendation] = []

    # ── Engine 1: CUR Waste Hunter ─────────────────────────────────────────

    # 1. Idle Public IPv4 / ElasticIP
    all_recs.extend(_build_recs(
        sql=q.IDLE_IPS_QUERY.format(account_filter=account_filter),
        engine="Engine 1 (CUR)",
        opt_type="Idle Resource",
        title_fn=lambda _: "Release Idle Public IP Address",
        desc_fn=lambda res: f"Public IPv4 address {res} is unattached and incurring idle charges. Release it in the AWS Console to stop billing immediately.",
        action_type="Release",
        severity="Low",
    ))

    # 2. gp2 → gp3 EBS Modernization
    all_recs.extend(_build_recs(
        sql=q.GP2_VOLUMES_QUERY.format(account_filter=account_filter),
        engine="Engine 1 (CUR)",
        opt_type="Modernization (Storage)",
        title_fn=lambda _: "Upgrade EBS Volume from gp2 to gp3",
        desc_fn=lambda res: f"Volume {res} uses legacy gp2 storage. Upgrading to gp3 reduces cost by ~20% and improves baseline IOPS with zero downtime.",
        action_type="Modify",
        severity="Medium",
    ))

    # 3. Old-Generation EC2 Instances
    all_recs.extend(_build_recs(
        sql=q.OLD_GEN_COMPUTE_QUERY.format(account_filter=account_filter),
        engine="Engine 1 (CUR)",
        opt_type="Modernization (Compute)",
        title_fn=lambda inst: f"Upgrade Legacy Instance ({inst})",
        desc_fn=lambda res: f"Instance {res} runs on old-generation hardware. Upgrading to the equivalent modern family (t3/m5/c5) typically saves 10-20% with better CPU performance.",
        action_type="Upgrade",
        severity="High",
    ))

    # 4. Zombie NAT Gateways
    all_recs.extend(_build_recs(
        sql=q.ZOMBIE_NAT_GATEWAYS_QUERY.format(account_filter=account_filter),
        engine="Engine 1 (CUR)",
        opt_type="Idle Resource",
        title_fn=lambda _: "Delete Zombie NAT Gateway",
        desc_fn=lambda res: f"NAT Gateway {res} is incurring continuous hourly charges but processed zero bytes of data over the last 60 days. It is likely abandoned.",
        action_type="Delete",
        severity="High",
    ))

    # 5. Idle Load Balancers
    all_recs.extend(_build_recs(
        sql=q.IDLE_LOAD_BALANCERS_QUERY.format(account_filter=account_filter),
        engine="Engine 1 (CUR)",
        opt_type="Idle Resource",
        title_fn=lambda _: "Delete Idle Load Balancer",
        desc_fn=lambda res: f"Load Balancer {res} is running but processing zero traffic (no LCU/bytes charged) over the last 60 days. Delete it to save hourly fees.",
        action_type="Delete",
        severity="Medium",
    ))

    # 6. Unattached EBS Volumes (orphaned storage)
    all_recs.extend(_build_recs(
        sql=q.UNATTACHED_EBS_QUERY.format(account_filter=account_filter),
        engine="Engine 1 (CUR)",
        opt_type="Idle Resource",
        title_fn=lambda _: "Delete Unattached EBS Volume",
        desc_fn=lambda res: f"EBS volume {res} has no associated EC2 instance billing in the last 30 days. It is an orphaned volume silently incurring storage costs. Snapshot and delete it to stop charges.",
        action_type="Delete",
        severity="High",
    ))

    # 7. Stopped EC2 with Active EBS (long-stopped trap)
    all_recs.extend(_build_recs(
        sql=q.STOPPED_EC2_WITH_EBS_QUERY.format(account_filter=account_filter),
        engine="Engine 1 (CUR)",
        opt_type="Idle Resource",
        title_fn=lambda _: "Clean Up EBS Volumes on Stopped Instance",
        desc_fn=lambda res: f"Instance {res} has had no compute billing for 14+ days (stopped/terminated) but its EBS volumes are still generating storage charges. Snapshot and delete the volumes to eliminate this waste.",
        action_type="Delete",
        severity="Medium",
    ))

    # ── Engine 2: AWS Cost Optimization Hub (ML recommendations) ──────────
    try:
        hub_filter = "" if account == "All" else f"AND account_name = '{account}'"
        hub_rows = db.query(f"""
            SELECT *
            FROM cost.aws_hub FINAL
            WHERE export_date = (
                SELECT MAX(export_date) FROM cost.aws_hub
            )
            {hub_filter}
            ORDER BY estimated_monthly_savings DESC
            LIMIT 200
        """)
        for r in hub_rows:
            savings = float(r.get("estimated_monthly_savings") or 0)
            action  = str(r.get("action_type") or "Modify")
            res_id  = str(r.get("resource_id") or "")
            rtype   = str(r.get("resource_type") or "")
            current = str(r.get("current_resource_summary") or "")
            recommended = str(r.get("recommended_resource_summary") or "")

            # Map AWS action types to severity
            severity_map = {
                "Rightsize": "High",
                "MigrateToGraviton": "High",
                "PurchaseSavingsPlans": "Medium",
                "PurchaseReservedInstances": "Medium",
            }
            severity = severity_map.get(action, "Low")

            all_recs.append(schemas.OptimizationRecommendation(
                id=f"hub-{r.get('recommendation_id', res_id)}",
                engine="Engine 2 (AWS ML)",
                type="Rightsizing" if "Rightsize" in action else ("Graviton Migration" if "Graviton" in action else "Commitment Discount"),
                title=f"{action.replace('MigrateToGraviton', 'Migrate to Graviton').replace('Rightsize', 'Rightsize')} — {rtype}",
                description=f"{res_id}: Change from {current} → {recommended}" if current and recommended else f"AWS ML recommends {action} for {res_id}.",
                severity=severity,
                estimated_monthly_savings=savings,
                resource_id=res_id,
                account_name=str(r.get("account_name") or ""),
                region=str(r.get("region") or ""),
                action_type=action,
            ))
    except Exception:
        # aws_hub table may be empty until first sync — silently skip
        pass

    # Sort by highest dollar savings first — most actionable items at the top
    all_recs.sort(key=lambda x: x.estimated_monthly_savings, reverse=True)

    return schemas.OptimizationsResponse(
        total_estimated_savings=round(sum(r.estimated_monthly_savings for r in all_recs), 2),
        recommendations=all_recs,
    )


@router.post("/sync", summary="Trigger Engine 2 sync from AWS Cost Optimization Hub")
async def sync_optimizations(background_tasks: BackgroundTasks):
    """
    Trigger a background sync of AWS Cost Optimization Hub recommendations.
    This calls boto3, paginates through all recommendations, and stores them
    in the aws_hub ClickHouse table. The main GET / endpoint then reads from there.

    Safe to call multiple times — ReplacingMergeTree deduplicates on (account, region, resource, action, date).
    """
    background_tasks.add_task(_run_hub_sync)
    return {"status": "sync started", "message": "Engine 2 sync running in background. Refresh /optimizations in ~30 seconds."}


def _run_hub_sync():
    """Background worker: fetch AWS Cost Optimization Hub recs and upsert to ClickHouse."""
    import boto3
    import logging
    from datetime import datetime
    from core.database import get_client

    logger = logging.getLogger("engine2_sync")
    today = datetime.now().date()
    ch_client = get_client()

    try:
        hub = boto3.client("cost-optimization-hub", region_name="us-east-1")
        paginator = hub.get_paginator("list_recommendations")

        rows = []
        for page in paginator.paginate():
            for rec in page.get("items", []):
                rows.append([
                    rec.get("recommendationId", ""),
                    rec.get("accountId", ""),
                    "",   # account_name — populated from accountId if needed
                    rec.get("region", ""),
                    rec.get("resourceId", ""),
                    rec.get("resourceType", ""),
                    rec.get("actionType", ""),
                    float(rec.get("estimatedMonthlySavings", 0) or 0),
                    float(rec.get("estimatedMonthlyCost", 0) or 0),
                    rec.get("currentResourceSummary", ""),
                    rec.get("recommendedResourceSummary", ""),
                    rec.get("currencyCode", "USD"),
                    today,
                    datetime.now(),
                ])

        if rows:
            cols = [
                "recommendation_id", "account_id", "account_name", "region",
                "resource_id", "resource_type", "action_type",
                "estimated_monthly_savings", "estimated_monthly_cost",
                "current_resource_summary", "recommended_resource_summary",
                "currency_code", "export_date", "ingested_at",
            ]
            ch_client.insert("cost.aws_hub", rows, column_names=cols)
            logger.info(f"Engine 2 sync complete: {len(rows)} recommendations ingested.")
        else:
            logger.info("Engine 2 sync: no recommendations returned from AWS.")

    except Exception as e:
        logger.error(f"Engine 2 sync failed: {e}", exc_info=True)
