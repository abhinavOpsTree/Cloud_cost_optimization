"""
Optimization Engine 1: CUR Waste Hunter Queries

These queries run instantly against the local ClickHouse database.
They use a fixed 30-day rolling window to ensure recommendations always reflect
CURRENTLY active waste — not historical snapshots from months ago.
The {account_filter} placeholder still respects the user's account dropdown.
"""

# Detects Public IPv4 addresses that AWS is billing for but are not attached.
IDLE_IPS_QUERY = """
    SELECT
        resource_id,
        argMax(account_name, usage_start_ts) AS account_name,
        argMax(region, usage_start_ts)       AS region,
        ROUND(
            SUM(cost_unblended) / COUNT(DISTINCT toDate(usage_start_ts)) * 30.44,
        2) AS estimated_monthly_savings
    FROM cost.service_costs
    WHERE usage_start_ts >= today() - 60
      AND (usage_type LIKE '%PublicIPv4:IdleAddress%' OR usage_type LIKE '%ElasticIP:IdleAddress%')
      {account_filter}
    GROUP BY resource_id
    HAVING estimated_monthly_savings > 0
    ORDER BY estimated_monthly_savings DESC
"""

# Detects old-generation EBS volumes (gp2) that can be migrated to gp3.
# gp3 is ~20% cheaper and has better baseline IOPS than gp2.
GP2_VOLUMES_QUERY = """
    SELECT
        resource_id,
        argMax(account_name, usage_start_ts) AS account_name,
        argMax(region, usage_start_ts)       AS region,
        ROUND(
            SUM(cost_unblended) / COUNT(DISTINCT toDate(usage_start_ts)) * 30.44 * 0.20,
        2) AS estimated_monthly_savings
    FROM cost.service_costs
    WHERE usage_start_ts >= today() - 60
      AND usage_type LIKE '%EBS:VolumeUsage.gp2%'
      {account_filter}
    GROUP BY resource_id
    HAVING estimated_monthly_savings > 0
    ORDER BY estimated_monthly_savings DESC
"""

# Detects legacy EC2 instances (t2, m4, c4) that should be upgraded to newer generations.
# Conservatively assumes 10% savings — actual savings can be higher (up to 20%).
OLD_GEN_COMPUTE_QUERY = """
    SELECT
        resource_id,
        argMax(account_name, usage_start_ts) AS account_name,
        argMax(region, usage_start_ts)       AS region,
        argMax(instance_type, usage_start_ts) AS old_instance_type,
        ROUND(
            SUM(cost_unblended) / COUNT(DISTINCT toDate(usage_start_ts)) * 30.44 * 0.10,
        2) AS estimated_monthly_savings
    FROM cost.service_costs
    WHERE usage_start_ts >= today() - 60
      AND product_code = 'AmazonEC2'
      AND instance_type IN ('t2.nano', 't2.micro', 't2.small', 't2.medium', 't2.large', 't2.xlarge', 't2.2xlarge',
                            'm4.large', 'm4.xlarge', 'm4.2xlarge', 'm4.4xlarge', 'm4.10xlarge', 'm4.16xlarge',
                            'c4.large', 'c4.xlarge', 'c4.2xlarge', 'c4.4xlarge', 'c4.8xlarge')
      {account_filter}
    GROUP BY resource_id
    HAVING estimated_monthly_savings > 0
    ORDER BY estimated_monthly_savings DESC
"""

# Detects NAT Gateways that are incurring hourly charges but processing zero data (zombies).
# Savings equal the full cost of the NAT Gateway over the period.
ZOMBIE_NAT_GATEWAYS_QUERY = """
    SELECT
        resource_id,
        argMax(account_name, usage_start_ts) AS account_name,
        argMax(region, usage_start_ts)       AS region,
        ROUND(
            SUM(cost_unblended) / COUNT(DISTINCT toDate(usage_start_ts)) * 30.44,
        2) AS estimated_monthly_savings
    FROM cost.service_costs
    WHERE usage_start_ts >= today() - 60
      AND product_code = 'AmazonEC2'
      AND (usage_type LIKE '%NatGateway-Hours%' OR usage_type LIKE '%NatGateway-Bytes%')
      {account_filter}
    GROUP BY resource_id
    HAVING 
        SUM(CASE WHEN usage_type LIKE '%NatGateway-Hours%' THEN cost_unblended ELSE 0 END) > 0
        AND SUM(CASE WHEN usage_type LIKE '%NatGateway-Bytes%' THEN cost_unblended ELSE 0 END) = 0
        AND estimated_monthly_savings > 0
    ORDER BY estimated_monthly_savings DESC
"""

# Detects Load Balancers (ALB, NLB, ELB) that are incurring hourly charges but processing zero LCU/data (idle).
# Savings equal the full cost of the Load Balancer over the period.
IDLE_LOAD_BALANCERS_QUERY = """
    SELECT
        resource_id,
        argMax(account_name, usage_start_ts) AS account_name,
        argMax(region, usage_start_ts)       AS region,
        ROUND(
            SUM(cost_unblended) / COUNT(DISTINCT toDate(usage_start_ts)) * 30.44,
        2) AS estimated_monthly_savings
    FROM cost.service_costs
    WHERE usage_start_ts >= today() - 60
      AND product_code = 'AWSElasticLoadBalancing'
      AND (usage_type LIKE '%LoadBalancerUsage%' OR usage_type LIKE '%LCUUsage%' OR usage_type LIKE '%DataProcessing-Bytes%')
      {account_filter}
    GROUP BY resource_id
    HAVING 
        SUM(CASE WHEN usage_type LIKE '%LoadBalancerUsage%' THEN cost_unblended ELSE 0 END) > 0
        AND SUM(CASE WHEN usage_type LIKE '%LCUUsage%' OR usage_type LIKE '%DataProcessing-Bytes%' THEN cost_unblended ELSE 0 END) = 0
        AND estimated_monthly_savings > 0
    ORDER BY estimated_monthly_savings DESC
"""


# Detects EBS volumes that have been incurring charges but have NO associated
# EC2 instance billing in the same period — meaning they are unattached orphans.
# Savings = full cost of the volume (just delete it).
UNATTACHED_EBS_QUERY = """
    SELECT
        resource_id,
        argMax(account_name, usage_start_ts) AS account_name,
        argMax(region, usage_start_ts)       AS region,
        ROUND(
            SUM(cost_unblended) / COUNT(DISTINCT toDate(usage_start_ts)) * 30.44,
        2) AS estimated_monthly_savings
    FROM cost.service_costs
    WHERE usage_start_ts >= today() - 60
      AND product_code = 'AmazonEC2'
      AND usage_type LIKE '%EBS:VolumeUsage%'
      AND resource_id LIKE 'vol-%'
      -- Exclude volumes that have had compute billing in the last 30 days
      -- (attached volumes are co-billed alongside BoxUsage rows)
      AND resource_id NOT IN (
          SELECT DISTINCT resource_id
          FROM cost.service_costs
          WHERE usage_start_ts >= today() - 30
            AND product_code = 'AmazonEC2'
            AND usage_type LIKE '%BoxUsage%'
            AND resource_id LIKE 'vol-%'
      )
      {account_filter}
    GROUP BY resource_id
    HAVING estimated_monthly_savings > 0
    ORDER BY estimated_monthly_savings DESC
"""


# Detects EC2 instances that have been STOPPED (no compute rows in 14+ days)
# but are still accruing EBS storage charges for their attached volumes.
# This is the "long-stopped trap" — the instance looks terminated in CUR
# but the EBS volumes are silently billing you every month.
# Savings = the EBS cost currently being wasted on those volumes.
STOPPED_EC2_WITH_EBS_QUERY = """
    SELECT
        resource_id,
        argMax(account_name, usage_start_ts) AS account_name,
        argMax(region, usage_start_ts)       AS region,
        ROUND(
            SUM(cost_unblended) / COUNT(DISTINCT toDate(usage_start_ts)) * 30.44,
        2) AS estimated_monthly_savings
    FROM cost.service_costs
    WHERE usage_start_ts >= today() - 30
      AND product_code = 'AmazonEC2'
      AND usage_type LIKE '%EBS:VolumeUsage%'
      AND resource_id IN (
          -- Instances with billing history but no compute rows in the last 14 days
          SELECT resource_id
          FROM cost.service_costs
          WHERE usage_start_ts >= today() - 90
            AND product_code = 'AmazonEC2'
            AND resource_id LIKE 'i-%'
            AND usage_type LIKE '%BoxUsage%'
            {account_filter}
          GROUP BY resource_id
          HAVING MAX(toDate(usage_start_ts)) < today() - 14
      )
      {account_filter}
    GROUP BY resource_id
    HAVING estimated_monthly_savings > 0
    ORDER BY estimated_monthly_savings DESC
"""
