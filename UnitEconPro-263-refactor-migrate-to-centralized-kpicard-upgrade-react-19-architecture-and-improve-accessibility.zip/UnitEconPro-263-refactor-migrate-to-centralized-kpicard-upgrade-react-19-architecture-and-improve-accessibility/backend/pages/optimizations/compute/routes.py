"""
Compute Optimization Routes

GET /api/v1/optimizations/compute/ec2
    → EC2 savings breakdown by issue type + per-instance list
"""
from fastapi import APIRouter, Query
from typing import Annotated, Optional, Union

from core import database as db
from . import queries as q
from .queries import EC2_INSTANCE_DETAIL
from . import schemas

router = APIRouter(
    prefix="/api/v1/optimizations/compute",
    tags=["Optimizations – Compute"],
)

_SEVERITY = {
    "SEVERELY_OVER_PROVISIONED": "Critical",
    "OVER_PROVISIONED":          "High",
    "oldgen":                    "High",
    "stopped_ebs":               "Medium",
    "savings_plan":              "High",
}

_OLDGEN_MAP = {
    "t2.nano": "t3.nano", "t2.micro": "t3.micro", "t2.small": "t3.small",
    "t2.medium": "t3.medium", "t2.large": "t3.large",
    "t2.xlarge": "t3.xlarge", "t2.2xlarge": "t3.2xlarge",
    "m4.large": "m5.large", "m4.xlarge": "m5.xlarge",
    "m4.2xlarge": "m5.2xlarge", "m4.4xlarge": "m5.4xlarge",
    "c4.large": "c5.large", "c4.xlarge": "c5.xlarge",
    "c4.2xlarge": "c5.2xlarge", "c4.4xlarge": "c5.4xlarge",
}

_DOWNSIZE_MAP = {
    "t3.medium": "t3.small", "t3.large": "t3.medium",
    "t3.xlarge": "t3.large", "t3.2xlarge": "t3.xlarge",
    "t2.medium": "t2.small", "t2.large": "t2.medium",
    "t2.xlarge": "t2.large", "t2.2xlarge": "t2.xlarge",
    "m5.large": "m5.medium", "m5.xlarge": "m5.large",
    "m5.2xlarge": "m5.xlarge", "m5.4xlarge": "m5.2xlarge",
    "c5.large": "c5.medium", "c5.xlarge": "c5.large",
    "c5.2xlarge": "c5.xlarge", "c5a.2xlarge": "c5a.xlarge",
    "c5a.xlarge": "c5a.large",
}


def _account_filter(account: str) -> str:
    if account == "All":
        return ""
    safe = account.replace("'", "''")
    return f"AND account_name = '{safe}'"




# ── /compute/ec2 ─────────────────────────────────────────────────────────────

@router.get("/ec2")
def get_ec2_summary(
    account:     Annotated[str, Query(description="Account name or 'All'")] = "All",
    instance_id: Annotated[Optional[str], Query(description="Filter to a single instance ID")] = None,
):
    """
    No instance_id  → all EC2 instances with savings summary
    With instance_id → single instance deep-dive with all recommendations
    """
    af = _account_filter(account)

    if instance_id:
        return _get_instance_detail(instance_id, af)

    rightsizing_rows = db.query(q.EC2_RIGHTSIZING_SAVINGS.format(account_filter=af))
    oldgen_rows      = db.query(q.EC2_OLDGEN_SAVINGS.format(account_filter=af))
    stopped_rows     = db.query(q.EC2_STOPPED_EBS_WASTE.format(account_filter=af))
    sp_rows          = db.query(q.EC2_SAVINGS_PLAN_CANDIDATES.format(account_filter=af))

    # Deduplicate — an instance can appear in both rightsizing AND savings_plan
    # Keep highest saving per instance, track all issues
    instance_map: dict = {}

    def _upsert(rows, issue_key, top_issue_fn, severity_key):
        for r in rows:
            iid      = str(r["instance_id"])
            savings  = float(r.get("monthly_savings") or 0)
            cost     = float(r.get("monthly_cost") or 0)
            name_tag = (r.get("tags") or {}).get("Name", "")

            if iid not in instance_map:
                instance_map[iid] = {
                    "instance_id":    iid,
                    "instance_name":  name_tag or iid,
                    "instance_type":  str(r.get("instance_type") or ""),
                    "instance_state": str(r.get("instance_state") or ""),
                    "region":         str(r.get("region") or ""),
                    "account_name":   str(r.get("account_name") or ""),
                    "monthly_cost":   cost,
                    "monthly_savings": savings,
                    "top_issue":      top_issue_fn(r),
                    "severity":       _SEVERITY[severity_key],
                    "issues":         {issue_key: savings},
                }
            else:
                instance_map[iid]["monthly_savings"] += savings
                instance_map[iid]["issues"][issue_key] = savings
                # upgrade severity if higher
                sev_order = {"Critical": 4, "High": 3, "Medium": 2, "Low": 1}
                new_sev = _SEVERITY[severity_key]
                if sev_order.get(new_sev, 0) > sev_order.get(instance_map[iid]["severity"], 0):
                    instance_map[iid]["severity"] = new_sev
                    instance_map[iid]["top_issue"] = top_issue_fn(r)

    for r in rightsizing_rows:
        _upsert([r], "rightsizing",
                lambda row: f"CPU avg {row['cpu_avg_pct']:.1f}% — {row['rightsizing_signal'].replace('_', ' ').title()}",
                r["rightsizing_signal"])

    for r in oldgen_rows:
        _upsert([r], "oldgen",
                lambda row: f"Old-gen {row['instance_type']} \u2192 upgrade to {_OLDGEN_MAP.get(str(row['instance_type']), 'newer gen')}",
                "oldgen")

    for r in stopped_rows:
        _upsert([r], "stopped_ebs",
                lambda row: f"Stopped instance paying ${row['monthly_cost']:.2f}/mo EBS storage",
                "stopped_ebs")

    for r in sp_rows:
        _upsert([r], "savings_plan",
                lambda row: "Continuous OnDemand \u2014 1-yr Savings Plan saves 40%",
                "savings_plan")

    # Build by_issue breakdown
    issue_totals = {
        "Over-provisioned (Rightsizing)": {"count": 0, "savings": 0.0},
        "Old Generation Upgrade":         {"count": 0, "savings": 0.0},
        "Stopped Instance EBS Waste":     {"count": 0, "savings": 0.0},
        "Savings Plan Opportunity":       {"count": 0, "savings": 0.0},
    }
    issue_key_map = {
        "rightsizing": "Over-provisioned (Rightsizing)",
        "oldgen":      "Old Generation Upgrade",
        "stopped_ebs": "Stopped Instance EBS Waste",
        "savings_plan":"Savings Plan Opportunity",
    }
    for inst in instance_map.values():
        for k, v in inst["issues"].items():
            label = issue_key_map[k]
            issue_totals[label]["count"]   += 1
            issue_totals[label]["savings"] += v

    by_issue = [
        schemas.IssueSavings(issue=label, count=d["count"],
                             monthly_savings=round(d["savings"], 2))
        for label, d in issue_totals.items()
        if d["count"] > 0
    ]

    instances = [
        schemas.EC2InstanceSaving(
            instance_id=v["instance_id"],
            instance_name=v["instance_name"],
            instance_type=v["instance_type"],
            instance_state=v["instance_state"],
            region=v["region"],
            account_name=v["account_name"],
            monthly_cost=round(v["monthly_cost"], 2),
            monthly_savings=round(v["monthly_savings"], 2),
            saving_pct=round(v["monthly_savings"] / v["monthly_cost"] * 100, 1)
                       if v["monthly_cost"] > 0 else 0,
            top_issue=v["top_issue"],
            severity=v["severity"],
        )
        for v in sorted(instance_map.values(),
                        key=lambda x: x["monthly_savings"], reverse=True)
    ]

    total_cost    = sum(i.monthly_cost for i in instances)
    total_savings = sum(i.monthly_savings for i in instances)

    return schemas.EC2Summary(
        total_monthly_cost=round(total_cost, 2),
        total_monthly_savings=round(total_savings, 2),
        saving_pct=round(total_savings / total_cost * 100, 1) if total_cost > 0 else 0,
        by_issue=sorted(by_issue, key=lambda x: x.monthly_savings, reverse=True),
        instances=instances,
    )


# ── helpers ───────────────────────────────────────────────────────────────────

def _get_ec2_total_savings(account_filter: str) -> float:
    rightsizing = db.query(q.EC2_RIGHTSIZING_SAVINGS.format(account_filter=account_filter))
    oldgen      = db.query(q.EC2_OLDGEN_SAVINGS.format(account_filter=account_filter))
    stopped     = db.query(q.EC2_STOPPED_EBS_WASTE.format(account_filter=account_filter))
    sp          = db.query(q.EC2_SAVINGS_PLAN_CANDIDATES.format(account_filter=account_filter))

    # Deduplicate savings_plan vs rightsizing — don't double-count same instance
    rightsizing_ids = {str(r["instance_id"]) for r in rightsizing}
    sp_deduped = [r for r in sp if str(r["instance_id"]) not in rightsizing_ids]

    total = (
        sum(float(r.get("monthly_savings") or 0) for r in rightsizing) +
        sum(float(r.get("monthly_savings") or 0) for r in oldgen) +
        sum(float(r.get("monthly_savings") or 0) for r in stopped) +
        sum(float(r.get("monthly_savings") or 0) for r in sp_deduped)
    )
    return round(total, 2)


# ── Single instance detail ────────────────────────────────────────────────────

_DOWNSIZE_MAP = {
    "t3.nano": "t3.nano", "t3.micro": "t3.nano", "t3.small": "t3.micro",
    "t3.medium": "t3.small", "t3.large": "t3.medium",
    "t3.xlarge": "t3.large", "t3.2xlarge": "t3.xlarge",
    "t2.micro": "t2.nano", "t2.small": "t2.micro",
    "t2.medium": "t2.small", "t2.large": "t2.medium",
    "t2.xlarge": "t2.large", "t2.2xlarge": "t2.xlarge",
    "m5.large": "m5.large", "m5.xlarge": "m5.large",
    "m5.2xlarge": "m5.xlarge", "m5.4xlarge": "m5.2xlarge",
    "c5.xlarge": "c5.large", "c5.2xlarge": "c5.xlarge",
    "c5a.xlarge": "c5a.large", "c5a.2xlarge": "c5a.xlarge",
}


def _get_instance_detail(instance_id: str, af: str) -> schemas.EC2InstanceDetail:
    from fastapi import HTTPException

    rows = db.query(EC2_INSTANCE_DETAIL, params={"instance_id": instance_id})
    if not rows:
        raise HTTPException(status_code=404, detail=f"Instance '{instance_id}' not found or has no billing data")

    r            = rows[0]
    monthly_cost = float(r.get("monthly_cost") or 0)
    signal       = str(r.get("rightsizing_signal") or "")
    itype        = str(r.get("instance_type") or "")
    lifecycle    = str(r.get("instance_lifecycle") or "")
    state        = str(r.get("instance_state") or "")
    active_days  = int(r.get("active_days") or 0)
    cpu_avg      = float(r.get("cpu_avg_pct") or -1)
    tags         = r.get("tags") or {}
    name         = tags.get("Name", instance_id)

    recs: list[schemas.EC2Recommendation] = []

    # 1. Rightsizing
    if signal in ("OVER_PROVISIONED", "SEVERELY_OVER_PROVISIONED") and cpu_avg >= 0:
        saving_pct   = 0.55 if signal == "SEVERELY_OVER_PROVISIONED" else 0.40
        savings      = round(monthly_cost * saving_pct, 2)
        target_type  = _DOWNSIZE_MAP.get(itype, f"smaller {itype}")
        recs.append(schemas.EC2Recommendation(
            type="Rightsizing",
            severity="Critical" if signal == "SEVERELY_OVER_PROVISIONED" else "High",
            effort="Medium",
            issue=f"CPU avg {cpu_avg:.1f}% over 30 days — {signal.replace('_', ' ').title()}",
            action=f"Downsize {itype} → {target_type}",
            current_config=f"{itype} — ${monthly_cost:.2f}/mo",
            recommended_config=f"{target_type} — ${monthly_cost - savings:.2f}/mo",
            monthly_savings=savings,
            saving_pct=round(saving_pct * 100, 1),
        ))

    # 2. Old-gen upgrade
    if itype in _OLDGEN_MAP:
        savings = round(monthly_cost * 0.15, 2)
        recs.append(schemas.EC2Recommendation(
            type="OldGen",
            severity="High",
            effort="Medium",
            issue=f"{itype} is old-generation hardware",
            action=f"Upgrade {itype} → {_OLDGEN_MAP[itype]}",
            current_config=f"{itype} — ${monthly_cost:.2f}/mo",
            recommended_config=f"{_OLDGEN_MAP[itype]} — ${monthly_cost - savings:.2f}/mo",
            monthly_savings=savings,
            saving_pct=15.0,
        ))

    # 3. Stopped instance EBS waste
    root_gb = int(r.get("root_volume_size_gb") or 0)
    if state == "stopped" and root_gb > 0:
        savings = round(root_gb * 0.08, 2)
        recs.append(schemas.EC2Recommendation(
            type="StoppedEBS",
            severity="Medium",
            effort="Immediate",
            issue=f"Instance stopped but {root_gb}GB EBS volume still billing",
            action="Snapshot and delete EBS volume, or terminate instance",
            current_config=f"{root_gb}GB gp3 — ${savings:.2f}/mo",
            recommended_config="$0/mo after deletion",
            monthly_savings=savings,
            saving_pct=100.0,
        ))

    # 4. Savings plan (continuous OnDemand)
    if state == "running" and lifecycle == "on-demand" and active_days >= 60:
        savings = round(monthly_cost * 0.40, 2)
        recs.append(schemas.EC2Recommendation(
            type="SavingsPlan",
            severity="High",
            effort="Low",
            issue=f"Running OnDemand for {active_days} days continuously",
            action="Purchase 1-year Compute Savings Plan (no upfront)",
            current_config=f"OnDemand — ${monthly_cost:.2f}/mo",
            recommended_config=f"Savings Plan — ${monthly_cost - savings:.2f}/mo",
            monthly_savings=savings,
            saving_pct=40.0,
        ))

    # 5. Governance — missing Environment tag
    if not tags.get("Environment") and state == "running":
        recs.append(schemas.EC2Recommendation(
            type="Governance",
            severity="Medium",
            effort="Immediate",
            issue="No Environment tag on running instance",
            action="Add tag: Environment=prod/dev/staging",
            monthly_savings=0,
        ))

    # 6. Public IP cost flag
    if r.get("has_public_ip") and state == "running":
        recs.append(schemas.EC2Recommendation(
            type="Governance",
            severity="Low",
            effort="Low",
            issue="Public IPv4 attached — $3.65/mo charge since Feb 2024",
            action="Convert to Elastic IP to prevent address churn on restart",
            monthly_savings=0,
        ))

    # 7. gp2 root volume
    if str(r.get("root_volume_type") or "") == "gp2":
        vol_savings = round(root_gb * 0.08 * 0.20, 2)
        recs.append(schemas.EC2Recommendation(
            type="Modernization",
            severity="Medium",
            effort="Immediate",
            issue="Root volume is gp2 — 20% more expensive than gp3",
            action="Modify volume type to gp3 (zero downtime, free operation)",
            current_config=f"gp2 {root_gb}GB",
            recommended_config=f"gp3 {root_gb}GB",
            monthly_savings=vol_savings,
            saving_pct=20.0,
        ))

    total_savings = round(sum(rec.monthly_savings for rec in recs), 2)

    return schemas.EC2InstanceDetail(
        instance_id=instance_id,
        instance_name=name,
        instance_type=itype,
        instance_state=state,
        instance_lifecycle=lifecycle,
        region=str(r.get("region") or ""),
        account_name=str(r.get("account_name") or ""),
        monthly_cost=monthly_cost,
        total_monthly_savings=total_savings,
        saving_pct=round(total_savings / monthly_cost * 100, 1) if monthly_cost > 0 else 0,
        cpu_avg_pct=cpu_avg if cpu_avg >= 0 else None,
        cpu_max_pct=float(r.get("cpu_max_pct") or -1) if float(r.get("cpu_max_pct") or -1) >= 0 else None,
        cpu_p95_pct=float(r.get("cpu_p95_pct") or -1) if float(r.get("cpu_p95_pct") or -1) >= 0 else None,
        net_in_mbps=float(r.get("net_in_mbps") or -1) if float(r.get("net_in_mbps") or -1) >= 0 else None,
        net_out_mbps=float(r.get("net_out_mbps") or -1) if float(r.get("net_out_mbps") or -1) >= 0 else None,
        active_days=active_days,
        tags=tags,
        recommendations=sorted(recs, key=lambda x: x.monthly_savings, reverse=True),
    )
