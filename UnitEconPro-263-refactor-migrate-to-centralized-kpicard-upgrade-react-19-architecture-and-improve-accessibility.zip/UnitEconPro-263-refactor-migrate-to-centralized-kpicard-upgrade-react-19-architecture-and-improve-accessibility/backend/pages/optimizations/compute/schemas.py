from pydantic import BaseModel
from typing import Optional, List


class ServiceSavings(BaseModel):
    service:          str
    monthly_cost:     float
    monthly_savings:  float
    saving_pct:       float
    resource_count:   int


class ComputeSummary(BaseModel):
    total_monthly_cost:    float
    total_monthly_savings: float
    saving_pct:            float
    by_service:            List[ServiceSavings]


class IssueSavings(BaseModel):
    issue:           str
    count:           int
    monthly_savings: float


class EC2InstanceSaving(BaseModel):
    instance_id:     str
    instance_name:   Optional[str] = None
    instance_type:   Optional[str] = None
    instance_state:  str
    region:          str
    account_name:    str
    monthly_cost:    float
    monthly_savings: float
    saving_pct:      float
    top_issue:       str
    severity:        str


class EC2Summary(BaseModel):
    total_monthly_cost:    float
    total_monthly_savings: float
    saving_pct:            float
    by_issue:              List[IssueSavings]
    instances:             List[EC2InstanceSaving]


# ── Single instance detail ────────────────────────────────────────────────────

class EC2Recommendation(BaseModel):
    type:               str    # Rightsizing | OldGen | StoppedEBS | SavingsPlan | Governance
    severity:           str    # Critical | High | Medium | Low
    effort:             str    # Immediate | Low | Medium | High
    issue:              str
    action:             str
    current_config:     Optional[str] = None
    recommended_config: Optional[str] = None
    monthly_savings:    float
    saving_pct:         Optional[float] = None


class EC2InstanceDetail(BaseModel):
    instance_id:           str
    instance_name:         Optional[str] = None
    instance_type:         Optional[str] = None
    instance_state:        str
    instance_lifecycle:    str
    region:                str
    account_name:          str
    monthly_cost:          float
    total_monthly_savings: float
    saving_pct:            float
    cpu_avg_pct:           Optional[float] = None
    cpu_max_pct:           Optional[float] = None
    cpu_p95_pct:           Optional[float] = None
    net_in_mbps:           Optional[float] = None
    net_out_mbps:          Optional[float] = None
    active_days:           int
    tags:                  Optional[dict] = None
    recommendations:       List[EC2Recommendation]
