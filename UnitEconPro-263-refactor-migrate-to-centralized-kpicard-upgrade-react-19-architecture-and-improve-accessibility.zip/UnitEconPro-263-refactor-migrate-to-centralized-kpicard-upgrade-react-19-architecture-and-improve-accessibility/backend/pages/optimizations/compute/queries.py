"""
Compute Optimization Queries
All savings calculated from live ClickHouse data — no ingestion needed.
"""

# ── Level 1: Total monthly cost per compute service ──────────────────────────
COMPUTE_COST_BY_SERVICE = """
    SELECT
        product_code                                        AS service,
        round(sum(cost_unblended) / 90 * 30, 2)            AS monthly_cost,
        count(DISTINCT resource_id)                         AS resource_count
    FROM cost.service_costs
    WHERE usage_start_ts >= now() - INTERVAL 90 DAY
      AND product_code IN ('AmazonEC2', 'AmazonECR', 'AmazonEKS')
      {account_filter}
    GROUP BY product_code
"""

# ── EC2 savings queries ───────────────────────────────────────────────────────

# Over-provisioned EC2 (from CloudWatch CPU data)
# OVER_PROVISIONED      → 40% savings (downsize 1 size)
# SEVERELY_OVER_PROVISIONED → 55% savings (downsize 2 sizes)
EC2_RIGHTSIZING_SAVINGS = """
    SELECT
        m.instance_id,
        m.instance_type,
        m.instance_state,
        m.region,
        m.account_name,
        m.rightsizing_signal,
        m.cpu_avg_pct,
        m.cpu_p95_pct,
        m.cpu_max_pct,
        m.tags,
        round(sum(sc.cost_unblended) / 90 * 30, 2)         AS monthly_cost,
        round(sum(sc.cost_unblended) / 90 * 30 *
            multiIf(m.rightsizing_signal = 'SEVERELY_OVER_PROVISIONED', 0.55,
                    m.rightsizing_signal = 'OVER_PROVISIONED', 0.40, 0), 2)
                                                            AS monthly_savings
    FROM cost.aws_ec2_metadata AS m FINAL
    JOIN cost.service_costs AS sc FINAL ON sc.resource_id = m.instance_id
    WHERE m.rightsizing_signal IN ('OVER_PROVISIONED', 'SEVERELY_OVER_PROVISIONED')
      AND m.cpu_avg_pct >= 0
      AND sc.product_code = 'AmazonEC2'
      AND sc.usage_type LIKE '%BoxUsage%'
      AND sc.usage_start_ts >= now() - INTERVAL 90 DAY
      {account_filter}
    GROUP BY m.instance_id, m.instance_type, m.instance_state, m.region,
             m.account_name, m.rightsizing_signal, m.cpu_avg_pct,
             m.cpu_p95_pct, m.cpu_max_pct, m.tags
    HAVING monthly_savings > 0
    ORDER BY monthly_savings DESC
"""

# Old-generation instances (t2, m4, c4) → upgrade saves ~15%
EC2_OLDGEN_SAVINGS = """
    SELECT
        sc.resource_id                                      AS instance_id,
        argMax(sc.instance_type, sc.usage_start_ts)        AS instance_type,
        argMax(sc.account_name, sc.usage_start_ts)         AS account_name,
        argMax(sc.region, sc.usage_start_ts)               AS region,
        coalesce(m.instance_state, '')                      AS instance_state,
        m.tags,
        round(sum(sc.cost_unblended) / 90 * 30, 2)         AS monthly_cost,
        round(sum(sc.cost_unblended) / 90 * 30 * 0.15, 2)  AS monthly_savings
    FROM cost.service_costs AS sc FINAL
    LEFT JOIN cost.aws_ec2_metadata AS m FINAL ON m.instance_id = sc.resource_id
    WHERE sc.product_code = 'AmazonEC2'
      AND sc.usage_type LIKE '%BoxUsage%'
      AND sc.usage_start_ts >= now() - INTERVAL 90 DAY
      AND sc.instance_type IN (
          't2.nano','t2.micro','t2.small','t2.medium','t2.large','t2.xlarge','t2.2xlarge',
          'm4.large','m4.xlarge','m4.2xlarge','m4.4xlarge','m4.10xlarge','m4.16xlarge',
          'c4.large','c4.xlarge','c4.2xlarge','c4.4xlarge','c4.8xlarge'
      )
      {account_filter}
    GROUP BY sc.resource_id, m.instance_state, m.tags
    HAVING monthly_savings > 0
    ORDER BY monthly_savings DESC
"""

# Stopped EC2 instances still paying for attached EBS volumes
EC2_STOPPED_EBS_WASTE = """
    SELECT
        instance_id,
        instance_type,
        instance_state,
        region,
        account_name,
        attached_ebs_count,
        root_volume_size_gb,
        tags,
        round(root_volume_size_gb * 0.08, 2) AS monthly_cost,
        round(root_volume_size_gb * 0.08, 2) AS monthly_savings
    FROM cost.aws_ec2_metadata FINAL
    WHERE instance_state = 'stopped'
      AND attached_ebs_count > 0
      AND root_volume_size_gb > 0
      {account_filter}
    ORDER BY monthly_savings DESC
"""

# Continuous OnDemand instances — savings plan saves ~40%
EC2_SAVINGS_PLAN_CANDIDATES = """
    SELECT
        m.instance_id,
        m.instance_type,
        m.instance_state,
        m.region,
        m.account_name,
        m.tags,
        round(sum(sc.cost_unblended) / 90 * 30, 2)         AS monthly_cost,
        round(sum(sc.cost_unblended) / 90 * 30 * 0.40, 2)  AS monthly_savings
    FROM cost.aws_ec2_metadata AS m FINAL
    JOIN cost.service_costs AS sc FINAL ON sc.resource_id = m.instance_id
    WHERE m.instance_state = 'running'
      AND m.instance_lifecycle = 'on-demand'
      AND sc.product_code = 'AmazonEC2'
      AND sc.usage_type LIKE '%BoxUsage%'
      AND sc.usage_start_ts >= now() - INTERVAL 90 DAY
      {account_filter}
    GROUP BY m.instance_id, m.instance_type, m.instance_state,
             m.region, m.account_name, m.tags
    HAVING count(DISTINCT toDate(sc.usage_start_ts)) >= 60
       AND monthly_savings > 0
    ORDER BY monthly_savings DESC
"""


# Single instance full detail
EC2_INSTANCE_DETAIL = """
    SELECT
        m.instance_id,
        m.instance_type,
        m.instance_state,
        m.instance_lifecycle,
        m.region,
        m.account_name,
        m.cpu_avg_pct,
        m.cpu_max_pct,
        m.cpu_p95_pct,
        m.net_in_mbps,
        m.net_out_mbps,
        m.rightsizing_signal,
        m.has_public_ip,
        m.root_volume_type,
        m.root_volume_size_gb,
        m.detailed_monitoring,
        m.tags,
        round(sum(sc.cost_unblended) / 90 * 30, 2)         AS monthly_cost,
        count(DISTINCT toDate(sc.usage_start_ts))           AS active_days
    FROM cost.aws_ec2_metadata AS m FINAL
    JOIN cost.service_costs AS sc FINAL ON sc.resource_id = m.instance_id
    WHERE m.instance_id = {instance_id:String}
      AND sc.product_code = 'AmazonEC2'
      AND sc.usage_type LIKE '%BoxUsage%'
      AND sc.usage_start_ts >= now() - INTERVAL 90 DAY
    GROUP BY m.instance_id, m.instance_type, m.instance_state, m.instance_lifecycle,
             m.region, m.account_name, m.cpu_avg_pct, m.cpu_max_pct, m.cpu_p95_pct,
             m.net_in_mbps, m.net_out_mbps, m.rightsizing_signal,
             m.has_public_ip, m.root_volume_type, m.root_volume_size_gb,
             m.detailed_monitoring, m.tags
"""
