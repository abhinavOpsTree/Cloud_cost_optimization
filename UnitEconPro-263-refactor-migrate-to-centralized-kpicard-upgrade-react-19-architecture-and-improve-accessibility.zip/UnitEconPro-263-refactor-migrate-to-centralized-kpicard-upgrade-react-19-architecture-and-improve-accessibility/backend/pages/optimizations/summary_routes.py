"""
GET /api/v1/optimizations/summary?category=compute
GET /api/v1/optimizations/summary?category=compute&service=ec2
GET /api/v1/optimizations/summary?category=compute&service=eks
GET /api/v1/optimizations/summary?category=compute&service=ecr

category only  → total cost + savings across all services in that category
category+service → scoped to that specific service

category=compute, service=ec2  → fully implemented
category=compute, service=ecr  → coming soon
category=compute, service=eks  → coming soon
category=storage               → coming soon
category=network               → coming soon
"""
from fastapi import APIRouter, Query, HTTPException
from typing import Annotated, Optional
from pydantic import BaseModel

from core import database as db
from pages.optimizations.compute.queries import (
    COMPUTE_COST_BY_SERVICE,
    EC2_RIGHTSIZING_SAVINGS,
    EC2_OLDGEN_SAVINGS,
    EC2_STOPPED_EBS_WASTE,
    EC2_SAVINGS_PLAN_CANDIDATES,
)

router = APIRouter(
    prefix="/api/v1/optimizations",
    tags=["Optimizations – Summary"],
)


class OptimizationSummary(BaseModel):
    category:              str
    service:               Optional[str] = None
    total_monthly_cost:    float
    total_monthly_savings: float
    saving_pct:            float


def _af(account: str) -> str:
    if account == "All":
        return ""
    return f"AND account_name = '{account.replace(chr(39), chr(39)*2)}'"


def _ec2_cost_and_savings(af: str) -> tuple[float, float]:
    cost_rows   = db.query(COMPUTE_COST_BY_SERVICE.format(account_filter=af))
    ec2_cost    = next((float(r["monthly_cost"]) for r in cost_rows if r["service"] == "AmazonEC2"), 0.0)

    rightsizing = db.query(EC2_RIGHTSIZING_SAVINGS.format(account_filter=af))
    oldgen      = db.query(EC2_OLDGEN_SAVINGS.format(account_filter=af))
    stopped     = db.query(EC2_STOPPED_EBS_WASTE.format(account_filter=af))
    sp          = db.query(EC2_SAVINGS_PLAN_CANDIDATES.format(account_filter=af))

    rs_ids     = {str(r["instance_id"]) for r in rightsizing}
    sp_deduped = [r for r in sp if str(r["instance_id"]) not in rs_ids]

    ec2_savings = round(
        sum(float(r.get("monthly_savings") or 0) for r in rightsizing) +
        sum(float(r.get("monthly_savings") or 0) for r in oldgen) +
        sum(float(r.get("monthly_savings") or 0) for r in stopped) +
        sum(float(r.get("monthly_savings") or 0) for r in sp_deduped),
        2
    )
    return ec2_cost, ec2_savings


@router.get("/summary", response_model=OptimizationSummary)
def get_optimization_summary(
    category: Annotated[str, Query(description="compute | storage | network")] = "compute",
    service:  Annotated[Optional[str], Query(description="ec2 | ecr | eks (optional — omit for all)")] = None,
    account:  Annotated[str, Query(description="Account name or 'All'")] = "All",
):
    af  = _af(account)
    cat = category.lower()
    svc = service.lower() if service else None

    if cat != "compute":
        raise HTTPException(status_code=501, detail=f"category='{cat}' not yet implemented")

    cost_rows = db.query(COMPUTE_COST_BY_SERVICE.format(account_filter=af))

    if svc is None:
        # All compute services
        ec2_cost, ec2_savings = _ec2_cost_and_savings(af)
        ecr_cost = next((float(r["monthly_cost"]) for r in cost_rows if r["service"] == "AmazonECR"), 0.0)
        eks_cost = next((float(r["monthly_cost"]) for r in cost_rows if r["service"] == "AmazonEKS"), 0.0)

        total_cost    = round(ec2_cost + ecr_cost + eks_cost, 2)
        total_savings = round(ec2_savings + ecr_cost * 0.10 + eks_cost * 0.20, 2)

    elif svc == "ec2":
        total_cost, total_savings = _ec2_cost_and_savings(af)

    elif svc in ("ecr", "eks"):
        svc_key  = "AmazonECR" if svc == "ecr" else "AmazonEKS"
        pct      = 0.10        if svc == "ecr" else 0.20
        total_cost = next((float(r["monthly_cost"]) for r in cost_rows if r["service"] == svc_key), 0.0)
        total_savings = round(total_cost * pct, 2)

    else:
        raise HTTPException(status_code=400, detail=f"Unknown service '{svc}'. Valid for compute: ec2, ecr, eks")

    return OptimizationSummary(
        category=cat,
        service=svc,
        total_monthly_cost=round(total_cost, 2),
        total_monthly_savings=round(total_savings, 2),
        saving_pct=round(total_savings / total_cost * 100, 1) if total_cost > 0 else 0,
    )
