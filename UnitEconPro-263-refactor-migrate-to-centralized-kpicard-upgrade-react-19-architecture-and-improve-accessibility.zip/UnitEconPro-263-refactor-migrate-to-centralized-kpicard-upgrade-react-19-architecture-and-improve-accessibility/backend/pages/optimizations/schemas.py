from pydantic import BaseModel
from typing import Optional, List

class OptimizationRecommendation(BaseModel):
    id: str
    engine: str  # "Engine 1 (CUR)" or "Engine 2 (AWS ML)" or "Engine 3 (EC2 API)"
    type: str    # "Idle Resource", "Modernization", "Rightsizing"
    title: str
    description: str
    severity: str # "High", "Medium", "Low"
    estimated_monthly_savings: float
    resource_id: Optional[str] = None
    account_name: Optional[str] = None
    region: Optional[str] = None
    action_type: str # "Delete", "Modify", "Upgrade", "Terminate"
    
class OptimizationsResponse(BaseModel):
    total_estimated_savings: float
    recommendations: List[OptimizationRecommendation]
