"""
UnitEconPro Backend API
Main FastAPI application with page-based routing
"""
from contextlib import asynccontextmanager
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from core.config import PUBLIC_SERVER_URL, CLICKHOUSE_HOST, CLICKHOUSE_DATABASE, ENVIRONMENT
from core.database import get_connection_info
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

# Import page routers
from pages.dashboard.routes import router as dashboard_router
from pages.analytics.routes import router as analytics_router
from pages.compute.ec2.routes import router as ec2_router
from pages.compute.ecr.routes import router as ecr_router
from pages.compute.eks.routes import router as eks_router
from pages.compute.ecs.routes import router as ecs_router
from pages.storage.s3.routes import router as s3_router
from pages.storage.ebs.routes import router as ebs_router
from pages.databases.rds.routes import router as rds_router
from pages.networking.vpc.routes import router as vpc_router
from pages.networking.elb.routes import router as elb_router
from pages.networking.datatransfer.routes import router as datatransfer_router
from pages.monitoring.cloudwatch.routes import router as cloudwatch_router
from pages.budget.routes import router as budget_router


@asynccontextmanager
async def lifespan(app: FastAPI):
    from core.database import _init_pool
    import asyncio
    await asyncio.to_thread(_init_pool)
    yield


app = FastAPI(
    title="UnitEconPro API",
    description="Cost Analytics Dashboard API - Page-based Architecture",
    version="2.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan,
)

@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    logging.getLogger(__name__).error(f"Unhandled error on {request.url}: {exc}", exc_info=True)
    return JSONResponse(status_code=500, content={"detail": "Internal server error"})


app.add_middleware(
    CORSMiddleware,
    # allow_origins=["*"] + allow_credentials=True is forbidden by the CORS spec —
    # browsers silently block ALL responses when both are set together.
    # This API is stateless (no cookies, no cross-origin auth headers needed),
    # so credentials=False is correct and makes the wildcard origin work properly.
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
    expose_headers=["*"],
)

app.include_router(dashboard_router)
app.include_router(analytics_router)
app.include_router(ec2_router)
app.include_router(ecr_router)
app.include_router(eks_router)
app.include_router(ecs_router)
app.include_router(s3_router)
app.include_router(ebs_router)
app.include_router(rds_router)
app.include_router(vpc_router)
app.include_router(elb_router)
app.include_router(datatransfer_router)
app.include_router(cloudwatch_router)
app.include_router(budget_router)

from pages.accounts.routes import router as accounts_router
app.include_router(accounts_router)

from pages.optimizations.routes import router as optimizations_router
app.include_router(optimizations_router)

from pages.optimizations.summary_routes import router as opt_summary_router
app.include_router(opt_summary_router)

from pages.optimizations.compute.routes import router as compute_opt_router
app.include_router(compute_opt_router)

from pages.settings.routes import router as settings_router
app.include_router(settings_router)

from pages.permissions.routes import router as permissions_router
app.include_router(permissions_router)

from pages.alerts.routes import router as alerts_router
app.include_router(alerts_router)

from pages.alerts.alert_rules import router as alert_rules_router
app.include_router(alert_rules_router)

from pages.comparison.routes import router as comparison_router
app.include_router(comparison_router)

