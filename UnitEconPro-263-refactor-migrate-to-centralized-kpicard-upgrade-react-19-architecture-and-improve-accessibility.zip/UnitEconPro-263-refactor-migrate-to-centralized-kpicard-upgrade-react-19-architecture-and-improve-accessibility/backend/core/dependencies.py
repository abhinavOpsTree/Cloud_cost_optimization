
from datetime import datetime, timedelta
from typing import Annotated

from fastapi import Depends, HTTPException, Query
from pydantic import BaseModel


def _default_start() -> str:
    return (datetime.utcnow() - timedelta(days=30)).strftime("%Y-%m-%d")

def _default_end() -> str:
    return datetime.utcnow().strftime("%Y-%m-%d")




class DateRange(BaseModel):
    """Parsed, ClickHouse-ready context injected into every route."""
    start: str          # e.g. "2026-01-21 00:00:00"
    end: str            # e.g. "2026-02-20 23:59:59"
    account_filter: str # e.g. "" or "AND account_name = {account_name:String}"
    account_name: str   # e.g. "All" or "opstree"
    params: dict = {}   # bound parameters to pass to db.query(sql, params)





_DATE_FORMATS = [
    "%Y-%m-%d",
    "%Y-%m-%dT%H:%M:%S",
    "%Y-%m-%d %H:%M:%S",
    "%Y-%m-%dT%H:%M:%S.%f",
    "%Y-%m-%d %H:%M:%S.%f",
]

def _parse_date(value: str, param_name: str) -> datetime:
    """Parse any of the accepted formats and return a datetime. Raise 400 on failure."""
    for fmt in _DATE_FORMATS:
        try:
            return datetime.strptime(value, fmt)
        except ValueError:
            continue
    raise HTTPException(
        status_code=400,
        detail=f"'{param_name}' must be YYYY-MM-DD or YYYY-MM-DDTHH:MM:SS. Got: '{value}'",
    )


def date_range_params(
    start_date: Annotated[
        str | None,
        Query(
            description="Start date. Accepts YYYY-MM-DD or YYYY-MM-DDTHH:MM:SS. Defaults to 30 days ago.",
            openapi_examples={"example": {"value": "2026-01-21"}},
        ),
    ] = None,
    end_date: Annotated[
        str | None,
        Query(
            description="End date. Accepts YYYY-MM-DD or YYYY-MM-DDTHH:MM:SS. Defaults to today.",
            openapi_examples={"example": {"value": "2026-02-20"}},
        ),
    ] = None,
    account: Annotated[
        str,
        Query(description="Account name to filter by, or 'All' for all accounts."),
    ] = "All",
) -> DateRange:
    # Apply live defaults on every call (no frozen state)
    raw_start = start_date or _default_start()
    raw_end   = end_date   or _default_end()

    # Parse — accepts date-only or datetime strings, always strips to date
    s_dt = _parse_date(raw_start, "start_date")
    e_dt = _parse_date(raw_end,   "end_date")

    # Use only the date part regardless of what the frontend sent
    start = s_dt.strftime("%Y-%m-%d")
    end   = e_dt.strftime("%Y-%m-%d")

    if s_dt.date() > e_dt.date():
        raise HTTPException(status_code=400, detail="start_date must not be after end_date.")

    # Sanitize account name — strip whitespace
    account = " ".join(account.split())

    # Use a bound parameter instead of string interpolation to prevent SQL injection.
    # All db.query() / db.query_safe() calls must pass ctx.params alongside the SQL.
    if account == "All":
        acct_filter = ""
        bound_params = {}
    else:
        acct_filter = "AND account_name = {account_name:String}"
        bound_params = {"account_name": account}

    return DateRange(
        start=f"{start} 00:00:00",
        end=f"{end} 23:59:59",
        account_filter=acct_filter,
        account_name=account,
        params=bound_params,
    )


# Convenience type alias for route signatures
DateCtx = Annotated[DateRange, Depends(date_range_params)]


class AccountRange(BaseModel):
    """Account-only context for endpoints that compute fixed time windows internally
    (e.g. /financials) and don't accept a caller-supplied date range."""
    account_filter: str
    account_name: str
    params: dict = {}


def account_only_params(
    account: Annotated[
        str,
        Query(description="Account name to filter by, or 'All' for all accounts."),
    ] = "All",
) -> AccountRange:
    account = " ".join(account.split())
    if account == "All":
        return AccountRange(account_filter="", account_name="All", params={})
    return AccountRange(
        account_filter="AND account_name = {account_name:String}",
        account_name=account,
        params={"account_name": account},
    )


# Account-only alias — no start_date / end_date params exposed in Swagger
AccountCtx = Annotated[AccountRange, Depends(account_only_params)]
