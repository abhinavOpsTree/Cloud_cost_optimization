import os
from cryptography.fernet import Fernet
from typing import Optional

def get_master_key() -> str:
    """
    Retrieves the master encryption key from the environment.
    Strips surrounding quotes to handle Docker Compose .env literal parsing.
    If not found, raises a ValueError.
    """
    key = os.getenv("ENCRYPTION_MASTER_KEY", "").strip().strip('"').strip("'")
    if not key:
        raise ValueError("ENCRYPTION_MASTER_KEY environment variable is not set. Cannot perform cryptographic operations.")
    return key


def encrypt_string(plaintext: str) -> str:
    """
    Encrypts a plaintext string using the master key.
    """
    if not plaintext:
        return ""
    
    key = get_master_key()
    f = Fernet(key.encode('utf-8'))
    encrypted_bytes = f.encrypt(plaintext.encode('utf-8'))
    return encrypted_bytes.decode('utf-8')


def decrypt_string(encrypted_text: str) -> str:
    """
    Decrypts an encrypted string using the master key.
    """
    if not encrypted_text:
        return ""
        
    key = get_master_key()
    f = Fernet(key.encode('utf-8'))
    decrypted_bytes = f.decrypt(encrypted_text.encode('utf-8'))
    return decrypted_bytes.decode('utf-8')

