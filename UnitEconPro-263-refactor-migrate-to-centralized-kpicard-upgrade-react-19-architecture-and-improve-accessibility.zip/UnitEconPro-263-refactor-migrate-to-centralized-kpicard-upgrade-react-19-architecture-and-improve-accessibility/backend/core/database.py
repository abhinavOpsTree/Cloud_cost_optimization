"""
ClickHouse connection — fixed-size pool with auto-reconnect.
Supports local, Docker, and production environments.

Pool design:
  - POOL_SIZE connections created at startup, held in a queue.Queue.
  - Each query() call checks out a connection, runs the query, returns it.
  - Concurrent requests get separate connections → no serialization.
  - Dead connections are replaced on checkout (retryable error detection).
  - Pool size should match your ClickHouse server's max_connections setting.
    Default 20 is safe for most deployments; raise if you see pool exhaustion
    warnings under high load.
"""
import queue
import clickhouse_connect
import logging
import threading
from .config import (
    CLICKHOUSE_HOST, CLICKHOUSE_PORT,
    CLICKHOUSE_USER, CLICKHOUSE_PASSWORD,
    CLICKHOUSE_DATABASE, CLICKHOUSE_TLS,
    ENVIRONMENT,
)

logger = logging.getLogger(__name__)

POOL_SIZE = 20

_pool: queue.Queue = queue.Queue(maxsize=POOL_SIZE)
_pool_lock = threading.Lock()
_pool_initialized = False
_init_lock = threading.Lock()
_connection_info = None


def _create_client():
    """Create a fresh ClickHouse HTTP client."""
    return clickhouse_connect.get_client(
        host=CLICKHOUSE_HOST,
        port=CLICKHOUSE_PORT,
        username=CLICKHOUSE_USER,
        password=CLICKHOUSE_PASSWORD,
        database=CLICKHOUSE_DATABASE,
        secure=CLICKHOUSE_TLS,
        connect_timeout=10,
        send_receive_timeout=120,
        settings={
            "max_execution_time": 90,
            "max_memory_usage": 2000000000,  # 2GB per query
        },
    )


def _init_pool():
    """Create the connection pool and fetch version info. Called once at startup."""
    global _pool_initialized, _connection_info
    with _init_lock:
        if _pool_initialized:
            return
        logger.info(f"Initialising ClickHouse pool [{ENVIRONMENT}]: {CLICKHOUSE_HOST}:{CLICKHOUSE_PORT} (size={POOL_SIZE})")
        # Create all connections upfront so the first burst of requests doesn't
        # pay connection-setup latency.
        for _ in range(POOL_SIZE):
            _pool.put(_create_client())

        # Fetch version using one connection from the pool
        client = _pool.get()
        try:
            version = client.command("SELECT version()")
            _connection_info = {
                "host": CLICKHOUSE_HOST,
                "port": CLICKHOUSE_PORT,
                "database": CLICKHOUSE_DATABASE,
                "environment": ENVIRONMENT,
                "version": version,
            }
            logger.info(f"ClickHouse pool ready — v{version} ({POOL_SIZE} connections)")
        finally:
            _pool.put(client)

        _pool_initialized = True


def _ensure_pool():
    if not _pool_initialized:
        _init_pool()


def get_connection_info():
    """Return information about the current ClickHouse connection."""
    _ensure_pool()
    return _connection_info


def _checkout() -> tuple:
    """
    Check out a client from the pool.
    Returns (client, is_fresh) — is_fresh=True means it was just created
    to replace a dead connection (caller can log/metric this).
    Blocks up to 30s if pool is exhausted, then raises queue.Empty.
    """
    _ensure_pool()
    try:
        client = _pool.get(timeout=30)
        return client, False
    except queue.Empty:
        # Pool exhausted — create a temporary overflow connection rather than
        # failing the request. Log a warning so you know to increase POOL_SIZE.
        logger.warning("ClickHouse pool exhausted — creating overflow connection")
        return _create_client(), True


def _checkin(client, overflow: bool = False):
    """Return a client to the pool. Overflow connections are closed instead."""
    if overflow:
        try:
            client.close()
        except Exception:
            pass
        return
    try:
        _pool.put_nowait(client)
    except queue.Full:
        # Shouldn't happen, but close rather than leak
        try:
            client.close()
        except Exception:
            pass


def query(sql: str, params: dict = None):
    """
    Run a SELECT and return list of dicts.
    Checks out a dedicated connection from the pool — concurrent callers
    each get their own connection, eliminating serialization.
    Retries once on connection/memory failure with a fresh connection.
    """
    _ensure_pool()
    client, overflow = _checkout()
    try:
        for attempt in range(2):
            try:
                result = client.query(sql, parameters=params or {})
                return [
                    dict(zip(result.column_names, row))
                    for row in result.result_rows
                ]
            except Exception as e:
                if attempt == 0 and _is_retryable_error(e):
                    logger.warning(f"Query failed (attempt 1), replacing connection and retrying: {e}")
                    try:
                        client.close()
                    except Exception:
                        pass
                    client = _create_client()
                    overflow = True  # don't return this replacement to pool; it's untracked
                    continue
                logger.error(f"Query failed after retries: {e}")
                raise
    finally:
        _checkin(client, overflow)


def query_safe(sql: str, params: dict = None, default=None):
    """Like query() but returns `default` instead of raising. Use for non-critical reads."""
    try:
        return query(sql, params)
    except Exception as e:
        logger.warning(f"query_safe swallowed error: {e}")
        return default if default is not None else []


def query_single_value(sql: str, params: dict = None):
    """
    Run a SELECT that returns one scalar value.
    Uses the same pool checkout pattern as query().
    """
    _ensure_pool()
    client, overflow = _checkout()
    try:
        for attempt in range(2):
            try:
                result = client.query(sql, parameters=params or {})
                return result.result_rows[0][0] if result.result_rows else None
            except Exception as e:
                if attempt == 0 and _is_retryable_error(e):
                    logger.warning(f"query_single_value failed (attempt 1), replacing connection: {e}")
                    try:
                        client.close()
                    except Exception:
                        pass
                    client = _create_client()
                    overflow = True
                    continue
                logger.error(f"query_single_value failed after retries: {e}")
                raise
    finally:
        _checkin(client, overflow)


def _is_retryable_error(e: Exception) -> bool:
    msg = str(e).lower()
    return any(m in msg for m in [
        "no route to host", "connection refused", "connection reset",
        "read timed out", "httpconnectionpool", "remotedisconnected",
        "session_is_locked", "max retries exceeded", "timeout exceeded",
        "db::exception: timeout", "socket.timeout", "unexpected eof",
        "memory_limit_exceeded", "memory limit exceeded", "broken pipe",
        "connection aborted", "peer closed", "eof occurred",
    ])


def get_client():
    """
    Check out a client from the pool for direct use.

    IMPORTANT: Callers that use this function are responsible for operations
    that don't fit the query()/command() helpers (e.g. streaming inserts).
    The returned client is checked out from the pool — it will be returned
    automatically when the pool recycles it on the next checkout cycle.

    For most use cases, prefer command() for writes and query() for reads.
    This function exists for backward compatibility with routes that need
    direct client access (accounts, permissions, optimizations).
    """
    _ensure_pool()
    # For direct-use callers, create a dedicated client outside the pool
    # so pool connections aren't held indefinitely by long-running operations.
    return _create_client()


def command(sql: str, params: dict = None):
    """
    Execute a write command (INSERT, CREATE, ALTER, etc.) using a pool connection.
    Returns the command result string from ClickHouse.
    """
    _ensure_pool()
    client, overflow = _checkout()
    try:
        return client.command(sql, parameters=params or {})
    except Exception as e:
        logger.error(f"Command failed: {e}")
        raise
    finally:
        _checkin(client, overflow)
