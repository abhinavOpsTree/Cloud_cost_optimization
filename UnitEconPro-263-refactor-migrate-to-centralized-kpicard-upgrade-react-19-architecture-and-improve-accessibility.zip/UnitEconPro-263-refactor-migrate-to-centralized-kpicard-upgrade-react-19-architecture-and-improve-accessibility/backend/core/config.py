"""
Settings loaded from .env — single source of truth.
Environment variables override .env file values (important for Docker).
"""
import os
from dotenv import load_dotenv

# Load .env file (but environment variables take precedence)
load_dotenv(os.path.join(os.path.dirname(__file__), '../..', '.env'))

# ClickHouse Configuration
# Priority: 1) Environment Variable → 2) .env file → 3) Default
CLICKHOUSE_HOST = os.getenv("CLICKHOUSE_HOST", "localhost")
CLICKHOUSE_PORT = int(os.getenv("CLICKHOUSE_PORT", "8123"))
CLICKHOUSE_USER = os.getenv("CLICKHOUSE_USER", "dba")
CLICKHOUSE_PASSWORD = os.getenv("CLICKHOUSE_PASSWORD", "secretPassword")
CLICKHOUSE_DATABASE = os.getenv("CLICKHOUSE_DATABASE", "cost")
CLICKHOUSE_TABLE = os.getenv("CLICKHOUSE_TABLE", "service_costs")
CLICKHOUSE_TLS = os.getenv("CLICKHOUSE_TLS", "false").lower() == "true"

# API Server Configuration
PUBLIC_SERVER_URL = os.getenv("PUBLIC_SERVER_URL", "http://localhost:8000")

# Environment Detection
def get_environment():
    """Detect current environment based on CLICKHOUSE_HOST."""
    if CLICKHOUSE_HOST == "clickhouse":
        return "docker"
    elif CLICKHOUSE_HOST in ["localhost", "127.0.0.1"]:
        return "local"
    else:
        return "production"

ENVIRONMENT = get_environment()