"""
EKS API Test Suite — 25 Test Cases
Validates all EKS endpoints against direct ClickHouse queries.
100% accuracy validation, no estimation.
"""
import sys
import requests
from core import database as db

BASE_URL = "http://localhost:8000"

def api(endpoint: str):
    """Helper to call API and return JSON."""
    resp = requests.get(f"{BASE_URL}{endpoint}")
    assert resp.status_code == 200, f"API failed: {resp.status_code} {resp.text}"
    return resp.json()

def ch_query(sql: str):
    """Helper to run ClickHouse query."""
    return db.query(sql)

# ══════════════════════════════════════════════════════════
# EKS SUMMARY TESTS (TC69-TC73)
# ══════════════════════════════════════════════════════════

class TestEKSSummary:
    """Test /api/v1/compute/eks/summary endpoint."""
    
    @classmethod
    def setup_class(cls):
        cls.data = api("/api/v1/compute/eks/summary")
        
        # Get the EXACT date range the API used
        dates_config = api("/api/v1/config/get-dates")
        start = f"{dates_config['start_date']} 00:00:00"
        end = f"{dates_config['end_date']} 23:59:59"
        
        cls.ch_sql = f"""
            SELECT
                ROUND(SUM(cost_unblended), 2) AS total_cost,
                CASE
                    WHEN COUNT(DISTINCT toDate(usage_start_ts)) > 0
                    THEN ROUND(SUM(cost_unblended) / COUNT(DISTINCT toDate(usage_start_ts)), 2)
                    ELSE 0
                END AS avg_daily_cost,
                COUNT(DISTINCT resource_id) AS total_clusters,
                ROUND(SUM(usage_qty), 2) AS total_cluster_hours
            FROM cost.service_costs FINAL
            WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
              AND product_code = 'AmazonEKS'
        """
        cls.ch_row = ch_query(cls.ch_sql)[0]
    
    def test_69_eks_total_cost_matches(self):
        """TC69: EKS total_cost matches ClickHouse SUM(cost_unblended)."""
        assert self.data["total_cost"] == self.ch_row["total_cost"], \
            f"API: {self.data['total_cost']}, CH: {self.ch_row['total_cost']}"
    
    def test_70_eks_avg_daily_cost_matches(self):
        """TC70: EKS avg_daily_cost matches ClickHouse calculation."""
        assert self.data["avg_daily_cost"] == self.ch_row["avg_daily_cost"], \
            f"API: {self.data['avg_daily_cost']}, CH: {self.ch_row['avg_daily_cost']}"
    
    def test_71_eks_total_clusters_matches(self):
        """TC71: EKS total_clusters matches COUNT(DISTINCT resource_id)."""
        assert self.data["total_clusters"] == self.ch_row["total_clusters"], \
            f"API: {self.data['total_clusters']}, CH: {self.ch_row['total_clusters']}"
    
    def test_72_eks_cluster_hours_matches(self):
        """TC72: EKS total_cluster_hours matches SUM(usage_qty)."""
        assert self.data["total_cluster_hours"] == self.ch_row["total_cluster_hours"], \
            f"API: {self.data['total_cluster_hours']}, CH: {self.ch_row['total_cluster_hours']}"
    
    def test_73_eks_summary_has_all_fields(self):
        """TC73: EKS summary response has all required fields."""
        required = ["total_cost", "avg_daily_cost", "total_clusters", "total_cluster_hours"]
        for field in required:
            assert field in self.data, f"Missing field: {field}"
            assert isinstance(self.data[field], (int, float)), f"{field} not numeric"


# ══════════════════════════════════════════════════════════
# EKS TREND TESTS (TC74-TC77)
# ══════════════════════════════════════════════════════════

class TestEKSTrend:
    """Test /api/v1/compute/eks/trend endpoint."""
    
    @classmethod
    def setup_class(cls):
        cls.data = api("/api/v1/compute/eks/trend")
        
        from core.state import global_dates
        start = f"{global_dates['start_date']} 00:00:00"
        end = f"{global_dates['end_date']} 23:59:59"
        
        cls.ch_sql = f"""
            SELECT
                formatDateTime(toDate(usage_start_ts), '%Y-%m-%d') AS date,
                ROUND(SUM(cost_unblended), 2) AS cost
            FROM cost.service_costs FINAL
            WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
              AND product_code = 'AmazonEKS'
            GROUP BY toDate(usage_start_ts)
            ORDER BY toDate(usage_start_ts) ASC
        """
        cls.ch_rows = ch_query(cls.ch_sql)
    
    def test_74_eks_trend_count_matches(self):
        """TC74: EKS trend returns same number of days as ClickHouse."""
        assert len(self.data) == len(self.ch_rows), \
            f"API: {len(self.data)} days, CH: {len(self.ch_rows)} days"
    
    def test_75_eks_trend_dates_match(self):
        """TC75: EKS trend dates match ClickHouse dates."""
        api_dates = [d["date"] for d in self.data]
        ch_dates = [r["date"] for r in self.ch_rows]
        assert api_dates == ch_dates, "Date sequences don't match"
    
    def test_76_eks_trend_costs_match(self):
        """TC76: EKS trend costs match ClickHouse row-by-row."""
        for i, (api_row, ch_row) in enumerate(zip(self.data, self.ch_rows)):
            assert api_row["cost"] == ch_row["cost"], \
                f"Day {i}: API {api_row['cost']} != CH {ch_row['cost']}"
    
    def test_77_eks_trend_sum_equals_total(self):
        """TC77: Sum of EKS trend ≈ summary total_cost (±0.02 for independent ROUND)."""
        summary = api("/api/v1/compute/eks/summary")
        trend_sum = round(sum(d["cost"] for d in self.data), 2)
        assert abs(trend_sum - summary["total_cost"]) <= 0.02, \
            f"Trend sum {trend_sum} not within ±0.02 of summary {summary['total_cost']}"


# ══════════════════════════════════════════════════════════
# EKS BREAKDOWN TESTS (TC78-TC85)
# ══════════════════════════════════════════════════════════

class TestEKSBreakdowns:
    """Test /api/v1/compute/eks/breakdown/* endpoints."""
    
    def test_78_eks_cluster_breakdown_count(self):
        """TC78: EKS cluster breakdown count matches ClickHouse."""
        from core.state import global_dates
        start = f"{global_dates['start_date']} 00:00:00"
        end = f"{global_dates['end_date']} 23:59:59"
        
        api_data = api("/api/v1/compute/eks/breakdown/cluster")
        ch_sql = f"""
            SELECT COUNT(DISTINCT resource_id) as cnt
            FROM cost.service_costs FINAL
            WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
              AND product_code = 'AmazonEKS' AND resource_id != ''
        """
        ch_count = ch_query(ch_sql)[0]["cnt"]
        assert len(api_data) == ch_count, f"API: {len(api_data)}, CH: {ch_count}"
    
    def test_79_eks_cluster_breakdown_costs_match(self):
        """TC79: EKS cluster breakdown costs match ClickHouse."""
        from core.state import global_dates
        start = f"{global_dates['start_date']} 00:00:00"
        end = f"{global_dates['end_date']} 23:59:59"
        
        api_data = api("/api/v1/compute/eks/breakdown/cluster")
        ch_sql = f"""
            SELECT
                splitByString('/', resource_id)[-1] AS name,
                ROUND(SUM(cost_unblended), 2) AS cost
            FROM cost.service_costs FINAL
            WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
              AND product_code = 'AmazonEKS' AND resource_id != ''
            GROUP BY resource_id
            ORDER BY cost DESC
        """
        ch_rows = ch_query(ch_sql)
        
        for api_row, ch_row in zip(api_data, ch_rows):
            assert api_row["name"] == ch_row["name"], f"Name mismatch: {api_row['name']} != {ch_row['name']}"
            assert api_row["cost"] == ch_row["cost"], f"Cost mismatch for {api_row['name']}"
    
    def test_80_eks_cluster_sum_equals_total(self):
        """TC80: Sum of cluster breakdown equals summary total_cost."""
        clusters = api("/api/v1/compute/eks/breakdown/cluster")
        summary = api("/api/v1/compute/eks/summary")
        cluster_sum = round(sum(c["cost"] for c in clusters), 2)
        assert cluster_sum == summary["total_cost"], \
            f"Cluster sum {cluster_sum} != Summary {summary['total_cost']}"
    
    def test_81_eks_region_breakdown_matches(self):
        """TC81: EKS region breakdown matches ClickHouse."""
        from core.state import global_dates
        start = f"{global_dates['start_date']} 00:00:00"
        end = f"{global_dates['end_date']} 23:59:59"
        
        api_data = api("/api/v1/compute/eks/breakdown/region")
        ch_sql = f"""
            SELECT
                region AS name,
                ROUND(SUM(cost_unblended), 2) AS cost
            FROM cost.service_costs FINAL
            WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
              AND product_code = 'AmazonEKS' AND trimBoth(region) != ''
            GROUP BY region
            ORDER BY cost DESC
        """
        ch_rows = ch_query(ch_sql)
        
        assert len(api_data) == len(ch_rows), f"Count mismatch: API {len(api_data)}, CH {len(ch_rows)}"
        for api_row, ch_row in zip(api_data, ch_rows):
            assert api_row["name"] == ch_row["name"]
            assert api_row["cost"] == ch_row["cost"]
    
    def test_82_eks_region_sum_equals_total(self):
        """TC82: Sum of region breakdown equals summary total_cost."""
        regions = api("/api/v1/compute/eks/breakdown/region")
        summary = api("/api/v1/compute/eks/summary")
        region_sum = round(sum(r["cost"] for r in regions), 2)
        assert region_sum == summary["total_cost"], \
            f"Region sum {region_sum} != Summary {summary['total_cost']}"
    
    def test_83_eks_account_breakdown_matches(self):
        """TC83: EKS account breakdown matches ClickHouse."""
        from core.state import global_dates
        start = f"{global_dates['start_date']} 00:00:00"
        end = f"{global_dates['end_date']} 23:59:59"
        
        api_data = api("/api/v1/compute/eks/breakdown/account")
        ch_sql = f"""
            SELECT
                account_name AS name,
                ROUND(SUM(cost_unblended), 2) AS cost
            FROM cost.service_costs FINAL
            WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
              AND product_code = 'AmazonEKS' AND account_name IS NOT NULL
            GROUP BY account_name
            ORDER BY cost DESC
        """
        ch_rows = ch_query(ch_sql)
        
        assert len(api_data) == len(ch_rows)
        for api_row, ch_row in zip(api_data, ch_rows):
            assert api_row["name"] == ch_row["name"]
            assert api_row["cost"] == ch_row["cost"]
    
    def test_84_eks_account_sum_equals_total(self):
        """TC84: Sum of account breakdown equals summary total_cost."""
        accounts = api("/api/v1/compute/eks/breakdown/account")
        summary = api("/api/v1/compute/eks/summary")
        account_sum = round(sum(a["cost"] for a in accounts), 2)
        assert account_sum == summary["total_cost"], \
            f"Account sum {account_sum} != Summary {summary['total_cost']}"
    
    def test_85_eks_breakdowns_sorted_descending(self):
        """TC85: All EKS breakdowns are sorted by cost DESC."""
        for endpoint in ["/breakdown/cluster", "/breakdown/region", "/breakdown/account"]:
            data = api(f"/api/v1/compute/eks{endpoint}")
            costs = [item["cost"] for item in data]
            assert costs == sorted(costs, reverse=True), f"{endpoint} not sorted DESC"


# ══════════════════════════════════════════════════════════
# EKS CLUSTERS TABLE TESTS (TC86-TC93)
# ══════════════════════════════════════════════════════════

class TestEKSClusters:
    """Test /api/v1/compute/eks/clusters endpoint."""
    
    @classmethod
    def setup_class(cls):
        from core.state import global_dates
        start = f"{global_dates['start_date']} 00:00:00"
        end = f"{global_dates['end_date']} 23:59:59"
        
        cls.data = api("/api/v1/compute/eks/clusters")
        cls.ch_sql = f"""
            SELECT
                splitByString('/', resource_id)[-1] AS cluster_name,
                argMax(region, usage_start_ts) AS region,
                argMax(account_name, usage_start_ts) AS account,
                ROUND(SUM(usage_qty), 2) AS cluster_hours,
                ROUND(SUM(cost_unblended), 2) AS total_cost
            FROM cost.service_costs FINAL
            WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
              AND product_code = 'AmazonEKS' AND resource_id != ''
            GROUP BY resource_id
            ORDER BY total_cost DESC
            LIMIT 50
        """
        cls.ch_rows = ch_query(cls.ch_sql)
    
    def test_86_eks_clusters_count_matches(self):
        """TC86: EKS clusters count matches ClickHouse."""
        assert len(self.data) == len(self.ch_rows), \
            f"API: {len(self.data)}, CH: {len(self.ch_rows)}"
    
    def test_87_eks_top_cluster_matches(self):
        """TC87: Top EKS cluster matches ClickHouse (highest cost)."""
        api_top = self.data[0]
        ch_top = self.ch_rows[0]
        assert api_top["cluster_name"] == ch_top["cluster_name"]
        assert api_top["total_cost"] == ch_top["total_cost"]
    
    def test_88_eks_clusters_sorted_by_cost(self):
        """TC88: EKS clusters are sorted by cost DESC."""
        costs = [c["total_cost"] for c in self.data]
        assert costs == sorted(costs, reverse=True), "Clusters not sorted by cost DESC"
    
    def test_89_eks_cluster_names_match(self):
        """TC89: EKS cluster names match ClickHouse (set comparison)."""
        api_names = set(c["cluster_name"] for c in self.data)
        ch_names = set(r["cluster_name"] for r in self.ch_rows)
        assert api_names == ch_names, f"Name mismatch: {api_names} != {ch_names}"
    
    def test_90_eks_cluster_costs_match(self):
        """TC90: EKS cluster costs match ClickHouse row-by-row."""
        for api_row, ch_row in zip(self.data, self.ch_rows):
            assert api_row["cluster_name"] == ch_row["cluster_name"]
            assert api_row["total_cost"] == ch_row["total_cost"], \
                f"{api_row['cluster_name']}: API {api_row['total_cost']} != CH {ch_row['total_cost']}"
    
    def test_91_eks_cluster_hours_match(self):
        """TC91: EKS cluster hours match ClickHouse."""
        for api_row, ch_row in zip(self.data, self.ch_rows):
            assert api_row["cluster_hours"] == ch_row["cluster_hours"], \
                f"{api_row['cluster_name']}: Hours mismatch"
    
    def test_92_eks_cluster_regions_match(self):
        """TC92: EKS cluster regions match ClickHouse (argMax)."""
        for api_row, ch_row in zip(self.data, self.ch_rows):
            assert api_row["region"] == ch_row["region"], \
                f"{api_row['cluster_name']}: Region mismatch"
    
    def test_93_eks_clusters_have_all_fields(self):
        """TC93: All EKS cluster rows have required fields."""
        required = ["cluster_name", "region", "account", "cluster_hours", "total_cost"]
        for cluster in self.data:
            for field in required:
                assert field in cluster, f"Missing field: {field}"
                if field in ["cluster_hours", "total_cost"]:
                    assert isinstance(cluster[field], (int, float)), f"{field} not numeric"


# ══════════════════════════════════════════════════════════
# RUN ALL TESTS
# ══════════════════════════════════════════════════════════

if __name__ == "__main__":
    import pytest
    sys.exit(pytest.main([__file__, "-v", "--tb=short"]))
