"""
EC2 & ECR API Validation Test Suite
50 test cases that compare API responses against direct ClickHouse queries.

Usage:
    cd /home/harshitverma/UnitEconPro/backend
    python -m pytest tests/test_ec2_ecr_apis.py -v
"""
import requests
import sys
import os
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from core import database as db
from core.state import global_dates

API = "http://localhost:8000/api/v1"

# ── Fixtures ─────────────────────────────────────────────

@pytest.fixture(scope="session", autouse=True)
def set_dates():
    """Ensure global dates are set before any tests run."""
    requests.post(f"{API}/config/set-dates", json={
        "start_date": global_dates["start_date"],
        "end_date": global_dates["end_date"],
        "account_name": "All",
    })
    yield


def ch(sql: str):
    """Run a direct ClickHouse query and return rows."""
    start = f"{global_dates['start_date']} 00:00:00"
    end = f"{global_dates['end_date']} 23:59:59"
    return db.query(sql.format(start=start, end=end, account_filter=""))


def api(path: str):
    """GET an API endpoint and return parsed JSON."""
    r = requests.get(f"{API}{path}")
    assert r.status_code == 200, f"API {path} returned {r.status_code}: {r.text}"
    return r.json()


# ═══════════════════════════════════════════════════════════
#  EC2 TESTS (1–25)
# ═══════════════════════════════════════════════════════════

# ── EC2 Summary (tests 1–7) ──────────────────────────────

class TestEC2Summary:
    @pytest.fixture(autouse=True)
    def setup(self):
        self.data = api("/compute/ec2/summary")
        self.ch_row = ch("""
            SELECT
                ROUND(SUM(cost_unblended), 2) AS total_cost,
                ROUND(SUM(cost_unblended) / COUNT(DISTINCT toDate(usage_start_ts)), 2) AS avg_daily_cost,
                COUNT(DISTINCT resource_id) AS total_instances,
                ROUND(SUM(usage_qty), 2) AS total_usage_hours
            FROM cost.service_costs FINAL
            WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
              AND product_code = 'AmazonEC2'
              {account_filter}
        """)[0]

    def test_01_total_cost_matches(self):
        """TC01: EC2 total_cost matches ClickHouse SUM(cost_unblended)."""
        assert self.data["total_cost"] == float(self.ch_row["total_cost"])

    def test_02_avg_daily_cost_matches(self):
        """TC02: EC2 avg_daily_cost matches ClickHouse calculation."""
        assert self.data["avg_daily_cost"] == float(self.ch_row["avg_daily_cost"])

    def test_03_total_instances_matches(self):
        """TC03: EC2 total_instances matches COUNT(DISTINCT resource_id)."""
        assert self.data["total_instances"] == int(self.ch_row["total_instances"])

    def test_04_total_usage_hours_matches(self):
        """TC04: EC2 total_usage_hours matches SUM(usage_qty)."""
        assert self.data["total_usage_hours"] == float(self.ch_row["total_usage_hours"])

    def test_05_total_cost_positive(self):
        """TC05: EC2 total_cost is non-negative."""
        assert self.data["total_cost"] >= 0

    def test_06_response_has_all_fields(self):
        """TC06: EC2 summary response has all 4 expected fields."""
        for key in ["total_cost", "avg_daily_cost", "total_instances", "total_usage_hours"]:
            assert key in self.data, f"Missing field: {key}"

    def test_07_avg_lte_total(self):
        """TC07: EC2 avg_daily_cost <= total_cost (sanity)."""
        assert self.data["avg_daily_cost"] <= self.data["total_cost"]


# ── EC2 Trend (tests 8–11) ───────────────────────────────

class TestEC2Trend:
    @pytest.fixture(autouse=True)
    def setup(self):
        self.data = api("/compute/ec2/trend")
        self.ch_rows = ch("""
            SELECT
                formatDateTime(toDate(usage_start_ts), '%Y-%m-%d') AS date,
                ROUND(SUM(cost_unblended), 2) AS cost
            FROM cost.service_costs FINAL
            WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
              AND product_code = 'AmazonEC2'
              {account_filter}
            GROUP BY toDate(usage_start_ts)
            ORDER BY toDate(usage_start_ts) ASC
        """)

    def test_08_trend_count_matches(self):
        """TC08: EC2 trend has same number of data points as ClickHouse."""
        assert len(self.data) == len(self.ch_rows)

    def test_09_trend_dates_match(self):
        """TC09: EC2 trend dates match ClickHouse dates in order."""
        api_dates = [d["date"] for d in self.data]
        ch_dates = [r["date"] for r in self.ch_rows]
        assert api_dates == ch_dates

    def test_10_trend_costs_match(self):
        """TC10: EC2 trend costs match ClickHouse costs for each date."""
        for api_row, ch_row in zip(self.data, self.ch_rows):
            assert api_row["cost"] == float(ch_row["cost"]), f"Mismatch on {api_row['date']}"

    def test_11_trend_sum_equals_total(self):
        """TC11: Sum of EC2 daily trend costs equals summary total_cost."""
        summary = api("/compute/ec2/summary")
        trend_sum = round(sum(d["cost"] for d in self.data), 2)
        assert trend_sum == summary["total_cost"]


# ── EC2 Breakdowns (tests 12–19) ─────────────────────────

class TestEC2Breakdowns:
    def _validate_breakdown(self, api_path, ch_sql, label):
        """Helper: compare API breakdown vs ClickHouse."""
        data = api(api_path)
        rows = ch(ch_sql)
        assert len(data) == len(rows), f"{label} count mismatch: API={len(data)} CH={len(rows)}"
        for api_row, ch_row in zip(data, rows):
            assert api_row["name"] == ch_row["name"], f"{label} name mismatch"
            assert api_row["cost"] == float(ch_row["cost"]), f"{label} cost mismatch for {api_row['name']}"

    def test_12_by_region_matches(self):
        """TC12: EC2 by-region matches ClickHouse."""
        self._validate_breakdown(
            "/compute/ec2/breakdown/region",
            """SELECT region AS name, ROUND(SUM(cost_unblended), 2) AS cost
               FROM cost.service_costs FINAL
               WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
                 AND product_code = 'AmazonEC2' AND trimBoth(region) != '' {account_filter}
               GROUP BY region ORDER BY cost DESC""",
            "EC2 Region"
        )

    def test_13_by_account_matches(self):
        """TC13: EC2 by-account matches ClickHouse."""
        self._validate_breakdown(
            "/compute/ec2/breakdown/account",
            """SELECT account_name AS name, ROUND(SUM(cost_unblended), 2) AS cost
               FROM cost.service_costs FINAL
               WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
                 AND product_code = 'AmazonEC2' AND account_name IS NOT NULL {account_filter}
               GROUP BY account_name ORDER BY cost DESC""",
            "EC2 Account"
        )

    def test_14_by_instance_type_matches(self):
        """TC14: EC2 by-instance-type matches ClickHouse."""
        self._validate_breakdown(
            "/compute/ec2/breakdown/instance-type",
            """SELECT trim(instance_type) AS name, ROUND(SUM(cost_unblended), 2) AS cost
               FROM cost.service_costs FINAL
               WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
                 AND product_code = 'AmazonEC2' AND trim(instance_type) != '' {account_filter}
               GROUP BY name ORDER BY cost DESC""",
            "EC2 Instance Type"
        )

    def test_15_by_instance_family_matches(self):
        """TC15: EC2 by-instance-family matches ClickHouse."""
        self._validate_breakdown(
            "/compute/ec2/breakdown/instance-family",
            """SELECT trim(instance_family) AS name, ROUND(SUM(cost_unblended), 2) AS cost
               FROM cost.service_costs FINAL
               WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
                 AND product_code = 'AmazonEC2' AND trim(instance_family) != '' {account_filter}
               GROUP BY name ORDER BY cost DESC""",
            "EC2 Instance Family"
        )

    def test_16_by_pricing_model_matches(self):
        """TC16: EC2 by-pricing-model matches ClickHouse."""
        self._validate_breakdown(
            "/compute/ec2/breakdown/pricing-model",
            """SELECT trim(pricing_model) AS name, ROUND(SUM(cost_unblended), 2) AS cost
               FROM cost.service_costs FINAL
               WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
                 AND product_code = 'AmazonEC2' AND trim(pricing_model) != '' {account_filter}
               GROUP BY name ORDER BY cost DESC""",
            "EC2 Pricing Model"
        )

    def test_17_by_instance_type_family_matches(self):
        """TC17: EC2 by-instance-type-family matches ClickHouse."""
        self._validate_breakdown(
            "/compute/ec2/breakdown/instance-type-family",
            """SELECT trim(instance_type_family) AS name, ROUND(SUM(cost_unblended), 2) AS cost
               FROM cost.service_costs FINAL
               WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
                 AND product_code = 'AmazonEC2' AND trim(instance_type_family) != '' {account_filter}
               GROUP BY name ORDER BY cost DESC""",
            "EC2 Instance Type Family"
        )

    def test_18_by_availability_zone_matches(self):
        """TC18: EC2 by-availability-zone matches ClickHouse."""
        self._validate_breakdown(
            "/compute/ec2/breakdown/availability-zone",
            """SELECT availability_zone AS name, ROUND(SUM(cost_unblended), 2) AS cost
               FROM cost.service_costs FINAL
               WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
                 AND product_code = 'AmazonEC2' AND trimBoth(availability_zone) != '' {account_filter}
               GROUP BY availability_zone ORDER BY cost DESC""",
            "EC2 Availability Zone"
        )

    def test_19_region_sum_lte_total(self):
        """TC19: Sum of EC2 region breakdown <= total cost (some rows may have empty region)."""
        regions = api("/compute/ec2/breakdown/region")
        summary = api("/compute/ec2/summary")
        region_sum = round(sum(r["cost"] for r in regions), 2)
        assert region_sum <= summary["total_cost"] + 0.01


# ── EC2 Instances Table (tests 20–25) ────────────────────

class TestEC2Instances:
    @pytest.fixture(autouse=True)
    def setup(self):
        self.data = api("/compute/ec2/instances")
        self.ch_rows = ch("""
            SELECT
                resource_id AS instance_id,
                argMax(instance_type, usage_start_ts) AS instance_type,
                argMax(region, usage_start_ts) AS region,
                argMax(account_name, usage_start_ts) AS account,
                ROUND(SUM(cost_unblended), 2) AS total_cost,
                ROUND(SUM(usage_qty), 2) AS usage_hours
            FROM cost.service_costs FINAL
            WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
              AND product_code = 'AmazonEC2' AND resource_id != '' {account_filter}
            GROUP BY resource_id ORDER BY total_cost DESC LIMIT 50
        """)

    def test_20_instance_count_matches(self):
        """TC20: EC2 instances count matches ClickHouse LIMIT 50."""
        assert len(self.data) == len(self.ch_rows)

    def test_21_instance_ids_match(self):
        """TC21: EC2 instance IDs are the same set (order may vary for equal-cost instances)."""
        api_ids = set(d["instance_id"] for d in self.data)
        ch_ids = set(r["instance_id"] for r in self.ch_rows)
        assert api_ids == ch_ids

    def test_22_top_instance_cost_matches(self):
        """TC22: EC2 top instance cost matches ClickHouse."""
        if self.data:
            assert self.data[0]["total_cost"] == float(self.ch_rows[0]["total_cost"])

    def test_23_instance_costs_sorted_desc(self):
        """TC23: EC2 instances are sorted by cost descending."""
        costs = [d["total_cost"] for d in self.data]
        assert costs == sorted(costs, reverse=True)

    def test_24_all_instance_fields_present(self):
        """TC24: Each EC2 instance row has all required fields."""
        required = ["instance_id", "instance_type", "region", "account", "total_cost", "usage_hours"]
        for row in self.data[:5]:
            for key in required:
                assert key in row, f"Missing field: {key}"

    def test_25_instance_costs_match_all(self):
        """TC25: All EC2 instance costs match ClickHouse row-by-row."""
        for api_row, ch_row in zip(self.data, self.ch_rows):
            assert api_row["total_cost"] == float(ch_row["total_cost"]), \
                f"Cost mismatch for {api_row['instance_id']}"


# ═══════════════════════════════════════════════════════════
#  ECR TESTS (26–50)
# ═══════════════════════════════════════════════════════════

# ── ECR Summary (tests 26–33) ────────────────────────────

class TestECRSummary:
    @pytest.fixture(autouse=True)
    def setup(self):
        self.data = api("/compute/ecr/summary")
        self.ch_row = ch("""
            SELECT
                ROUND(SUM(cost_unblended), 2) AS total_cost,
                ROUND(SUM(cost_unblended) / COUNT(DISTINCT toDate(usage_start_ts)), 2) AS avg_daily_cost,
                COUNT(DISTINCT resource_id) AS active_repositories,
                ROUND(SUM(CASE WHEN usage_type LIKE '%Storage%' THEN usage_qty ELSE 0 END), 2) AS total_storage_gb,
                ROUND(SUM(CASE WHEN usage_type LIKE '%Storage%' THEN cost_unblended ELSE 0 END), 2) AS storage_cost,
                ROUND(SUM(CASE WHEN usage_type LIKE '%DataTransfer%' OR usage_type LIKE '%AWS-Out%' OR usage_type LIKE '%AWS-In%' THEN cost_unblended ELSE 0 END), 2) AS transfer_cost
            FROM cost.service_costs FINAL
            WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
              AND product_code = 'AmazonECR' {account_filter}
        """)[0]

    def test_26_ecr_total_cost_matches(self):
        """TC26: ECR total_cost matches ClickHouse."""
        assert self.data["total_cost"] == float(self.ch_row["total_cost"])

    def test_27_ecr_avg_daily_cost_matches(self):
        """TC27: ECR avg_daily_cost matches ClickHouse."""
        assert self.data["avg_daily_cost"] == float(self.ch_row["avg_daily_cost"])

    def test_28_ecr_active_repos_matches(self):
        """TC28: ECR active_repositories matches COUNT(DISTINCT resource_id)."""
        assert self.data["active_repositories"] == int(self.ch_row["active_repositories"])

    def test_29_ecr_storage_gb_matches(self):
        """TC29: ECR total_storage_gb matches ClickHouse."""
        assert self.data["total_storage_gb"] == float(self.ch_row["total_storage_gb"])

    def test_30_ecr_storage_cost_matches(self):
        """TC30: ECR storage_cost matches ClickHouse."""
        assert self.data["storage_cost"] == float(self.ch_row["storage_cost"])

    def test_31_ecr_transfer_cost_matches(self):
        """TC31: ECR transfer_cost matches ClickHouse."""
        assert self.data["transfer_cost"] == float(self.ch_row["transfer_cost"])

    def test_32_ecr_cost_composition(self):
        """TC32: ECR storage_cost + transfer_cost ≈ total_cost (±0.02 for independent ROUND)."""
        composition = round(self.data["storage_cost"] + self.data["transfer_cost"], 2)
        assert abs(composition - self.data["total_cost"]) <= 0.02, \
            f"Composition {composition} not within ±0.02 of total {self.data['total_cost']}"

    def test_33_ecr_all_fields_present(self):
        """TC33: ECR summary has all 6 expected fields."""
        for key in ["total_cost", "avg_daily_cost", "active_repositories",
                     "total_storage_gb", "storage_cost", "transfer_cost"]:
            assert key in self.data


# ── ECR Trend (tests 34–37) ──────────────────────────────

class TestECRTrend:
    @pytest.fixture(autouse=True)
    def setup(self):
        self.data = api("/compute/ecr/trend")
        self.ch_rows = ch("""
            SELECT formatDateTime(toDate(usage_start_ts), '%Y-%m-%d') AS date,
                   ROUND(SUM(cost_unblended), 2) AS cost
            FROM cost.service_costs FINAL
            WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
              AND product_code = 'AmazonECR' {account_filter}
            GROUP BY toDate(usage_start_ts) ORDER BY toDate(usage_start_ts) ASC
        """)

    def test_34_ecr_trend_count(self):
        """TC34: ECR trend point count matches ClickHouse."""
        assert len(self.data) == len(self.ch_rows)

    def test_35_ecr_trend_dates(self):
        """TC35: ECR trend dates match ClickHouse."""
        assert [d["date"] for d in self.data] == [r["date"] for r in self.ch_rows]

    def test_36_ecr_trend_costs(self):
        """TC36: ECR trend costs match ClickHouse row-by-row."""
        for a, c in zip(self.data, self.ch_rows):
            assert a["cost"] == float(c["cost"]), f"Mismatch on {a['date']}"

    def test_37_ecr_trend_sum_equals_total(self):
        """TC37: Sum of ECR daily trend equals summary total_cost."""
        summary = api("/compute/ecr/summary")
        assert round(sum(d["cost"] for d in self.data), 2) == summary["total_cost"]


# ── ECR Storage Trend (tests 38–40) ──────────────────────

class TestECRStorageTrend:
    @pytest.fixture(autouse=True)
    def setup(self):
        self.data = api("/compute/ecr/storage-trend")
        self.ch_rows = ch("""
            SELECT formatDateTime(toDate(usage_start_ts), '%Y-%m-%d') AS date,
                   ROUND(SUM(usage_qty), 2) AS storage_gb
            FROM cost.service_costs FINAL
            WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
              AND product_code = 'AmazonECR' AND usage_type LIKE '%Storage%' {account_filter}
            GROUP BY toDate(usage_start_ts) ORDER BY toDate(usage_start_ts) ASC
        """)

    def test_38_ecr_storage_trend_count(self):
        """TC38: ECR storage trend point count matches ClickHouse."""
        assert len(self.data) == len(self.ch_rows)

    def test_39_ecr_storage_trend_values(self):
        """TC39: ECR storage trend GB values match ClickHouse."""
        for a, c in zip(self.data, self.ch_rows):
            assert a["storage_gb"] == float(c["storage_gb"]), f"Mismatch on {a['date']}"

    def test_40_ecr_storage_trend_sum(self):
        """TC40: Sum of ECR storage trend ≈ summary total_storage_gb (±0.1 for rounding)."""
        summary = api("/compute/ecr/summary")
        trend_sum = round(sum(d["storage_gb"] for d in self.data), 2)
        assert abs(trend_sum - summary["total_storage_gb"]) <= 0.1, \
            f"Trend sum {trend_sum} not within ±0.1 of summary {summary['total_storage_gb']}"


# ── ECR Breakdowns (tests 41–46) ─────────────────────────

class TestECRBreakdowns:
    def _validate(self, api_path, ch_sql, label):
        data = api(api_path)
        rows = ch(ch_sql)
        assert len(data) == len(rows), f"{label} count mismatch"
        for a, c in zip(data, rows):
            assert a["name"] == c["name"], f"{label} name mismatch"
            assert a["cost"] == float(c["cost"]), f"{label} cost mismatch for {a['name']}"

    def test_41_ecr_by_usage_type(self):
        """TC41: ECR by-usage-type matches ClickHouse CASE logic."""
        self._validate(
            "/compute/ecr/breakdown/usage-type",
            """SELECT
                CASE WHEN usage_type LIKE '%Storage%' THEN 'Storage'
                     WHEN usage_type LIKE '%DataTransfer%' OR usage_type LIKE '%AWS-Out%' OR usage_type LIKE '%AWS-In%' THEN 'Data Transfer'
                     ELSE 'Other' END AS name,
                ROUND(SUM(cost_unblended), 2) AS cost
               FROM cost.service_costs FINAL
               WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
                 AND product_code = 'AmazonECR' {account_filter}
               GROUP BY name ORDER BY cost DESC""",
            "ECR Usage Type"
        )

    def test_42_ecr_by_region(self):
        """TC42: ECR by-region matches ClickHouse."""
        self._validate(
            "/compute/ecr/breakdown/region",
            """SELECT region AS name, ROUND(SUM(cost_unblended), 2) AS cost
               FROM cost.service_costs FINAL
               WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
                 AND product_code = 'AmazonECR' AND trimBoth(region) != '' {account_filter}
               GROUP BY region ORDER BY cost DESC""",
            "ECR Region"
        )

    def test_43_ecr_by_account(self):
        """TC43: ECR by-account matches ClickHouse."""
        self._validate(
            "/compute/ecr/breakdown/account",
            """SELECT account_name AS name, ROUND(SUM(cost_unblended), 2) AS cost
               FROM cost.service_costs FINAL
               WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
                 AND product_code = 'AmazonECR' AND account_name IS NOT NULL {account_filter}
               GROUP BY account_name ORDER BY cost DESC""",
            "ECR Account"
        )

    def test_44_ecr_usage_type_sum_equals_total(self):
        """TC44: Sum of ECR usage type breakdown ≈ total_cost (±0.02 for independent ROUND)."""
        types = api("/compute/ecr/breakdown/usage-type")
        summary = api("/compute/ecr/summary")
        type_sum = round(sum(t["cost"] for t in types), 2)
        assert abs(type_sum - summary["total_cost"]) <= 0.02, \
            f"Usage type sum {type_sum} not within ±0.02 of total {summary['total_cost']}"

    def test_45_ecr_region_count(self):
        """TC45: ECR region count > 0."""
        regions = api("/compute/ecr/breakdown/region")
        assert len(regions) > 0

    def test_46_ecr_breakdowns_sorted_desc(self):
        """TC46: All ECR breakdowns are sorted by cost descending."""
        for path in ["/compute/ecr/breakdown/usage-type",
                     "/compute/ecr/breakdown/region",
                     "/compute/ecr/breakdown/account"]:
            data = api(path)
            costs = [d["cost"] for d in data]
            assert costs == sorted(costs, reverse=True), f"{path} not sorted desc"


# ── ECR Repositories (tests 47–50) ───────────────────────

class TestECRRepositories:
    @pytest.fixture(autouse=True)
    def setup(self):
        self.data = api("/compute/ecr/repositories")
        self.ch_rows = ch("""
            SELECT
                splitByString('/', resource_id)[-1] AS repository_name,
                argMax(region, usage_start_ts) AS region,
                argMax(account_name, usage_start_ts) AS account,
                ROUND(SUM(CASE WHEN usage_type LIKE '%Storage%' THEN usage_qty ELSE 0 END), 2) AS storage_gb,
                ROUND(SUM(CASE WHEN usage_type LIKE '%DataTransfer%' OR usage_type LIKE '%AWS-Out%' OR usage_type LIKE '%AWS-In%' THEN usage_qty ELSE 0 END), 2) AS transfer_gb,
                ROUND(SUM(cost_unblended), 2) AS total_cost
            FROM cost.service_costs FINAL
            WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
              AND product_code = 'AmazonECR' AND resource_id != '' {account_filter}
            GROUP BY resource_id ORDER BY total_cost DESC LIMIT 50
        """)

    def test_47_ecr_repo_count(self):
        """TC47: ECR repository count matches ClickHouse."""
        assert len(self.data) == len(self.ch_rows)

    def test_48_ecr_top_repo_matches(self):
        """TC48: ECR top repository name and cost match ClickHouse."""
        if self.data:
            assert self.data[0]["repository_name"] == self.ch_rows[0]["repository_name"]
            assert self.data[0]["total_cost"] == float(self.ch_rows[0]["total_cost"])

    def test_49_ecr_repos_sorted_desc(self):
        """TC49: ECR repositories sorted by cost descending."""
        costs = [d["total_cost"] for d in self.data]
        assert costs == sorted(costs, reverse=True)

    def test_50_ecr_repo_fields_and_costs_match(self):
        """TC50: All ECR repository costs match ClickHouse row-by-row."""
        required = ["repository_name", "region", "account", "storage_gb", "transfer_gb", "total_cost"]
        for api_row, ch_row in zip(self.data, self.ch_rows):
            for key in required:
                assert key in api_row, f"Missing field: {key}"
            assert api_row["total_cost"] == float(ch_row["total_cost"]), \
                f"Cost mismatch for {api_row['repository_name']}"
