"""
RDS API Test Suite — 50 Comprehensive Validation Tests
Validates all 11 RDS endpoints (including new engine and storage-trend) against ClickHouse data.
Pattern: Same as test_ebs_api.py and test_s3_api.py
"""
import requests
from core import database as db


BASE_URL = "http://localhost:8000"


def api(endpoint: str):
    """Call API endpoint and return JSON."""
    resp = requests.get(f"{BASE_URL}{endpoint}")
    assert resp.status_code == 200, f"API call failed: {resp.status_code} {resp.text}"
    return resp.json()


def ch_query(sql: str):
    """Execute ClickHouse query and return rows."""
    return db.query(sql)


# ══════════════════════════════════════════════════════════
# TEST CLASS 1: RDS SUMMARY (10 tests)
# ══════════════════════════════════════════════════════════

class TestRDSSummary:
    @classmethod
    def setup_class(cls):
        cls.data = api("/api/v1/databases/rds/summary")

        dates_config = api("/api/v1/config/get-dates")
        start = f"{dates_config['start_date']} 00:00:00"
        end = f"{dates_config['end_date']} 23:59:59"

        cls.ch_sql = f"""
            SELECT
                ROUND(SUM(cost_unblended), 4) AS total_cost,
                CASE
                    WHEN COUNT(DISTINCT toDate(usage_start_ts)) > 0
                    THEN ROUND(SUM(cost_unblended) / COUNT(DISTINCT toDate(usage_start_ts)), 4)
                    ELSE 0
                END AS avg_daily_cost,
                COUNT(DISTINCT resource_id) AS total_instances,
                ROUND(SUM(usage_qty), 2) AS total_usage_hours
            FROM cost.service_costs FINAL
            WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
              AND product_code IN ('AmazonRDS', 'AmazonAurora')
        """
        cls.ch_row = ch_query(cls.ch_sql)[0]

    def test_300_rds_total_cost_matches(self):
        """TC300: RDS total cost matches ClickHouse."""
        assert self.data["total_cost"] == self.ch_row["total_cost"], \
            f"API {self.data['total_cost']} != CH {self.ch_row['total_cost']}"

    def test_301_rds_avg_daily_cost_matches(self):
        """TC301: RDS avg daily cost matches ClickHouse."""
        assert self.data["avg_daily_cost"] == self.ch_row["avg_daily_cost"], \
            f"API {self.data['avg_daily_cost']} != CH {self.ch_row['avg_daily_cost']}"

    def test_302_rds_total_instances_matches(self):
        """TC302: RDS total instances matches ClickHouse."""
        assert self.data["total_instances"] == self.ch_row["total_instances"], \
            f"API {self.data['total_instances']} != CH {self.ch_row['total_instances']}"

    def test_303_rds_usage_hours_matches(self):
        """TC303: RDS total usage hours matches ClickHouse."""
        assert self.data["total_usage_hours"] == self.ch_row["total_usage_hours"], \
            f"API {self.data['total_usage_hours']} != CH {self.ch_row['total_usage_hours']}"

    def test_304_rds_cost_is_non_negative(self):
        """TC304: RDS total cost is non-negative."""
        assert self.data["total_cost"] >= 0, "Total cost should be non-negative"

    def test_305_rds_instances_count_is_non_negative(self):
        """TC305: RDS instance count is non-negative."""
        assert self.data["total_instances"] >= 0, "Instance count should be non-negative"

    def test_306_rds_usage_hours_is_non_negative(self):
        """TC306: RDS usage hours is non-negative."""
        assert self.data["total_usage_hours"] >= 0, "Usage hours should be non-negative"

    def test_307_rds_avg_daily_cost_calculation(self):
        """TC307: Avg daily cost matches ClickHouse calculation."""
        # The API uses COUNT(DISTINCT toDate(usage_start_ts)) for days
        # So avg_daily_cost from API should match ClickHouse's calculation
        assert self.data["avg_daily_cost"] == self.ch_row["avg_daily_cost"], \
            f"API avg {self.data['avg_daily_cost']} != CH avg {self.ch_row['avg_daily_cost']}"

    def test_308_rds_summary_has_all_fields(self):
        """TC308: Summary response has all required fields."""
        required_fields = ["total_cost", "avg_daily_cost", "total_instances", "total_usage_hours"]
        for field in required_fields:
            assert field in self.data, f"Missing field: {field}"

    def test_309_rds_summary_values_are_numeric(self):
        """TC309: All summary values are numeric."""
        assert isinstance(self.data["total_cost"], (int, float))
        assert isinstance(self.data["avg_daily_cost"], (int, float))
        assert isinstance(self.data["total_instances"], int)
        assert isinstance(self.data["total_usage_hours"], (int, float))


# ══════════════════════════════════════════════════════════
# TEST CLASS 2: RDS TRENDS (10 tests)
# ══════════════════════════════════════════════════════════

class TestRDSTrends:
    @classmethod
    def setup_class(cls):
        cls.trend = api("/api/v1/databases/rds/trend")
        cls.storage_trend = api("/api/v1/databases/rds/storage-trend")
        cls.summary = api("/api/v1/databases/rds/summary")

    def test_310_cost_trend_sum_matches_total(self):
        """TC310: Sum of trend costs matches summary total."""
        trend_sum = sum(d["cost"] for d in self.trend)
        diff = abs(trend_sum - self.summary["total_cost"])
        assert diff < 0.5, f"Trend sum {trend_sum} != Summary {self.summary['total_cost']}"

    def test_311_cost_trend_has_data(self):
        """TC311: Cost trend returns data if cost > 0."""
        if self.summary["total_cost"] > 0:
            assert len(self.trend) > 0, "Trend should have data when cost exists"

    def test_312_cost_trend_dates_are_sequential(self):
        """TC312: Trend dates are in sequential order."""
        if len(self.trend) > 1:
            for i in range(1, len(self.trend)):
                prev = self.trend[i-1]["date"]
                curr = self.trend[i]["date"]
                assert curr > prev, f"Dates not sequential: {prev} -> {curr}"

    def test_313_cost_trend_first_day_matches_ch(self):
        """TC313: First day in trend matches ClickHouse."""
        if self.trend:
            dates_config = api("/api/v1/config/get-dates")
            start = f"{dates_config['start_date']} 00:00:00"
            end = f"{dates_config['end_date']} 23:59:59"
            
            first_day_sql = f"""
                SELECT ROUND(SUM(cost_unblended), 4) as cost
                FROM cost.service_costs FINAL
                WHERE product_code IN ('AmazonRDS', 'AmazonAurora')
                  AND toDate(usage_start_ts) = (
                    SELECT MIN(toDate(usage_start_ts))
                    FROM cost.service_costs FINAL
                    WHERE product_code IN ('AmazonRDS', 'AmazonAurora')
                      AND usage_start_ts >= '{start}'
                      AND usage_start_ts <= '{end}'
                  )
                  AND usage_start_ts >= '{start}'
                  AND usage_start_ts <= '{end}'
            """
            ch_result = ch_query(first_day_sql)
            if ch_result:
                assert self.trend[0]["cost"] == ch_result[0]["cost"]

    def test_314_cost_trend_values_are_positive(self):
        """TC314: All trend costs are non-negative."""
        for day in self.trend:
            assert day["cost"] >= 0, f"Negative cost on {day['date']}: {day['cost']}"

    def test_315_cost_trend_has_required_fields(self):
        """TC315: Each trend point has date and cost."""
        for day in self.trend:
            assert "date" in day, "Missing date field"
            assert "cost" in day, "Missing cost field"

    def test_316_cost_trend_dates_are_valid(self):
        """TC316: Trend dates are valid date strings."""
        import datetime
        for day in self.trend:
            try:
                datetime.datetime.strptime(day["date"], "%Y-%m-%d")
            except ValueError:
                assert False, f"Invalid date format: {day['date']}"

    def test_317_cost_trend_no_duplicate_dates(self):
        """TC317: Trend has no duplicate dates."""
        dates = [d["date"] for d in self.trend]
        assert len(dates) == len(set(dates)), "Duplicate dates found in trend"

    def test_318_cost_trend_covers_date_range(self):
        """TC318: Trend spans expected date range."""
        if self.trend and self.summary["total_cost"] > 0:
            dates_config = api("/api/v1/config/get-dates")
            assert self.trend[0]["date"] >= dates_config["start_date"]
            assert self.trend[-1]["date"] <= dates_config["end_date"]

    def test_319_cost_trend_values_are_numeric(self):
        """TC319: All trend costs are numeric."""
        for day in self.trend:
            assert isinstance(day["cost"], (int, float)), f"Non-numeric cost: {day['cost']}"

    def test_319a_storage_trend_has_required_fields(self):
        """TC319a: Storage trend has date and storage_gb fields."""
        for day in self.storage_trend:
            assert "date" in day, "Missing date field"
            assert "storage_gb" in day, "Missing storage_gb field"

    def test_319b_storage_trend_values_are_non_negative(self):
        """TC319b: All storage values are non-negative."""
        for day in self.storage_trend:
            assert day["storage_gb"] >= 0, f"Negative storage on {day['date']}: {day['storage_gb']}"


# ══════════════════════════════════════════════════════════
# TEST CLASS 3: RDS BREAKDOWNS (14 tests)
# ══════════════════════════════════════════════════════════

class TestRDSBreakdowns:
    @classmethod
    def setup_class(cls):
        cls.summary = api("/api/v1/databases/rds/summary")
        cls.engine = api("/api/v1/databases/rds/breakdown/engine")
        cls.instance_type = api("/api/v1/databases/rds/breakdown/instance-type")
        cls.region = api("/api/v1/databases/rds/breakdown/region")
        cls.account = api("/api/v1/databases/rds/breakdown/account")
        cls.operation = api("/api/v1/databases/rds/breakdown/operation")
        cls.usage_type = api("/api/v1/databases/rds/breakdown/usage-type")
        cls.pricing_model = api("/api/v1/databases/rds/breakdown/pricing-model")

    def test_320_engine_breakdown_sum_equals_total(self):
        """TC320: Engine breakdown sum equals total cost."""
        if self.engine:
            breakdown_sum = sum(e["cost"] for e in self.engine)
            diff = abs(breakdown_sum - self.summary["total_cost"])
            assert diff < 0.1, f"Engine sum {breakdown_sum} != Total {self.summary['total_cost']}"

    def test_321_instance_type_breakdown_sum_equals_total(self):
        """TC321: Instance type breakdown sum ≈ total cost."""
        if self.instance_type:
            breakdown_sum = sum(i["cost"] for i in self.instance_type)
            diff = abs(breakdown_sum - self.summary["total_cost"])
            # Allow tolerance if some costs don't have instance_type
            assert diff < self.summary["total_cost"] * 0.5, \
                f"Instance type sum {breakdown_sum} too far from total {self.summary['total_cost']}"

    def test_322_region_breakdown_sum_equals_total(self):
        """TC322: Region breakdown sum ≈ total cost."""
        if self.region:
            breakdown_sum = sum(r["cost"] for r in self.region)
            diff = abs(breakdown_sum - self.summary["total_cost"])
            assert diff < 1.0, f"Region sum {breakdown_sum} != Total {self.summary['total_cost']}"

    def test_323_account_breakdown_sum_equals_total(self):
        """TC323: Account breakdown sum equals total cost."""
        if self.account:
            breakdown_sum = sum(a["cost"] for a in self.account)
            diff = abs(breakdown_sum - self.summary["total_cost"])
            assert diff < 0.1, f"Account sum {breakdown_sum} != Total {self.summary['total_cost']}"

    def test_324_operation_breakdown_sum_equals_total(self):
        """TC324: Operation breakdown sum ≈ total cost."""
        if self.operation:
            breakdown_sum = sum(o["cost"] for o in self.operation)
            diff = abs(breakdown_sum - self.summary["total_cost"])
            assert diff < 1.0, f"Operation sum {breakdown_sum} != Total {self.summary['total_cost']}"

    def test_325_usage_type_breakdown_sum_equals_total(self):
        """TC325: Usage type breakdown sum equals total cost."""
        if self.usage_type:
            breakdown_sum = sum(u["cost"] for u in self.usage_type)
            diff = abs(breakdown_sum - self.summary["total_cost"])
            assert diff < 0.1, f"Usage type sum {breakdown_sum} != Total {self.summary['total_cost']}"

    def test_325_pricing_model_breakdown_sum_equals_total(self):
        """TC325: Pricing model breakdown sum ≈ total cost."""
        if self.pricing_model:
            breakdown_sum = sum(p["cost"] for p in self.pricing_model)
            diff = abs(breakdown_sum - self.summary["total_cost"])
            assert diff < 1.0, f"Pricing model sum {breakdown_sum} != Total {self.summary['total_cost']}"

    def test_326_region_breakdown_sorted_by_cost(self):
        """TC326: Region breakdown is sorted descending by cost."""
        if len(self.region) > 1:
            for i in range(1, len(self.region)):
                assert self.region[i-1]["cost"] >= self.region[i]["cost"], \
                    f"Not sorted: {self.region[i-1]['cost']} < {self.region[i]['cost']}"

    def test_327_operation_breakdown_sorted_by_cost(self):
        """TC327: Operation breakdown is sorted descending by cost."""
        if len(self.operation) > 1:
            for i in range(1, len(self.operation)):
                assert self.operation[i-1]["cost"] >= self.operation[i]["cost"]

    def test_328_breakdowns_have_required_fields(self):
        """TC328: All breakdowns have name and cost fields."""
        for breakdown in [self.region, self.account, self.operation]:
            for item in breakdown:
                assert "name" in item, "Missing name field"
                assert "cost" in item, "Missing cost field"

    def test_329_breakdown_costs_are_positive(self):
        """TC329: All breakdown costs are non-negative."""
        for breakdown in [self.region, self.account, self.operation, self.usage_type]:
            for item in breakdown:
                assert item["cost"] >= 0, f"Negative cost: {item}"

    def test_330_instance_type_has_usage_and_unit(self):
        """TC330: Instance type breakdown includes usage and unit."""
        if self.instance_type:
            for item in self.instance_type:
                assert "usage" in item, "Missing usage field"
                assert "unit" in item, "Missing unit field"

    def test_331_usage_type_categorizes_correctly(self):
        """TC331: Usage type breakdown has expected categories."""
        if self.usage_type:
            names = [u["name"] for u in self.usage_type]
            expected_categories = ["Backup Storage", "Instance Usage", "Storage", "Provisioned IOPS", "Multi-AZ", "Other"]
            # At least one category should exist
            assert any(cat in names for cat in expected_categories), \
                f"No expected categories found in {names}"

    def test_332_pricing_model_has_ondemand(self):
        """TC332: Pricing model includes OnDemand if cost exists."""
        if self.summary["total_cost"] > 0 and self.pricing_model:
            names = [p["name"] for p in self.pricing_model]
            # Most RDS costs are OnDemand
            assert len(names) > 0, "Should have at least one pricing model"

    def test_333_breakdown_values_are_numeric(self):
        """TC333: All breakdown costs are numeric."""
        for breakdown in [self.region, self.account, self.operation]:
            for item in breakdown:
                assert isinstance(item["cost"], (int, float)), f"Non-numeric cost: {item['cost']}"


# ══════════════════════════════════════════════════════════
# TEST CLASS 4: RDS INSTANCES (8 tests)
# ══════════════════════════════════════════════════════════

class TestRDSInstances:
    @classmethod
    def setup_class(cls):
        cls.instances = api("/api/v1/databases/rds/instances")
        cls.summary = api("/api/v1/databases/rds/summary")
        
        dates_config = api("/api/v1/config/get-dates")
        start = f"{dates_config['start_date']} 00:00:00"
        end = f"{dates_config['end_date']} 23:59:59"
        
        cls.ch_instances = ch_query(f"""
            SELECT
                resource_id AS instance_id,
                ROUND(SUM(cost_unblended), 4) AS total_cost
            FROM cost.service_costs FINAL
            WHERE product_code IN ('AmazonRDS', 'AmazonAurora')
              AND usage_start_ts >= '{start}'
              AND usage_start_ts <= '{end}'
              AND resource_id IS NOT NULL
              AND trimBoth(resource_id) != ''
            GROUP BY resource_id
            ORDER BY total_cost DESC, resource_id ASC
            LIMIT 1
        """)

    def test_334_instances_top_instance_matches_ch(self):
        """TC334: Top RDS instance matches ClickHouse."""
        if self.instances and self.ch_instances:
            api_top = self.instances[0]
            ch_top = self.ch_instances[0]
            assert api_top["instance_id"] == ch_top["instance_id"], \
                f"API top {api_top['instance_id']} != CH top {ch_top['instance_id']}"
            assert api_top["total_cost"] == ch_top["total_cost"], \
                f"API cost {api_top['total_cost']} != CH cost {ch_top['total_cost']}"

    def test_335_instances_sorted_by_cost(self):
        """TC335: Instances are sorted descending by cost."""
        if len(self.instances) > 1:
            for i in range(1, len(self.instances)):
                # Check primary sort (cost DESC)
                prev_cost = self.instances[i-1]["total_cost"]
                curr_cost = self.instances[i]["total_cost"]
                assert prev_cost >= curr_cost, \
                    f"Not sorted by cost: {prev_cost} < {curr_cost}"

    def test_336_instances_have_required_fields(self):
        """TC336: Each instance has required fields."""
        required_fields = ["instance_id", "total_cost", "usage_hours"]
        for inst in self.instances:
            for field in required_fields:
                assert field in inst, f"Missing field {field} in instance"

    def test_337_instances_costs_are_positive(self):
        """TC337: All instance costs are non-negative."""
        for inst in self.instances:
            assert inst["total_cost"] >= 0, f"Negative cost: {inst['total_cost']}"

    def test_338_instances_usage_is_non_negative(self):
        """TC338: All instance usage hours are non-negative."""
        for inst in self.instances:
            assert inst["usage_hours"] >= 0, f"Negative usage: {inst['usage_hours']}"

    def test_339_instances_limit_is_50(self):
        """TC339: Instances endpoint returns max 50 results."""
        assert len(self.instances) <= 50, f"Returned {len(self.instances)} instances, max is 50"

    def test_340_instances_have_region_info(self):
        """TC340: Instances include region information."""
        if self.instances:
            # At least some instances should have region
            has_region = any(inst.get("region") is not None for inst in self.instances)
            assert has_region, "No instances have region information"

    def test_341_instances_count_matches_summary(self):
        """TC341: Instance count consistency check."""
        if self.summary["total_instances"] > 0:
            assert len(self.instances) > 0, "Summary shows instances but table is empty"
        # Note: Summary counts distinct resource_ids, but table only includes those with cost > 0
        # So instance count can be <= summary count


# ══════════════════════════════════════════════════════════
# TEST CLASS 5: RDS INTEGRATION (8 tests)
# ══════════════════════════════════════════════════════════

class TestRDSIntegration:
    @classmethod
    def setup_class(cls):
        cls.summary = api("/api/v1/databases/rds/summary")
        cls.trend = api("/api/v1/databases/rds/trend")
        cls.instances = api("/api/v1/databases/rds/instances")
        cls.region = api("/api/v1/databases/rds/breakdown/region")

    def test_342_summary_and_trend_consistency(self):
        """TC342: Summary total matches trend sum."""
        trend_sum = sum(d["cost"] for d in self.trend)
        diff = abs(trend_sum - self.summary["total_cost"])
        assert diff < 0.5, f"Summary {self.summary['total_cost']} != Trend sum {trend_sum}"

    def test_343_instances_sum_matches_summary(self):
        """TC343: Instance costs sum ≈ summary total."""
        if self.instances:
            instances_sum = sum(i["total_cost"] for i in self.instances)
            # Instances might be limited to top 50, so sum can be ≤ total
            assert instances_sum <= self.summary["total_cost"] + 0.1, \
                f"Instances sum {instances_sum} > Total {self.summary['total_cost']}"

    def test_344_region_breakdown_consistency(self):
        """TC344: Region breakdown sums to total."""
        if self.region:
            region_sum = sum(r["cost"] for r in self.region)
            diff = abs(region_sum - self.summary["total_cost"])
            assert diff < 1.0, f"Region sum {region_sum} != Total {self.summary['total_cost']}"

    def test_345_all_endpoints_respond(self):
        """TC345: All 11 RDS endpoints return 200."""
        endpoints = [
            "/api/v1/databases/rds/summary",
            "/api/v1/databases/rds/trend",
            "/api/v1/databases/rds/storage-trend",
            "/api/v1/databases/rds/breakdown/engine",
            "/api/v1/databases/rds/breakdown/instance-type",
            "/api/v1/databases/rds/breakdown/region",
            "/api/v1/databases/rds/breakdown/account",
            "/api/v1/databases/rds/breakdown/operation",
            "/api/v1/databases/rds/breakdown/usage-type",
            "/api/v1/databases/rds/breakdown/pricing-model",
            "/api/v1/databases/rds/instances",
        ]
        for endpoint in endpoints:
            resp = requests.get(f"{BASE_URL}{endpoint}")
            assert resp.status_code == 200, f"{endpoint} failed: {resp.status_code}"

    def test_346_zero_cost_handling(self):
        """TC346: APIs handle zero cost gracefully."""
        if self.summary["total_cost"] == 0:
            assert len(self.trend) == 0 or all(d["cost"] == 0 for d in self.trend)
            assert len(self.instances) == 0 or all(i["total_cost"] == 0 for i in self.instances)

    def test_347_data_types_consistency(self):
        """TC347: All numeric fields are proper types."""
        assert isinstance(self.summary["total_cost"], (int, float))
        for day in self.trend:
            assert isinstance(day["cost"], (int, float))
        for inst in self.instances:
            assert isinstance(inst["total_cost"], (int, float))

    def test_348_no_null_costs(self):
        """TC348: No null costs in any endpoint."""
        assert self.summary["total_cost"] is not None
        for day in self.trend:
            assert day["cost"] is not None
        for inst in self.instances:
            assert inst["total_cost"] is not None

    def test_349_rds_module_completeness(self):
        """TC349: RDS module has all expected functionality."""
        # Verify core analytics
        assert "total_cost" in self.summary
        assert "avg_daily_cost" in self.summary
        assert "total_instances" in self.summary
        
        # Verify trend data
        assert isinstance(self.trend, list)
        
        # Verify breakdowns exist
        assert isinstance(self.region, list)
        
        # Verify instance details
        assert isinstance(self.instances, list)
