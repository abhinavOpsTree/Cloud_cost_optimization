"""
S3 API Test Suite — 50 Comprehensive Validation Tests
Validates all 12 S3 endpoints against ClickHouse data.
Pattern: Same as test_eks_api.py (25 tests, all passing)
"""
import requests
from core import database as db


BASE_URL = "http://localhost:8000"


def api(endpoint: str):
    """Call API endpoint and return JSON."""
    resp = requests.get(f"{BASE_URL}{endpoint}")
    assert resp.status_code == 200, f"API call failed: {resp.status_code} {resp.text}"
    return resp.json()


def ch_query(sql: str):
    """Execute ClickHouse query and return rows."""
    return db.query(sql)


# ══════════════════════════════════════════════════════════
# TEST CLASS 1: S3 SUMMARY (10 tests)
# ══════════════════════════════════════════════════════════

class TestS3Summary:
    @classmethod
    def setup_class(cls):
        cls.data = api("/api/v1/storage/s3/summary")
        
        # Get the EXACT date range the API used
        dates_config = api("/api/v1/config/get-dates")
        start = f"{dates_config['start_date']} 00:00:00"
        end = f"{dates_config['end_date']} 23:59:59"
        
        cls.ch_sql = f"""
            SELECT
                ROUND(SUM(cost_unblended), 2) AS total_cost,
                CASE
                    WHEN COUNT(DISTINCT toDate(usage_start_ts)) > 0
                    THEN ROUND(SUM(cost_unblended) / COUNT(DISTINCT toDate(usage_start_ts)), 2)
                    ELSE 0
                END AS avg_daily_cost,
                COUNT(DISTINCT resource_id) AS total_buckets,
                ROUND(SUM(CASE WHEN usage_type LIKE '%Storage%' THEN usage_qty ELSE 0 END), 2) AS total_storage_gb,
                CASE 
                    WHEN SUM(cost_unblended) > 0 THEN 
                        ROUND(SUM(CASE WHEN usage_type LIKE '%Request%' THEN usage_qty ELSE 0 END) / SUM(cost_unblended), 2)
                    ELSE 0 
                END AS request_efficiency
            FROM cost.service_costs FINAL
            WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
              AND product_code = 'AmazonS3'
        """
        cls.ch_row = ch_query(cls.ch_sql)[0]
    
    def test_104_s3_total_cost_matches(self):
        """TC104: S3 total cost matches ClickHouse."""
        assert self.data["total_cost"] == self.ch_row["total_cost"], \
            f"API {self.data['total_cost']} != CH {self.ch_row['total_cost']}"
    
    def test_105_s3_avg_daily_cost_matches(self):
        """TC105: S3 avg daily cost matches ClickHouse."""
        assert self.data["avg_daily_cost"] == self.ch_row["avg_daily_cost"], \
            f"API {self.data['avg_daily_cost']} != CH {self.ch_row['avg_daily_cost']}"
    
    def test_106_s3_total_buckets_matches(self):
        """TC106: S3 total buckets matches ClickHouse."""
        assert self.data["total_buckets"] == self.ch_row["total_buckets"], \
            f"API {self.data['total_buckets']} != CH {self.ch_row['total_buckets']}"
    
    def test_107_s3_total_storage_gb_matches(self):
        """TC107: S3 total storage GB matches ClickHouse."""
        assert self.data["total_storage_gb"] == self.ch_row["total_storage_gb"], \
            f"API {self.data['total_storage_gb']} != CH {self.ch_row['total_storage_gb']}"
    
    def test_108_s3_request_efficiency_matches(self):
        """TC108: S3 request efficiency matches ClickHouse."""
        assert self.data["request_efficiency"] == self.ch_row["request_efficiency"], \
            f"API {self.data['request_efficiency']} != CH {self.ch_row['request_efficiency']}"
    
    def test_109_s3_cost_is_positive(self):
        """TC109: S3 total cost is positive."""
        assert self.data["total_cost"] > 0, "Total cost should be positive"
    
    def test_110_s3_buckets_count_is_positive(self):
        """TC110: S3 bucket count is positive."""
        assert self.data["total_buckets"] > 0, "Bucket count should be positive"
    
    def test_111_s3_storage_gb_is_positive(self):
        """TC111: S3 storage GB is positive."""
        assert self.data["total_storage_gb"] > 0, "Storage GB should be positive"
    
    def test_112_s3_efficiency_is_reasonable(self):
        """TC112: Request efficiency is within reasonable range."""
        # Typical range: 1,000 - 1,000,000 requests per dollar
        assert 1000 <= self.data["request_efficiency"] <= 1000000, \
            f"Efficiency {self.data['request_efficiency']} outside reasonable range"
    
    def test_113_s3_avg_daily_cost_calculation(self):
        """TC113: Avg daily cost = total cost / days."""
        dates_config = api("/api/v1/config/get-dates")
        from datetime import datetime
        start = datetime.strptime(dates_config['start_date'], '%Y-%m-%d')
        end = datetime.strptime(dates_config['end_date'], '%Y-%m-%d')
        days = (end - start).days + 1
        
        expected_avg = round(self.data["total_cost"] / days, 2)
        assert abs(self.data["avg_daily_cost"] - expected_avg) <= 0.02, \
            f"Avg daily cost calculation mismatch"


# ══════════════════════════════════════════════════════════
# TEST CLASS 2: S3 TRENDS (8 tests)
# ══════════════════════════════════════════════════════════

class TestS3Trends:
    @classmethod
    def setup_class(cls):
        cls.cost_trend = api("/api/v1/storage/s3/trend")
        cls.storage_trend = api("/api/v1/storage/s3/storage-trend")
        cls.summary = api("/api/v1/storage/s3/summary")
        
        dates_config = api("/api/v1/config/get-dates")
        cls.start = f"{dates_config['start_date']} 00:00:00"
        cls.end = f"{dates_config['end_date']} 23:59:59"
    
    def test_114_cost_trend_sum_matches_total(self):
        """TC114: Sum of cost trend equals summary total cost."""
        trend_sum = round(sum(day["cost"] for day in self.cost_trend), 2)
        assert abs(trend_sum - self.summary["total_cost"]) <= 0.03, \
            f"Trend sum {trend_sum} != Summary {self.summary['total_cost']}"
    
    def test_115_cost_trend_has_data(self):
        """TC115: Cost trend has data points."""
        assert len(self.cost_trend) > 0, "Cost trend should have data"
    
    def test_116_storage_trend_has_data(self):
        """TC116: Storage trend has data points."""
        assert len(self.storage_trend) > 0, "Storage trend should have data"
    
    def test_117_cost_trend_dates_are_sequential(self):
        """TC117: Cost trend dates are in ascending order."""
        dates = [day["date"] for day in self.cost_trend]
        assert dates == sorted(dates), "Dates should be in ascending order"
    
    def test_118_storage_trend_dates_are_sequential(self):
        """TC118: Storage trend dates are in ascending order."""
        dates = [day["date"] for day in self.storage_trend]
        assert dates == sorted(dates), "Dates should be in ascending order"
    
    def test_119_cost_trend_first_day_matches_ch(self):
        """TC119: First day of cost trend matches ClickHouse."""
        if not self.cost_trend:
            return
        
        first_day = self.cost_trend[0]
        ch_sql = f"""
            SELECT ROUND(SUM(cost_unblended), 2) as cost
            FROM cost.service_costs FINAL
            WHERE toDate(usage_start_ts) = '{first_day['date']}'
              AND product_code = 'AmazonS3'
        """
        ch_cost = ch_query(ch_sql)[0]["cost"]
        assert first_day["cost"] == ch_cost, \
            f"First day cost: API {first_day['cost']} != CH {ch_cost}"
    
    def test_120_storage_trend_values_are_positive(self):
        """TC120: All storage trend values are non-negative."""
        for day in self.storage_trend:
            assert day["storage_gb"] >= 0, f"Negative storage on {day['date']}"
    
    def test_121_cost_trend_values_are_positive(self):
        """TC121: All cost trend values are non-negative."""
        for day in self.cost_trend:
            assert day["cost"] >= 0, f"Negative cost on {day['date']}"


# ══════════════════════════════════════════════════════════
# TEST CLASS 3: S3 BREAKDOWNS (12 tests)
# ══════════════════════════════════════════════════════════

class TestS3Breakdowns:
    @classmethod
    def setup_class(cls):
        dates_config = api("/api/v1/config/get-dates")
        cls.start = f"{dates_config['start_date']} 00:00:00"
        cls.end = f"{dates_config['end_date']} 23:59:59"
        cls.summary = api("/api/v1/storage/s3/summary")
    
    def test_122_bucket_breakdown_matches_ch(self):
        """TC122: S3 bucket breakdown matches ClickHouse."""
        api_data = api("/api/v1/storage/s3/breakdown/bucket")
        
        ch_sql = f"""
            SELECT
                CASE
                    WHEN resource_id LIKE 'arn:aws:s3:::%' THEN splitByString(':::', resource_id)[-1]
                    ELSE resource_id
                END AS name,
                ROUND(SUM(cost_unblended), 2) AS cost
            FROM cost.service_costs FINAL
            WHERE usage_start_ts >= '{self.start}' AND usage_start_ts <= '{self.end}'
              AND product_code = 'AmazonS3'
              AND resource_id != ''
            GROUP BY resource_id
            ORDER BY cost DESC
            LIMIT 50
        """
        ch_data = ch_query(ch_sql)
        
        assert len(api_data) == len(ch_data), f"Count mismatch: API {len(api_data)} != CH {len(ch_data)}"
        
        for i, (api_row, ch_row) in enumerate(zip(api_data, ch_data)):
            assert api_row["name"] == ch_row["name"], f"Row {i}: Name mismatch"
            assert api_row["cost"] == ch_row["cost"], f"Row {i}: Cost mismatch"
    
    def test_123_region_breakdown_sum_equals_total(self):
        """TC123: Sum of region breakdown equals summary total."""
        regions = api("/api/v1/storage/s3/breakdown/region")
        region_sum = round(sum(r["cost"] for r in regions), 2)
        assert abs(region_sum - self.summary["total_cost"]) <= 0.02, \
            f"Region sum {region_sum} != Summary {self.summary['total_cost']}"
    
    def test_124_account_breakdown_sum_equals_total(self):
        """TC124: Sum of account breakdown equals summary total."""
        accounts = api("/api/v1/storage/s3/breakdown/account")
        account_sum = round(sum(a["cost"] for a in accounts), 2)
        assert abs(account_sum - self.summary["total_cost"]) <= 0.02, \
            f"Account sum {account_sum} != Summary {self.summary['total_cost']}"
    
    def test_125_operation_breakdown_sum_equals_total(self):
        """TC125: Sum of operation breakdown equals summary total."""
        operations = api("/api/v1/storage/s3/breakdown/operation")
        op_sum = round(sum(o["cost"] for o in operations), 2)
        assert abs(op_sum - self.summary["total_cost"]) <= 0.02, \
            f"Operation sum {op_sum} != Summary {self.summary['total_cost']}"
    
    def test_126_usage_type_breakdown_matches_ch(self):
        """TC126: S3 usage type breakdown matches ClickHouse."""
        api_data = api("/api/v1/storage/s3/breakdown/usage-type")
        
        ch_sql = f"""
            SELECT
                CASE
                    WHEN usage_type LIKE '%TimedStorage%' OR usage_type LIKE '%Storage%' THEN 'Storage'
                    WHEN usage_type LIKE '%Requests%' OR usage_type LIKE '%Request%' THEN 'Requests'
                    WHEN usage_type LIKE '%DataTransfer%' OR usage_type LIKE '%Transfer%' OR usage_type LIKE '%AWS-Out%' THEN 'Data Transfer'
                    ELSE 'Other'
                END AS name,
                ROUND(SUM(cost_unblended), 2) AS cost
            FROM cost.service_costs FINAL
            WHERE usage_start_ts >= '{self.start}' AND usage_start_ts <= '{self.end}'
              AND product_code = 'AmazonS3'
            GROUP BY name
            ORDER BY cost DESC
        """
        ch_data = ch_query(ch_sql)
        
        for api_row in api_data:
            ch_row = next((r for r in ch_data if r["name"] == api_row["name"]), None)
            assert ch_row is not None, f"Category {api_row['name']} not in CH"
            assert api_row["cost"] == ch_row["cost"], \
                f"{api_row['name']}: API {api_row['cost']} != CH {ch_row['cost']}"
    
    def test_127_usage_type_has_storage_category(self):
        """TC127: Usage type breakdown includes 'Storage' category."""
        usage_types = api("/api/v1/storage/s3/breakdown/usage-type")
        categories = [u["name"] for u in usage_types]
        assert "Storage" in categories, "Storage category missing"
    
    def test_128_usage_type_has_requests_category(self):
        """TC128: Usage type breakdown includes 'Requests' category."""
        usage_types = api("/api/v1/storage/s3/breakdown/usage-type")
        categories = [u["name"] for u in usage_types]
        assert "Requests" in categories, "Requests category missing"
    
    def test_129_pricing_model_breakdown_sum_equals_total(self):
        """TC129: Sum of pricing model breakdown equals summary total."""
        models = api("/api/v1/storage/s3/breakdown/pricing-model")
        model_sum = round(sum(m["cost"] for m in models), 2)
        assert abs(model_sum - self.summary["total_cost"]) <= 0.02, \
            f"Pricing model sum {model_sum} != Summary {self.summary['total_cost']}"
    
    def test_130_bucket_breakdown_sorted_by_cost(self):
        """TC130: Bucket breakdown is sorted by cost descending."""
        buckets = api("/api/v1/storage/s3/breakdown/bucket")
        costs = [b["cost"] for b in buckets]
        assert costs == sorted(costs, reverse=True), "Buckets not sorted by cost DESC"
    
    def test_131_region_breakdown_sorted_by_cost(self):
        """TC131: Region breakdown is sorted by cost descending."""
        regions = api("/api/v1/storage/s3/breakdown/region")
        costs = [r["cost"] for r in regions]
        assert costs == sorted(costs, reverse=True), "Regions not sorted by cost DESC"
    
    def test_132_operation_breakdown_sorted_by_cost(self):
        """TC132: Operation breakdown is sorted by cost descending."""
        operations = api("/api/v1/storage/s3/breakdown/operation")
        costs = [o["cost"] for o in operations]
        assert costs == sorted(costs, reverse=True), "Operations not sorted by cost DESC"
    
    def test_133_usage_type_breakdown_sorted_by_cost(self):
        """TC133: Usage type breakdown is sorted by cost descending."""
        usage_types = api("/api/v1/storage/s3/breakdown/usage-type")
        costs = [u["cost"] for u in usage_types]
        assert costs == sorted(costs, reverse=True), "Usage types not sorted by cost DESC"


# ══════════════════════════════════════════════════════════
# TEST CLASS 4: GRAFANA PARITY (10 tests)
# ══════════════════════════════════════════════════════════

class TestS3GrafanaParity:
    @classmethod
    def setup_class(cls):
        dates_config = api("/api/v1/config/get-dates")
        cls.start = f"{dates_config['start_date']} 00:00:00"
        cls.end = f"{dates_config['end_date']} 23:59:59"
    
    def test_134_request_type_breakdown_matches_ch(self):
        """TC134: Request type breakdown matches ClickHouse."""
        api_data = api("/api/v1/storage/s3/breakdown/request-type")
        
        ch_sql = f"""
            SELECT
                CASE
                    WHEN usage_type LIKE '%Tier1%' THEN 'Tier 1 (PUT/LIST)'
                    WHEN usage_type LIKE '%Tier2%' THEN 'Tier 2 (GET/SELECT)'
                    ELSE 'Other'
                END AS name,
                ROUND(SUM(cost_unblended), 2) AS cost,
                ROUND(SUM(usage_qty), 2) AS usage
            FROM cost.service_costs FINAL
            WHERE usage_start_ts >= '{self.start}' AND usage_start_ts <= '{self.end}'
              AND product_code = 'AmazonS3'
              AND usage_type LIKE '%Request%'
            GROUP BY name
            ORDER BY cost DESC
        """
        ch_data = ch_query(ch_sql)
        
        for api_row in api_data:
            ch_row = next((r for r in ch_data if r["name"] == api_row["name"]), None)
            if ch_row:
                assert api_row["cost"] == ch_row["cost"], \
                    f"{api_row['name']}: Cost mismatch"
                assert api_row["usage"] == ch_row["usage"], \
                    f"{api_row['name']}: Usage mismatch"
    
    def test_135_request_type_has_tier1(self):
        """TC135: Request type breakdown includes Tier 1."""
        request_types = api("/api/v1/storage/s3/breakdown/request-type")
        tiers = [r["name"] for r in request_types]
        assert any("Tier 1" in t for t in tiers), "Tier 1 missing"
    
    def test_136_request_type_has_tier2(self):
        """TC136: Request type breakdown includes Tier 2."""
        request_types = api("/api/v1/storage/s3/breakdown/request-type")
        tiers = [r["name"] for r in request_types]
        assert any("Tier 2" in t for t in tiers), "Tier 2 missing"
    
    def test_137_request_type_has_usage_field(self):
        """TC137: Request type items have usage field."""
        request_types = api("/api/v1/storage/s3/breakdown/request-type")
        for item in request_types:
            assert "usage" in item, "Usage field missing"
            assert item["usage"] >= 0, "Usage should be non-negative"
    
    def test_138_request_type_has_unit_field(self):
        """TC138: Request type items have unit field."""
        request_types = api("/api/v1/storage/s3/breakdown/request-type")
        for item in request_types:
            assert "unit" in item, "Unit field missing"
            assert item["unit"] == "Requests", f"Unit should be 'Requests', got '{item['unit']}'"
    
    def test_139_transfer_direction_breakdown_matches_ch(self):
        """TC139: Transfer direction breakdown matches ClickHouse."""
        api_data = api("/api/v1/storage/s3/breakdown/transfer-direction")
        
        ch_sql = f"""
            SELECT
                CASE
                    WHEN usage_type LIKE '%Out-Bytes%' OR usage_type LIKE '%AWS-Out%' THEN 'Outbound (Egress)'
                    WHEN usage_type LIKE '%In-Bytes%' OR usage_type LIKE '%AWS-In%' THEN 'Inbound (Ingress)'
                    ELSE 'Other'
                END AS name,
                ROUND(SUM(cost_unblended), 2) AS cost,
                ROUND(SUM(usage_qty), 2) AS usage
            FROM cost.service_costs FINAL
            WHERE usage_start_ts >= '{self.start}' AND usage_start_ts <= '{self.end}'
              AND product_code = 'AmazonS3'
              AND (usage_type LIKE '%Transfer%' OR usage_type LIKE '%Bytes%')
            GROUP BY name
            ORDER BY cost DESC
        """
        ch_data = ch_query(ch_sql)
        
        for api_row in api_data:
            ch_row = next((r for r in ch_data if r["name"] == api_row["name"]), None)
            if ch_row:
                assert api_row["cost"] == ch_row["cost"], \
                    f"{api_row['name']}: Cost mismatch"
                assert api_row["usage"] == ch_row["usage"], \
                    f"{api_row['name']}: Usage mismatch"
    
    def test_140_transfer_direction_has_outbound(self):
        """TC140: Transfer direction includes Outbound."""
        transfer = api("/api/v1/storage/s3/breakdown/transfer-direction")
        directions = [t["name"] for t in transfer]
        assert any("Outbound" in d for d in directions), "Outbound missing"
    
    def test_141_transfer_direction_has_inbound(self):
        """TC141: Transfer direction includes Inbound."""
        transfer = api("/api/v1/storage/s3/breakdown/transfer-direction")
        directions = [t["name"] for t in transfer]
        assert any("Inbound" in d for d in directions), "Inbound missing"
    
    def test_142_transfer_direction_has_usage_field(self):
        """TC142: Transfer direction items have usage field."""
        transfer = api("/api/v1/storage/s3/breakdown/transfer-direction")
        for item in transfer:
            assert "usage" in item, "Usage field missing"
            assert item["usage"] >= 0, "Usage should be non-negative"
    
    def test_143_transfer_direction_has_unit_field(self):
        """TC143: Transfer direction items have unit field."""
        transfer = api("/api/v1/storage/s3/breakdown/transfer-direction")
        for item in transfer:
            assert "unit" in item, "Unit field missing"
            assert item["unit"] == "GB", f"Unit should be 'GB', got '{item['unit']}'"


# ══════════════════════════════════════════════════════════
# TEST CLASS 5: S3 BUCKETS TABLE (10 tests)
# ══════════════════════════════════════════════════════════

class TestS3Buckets:
    @classmethod
    def setup_class(cls):
        cls.data = api("/api/v1/storage/s3/buckets")
        dates_config = api("/api/v1/config/get-dates")
        cls.start = f"{dates_config['start_date']} 00:00:00"
        cls.end = f"{dates_config['end_date']} 23:59:59"
    
    def test_144_buckets_top_bucket_matches_ch(self):
        """TC144: Top S3 bucket cost matches ClickHouse."""
        if not self.data:
            return
        
        top_bucket = self.data[0]
        
        ch_sql = f"""
            SELECT
                CASE
                    WHEN resource_id LIKE 'arn:aws:s3:::%' THEN splitByString(':::', resource_id)[-1]
                    ELSE resource_id
                END AS bucket_name,
                ROUND(SUM(cost_unblended), 2) AS total_cost
            FROM cost.service_costs FINAL
            WHERE usage_start_ts >= '{self.start}' AND usage_start_ts <= '{self.end}'
              AND product_code = 'AmazonS3'
              AND resource_id != ''
            GROUP BY resource_id
            ORDER BY total_cost DESC
            LIMIT 1
        """
        ch_row = ch_query(ch_sql)[0]
        
        assert top_bucket["bucket_name"] == ch_row["bucket_name"], \
            f"Top bucket name: API {top_bucket['bucket_name']} != CH {ch_row['bucket_name']}"
        assert top_bucket["total_cost"] == ch_row["total_cost"], \
            f"Top bucket cost: API {top_bucket['total_cost']} != CH {ch_row['total_cost']}"
    
    def test_145_buckets_sorted_by_cost(self):
        """TC145: S3 buckets are sorted by cost descending."""
        costs = [b["total_cost"] for b in self.data]
        assert costs == sorted(costs, reverse=True), "Buckets not sorted by cost DESC"
    
    def test_146_buckets_have_required_fields(self):
        """TC146: All buckets have required fields."""
        required_fields = ["bucket_name", "total_cost", "storage_gb", "request_count", "transfer_gb"]
        for bucket in self.data:
            for field in required_fields:
                assert field in bucket, f"Field '{field}' missing in bucket"
    
    def test_147_buckets_names_are_clean(self):
        """TC147: Bucket names don't contain ARN prefixes."""
        for bucket in self.data:
            assert not bucket["bucket_name"].startswith("arn:aws:s3"), \
                f"Bucket name contains ARN: {bucket['bucket_name']}"
    
    def test_148_buckets_costs_are_positive(self):
        """TC148: All bucket costs are non-negative."""
        for bucket in self.data:
            assert bucket["total_cost"] >= 0, \
                f"Negative cost for bucket {bucket['bucket_name']}"
    
    def test_149_buckets_storage_is_non_negative(self):
        """TC149: All bucket storage values are non-negative."""
        for bucket in self.data:
            assert bucket["storage_gb"] >= 0, \
                f"Negative storage for bucket {bucket['bucket_name']}"
    
    def test_150_buckets_requests_are_non_negative(self):
        """TC150: All bucket request counts are non-negative."""
        for bucket in self.data:
            assert bucket["request_count"] >= 0, \
                f"Negative requests for bucket {bucket['bucket_name']}"
    
    def test_151_buckets_transfer_is_non_negative(self):
        """TC151: All bucket transfer values are non-negative."""
        for bucket in self.data:
            assert bucket["transfer_gb"] >= 0, \
                f"Negative transfer for bucket {bucket['bucket_name']}"
    
    def test_152_buckets_limit_is_50(self):
        """TC152: Buckets table returns at most 50 items."""
        assert len(self.data) <= 50, f"Too many buckets: {len(self.data)}"
    
    def test_153_buckets_have_region_info(self):
        """TC153: Buckets have region information."""
        # At least one bucket should have a region
        has_region = any(b.get("region") for b in self.data)
        assert has_region, "No buckets have region information"
