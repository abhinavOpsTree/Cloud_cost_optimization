"""
EBS API Test Suite — 50 Comprehensive Validation Tests
Validates all 12 EBS endpoints against ClickHouse data.
Pattern: Same as test_s3_api.py (50 tests, audit-grade)
"""
import requests
from core import database as db


BASE_URL = "http://localhost:8000"


def api(endpoint: str):
    """Call API endpoint and return JSON."""
    resp = requests.get(f"{BASE_URL}{endpoint}")
    assert resp.status_code == 200, f"API call failed: {resp.status_code} {resp.text}"
    return resp.json()


def ch_query(sql: str):
    """Execute ClickHouse query and return rows."""
    return db.query(sql)


# ══════════════════════════════════════════════════════════
# TEST CLASS 1: EBS SUMMARY (10 tests)
# ══════════════════════════════════════════════════════════

class TestEBSSummary:
    @classmethod
    def setup_class(cls):
        cls.data = api("/api/v1/storage/ebs/summary")

        dates_config = api("/api/v1/config/get-dates")
        start = f"{dates_config['start_date']} 00:00:00"
        end = f"{dates_config['end_date']} 23:59:59"

        cls.ch_sql = f"""
            SELECT
                ROUND(SUM(cost_unblended), 2) AS total_cost,
                CASE
                    WHEN COUNT(DISTINCT toDate(usage_start_ts)) > 0
                    THEN ROUND(SUM(cost_unblended) / COUNT(DISTINCT toDate(usage_start_ts)), 2)
                    ELSE 0
                END AS avg_daily_cost,
                COUNT(DISTINCT CASE WHEN usage_type LIKE '%Volume%' THEN resource_id END) AS total_volumes,
                COUNT(DISTINCT CASE WHEN usage_type LIKE '%Snapshot%' THEN resource_id END) AS total_snapshots,
                ROUND(SUM(CASE WHEN usage_type LIKE '%Volume%' THEN usage_qty ELSE 0 END), 2) AS total_storage_gb,
                ROUND(SUM(CASE WHEN usage_type LIKE '%Snapshot%' THEN usage_qty ELSE 0 END), 2) AS total_snapshot_gb
            FROM cost.service_costs FINAL
            WHERE usage_start_ts >= '{start}' AND usage_start_ts <= '{end}'
              AND product_code = 'AmazonEBS'
        """
        cls.ch_row = ch_query(cls.ch_sql)[0]

    def test_200_ebs_total_cost_matches(self):
        """TC200: EBS total cost matches ClickHouse."""
        assert self.data["total_cost"] == self.ch_row["total_cost"], \
            f"API {self.data['total_cost']} != CH {self.ch_row['total_cost']}"

    def test_201_ebs_avg_daily_cost_matches(self):
        """TC201: EBS avg daily cost matches ClickHouse."""
        assert self.data["avg_daily_cost"] == self.ch_row["avg_daily_cost"], \
            f"API {self.data['avg_daily_cost']} != CH {self.ch_row['avg_daily_cost']}"

    def test_202_ebs_total_volumes_matches(self):
        """TC202: EBS total volumes matches ClickHouse."""
        assert self.data["total_volumes"] == self.ch_row["total_volumes"], \
            f"API {self.data['total_volumes']} != CH {self.ch_row['total_volumes']}"

    def test_203_ebs_total_snapshots_matches(self):
        """TC203: EBS total snapshots matches ClickHouse."""
        assert self.data["total_snapshots"] == self.ch_row["total_snapshots"], \
            f"API {self.data['total_snapshots']} != CH {self.ch_row['total_snapshots']}"

    def test_204_ebs_storage_gb_matches(self):
        """TC204: EBS total storage GB matches ClickHouse."""
        assert self.data["total_storage_gb"] == self.ch_row["total_storage_gb"], \
            f"API {self.data['total_storage_gb']} != CH {self.ch_row['total_storage_gb']}"

    def test_205_ebs_snapshot_gb_matches(self):
        """TC205: EBS total snapshot GB matches ClickHouse."""
        assert self.data["total_snapshot_gb"] == self.ch_row["total_snapshot_gb"], \
            f"API {self.data['total_snapshot_gb']} != CH {self.ch_row['total_snapshot_gb']}"

    def test_206_ebs_cost_is_positive(self):
        """TC206: EBS total cost is positive."""
        assert self.data["total_cost"] > 0, "Total cost should be positive"

    def test_207_ebs_volumes_count_is_positive(self):
        """TC207: EBS volume count is positive."""
        assert self.data["total_volumes"] > 0, "Volume count should be positive"

    def test_208_ebs_storage_gb_is_positive(self):
        """TC208: EBS storage GB is positive."""
        assert self.data["total_storage_gb"] > 0, "Storage GB should be positive"

    def test_209_ebs_avg_daily_cost_calculation(self):
        """TC209: Avg daily cost matches ClickHouse calculation (uses days with data, not calendar days)."""
        # ClickHouse calculates avg using COUNT(DISTINCT toDate(usage_start_ts))
        # which counts only days that have actual EBS data, not calendar days
        assert self.data["avg_daily_cost"] == self.ch_row["avg_daily_cost"], \
            f"Avg daily cost: API {self.data['avg_daily_cost']} != CH {self.ch_row['avg_daily_cost']}"


# ══════════════════════════════════════════════════════════
# TEST CLASS 2: EBS TRENDS (10 tests)
# ══════════════════════════════════════════════════════════

class TestEBSTrends:
    @classmethod
    def setup_class(cls):
        cls.cost_trend = api("/api/v1/storage/ebs/trend")
        cls.storage_trend = api("/api/v1/storage/ebs/storage-trend")
        cls.summary = api("/api/v1/storage/ebs/summary")

        dates_config = api("/api/v1/config/get-dates")
        cls.start = f"{dates_config['start_date']} 00:00:00"
        cls.end = f"{dates_config['end_date']} 23:59:59"

    def test_210_cost_trend_sum_matches_total(self):
        """TC210: Sum of cost trend equals summary total cost."""
        trend_sum = round(sum(day["cost"] for day in self.cost_trend), 2)
        assert abs(trend_sum - self.summary["total_cost"]) <= 0.03, \
            f"Trend sum {trend_sum} != Summary {self.summary['total_cost']}"

    def test_211_cost_trend_has_data(self):
        """TC211: Cost trend has data points."""
        assert len(self.cost_trend) > 0, "Cost trend should have data"

    def test_212_storage_trend_has_data(self):
        """TC212: Storage trend has data points."""
        assert len(self.storage_trend) > 0, "Storage trend should have data"

    def test_213_cost_trend_dates_are_sequential(self):
        """TC213: Cost trend dates are in ascending order."""
        dates = [day["date"] for day in self.cost_trend]
        assert dates == sorted(dates), "Dates should be in ascending order"

    def test_214_storage_trend_dates_are_sequential(self):
        """TC214: Storage trend dates are in ascending order."""
        dates = [day["date"] for day in self.storage_trend]
        assert dates == sorted(dates), "Dates should be in ascending order"

    def test_215_cost_trend_first_day_matches_ch(self):
        """TC215: First day of cost trend matches ClickHouse."""
        if not self.cost_trend:
            return

        first_day = self.cost_trend[0]
        ch_sql = f"""
            SELECT ROUND(SUM(cost_unblended), 2) as cost
            FROM cost.service_costs FINAL
            WHERE toDate(usage_start_ts) = '{first_day['date']}'
              AND product_code = 'AmazonEBS'
        """
        ch_cost = ch_query(ch_sql)[0]["cost"]
        assert first_day["cost"] == ch_cost, \
            f"First day cost: API {first_day['cost']} != CH {ch_cost}"

    def test_216_cost_trend_values_are_positive(self):
        """TC216: All cost trend values are non-negative."""
        for day in self.cost_trend:
            assert day["cost"] >= 0, f"Negative cost on {day['date']}"

    def test_217_storage_trend_volume_values_are_positive(self):
        """TC217: All storage trend volume GB values are non-negative."""
        for day in self.storage_trend:
            assert day["volume_gb"] >= 0, f"Negative volume GB on {day['date']}"

    def test_218_storage_trend_snapshot_values_are_positive(self):
        """TC218: All storage trend snapshot GB values are non-negative."""
        for day in self.storage_trend:
            assert day["snapshot_gb"] >= 0, f"Negative snapshot GB on {day['date']}"

    def test_219_storage_trend_has_both_fields(self):
        """TC219: Storage trend has both volume_gb and snapshot_gb."""
        for day in self.storage_trend:
            assert "volume_gb" in day, "volume_gb field missing"
            assert "snapshot_gb" in day, "snapshot_gb field missing"


# ══════════════════════════════════════════════════════════
# TEST CLASS 3: EBS BREAKDOWNS (14 tests)
# ══════════════════════════════════════════════════════════

class TestEBSBreakdowns:
    @classmethod
    def setup_class(cls):
        dates_config = api("/api/v1/config/get-dates")
        cls.start = f"{dates_config['start_date']} 00:00:00"
        cls.end = f"{dates_config['end_date']} 23:59:59"
        cls.summary = api("/api/v1/storage/ebs/summary")

    def test_220_volume_type_breakdown_matches_ch(self):
        """TC220: EBS volume type breakdown matches ClickHouse."""
        api_data = api("/api/v1/storage/ebs/breakdown/volume-type")

        ch_sql = f"""
            SELECT
                CASE
                    WHEN usage_type LIKE '%VolumeUsage.gp3%' THEN 'gp3'
                    WHEN usage_type LIKE '%VolumeUsage.gp2%' THEN 'gp2'
                    WHEN usage_type LIKE '%VolumeUsage.io1%' THEN 'io1'
                    WHEN usage_type LIKE '%VolumeUsage.io2%' THEN 'io2'
                    WHEN usage_type LIKE '%VolumeUsage.st1%' THEN 'st1'
                    WHEN usage_type LIKE '%VolumeUsage.sc1%' THEN 'sc1'
                    WHEN usage_type LIKE '%VolumeUsage%' THEN 'standard'
                    WHEN usage_type LIKE '%Snapshot%' THEN 'Snapshot'
                    ELSE 'Other'
                END AS name,
                ROUND(SUM(cost_unblended), 2) AS cost,
                ROUND(SUM(usage_qty), 2) AS usage
            FROM cost.service_costs FINAL
            WHERE usage_start_ts >= '{self.start}' AND usage_start_ts <= '{self.end}'
              AND product_code = 'AmazonEBS'
            GROUP BY name
            ORDER BY cost DESC
        """
        ch_data = ch_query(ch_sql)

        for api_row in api_data:
            ch_row = next((r for r in ch_data if r["name"] == api_row["name"]), None)
            assert ch_row is not None, f"Category {api_row['name']} not in CH"
            assert api_row["cost"] == ch_row["cost"], \
                f"{api_row['name']}: API {api_row['cost']} != CH {ch_row['cost']}"
            assert api_row["usage"] == ch_row["usage"], \
                f"{api_row['name']}: Usage API {api_row['usage']} != CH {ch_row['usage']}"

    def test_221_volume_type_sum_equals_total(self):
        """TC221: Sum of volume type breakdown equals summary total."""
        vol_types = api("/api/v1/storage/ebs/breakdown/volume-type")
        vol_sum = round(sum(v["cost"] for v in vol_types), 2)
        assert abs(vol_sum - self.summary["total_cost"]) <= 0.02, \
            f"Volume type sum {vol_sum} != Summary {self.summary['total_cost']}"

    def test_222_region_breakdown_sum_equals_total(self):
        """TC222: Sum of region breakdown equals summary total."""
        regions = api("/api/v1/storage/ebs/breakdown/region")
        region_sum = round(sum(r["cost"] for r in regions), 2)
        assert abs(region_sum - self.summary["total_cost"]) <= 0.02, \
            f"Region sum {region_sum} != Summary {self.summary['total_cost']}"

    def test_223_account_breakdown_sum_equals_total(self):
        """TC223: Sum of account breakdown equals summary total."""
        accounts = api("/api/v1/storage/ebs/breakdown/account")
        account_sum = round(sum(a["cost"] for a in accounts), 2)
        assert abs(account_sum - self.summary["total_cost"]) <= 0.02, \
            f"Account sum {account_sum} != Summary {self.summary['total_cost']}"

    def test_224_operation_breakdown_sum_equals_total(self):
        """TC224: Sum of operation breakdown equals summary total."""
        operations = api("/api/v1/storage/ebs/breakdown/operation")
        op_sum = round(sum(o["cost"] for o in operations), 2)
        assert abs(op_sum - self.summary["total_cost"]) <= 0.02, \
            f"Operation sum {op_sum} != Summary {self.summary['total_cost']}"

    def test_225_product_family_breakdown_sum_equals_total(self):
        """TC225: Sum of product family breakdown equals summary total."""
        families = api("/api/v1/storage/ebs/breakdown/product-family")
        family_sum = round(sum(f["cost"] for f in families), 2)
        assert abs(family_sum - self.summary["total_cost"]) <= 0.02, \
            f"Product family sum {family_sum} != Summary {self.summary['total_cost']}"

    def test_226_usage_type_breakdown_matches_ch(self):
        """TC226: EBS usage type breakdown matches ClickHouse."""
        api_data = api("/api/v1/storage/ebs/breakdown/usage-type")

        ch_sql = f"""
            SELECT
                CASE
                    WHEN usage_type LIKE '%Volume%' THEN 'Volume Storage'
                    WHEN usage_type LIKE '%Snapshot%' THEN 'Snapshot Storage'
                    ELSE 'Other'
                END AS name,
                ROUND(SUM(cost_unblended), 2) AS cost
            FROM cost.service_costs FINAL
            WHERE usage_start_ts >= '{self.start}' AND usage_start_ts <= '{self.end}'
              AND product_code = 'AmazonEBS'
            GROUP BY name
            ORDER BY cost DESC
        """
        ch_data = ch_query(ch_sql)

        for api_row in api_data:
            ch_row = next((r for r in ch_data if r["name"] == api_row["name"]), None)
            assert ch_row is not None, f"Category {api_row['name']} not in CH"
            assert api_row["cost"] == ch_row["cost"], \
                f"{api_row['name']}: API {api_row['cost']} != CH {ch_row['cost']}"

    def test_227_usage_type_has_volume_storage(self):
        """TC227: Usage type breakdown includes 'Volume Storage'."""
        usage_types = api("/api/v1/storage/ebs/breakdown/usage-type")
        categories = [u["name"] for u in usage_types]
        assert "Volume Storage" in categories, "Volume Storage category missing"

    def test_228_usage_type_has_snapshot_storage(self):
        """TC228: Usage type breakdown includes 'Snapshot Storage'."""
        usage_types = api("/api/v1/storage/ebs/breakdown/usage-type")
        categories = [u["name"] for u in usage_types]
        assert "Snapshot Storage" in categories, "Snapshot Storage category missing"

    def test_229_pricing_model_breakdown_sum_equals_total(self):
        """TC229: Sum of pricing model breakdown equals summary total."""
        models = api("/api/v1/storage/ebs/breakdown/pricing-model")
        model_sum = round(sum(m["cost"] for m in models), 2)
        assert abs(model_sum - self.summary["total_cost"]) <= 0.02, \
            f"Pricing model sum {model_sum} != Summary {self.summary['total_cost']}"

    def test_230_volume_type_sorted_by_cost(self):
        """TC230: Volume type breakdown is sorted by cost descending."""
        vol_types = api("/api/v1/storage/ebs/breakdown/volume-type")
        costs = [v["cost"] for v in vol_types]
        assert costs == sorted(costs, reverse=True), "Volume types not sorted by cost DESC"

    def test_231_region_breakdown_sorted_by_cost(self):
        """TC231: Region breakdown is sorted by cost descending."""
        regions = api("/api/v1/storage/ebs/breakdown/region")
        costs = [r["cost"] for r in regions]
        assert costs == sorted(costs, reverse=True), "Regions not sorted by cost DESC"

    def test_232_operation_breakdown_sorted_by_cost(self):
        """TC232: Operation breakdown is sorted by cost descending."""
        operations = api("/api/v1/storage/ebs/breakdown/operation")
        costs = [o["cost"] for o in operations]
        assert costs == sorted(costs, reverse=True), "Operations not sorted by cost DESC"

    def test_233_volume_type_has_usage_and_unit(self):
        """TC233: Volume type items have usage and unit fields."""
        vol_types = api("/api/v1/storage/ebs/breakdown/volume-type")
        for item in vol_types:
            assert "usage" in item, "Usage field missing"
            assert "unit" in item, "Unit field missing"
            assert item["usage"] >= 0, "Usage should be non-negative"
            assert item["unit"] == "GB", f"Unit should be 'GB', got '{item['unit']}'"


# ══════════════════════════════════════════════════════════
# TEST CLASS 4: EBS VOLUMES TABLE (8 tests)
# ══════════════════════════════════════════════════════════

class TestEBSVolumes:
    @classmethod
    def setup_class(cls):
        cls.data = api("/api/v1/storage/ebs/volumes")
        dates_config = api("/api/v1/config/get-dates")
        cls.start = f"{dates_config['start_date']} 00:00:00"
        cls.end = f"{dates_config['end_date']} 23:59:59"

    def test_234_volumes_top_volume_matches_ch(self):
        """TC234: Top EBS volume cost matches ClickHouse."""
        if not self.data:
            return

        top_vol = self.data[0]

        ch_sql = f"""
            SELECT
                resource_id AS volume_id,
                ROUND(SUM(cost_unblended), 2) AS total_cost
            FROM cost.service_costs FINAL
            WHERE usage_start_ts >= '{self.start}' AND usage_start_ts <= '{self.end}'
              AND product_code = 'AmazonEBS'
              AND resource_id != ''
              AND usage_type LIKE '%Volume%'
            GROUP BY resource_id
            ORDER BY total_cost DESC
            LIMIT 1
        """
        ch_row = ch_query(ch_sql)[0]

        assert top_vol["volume_id"] == ch_row["volume_id"], \
            f"Top volume ID: API {top_vol['volume_id']} != CH {ch_row['volume_id']}"
        assert top_vol["total_cost"] == ch_row["total_cost"], \
            f"Top volume cost: API {top_vol['total_cost']} != CH {ch_row['total_cost']}"

    def test_235_volumes_sorted_by_cost(self):
        """TC235: EBS volumes are sorted by cost descending."""
        costs = [v["total_cost"] for v in self.data]
        assert costs == sorted(costs, reverse=True), "Volumes not sorted by cost DESC"

    def test_236_volumes_have_required_fields(self):
        """TC236: All volumes have required fields."""
        required_fields = ["volume_id", "total_cost", "storage_gb", "volume_type"]
        for vol in self.data:
            for field in required_fields:
                assert field in vol, f"Field '{field}' missing in volume"

    def test_237_volumes_costs_are_positive(self):
        """TC237: All volume costs are non-negative."""
        for vol in self.data:
            assert vol["total_cost"] >= 0, \
                f"Negative cost for volume {vol['volume_id']}"

    def test_238_volumes_storage_is_non_negative(self):
        """TC238: All volume storage values are non-negative."""
        for vol in self.data:
            assert vol["storage_gb"] >= 0, \
                f"Negative storage for volume {vol['volume_id']}"

    def test_239_volumes_limit_is_50(self):
        """TC239: Volumes table returns at most 50 items."""
        assert len(self.data) <= 50, f"Too many volumes: {len(self.data)}"

    def test_240_volumes_have_valid_type(self):
        """TC240: Volume types are valid EBS types."""
        valid_types = {"gp2", "gp3", "io1", "io2", "st1", "sc1", "standard"}
        for vol in self.data:
            assert vol["volume_type"] in valid_types, \
                f"Invalid volume type: {vol['volume_type']}"

    def test_241_volumes_have_region_info(self):
        """TC241: Volumes have region information."""
        has_region = any(v.get("region") for v in self.data)
        assert has_region, "No volumes have region information"


# ══════════════════════════════════════════════════════════
# TEST CLASS 5: EBS SNAPSHOTS TABLE (8 tests)
# ══════════════════════════════════════════════════════════

class TestEBSSnapshots:
    @classmethod
    def setup_class(cls):
        cls.data = api("/api/v1/storage/ebs/snapshots")
        dates_config = api("/api/v1/config/get-dates")
        cls.start = f"{dates_config['start_date']} 00:00:00"
        cls.end = f"{dates_config['end_date']} 23:59:59"

    def test_242_snapshots_top_snapshot_matches_ch(self):
        """TC242: Top EBS snapshot cost matches ClickHouse."""
        if not self.data:
            return

        top_snap = self.data[0]

        ch_sql = f"""
            SELECT
                resource_id AS snapshot_id,
                ROUND(SUM(cost_unblended), 2) AS total_cost
            FROM cost.service_costs FINAL
            WHERE usage_start_ts >= '{self.start}' AND usage_start_ts <= '{self.end}'
              AND product_code = 'AmazonEBS'
              AND resource_id != ''
              AND usage_type LIKE '%Snapshot%'
            GROUP BY resource_id
            ORDER BY total_cost DESC, resource_id ASC
            LIMIT 1
        """
        ch_row = ch_query(ch_sql)[0]

        assert top_snap["snapshot_id"] == ch_row["snapshot_id"], \
            f"Top snapshot ID: API {top_snap['snapshot_id']} != CH {ch_row['snapshot_id']}"
        assert top_snap["total_cost"] == ch_row["total_cost"], \
            f"Top snapshot cost: API {top_snap['total_cost']} != CH {ch_row['total_cost']}"

    def test_243_snapshots_sorted_by_cost(self):
        """TC243: EBS snapshots are sorted by cost descending."""
        costs = [s["total_cost"] for s in self.data]
        assert costs == sorted(costs, reverse=True), "Snapshots not sorted by cost DESC"

    def test_244_snapshots_have_required_fields(self):
        """TC244: All snapshots have required fields."""
        required_fields = ["snapshot_id", "total_cost", "snapshot_gb"]
        for snap in self.data:
            for field in required_fields:
                assert field in snap, f"Field '{field}' missing in snapshot"

    def test_245_snapshots_costs_are_positive(self):
        """TC245: All snapshot costs are non-negative."""
        for snap in self.data:
            assert snap["total_cost"] >= 0, \
                f"Negative cost for snapshot {snap['snapshot_id']}"

    def test_246_snapshots_gb_is_non_negative(self):
        """TC246: All snapshot GB values are non-negative."""
        for snap in self.data:
            assert snap["snapshot_gb"] >= 0, \
                f"Negative snapshot GB for {snap['snapshot_id']}"

    def test_247_snapshots_limit_is_50(self):
        """TC247: Snapshots table returns at most 50 items."""
        assert len(self.data) <= 50, f"Too many snapshots: {len(self.data)}"

    def test_248_snapshots_have_region_info(self):
        """TC248: Snapshots have region information."""
        has_region = any(s.get("region") for s in self.data)
        assert has_region, "No snapshots have region information"

    def test_249_snapshots_count_matches_summary(self):
        """TC249: Snapshot count matches summary total_snapshots."""
        summary = api("/api/v1/storage/ebs/summary")
        # Snapshots list may be capped at 50 but should not exceed total
        assert len(self.data) <= summary["total_snapshots"], \
            f"Snapshot list ({len(self.data)}) > summary count ({summary['total_snapshots']})"
