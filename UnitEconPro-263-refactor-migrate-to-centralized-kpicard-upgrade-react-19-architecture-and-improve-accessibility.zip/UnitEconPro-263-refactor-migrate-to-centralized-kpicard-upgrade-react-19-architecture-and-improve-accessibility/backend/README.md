# UnitEconPro Backend API

## 📁 Page-Based Architecture

```
backend/
├── pages/                      # One folder per dashboard page
│   ├── dashboard/              # Main Dashboard Page
│   │   ├── routes.py          # 6 API endpoints
│   │   ├── queries.py         # SQL queries
│   │   └── schemas.py         # Response models
│   ├── compute/                # Compute Page (EC2, ECS, EKS)
│   ├── storage/                # Storage Page (S3, EBS)
│   ├── networking/             # Networking Page (VPC, ELB)
│   └── databases/              # Databases Page (RDS)
│
├── core/                       # Core utilities
│   ├── config.py              # Environment settings
│   └── database.py            # ClickHouse client
│
├── main.py                     # FastAPI app entry point
├── requirements.txt
└── README.md
```

## 🚀 Quick Start

```bash
cd backend
pip install -r requirements.txt
./run.sh
```

## 📊 Dashboard API Endpoints

### 1. Summary (Stat Cards)
**GET** `/api/dashboard/summary`

Response:
```json
{
  "total_cost": 127483.56,
  "avg_daily_cost": 4249.45,
  "active_services": 18,
  "total_accounts": 12,
  "active_regions": 7,
  "total_resources": 1247
}
```

### 2. Cost Trend (Area Chart)
**GET** `/api/dashboard/trend`

Response:
```json
[
  {
    "date": "2026-02-01",
    "cost": 4123.45,
    "previous_period_cost": 3890.12
  }
]
```

### 3. Service Breakdown (Bar Chart)
**GET** `/api/dashboard/breakdown/service`

Response:
```json
[
  { "name": "EC2", "cost": 45678.23 },
  { "name": "S3", "cost": 23456.78 }
]
```

### 4. Account Breakdown (Pie Chart)
**GET** `/api/dashboard/breakdown/account`

Response:
```json
[
  { "name": "Production", "cost": 67845.23 },
  { "name": "Development", "cost": 28456.78 }
]
```

### 5. Period Comparison (KPIs)
**GET** `/api/dashboard/comparison`

Response:
```json
{
  "yesterday_cost": 4523.82,
  "last_week_cost": 28945.67,
  "this_week_cost": 21783.45,
  "last_month_cost": 118732.41
}
```

### 6. Forecast (Predictions)
**GET** `/api/dashboard/forecast`

Response:
```json
{
  "predicted_week_cost": 30496.83,
  "predicted_month_cost": 131256.78
}
```

## ⚙️ Configuration Endpoints

### Set Global Dates
**POST** `/api/config/set-dates`

Body:
```json
{
  "start_date": "2026-01-01",
  "end_date": "2026-01-31",
  "account_name": "opstree"
}
```

### Get Global Dates
**GET** `/api/config/get-dates`

## 📖 Swagger Documentation

- **Swagger UI**: http://localhost:8000/docs
- **ReDoc**: http://localhost:8000/redoc

## 🏗️ Adding New Pages

To add a new page (e.g., "monitoring"):

1. Create folder structure:
```bash
mkdir -p pages/monitoring
touch pages/monitoring/{__init__.py,routes.py,queries.py,schemas.py}
```

2. Add queries in `queries.py`:
```python
CLOUDWATCH_COST = """
    SELECT SUM(cost_unblended)
    FROM cost.service_costs FINAL
    WHERE product_code = 'AmazonCloudWatch'
"""
```

3. Add schemas in `schemas.py`:
```python
class MonitoringCost(BaseModel):
    cloudwatch_cost: float
```

4. Add routes in `routes.py`:
```python
from fastapi import APIRouter
router = APIRouter(prefix="/api/monitoring", tags=["Monitoring"])

@router.get("/cost")
async def get_monitoring_cost():
    ...
```

5. Register in `main.py`:
```python
from pages.monitoring.routes import router as monitoring_router
app.include_router(monitoring_router)
```

## 🎯 Benefits of This Structure

✅ **Clear organization** - Each page has its own folder  
✅ **Easy to find** - Know exactly where code lives  
✅ **Scalable** - Add pages without touching existing code  
✅ **Team-friendly** - Multiple devs work on different pages  
✅ **Self-documenting** - Structure matches frontend pages  

## 🔧 Development

```bash
# Run with auto-reload
uvicorn main:app --reload

# Run on different port
uvicorn main:app --port 8080

# Run in production
uvicorn main:app --host 0.0.0.0 --port 8000 --workers 4
```
