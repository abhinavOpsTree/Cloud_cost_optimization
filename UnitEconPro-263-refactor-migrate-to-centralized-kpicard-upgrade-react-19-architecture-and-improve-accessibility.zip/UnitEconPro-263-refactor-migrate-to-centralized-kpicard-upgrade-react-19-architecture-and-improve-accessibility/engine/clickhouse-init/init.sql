CREATE DATABASE IF NOT EXISTS cost;

CREATE TABLE IF NOT EXISTS cost.service_costs
(
    account_id UInt64,
    usage_start_ts DateTime CODEC(DoubleDelta, ZSTD(1)),
    usage_end_ts DateTime CODEC(DoubleDelta, ZSTD(1)),
    product_code LowCardinality(String),
    operation LowCardinality(String),
    resource_id String CODEC(ZSTD(1)),
    usage_qty Decimal(18,8) CODEC(ZSTD(1)),
    cost_unblended Decimal(18,8) CODEC(ZSTD(1)),
    cost_blended Decimal(18,8) CODEC(ZSTD(1)),
    availability_zone LowCardinality(String),
    product_family LowCardinality(String),
    region LowCardinality(String),
    usage_type LowCardinality(String),
    instance_type LowCardinality(String),
    instance_family LowCardinality(String),
    instance_type_family LowCardinality(String),
    pricing_model LowCardinality(String),
    pricing_unit LowCardinality(String),
    account_name LowCardinality(String),
    autoscaling_group_name LowCardinality(String),
    scaling_type LowCardinality(String),
    row_hash String CODEC(ZSTD(1)),
    version UInt64 DEFAULT toUnixTimestamp64Milli(now64()),
    -- MIGRATION NOTE (existing deployments):
    -- The old schema had: tag_environment, tag_application, tag_owner, tag_project, tags_extra
    -- These were renamed to: tag_name, tag_env, tag_team, tag_app, tags_map
    -- CREATE TABLE IF NOT EXISTS is idempotent and will NOT alter existing tables.
    -- For existing deployments, run the following ALTER statements manually once:
    --   ALTER TABLE cost.service_costs RENAME COLUMN tag_environment TO tag_env;
    --   ALTER TABLE cost.service_costs ADD COLUMN IF NOT EXISTS tag_name LowCardinality(String) DEFAULT '';
    --   ALTER TABLE cost.service_costs ADD COLUMN IF NOT EXISTS tag_team LowCardinality(String) DEFAULT '';
    --   ALTER TABLE cost.service_costs ADD COLUMN IF NOT EXISTS tag_app  LowCardinality(String) DEFAULT '';
    --   ALTER TABLE cost.service_costs ADD COLUMN IF NOT EXISTS tags_map Map(String,String) DEFAULT map();
    tag_name LowCardinality(String) DEFAULT '',
    tag_env  LowCardinality(String) DEFAULT '',
    tag_team LowCardinality(String) DEFAULT '',
    tag_app  LowCardinality(String) DEFAULT '',
    tags_map Map(String, String) DEFAULT map()
)
ENGINE = ReplacingMergeTree(version)
PARTITION BY (account_id, toStartOfWeek(usage_start_ts))
ORDER BY (account_id, usage_start_ts, product_code, operation, resource_id, usage_type, region, availability_zone, row_hash)
SETTINGS index_granularity = 8192;

CREATE TABLE IF NOT EXISTS cost.account_map
(
    account_id String,
    account_name LowCardinality(String),
    environment LowCardinality(String) DEFAULT '',
    team LowCardinality(String) DEFAULT '',
    created_at DateTime DEFAULT now(),
    updated_at DateTime DEFAULT now()
)
ENGINE = ReplacingMergeTree(updated_at)
ORDER BY account_id
SETTINGS index_granularity = 8192;

CREATE TABLE IF NOT EXISTS cost.ingestion_log
(
    cloud LowCardinality(String),
    service LowCardinality(String),
    run_date Date,
    status LowCardinality(String),
    started_at DateTime,
    finished_at Nullable(DateTime),
    error_message String,
    version UInt64 DEFAULT toUnixTimestamp(started_at)
)
ENGINE = ReplacingMergeTree(version)
PARTITION BY toYYYYMM(run_date)
ORDER BY (cloud, service, run_date, started_at)
SETTINGS index_granularity = 8192;

CREATE TABLE IF NOT EXISTS cost.vm_utilization_summary
(
    provider                LowCardinality(String),
    account_id              String,
    resource_id             String,
    instance_type           LowCardinality(String),
    region                  LowCardinality(String),
    availability_zone       LowCardinality(String),
    event_date              Date,
    period_start            DateTime,
    period_end              DateTime,
    avg_cpu_percent         Float64,
    max_cpu_percent         Float64,
    avg_mem_percent         Float64,
    max_mem_percent         Float64,
    avg_network_in_mbps     Float64 DEFAULT 0,
    avg_network_out_mbps    Float64 DEFAULT 0,
    avg_disk_read_mbps      Float64 DEFAULT 0,
    avg_disk_write_mbps     Float64 DEFAULT 0,
    utilization_score       Float64,
    is_underutilized        UInt8,
    underutilization_reason String DEFAULT '',
    created_at              DateTime DEFAULT now(),
    updated_at              DateTime DEFAULT now()
)
ENGINE = ReplacingMergeTree(updated_at)
PARTITION BY toYYYYMM(event_date)
ORDER BY (provider, account_id, resource_id, event_date)
SETTINGS index_granularity = 8192;

CREATE TABLE IF NOT EXISTS cost.accounts
(
    account_id        String,
    account_name      String,
    access_key_id     String,
    secret_access_key String,
    status            LowCardinality(String) DEFAULT 'ACTIVE',
    created_at        DateTime DEFAULT now(),
    updated_at        DateTime DEFAULT now(),
    is_deleted        UInt8 DEFAULT 0,
    aws_account_id    String DEFAULT '',
    athena_database   String DEFAULT '',
    athena_bucket     String DEFAULT '',
    aws_region        LowCardinality(String) DEFAULT 'us-east-1',
    athena_table      String DEFAULT '',
    last_validated    Nullable(DateTime),
    last_error        String DEFAULT ''
)
ENGINE = ReplacingMergeTree(updated_at)
ORDER BY account_id
SETTINGS index_granularity = 8192;

CREATE TABLE IF NOT EXISTS cost.account_service_permissions
(
    account_id  String,
    service     LowCardinality(String),
    enabled     UInt8 DEFAULT 1,
    updated_at  DateTime DEFAULT now()
)
ENGINE = ReplacingMergeTree(updated_at)
ORDER BY (account_id, service)
SETTINGS index_granularity = 8192;

CREATE TABLE IF NOT EXISTS cost.aws_ecr_metadata
(
    account_id                 String,
    account_name               LowCardinality(String),
    region                     LowCardinality(String),
    repository_name            String,
    image_count                UInt32  DEFAULT 0,
    untagged_images            UInt32  DEFAULT 0,
    latest_push                Nullable(DateTime),
    critical_vulnerabilities   UInt32  DEFAULT 0,
    high_vulnerabilities       UInt32  DEFAULT 0,
    lifecycle_policy_enabled   UInt8   DEFAULT 0,
    ingested_at                DateTime DEFAULT now(),
    version                    UInt64   DEFAULT toUnixTimestamp64Milli(now64())
)
ENGINE = ReplacingMergeTree(version)
ORDER BY (account_id, region, repository_name)
SETTINGS index_granularity = 8192;

CREATE TABLE IF NOT EXISTS cost.aws_eks_metadata
(
    account_id                 String,
    account_name               LowCardinality(String),
    region                     LowCardinality(String),
    cluster_name               String,
    kubernetes_version         LowCardinality(String),
    cluster_status             LowCardinality(String),
    nodegroup_count            UInt32  DEFAULT 0,
    fargate_profiles_count     UInt32  DEFAULT 0,
    total_nodes                UInt32  DEFAULT 0,
    has_spot_nodes             UInt8   DEFAULT 0,
    has_degraded_nodegroup     UInt8   DEFAULT 0,
    node_instance_types        Array(String) DEFAULT [],
    addon_count                UInt32  DEFAULT 0,
    has_degraded_addon         UInt8   DEFAULT 0,
    ingested_at                DateTime DEFAULT now(),
    version                    UInt64   DEFAULT toUnixTimestamp64Milli(now64())
)
ENGINE = ReplacingMergeTree(version)
ORDER BY (account_id, region, cluster_name)
SETTINGS index_granularity = 8192;

CREATE TABLE IF NOT EXISTS cost.app_settings
(
    setting_key   String,
    setting_value String,
    updated_at    DateTime DEFAULT now()
)
ENGINE = ReplacingMergeTree(updated_at)
ORDER BY setting_key
SETTINGS index_granularity = 8192;

CREATE TABLE IF NOT EXISTS cost.aws_hub
(
    recommendation_id            String,
    account_id                   String,
    account_name                 LowCardinality(String),
    region                       LowCardinality(String),
    resource_id                  String,
    resource_type                LowCardinality(String),
    action_type                  LowCardinality(String),
    estimated_monthly_savings    Float64,
    estimated_monthly_cost       Float64,
    current_resource_summary     String,
    recommended_resource_summary String,
    currency_code                LowCardinality(String) DEFAULT 'USD',
    export_date                  Date DEFAULT today(),
    ingested_at                  DateTime DEFAULT now()
)
ENGINE = ReplacingMergeTree(ingested_at)
PARTITION BY toYYYYMM(export_date)
ORDER BY (account_id, region, resource_id, action_type, export_date, recommendation_id)
SETTINGS index_granularity = 8192;

INSERT INTO cost.app_settings (setting_key, setting_value)
SELECT key, val
FROM (
    SELECT 'ecr_cost_warning' AS key, '20' AS val
    UNION ALL SELECT 'ecr_cost_error', '50'
    UNION ALL SELECT 'ecr_storage_warning', '100'
    UNION ALL SELECT 'ecr_storage_error', '300'
    UNION ALL SELECT 'ecr_transfer_warning', '50'
    UNION ALL SELECT 'ecr_transfer_error', '150'
    UNION ALL SELECT 'eks_cost_warning', '50'
    UNION ALL SELECT 'eks_cost_error', '200'
) AS defaults
WHERE key NOT IN (SELECT setting_key FROM cost.app_settings FINAL);

CREATE TABLE IF NOT EXISTS cost.alert_rules
(
    rule_id String,
    account_id String,
    service LowCardinality(String),
    sensitivity Float32 DEFAULT 2.0,
    min_impact Float64 DEFAULT 10.0,
    enabled UInt8 DEFAULT 1,
    dod_pct_threshold Float32 DEFAULT 0.40,
    criticality_weight UInt8 DEFAULT 5,
    cooldown_hours UInt8 DEFAULT 24,
    created_at DateTime DEFAULT now(),
    updated_at DateTime DEFAULT now()
)
ENGINE = ReplacingMergeTree(updated_at)
ORDER BY (account_id, service)
SETTINGS index_granularity = 8192;

CREATE TABLE IF NOT EXISTS cost.alert_events
(
    alert_id          String,
    account_id        String,
    account_name      String,
    service           LowCardinality(String),
    severity          LowCardinality(String),
    cost_today        Float64,
    mean_cost         Float64,
    std_dev           Float64,
    upper_threshold   Float64,
    z_score           Float64,
    pct_above_mean    Float64,
    status            LowCardinality(String) DEFAULT 'OPEN',
    fired_at          DateTime DEFAULT now(),
    acknowledged_at   Nullable(DateTime) DEFAULT NULL,
    resolved_at       Nullable(DateTime),
    updated_at        DateTime DEFAULT now()
)
ENGINE = ReplacingMergeTree(updated_at)
PARTITION BY toYYYYMM(fired_at)
ORDER BY (account_id, service, alert_id)  -- alert_id required: same account+service can have multiple alerts per day
SETTINGS index_granularity = 8192;

CREATE TABLE IF NOT EXISTS cost.aws_s3_metadata
(
    account_id                  String,
    bucket_name                 String,
    region                      LowCardinality(String),
    creation_date               DateTime DEFAULT now(),
    account_name                LowCardinality(String) DEFAULT '',
    versioning_status           LowCardinality(String) DEFAULT 'Disabled',
    has_lifecycle_rules         UInt8 DEFAULT 0,
    clears_incomplete_multipart UInt8 DEFAULT 0,
    is_public                   UInt8 DEFAULT 0,
    encryption_type             LowCardinality(String) DEFAULT 'None',
    tags                        Map(String, String) DEFAULT map(),
    ingested_at                 DateTime DEFAULT now(),
    version                     UInt64 DEFAULT toUnixTimestamp64Milli(now64())
)
ENGINE = ReplacingMergeTree(version)
ORDER BY (account_id, bucket_name)
PARTITION BY account_id
SETTINGS index_granularity = 8192;

CREATE TABLE IF NOT EXISTS cost.aws_ec2_metadata
(
    account_id          String,
    account_name        LowCardinality(String),
    region              LowCardinality(String),
    availability_zone   LowCardinality(String),
    instance_id         String,
    instance_state      LowCardinality(String),
    instance_lifecycle  LowCardinality(String),
    platform            LowCardinality(String),
    architecture        LowCardinality(String),
    launch_time         Nullable(DateTime),
    tenancy             LowCardinality(String),
    ebs_optimized       UInt8  DEFAULT 0,
    detailed_monitoring UInt8  DEFAULT 0,
    has_public_ip       UInt8  DEFAULT 0,
    attached_ebs_count  UInt32 DEFAULT 0,
    root_volume_type    LowCardinality(String),
    root_volume_size_gb UInt32 DEFAULT 0,
    tags                Map(String, String) DEFAULT map(),
    ingested_at         DateTime DEFAULT now(),
    version             UInt64   DEFAULT toUnixTimestamp64Milli(now64()),
    -- CloudWatch free metrics (14-day window, no agent required)
    instance_type        LowCardinality(String) DEFAULT '',
    cpu_avg_pct          Float32 DEFAULT -1,
    cpu_max_pct          Float32 DEFAULT -1,
    cpu_p95_pct          Float32 DEFAULT -1,
    net_in_mbps          Float32 DEFAULT -1,
    net_out_mbps         Float32 DEFAULT -1,
    rightsizing_signal   LowCardinality(String) DEFAULT '',
    utilization_days     UInt8 DEFAULT 0,
    utilization_updated  Nullable(DateTime) DEFAULT NULL
)
ENGINE = ReplacingMergeTree(version)
ORDER BY (account_id, region, instance_id)
SETTINGS index_granularity = 8192;

-- Migration for existing deployments: add CloudWatch columns if not present
ALTER TABLE cost.aws_ec2_metadata
    ADD COLUMN IF NOT EXISTS instance_type       LowCardinality(String) DEFAULT '',
    ADD COLUMN IF NOT EXISTS cpu_avg_pct         Float32 DEFAULT -1,
    ADD COLUMN IF NOT EXISTS cpu_max_pct         Float32 DEFAULT -1,
    ADD COLUMN IF NOT EXISTS cpu_p95_pct         Float32 DEFAULT -1,
    ADD COLUMN IF NOT EXISTS net_in_mbps         Float32 DEFAULT -1,
    ADD COLUMN IF NOT EXISTS net_out_mbps        Float32 DEFAULT -1,
    ADD COLUMN IF NOT EXISTS rightsizing_signal  LowCardinality(String) DEFAULT '',
    ADD COLUMN IF NOT EXISTS utilization_days    UInt8 DEFAULT 0,
    ADD COLUMN IF NOT EXISTS utilization_updated Nullable(DateTime) DEFAULT NULL;

CREATE TABLE IF NOT EXISTS cost.aws_ebs_metadata
(
    account_id              String,
    account_name            LowCardinality(String),
    region                  LowCardinality(String),
    availability_zone       LowCardinality(String),
    volume_id               String,
    volume_type             LowCardinality(String),
    size_gb                 UInt32,
    iops                    UInt32  DEFAULT 0,
    throughput              UInt32  DEFAULT 0,
    state                   LowCardinality(String),
    attached_instance_id    Nullable(String) DEFAULT NULL,
    attached_device         Nullable(String) DEFAULT NULL,
    delete_on_termination   UInt8   DEFAULT 0,
    age_days                UInt32  DEFAULT 0,
    snapshot_count          UInt32  DEFAULT 0,
    last_snapshot_age_days  Int32   DEFAULT -1,
    encrypted               UInt8   DEFAULT 0,
    kms_key_id              String  DEFAULT '',
    multi_attach_enabled    UInt8   DEFAULT 0,
    tags                    Map(String, String) DEFAULT map(),
    create_time             Nullable(DateTime) DEFAULT NULL,
    ingested_at             DateTime DEFAULT now(),
    version                 UInt64   DEFAULT toUnixTimestamp64Milli(now64())
)
ENGINE = ReplacingMergeTree(version)
ORDER BY (account_id, region, volume_id)
SETTINGS index_granularity = 8192;

CREATE TABLE IF NOT EXISTS cost.aws_rds_metadata
(
    account_id                      String,
    account_name                    LowCardinality(String),
    region                          LowCardinality(String),
    availability_zone               LowCardinality(String),
    db_instance_id                  String,
    db_cluster_identifier           Nullable(String) DEFAULT NULL,
    db_arn                          String  DEFAULT '',
    engine                          LowCardinality(String),
    engine_version                  String,
    license_model                   LowCardinality(String),
    instance_class                  LowCardinality(String),
    instance_family                 LowCardinality(String),
    db_instance_status              LowCardinality(String),
    storage_type                    LowCardinality(String),
    allocated_storage_gb            UInt32  DEFAULT 0,
    max_allocated_storage_gb        UInt32  DEFAULT 0,
    provisioned_iops                UInt32  DEFAULT 0,
    storage_throughput              UInt32  DEFAULT 0,
    storage_encrypted               UInt8   DEFAULT 0,
    multi_az                        UInt8   DEFAULT 0,
    read_replica_count              UInt32  DEFAULT 0,
    source_db_instance_id           String  DEFAULT '',
    publicly_accessible             UInt8   DEFAULT 0,
    backup_retention_period         UInt32  DEFAULT 0,
    backup_window                   String  DEFAULT '',
    maintenance_window              String  DEFAULT '',
    instance_create_time            Nullable(DateTime),
    age_days                        UInt32  DEFAULT 0,
    auto_minor_version_upgrade      UInt8   DEFAULT 0,
    deletion_protection             UInt8   DEFAULT 0,
    performance_insights_enabled    UInt8   DEFAULT 0,
    performance_insights_retention  UInt32  DEFAULT 0,
    enhanced_monitoring_interval    UInt32  DEFAULT 0,
    ca_certificate_identifier       String  DEFAULT '',
    iam_db_auth_enabled             UInt8   DEFAULT 0,
    db_subnet_group                 String  DEFAULT '',
    tags                            Map(String, String) DEFAULT map(),
    avg_cpu_pct                     Float32 DEFAULT -1.0,
    max_cpu_pct                     Float32 DEFAULT -1.0,
    avg_connections                 Float32 DEFAULT -1.0,
    max_connections                 Float32 DEFAULT -1.0,
    avg_freeable_memory_bytes       Float64 DEFAULT -1.0,
    avg_read_iops                   Float32 DEFAULT -1.0,
    avg_write_iops                  Float32 DEFAULT -1.0,
    utilization_window_days         UInt8   DEFAULT 14,
    utilization_last_updated        Nullable(DateTime),
    ingested_at                     DateTime DEFAULT now(),
    version                         UInt64   DEFAULT toUnixTimestamp64Milli(now64())
)
ENGINE = ReplacingMergeTree(version)
ORDER BY (account_id, region, db_instance_id)
PARTITION BY account_id
SETTINGS index_granularity = 8192;

CREATE TABLE IF NOT EXISTS cost.aws_vpc_metadata
(
    account_id                      String,
    account_name                    LowCardinality(String),
    region                          LowCardinality(String),
    vpc_id                          String,
    vpc_name                        String DEFAULT '',
    cidr_block                      String,
    is_default_vpc                  UInt8 DEFAULT 0,
    subnet_count                    UInt32 DEFAULT 0,
    public_subnet_count             UInt32 DEFAULT 0,
    private_subnet_count            UInt32 DEFAULT 0,
    isolated_subnet_count           UInt32 DEFAULT 0,
    nat_gateway_count               UInt32 DEFAULT 0,
    active_nat_gateway_count        UInt32 DEFAULT 0,
    has_s3_gateway_endpoint         UInt8 DEFAULT 0,
    has_dynamodb_gateway_endpoint   UInt8 DEFAULT 0,
    has_internet_gateway            UInt8 DEFAULT 0,
    flow_logs_enabled               UInt8 DEFAULT 0,
    vpc_endpoint_count              UInt32 DEFAULT 0,
    tags                            Map(String, String) DEFAULT map(),
    ingested_at                     DateTime DEFAULT now(),
    version                         UInt64 DEFAULT toUnixTimestamp64Milli(now64())
)
ENGINE = ReplacingMergeTree(version)
ORDER BY (account_id, region, vpc_id)
PARTITION BY account_id
SETTINGS index_granularity = 8192;

-- ============================================================================
-- ELB (Elastic Load Balancing) FinOps Tables
-- ============================================================================

CREATE TABLE IF NOT EXISTS cost.aws_elb_metadata
(
    account_id              String,
    account_name            LowCardinality(String),
    region                  LowCardinality(String),
    load_balancer_name      String,
    load_balancer_arn       String,   -- Classic ARN constructed to match CUR

    load_balancer_type      LowCardinality(String),  -- application|network|gateway|classic
    scheme                  LowCardinality(String),  -- internet-facing|internal
    lb_state                LowCardinality(String),
    vpc_id                  String DEFAULT '',
    ip_address_type         LowCardinality(String) DEFAULT '',
    dns_name                String DEFAULT '',
    hosted_zone_id          String DEFAULT '',

    availability_zones      Array(String) DEFAULT [],
    subnet_ids              Array(String) DEFAULT [],
    eip_allocation_ids      Array(String) DEFAULT [],
    security_groups         Array(String) DEFAULT [],

    total_listeners         UInt32 DEFAULT 0,
    has_http_listener       UInt8 DEFAULT 0,
    has_https_listener      UInt8 DEFAULT 0,
    has_tcp_listener        UInt8 DEFAULT 0,
    has_tls_listener        UInt8 DEFAULT 0,
    http_to_https_redirect  UInt8 DEFAULT 0,
    total_rules             UInt32 DEFAULT 0,

    target_group_count          UInt32 DEFAULT 0,
    total_registered_targets    UInt32 DEFAULT 0,
    healthy_target_count        UInt32 DEFAULT 0,
    unhealthy_target_count      UInt32 DEFAULT 0,
    draining_target_count       UInt32 DEFAULT 0,
    unused_target_group_count   UInt32 DEFAULT 0,

    deletion_protection_enabled UInt8 DEFAULT 0,
    access_logs_enabled         UInt8 DEFAULT 0,
    access_logs_s3_bucket       String DEFAULT '',

    idle_timeout_seconds        UInt32 DEFAULT 60,
    http_desync_mitigation_mode LowCardinality(String) DEFAULT '',
    drop_invalid_header_fields  UInt8 DEFAULT 0,
    has_sticky_target_group     UInt8 DEFAULT 0,
    cross_zone_load_balancing   UInt8 DEFAULT 0,

    ssl_policy_names            Array(String) DEFAULT [],
    has_deprecated_ssl_policy   UInt8 DEFAULT 0,

    waf_enabled                 UInt8 DEFAULT 0,
    waf_web_acl_arn             String DEFAULT '',

    is_idle                     UInt8 DEFAULT 0,

    created_time                Nullable(DateTime),
    age_days                    UInt32 DEFAULT 0,

    tags                        Map(String, String) DEFAULT map(),
    ingested_at                 DateTime DEFAULT now(),
    version                     UInt64 DEFAULT toUnixTimestamp64Milli(now64())
)
ENGINE = ReplacingMergeTree(version)
ORDER BY (account_id, region, load_balancer_arn)
PARTITION BY account_id
SETTINGS index_granularity = 8192;


CREATE TABLE IF NOT EXISTS cost.aws_elb_target_group_metadata
(
    account_id              String,
    account_name            LowCardinality(String),
    region                  LowCardinality(String),
    load_balancer_arns      Array(String) DEFAULT [],   -- many-to-many
    target_group_name       String,
    target_group_arn        String,

    protocol                LowCardinality(String),
    port                    UInt32 DEFAULT 0,
    target_type             LowCardinality(String),
    vpc_id                  String DEFAULT '',
    load_balancing_algorithm LowCardinality(String) DEFAULT 'round_robin',

    health_check_enabled        UInt8 DEFAULT 1,
    health_check_protocol       LowCardinality(String) DEFAULT '',
    health_check_port           String DEFAULT 'traffic-port',
    health_check_path           String DEFAULT '/',
    health_check_interval_sec   UInt32 DEFAULT 30,
    health_check_timeout_sec    UInt32 DEFAULT 5,
    healthy_threshold           UInt32 DEFAULT 3,
    unhealthy_threshold         UInt32 DEFAULT 3,

    stickiness_enabled          UInt8 DEFAULT 0,
    stickiness_type             LowCardinality(String) DEFAULT '',
    stickiness_duration_sec     UInt32 DEFAULT 0,

    deregistration_delay_sec    UInt32 DEFAULT 300,
    slow_start_duration_sec     UInt32 DEFAULT 0,

    registered_target_count     UInt32 DEFAULT 0,
    healthy_count               UInt32 DEFAULT 0,
    unhealthy_count             UInt32 DEFAULT 0,
    draining_count              UInt32 DEFAULT 0,

    is_orphaned                 UInt8 DEFAULT 0,
    is_unused                   UInt8 DEFAULT 0,

    tags                        Map(String, String) DEFAULT map(),
    ingested_at                 DateTime DEFAULT now(),
    version                     UInt64 DEFAULT toUnixTimestamp64Milli(now64())
)
ENGINE = ReplacingMergeTree(version)
ORDER BY (account_id, region, target_group_arn)
PARTITION BY account_id
SETTINGS index_granularity = 8192;


CREATE TABLE IF NOT EXISTS cost.aws_elb_listener_metadata
(
    account_id                      String,
    account_name                    LowCardinality(String),
    region                          LowCardinality(String),
    load_balancer_arn               String,
    listener_arn                    String,

    port                            UInt32,
    protocol                        LowCardinality(String),
    ssl_policy                      LowCardinality(String) DEFAULT '',
    default_action_type             LowCardinality(String) DEFAULT '',
    has_redirect_action             UInt8 DEFAULT 0,
    alpn_policy                     LowCardinality(String) DEFAULT '',
    default_certificate_arn         String DEFAULT '',
    additional_certificate_count    UInt32 DEFAULT 0,
    rule_count                      UInt32 DEFAULT 0,

    ingested_at                     DateTime DEFAULT now(),
    version                         UInt64 DEFAULT toUnixTimestamp64Milli(now64())
)
ENGINE = ReplacingMergeTree(version)
ORDER BY (account_id, region, listener_arn)
PARTITION BY account_id
SETTINGS index_granularity = 8192;


CREATE TABLE IF NOT EXISTS cost.aws_gwlb_endpoint_metadata
(
    account_id              String,
    account_name            LowCardinality(String),
    region                  LowCardinality(String),
    vpc_endpoint_id         String,
    vpc_id                  String DEFAULT '',
    service_name            String DEFAULT '',
    subnet_ids              Array(String) DEFAULT [],
    endpoint_state          LowCardinality(String) DEFAULT '',
    age_days                UInt32 DEFAULT 0,
    created_time            Nullable(DateTime),
    tags                    Map(String, String) DEFAULT map(),
    ingested_at             DateTime DEFAULT now(),
    version                 UInt64 DEFAULT toUnixTimestamp64Milli(now64())
)
ENGINE = ReplacingMergeTree(version)
ORDER BY (account_id, region, vpc_endpoint_id)
PARTITION BY account_id
SETTINGS index_granularity = 8192;

CREATE TABLE IF NOT EXISTS cost.aws_nat_gateway_metadata
(
    account_id                  String,
    account_name                LowCardinality(String),
    region                      LowCardinality(String),
    availability_zone           LowCardinality(String),
    nat_gateway_id              String,
    vpc_id                      String,
    subnet_id                   String,
    state                       LowCardinality(String),
    connectivity_type           LowCardinality(String),
    elastic_ip_address          String DEFAULT '',
    elastic_ip_allocation_id    String DEFAULT '',
    create_time                 Nullable(DateTime),
    age_days                    UInt32 DEFAULT 0,
    subnet_active_eni_count     UInt32 DEFAULT 0,
    tags                        Map(String, String) DEFAULT map(),
    ingested_at                 DateTime DEFAULT now(),
    version                     UInt64 DEFAULT toUnixTimestamp64Milli(now64())
)
ENGINE = ReplacingMergeTree(version)
ORDER BY (account_id, region, nat_gateway_id)
PARTITION BY account_id
SETTINGS index_granularity = 8192;

CREATE TABLE IF NOT EXISTS cost.aws_eip_metadata
(
    account_id              String,
    account_name            LowCardinality(String),
    region                  LowCardinality(String),
    allocation_id           String,
    public_ip               String,
    association_id          String DEFAULT '',
    network_interface_id    String DEFAULT '',
    vpc_id                  String DEFAULT '',
    is_attached             UInt8 DEFAULT 0,
    tags                    Map(String, String) DEFAULT map(),
    ingested_at             DateTime DEFAULT now(),
    version                 UInt64 DEFAULT toUnixTimestamp64Milli(now64())
)
ENGINE = ReplacingMergeTree(version)
ORDER BY (account_id, region, allocation_id)
PARTITION BY account_id
SETTINGS index_granularity = 8192;

CREATE TABLE IF NOT EXISTS cost.aws_eni_metadata
(
    account_id              String,
    account_name            LowCardinality(String),
    region                  LowCardinality(String),
    eni_id                  String,
    vpc_id                  String DEFAULT '',
    subnet_id               String DEFAULT '',
    instance_id             String DEFAULT '',
    interface_type          LowCardinality(String) DEFAULT '',
    description             String DEFAULT '',
    tags                    Map(String, String) DEFAULT map(),
    ingested_at             DateTime DEFAULT now(),
    version                 UInt64 DEFAULT toUnixTimestamp64Milli(now64())
)
ENGINE = ReplacingMergeTree(version)
ORDER BY (account_id, region, eni_id)
PARTITION BY account_id
SETTINGS index_granularity = 8192;

CREATE OR REPLACE VIEW cost.ec2_criticality_view AS
WITH
    tags_norm AS (
        SELECT
            instance_id,
            account_id,
            launch_time,
            dateDiff('hour', launch_time, now()) AS age_hours,
            transform(
                lower(tags['Environment']),
                ['prod','prd','production','live','main','dev','development','sandbox','test','qa','uat','staging','stage'],
                ['PROD','PROD','PROD','PROD','PROD','DEV','DEV','DEV','DEV','DEV','DEV','STAGING','STAGING'],
                'UNKNOWN'
            ) AS env_norm
        FROM cost.aws_ec2_metadata FINAL
    ),
    usage_stats AS (
        SELECT
            instance_id,
            uniqExactIf(usage_date, daily_hours > 0) AS active_days,
            avgIf(daily_hours, dow BETWEEN 1 AND 5)  AS avg_weekday_hours,
            avgIf(daily_hours, dow IN (6, 7))         AS avg_weekend_hours
        FROM (
            SELECT
                CASE
                    WHEN resource_id LIKE 'arn:aws:ec2:%' THEN splitByChar('/', resource_id)[-1]
                    ELSE resource_id
                END AS instance_id,
                toDate(usage_start_ts)  AS usage_date,
                toDayOfWeek(usage_date) AS dow,
                SUM(usage_qty)          AS daily_hours
            FROM cost.service_costs FINAL
            WHERE product_code = 'AmazonEC2'
              AND usage_type LIKE '%BoxUsage%'
              AND usage_start_ts >= now() - INTERVAL 30 DAY
            GROUP BY instance_id, usage_date
        )
        GROUP BY instance_id
    ),
    joined AS (
        SELECT
            t.instance_id, t.account_id, t.launch_time, t.age_hours, t.env_norm,
            COALESCE(u.active_days, 0) AS active_days,
            COALESCE(u.avg_weekday_hours, 0) AS avg_weekday_hours,
            COALESCE(u.avg_weekend_hours, 0) AS avg_weekend_hours,
            (u.instance_id IS NULL) AS no_cur_data
        FROM tags_norm t
        LEFT JOIN usage_stats u ON t.instance_id = u.instance_id
    )
SELECT
    instance_id, account_id, launch_time, age_hours, env_norm, active_days,
    round(avg_weekday_hours, 1) AS avg_weekday_hours,
    round(avg_weekend_hours, 1) AS avg_weekend_hours,
    no_cur_data,
    CASE
        WHEN no_cur_data = true OR age_hours < 48                              THEN 'Evaluating'
        WHEN env_norm = 'PROD' AND avg_weekend_hours >= 20                     THEN 'Mission-Critical (24x7)'
        WHEN env_norm = 'PROD' AND avg_weekend_hours < 2 AND age_hours >= 168  THEN 'Reliability Risk'
        WHEN env_norm = 'PROD'                                                 THEN 'Mission-Critical'
        WHEN avg_weekday_hours >= 22 AND avg_weekend_hours >= 20               THEN 'Continuous (24x7)'
        WHEN avg_weekday_hours >= 10 AND avg_weekend_hours < 2                 THEN 'Business Hours (24x5)'
        WHEN active_days = 0                                                   THEN 'Idle / Zombie'
        WHEN active_days < 10 OR avg_weekday_hours < 5                         THEN 'Low Usage'
        ELSE 'Irregular'
    END AS criticality,
    CASE
        WHEN env_norm = 'PROD' AND avg_weekend_hours < 2 AND age_hours >= 168  THEN 'Prod offline on weekends — reliability risk. Verify backup and failover.'
        WHEN env_norm = 'DEV'  AND avg_weekend_hours >= 20                     THEN 'Dev instance running 24x7 — add automated start/stop schedule to save cost.'
        WHEN env_norm = 'UNKNOWN' AND avg_weekday_hours >= 20                  THEN 'Untagged continuous instance — tag Environment for governance and cost allocation.'
        WHEN active_days = 0                                                   THEN 'Zero usage in 30 days — immediate termination candidate.'
        WHEN no_cur_data = true                                                THEN 'Waiting for CUR data — check if instance is reporting usage.'
        ELSE NULL
    END AS insight
FROM joined
ORDER BY
    CASE criticality
        WHEN 'Mission-Critical (24x7)' THEN 1
        WHEN 'Reliability Risk'        THEN 2
        WHEN 'Mission-Critical'        THEN 3
        WHEN 'Continuous (24x7)'       THEN 4
        WHEN 'Business Hours (24x5)'   THEN 5
        WHEN 'Irregular'               THEN 6
        WHEN 'Low Usage'               THEN 7
        WHEN 'Idle / Zombie'           THEN 8
        WHEN 'Evaluating'              THEN 9
        ELSE 10
    END;

-- Budget Management
CREATE TABLE IF NOT EXISTS cost.account_budgets
(
    account_id      String,
    account_name    LowCardinality(String),
    year_month      String,
    budget_amount   Decimal(18,8),
    currency        LowCardinality(String) DEFAULT 'USD',
    created_at      DateTime DEFAULT now(),
    updated_at      DateTime DEFAULT now(),
    version         UInt64 DEFAULT toUnixTimestamp64Milli(now64())
)
ENGINE = ReplacingMergeTree(version)
ORDER BY (account_id, year_month)
SETTINGS index_granularity = 8192;
