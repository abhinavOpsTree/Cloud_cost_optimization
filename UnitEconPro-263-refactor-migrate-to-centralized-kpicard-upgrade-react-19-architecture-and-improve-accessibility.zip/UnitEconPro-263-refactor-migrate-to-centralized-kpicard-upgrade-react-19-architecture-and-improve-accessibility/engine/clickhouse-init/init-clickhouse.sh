#!/bin/sh

set -eux

# Use environment variables
: "${CLICKHOUSE_HOST:?Missing CLICKHOUSE_HOST}"
: "${CLICKHOUSE_PORT:?Missing CLICKHOUSE_PORT}"
: "${CLICKHOUSE_USER:?Missing CLICKHOUSE_USER}"
: "${CLICKHOUSE_PASSWORD:?Missing CLICKHOUSE_PASSWORD}"
: "${CLICKHOUSE_DATABASE:?Missing CLICKHOUSE_DATABASE}"
: "${CLICKHOUSE_TABLE:?Missing CLICKHOUSE_TABLE}"

STATUS_FILE="/init-status/done"

echo "Waiting for ClickHouse to be ready..."
until curl -s "http://${CLICKHOUSE_HOST}:${CLICKHOUSE_PORT}/ping" | grep -q "Ok"; do
  echo "⌛ Still waiting for ClickHouse..."
  sleep 1
done

echo "ClickHouse is up!"

echo "Creating database if not exists..."
curl -sS "http://${CLICKHOUSE_HOST}:${CLICKHOUSE_PORT}/?user=${CLICKHOUSE_USER}&password=${CLICKHOUSE_PASSWORD}" \
  --data "CREATE DATABASE IF NOT EXISTS ${CLICKHOUSE_DATABASE}"

echo "Creating service_costs table if not exists..."
curl -sS "http://${CLICKHOUSE_HOST}:${CLICKHOUSE_PORT}/?user=${CLICKHOUSE_USER}&password=${CLICKHOUSE_PASSWORD}" \
  --data-binary @- <<EOF
CREATE TABLE IF NOT EXISTS ${CLICKHOUSE_DATABASE}.service_costs
(
    account_id UInt64,
    usage_start_ts DateTime CODEC(DoubleDelta, ZSTD(1)),
    usage_end_ts DateTime CODEC(DoubleDelta, ZSTD(1)),
    product_code LowCardinality(String),
    operation LowCardinality(String),
    resource_id String CODEC(ZSTD(1)),
    usage_qty Float32 CODEC(ZSTD(1)),
    cost_unblended Float32 CODEC(ZSTD(1)),
    cost_blended Float32 CODEC(ZSTD(1)),
    availability_zone LowCardinality(String),
    product_family LowCardinality(String),
    region LowCardinality(String),
    usage_type LowCardinality(String),
    instance_type LowCardinality(String),
    instance_family LowCardinality(String),
    instance_type_family LowCardinality(String),
    pricing_model LowCardinality(String),
    pricing_unit LowCardinality(String),
    account_name LowCardinality(String),
    autoscaling_group_name LowCardinality(String),
    scaling_type LowCardinality(String),
    row_hash String CODEC(ZSTD(1)),
    version UInt64 DEFAULT toUnixTimestamp64Milli(now64()),
    tag_name LowCardinality(String) DEFAULT '',
    tag_environment LowCardinality(String) DEFAULT '',
    tag_team LowCardinality(String) DEFAULT '',
    tag_application LowCardinality(String) DEFAULT '',
    tag_owner LowCardinality(String) DEFAULT '',
    tag_project LowCardinality(String) DEFAULT '',
    tags_extra Map(String, String) DEFAULT map(),
    tag_env LowCardinality(String) DEFAULT '',
    tag_app LowCardinality(String) DEFAULT '',
    tags_map Map(String, String) DEFAULT map()
)
ENGINE = ReplacingMergeTree(version)
PARTITION BY (account_id, toStartOfWeek(usage_start_ts))
ORDER BY (account_id, usage_start_ts, product_code, operation, resource_id, usage_type, region, availability_zone, row_hash)
SETTINGS index_granularity = 8192
EOF

echo "Creating ingestion_log table if not exists..."
curl -sS "http://${CLICKHOUSE_HOST}:${CLICKHOUSE_PORT}/?user=${CLICKHOUSE_USER}&password=${CLICKHOUSE_PASSWORD}" \
  --data-binary @- <<EOF
CREATE TABLE IF NOT EXISTS ${CLICKHOUSE_DATABASE}.ingestion_log
(
    cloud String,
    service String,
    run_date Date,
    status String,
    started_at DateTime,
    finished_at Nullable(DateTime),
    error_message String,
    version UInt64 
)
ENGINE = ReplacingMergeTree(version)
PARTITION BY run_date
ORDER BY (cloud, service, run_date)
EOF

echo " Creating account_map table if not exists..."
curl -sS "http://${CLICKHOUSE_HOST}:${CLICKHOUSE_PORT}/?user=${CLICKHOUSE_USER}&password=${CLICKHOUSE_PASSWORD}" \
  --data-binary @- <<EOF
CREATE TABLE IF NOT EXISTS ${CLICKHOUSE_DATABASE}.account_map 
(
    account_id String,
    account_name String,
    environment LowCardinality(String) DEFAULT '',
    team LowCardinality(String) DEFAULT '',
    created_at DateTime DEFAULT now(),
    updated_at DateTime DEFAULT now()
)
ENGINE = ReplacingMergeTree(updated_at)
ORDER BY account_id
EOF

echo " Creating vm_utilization_summary table if not exists..."
curl -sS "http://${CLICKHOUSE_HOST}:${CLICKHOUSE_PORT}/?user=${CLICKHOUSE_USER}&password=${CLICKHOUSE_PASSWORD}" \
  --data-binary @- <<EOF
CREATE TABLE IF NOT EXISTS ${CLICKHOUSE_DATABASE}.vm_utilization_summary
(
    provider String,
    account_id String,
    resource_id String,
    instance_type String,
    region String,
    availability_zone String,
    event_date Date,
    period_start DateTime,
    period_end DateTime,
    avg_cpu_percent Float64,
    max_cpu_percent Float64,
    avg_mem_percent Float64,
    max_mem_percent Float64,
    avg_network_in_mbps Float64 DEFAULT 0,
    avg_network_out_mbps Float64 DEFAULT 0,
    avg_disk_read_mbps Float64 DEFAULT 0,
    avg_disk_write_mbps Float64 DEFAULT 0,
    utilization_score Float64,
    is_underutilized UInt8,
    underutilization_reason String DEFAULT '',
    created_at DateTime DEFAULT now(),
    updated_at DateTime DEFAULT now()
)
ENGINE = ReplacingMergeTree(updated_at)
ORDER BY (provider, account_id, resource_id, event_date)
PARTITION BY toYYYYMM(event_date)
EOF



# echo "Inserting sample row..."
#curl -sS "http://${CLICKHOUSE_HOST}:${CLICKHOUSE_PORT}/?user=${CLICKHOUSE_USER}&password=${CLICKHOUSE_PASSWORD}" \
# --data "INSERT INTO ${CLICKHOUSE_DATABASE}.${CLICKHOUSE_TABLE} VALUES('account_123', '2025-05-19 00:00:00', '2025-05-25 23:59:59', 'AmazonCloudWatch', 'compute', 'arn:aws:logs:ap-southeast-1:702037529261:log-group:/aws/eks/test-cluster/cluster', 10.5, 15.75, 12.50, 'compute_family', 'us-east-1', 'on_demand', 't3.medium', 't3', 'standard', 'On Demand', 'Hrs')"


echo " Creating accounts table if not exists..."
curl -sS "http://${CLICKHOUSE_HOST}:${CLICKHOUSE_PORT}/?user=${CLICKHOUSE_USER}&password=${CLICKHOUSE_PASSWORD}" \
  --data-binary @- <<EOF
CREATE TABLE IF NOT EXISTS ${CLICKHOUSE_DATABASE}.accounts
(
    account_id        String,
    account_name      String,
    aws_account_id    String,
    access_key_id     String,
    secret_access_key String,
    athena_database   String,
    athena_table      String DEFAULT '',
    athena_bucket     String,
    aws_region        String DEFAULT 'us-east-1',
    status            String DEFAULT 'ACTIVE',
    last_validated    Nullable(DateTime),
    last_error        String DEFAULT '',
    created_at        DateTime DEFAULT now(),
    updated_at        DateTime DEFAULT now(),
    is_deleted        UInt8 DEFAULT 0
)
ENGINE = ReplacingMergeTree(updated_at)
ORDER BY account_id
EOF


echo " Creating aws_ecr_metadata table if not exists..."
curl -sS "http://${CLICKHOUSE_HOST}:${CLICKHOUSE_PORT}/?user=${CLICKHOUSE_USER}&password=${CLICKHOUSE_PASSWORD}" \
  --data-binary @- <<EOF
CREATE TABLE IF NOT EXISTS ${CLICKHOUSE_DATABASE}.aws_ecr_metadata
(
    account_id                 String,
    account_name               String,
    region                     String,
    repository_name            String,
    image_count                UInt32  DEFAULT 0,
    untagged_images            UInt32  DEFAULT 0,
    latest_push                Nullable(DateTime),
    critical_vulnerabilities   UInt32  DEFAULT 0,
    high_vulnerabilities       UInt32  DEFAULT 0,
    lifecycle_policy_enabled   UInt8   DEFAULT 0,
    ingested_at                DateTime DEFAULT now()
)
ENGINE = ReplacingMergeTree(ingested_at)
ORDER BY (account_id, region, repository_name)
EOF

echo " Creating aws_eks_metadata table if not exists..."
curl -sS "http://${CLICKHOUSE_HOST}:${CLICKHOUSE_PORT}/?user=${CLICKHOUSE_USER}&password=${CLICKHOUSE_PASSWORD}" \
  --data-binary @- <<EOF
CREATE TABLE IF NOT EXISTS ${CLICKHOUSE_DATABASE}.aws_eks_metadata
(
    account_id                 String,
    account_name               String,
    region                     String,
    cluster_name               String,
    kubernetes_version         String,
    cluster_status             String,
    nodegroup_count            UInt32  DEFAULT 0,
    fargate_profiles_count     UInt32  DEFAULT 0,
    total_nodes                UInt32  DEFAULT 0,
    has_spot_nodes             UInt8   DEFAULT 0,
    has_degraded_nodegroup     UInt8   DEFAULT 0,
    node_instance_types        Array(String) DEFAULT [],
    addon_count                UInt32  DEFAULT 0,
    has_degraded_addon         UInt8   DEFAULT 0,
    ingested_at                DateTime DEFAULT now()
)
ENGINE = ReplacingMergeTree(ingested_at)
ORDER BY (account_id, region, cluster_name)
EOF

echo " Creating app_settings table if not exists..."
curl -sS "http://${CLICKHOUSE_HOST}:${CLICKHOUSE_PORT}/?user=${CLICKHOUSE_USER}&password=${CLICKHOUSE_PASSWORD}" \
  --data-binary @- <<EOF
CREATE TABLE IF NOT EXISTS ${CLICKHOUSE_DATABASE}.app_settings
(
    setting_key   String,
    setting_value String,
    updated_at    DateTime DEFAULT now()
)
ENGINE = ReplacingMergeTree(updated_at)
ORDER BY setting_key
EOF


echo " Creating aws_hub table for Engine 2 (Cost Optimization Hub) if not exists..."
curl -sS "http://${CLICKHOUSE_HOST}:${CLICKHOUSE_PORT}/?user=${CLICKHOUSE_USER}&password=${CLICKHOUSE_PASSWORD}" \
  --data-binary @- <<EOF
CREATE TABLE IF NOT EXISTS ${CLICKHOUSE_DATABASE}.aws_hub
(
    recommendation_id          String,
    account_id                 String,
    account_name               String,
    region                     String,
    resource_id                String,
    resource_type              String,
    action_type                String,
    estimated_monthly_savings  Float64,
    estimated_monthly_cost     Float64,
    current_resource_summary   String,
    recommended_resource_summary String,
    currency_code              String DEFAULT 'USD',
    export_date                Date   DEFAULT today(),
    ingested_at                DateTime DEFAULT now()
)
ENGINE = ReplacingMergeTree(ingested_at)
ORDER BY (account_id, region, resource_id, action_type, export_date)
EOF


echo "Creating account_service_permissions table..."
curl -sS "http://${CLICKHOUSE_HOST}:${CLICKHOUSE_PORT}/?user=${CLICKHOUSE_USER}&password=${CLICKHOUSE_PASSWORD}" \
  --data-binary @- <<EOF
CREATE TABLE IF NOT EXISTS ${CLICKHOUSE_DATABASE}.account_service_permissions
(
    account_id  String,
    service     String,
    enabled     UInt8 DEFAULT 1,
    updated_at  DateTime DEFAULT now()
)
ENGINE = ReplacingMergeTree(updated_at)
ORDER BY (account_id, service)
EOF

echo "Creating aws_ec2_metadata table..."
curl -sS "http://${CLICKHOUSE_HOST}:${CLICKHOUSE_PORT}/?user=${CLICKHOUSE_USER}&password=${CLICKHOUSE_PASSWORD}" \
  --data-binary @- <<EOF
CREATE TABLE IF NOT EXISTS ${CLICKHOUSE_DATABASE}.aws_ec2_metadata
(
    account_id          String,
    account_name        String,
    region              String,
    availability_zone   String,
    instance_id         String,
    instance_state      String,
    instance_lifecycle  String,
    platform            String,
    architecture        String,
    launch_time         Nullable(DateTime),
    tenancy             String,
    ebs_optimized       UInt8  DEFAULT 0,
    detailed_monitoring UInt8  DEFAULT 0,
    has_public_ip       UInt8  DEFAULT 0,
    attached_ebs_count  UInt32 DEFAULT 0,
    root_volume_type    String,
    root_volume_size_gb UInt32 DEFAULT 0,
    tags                Map(String, String) DEFAULT map(),
    ingested_at         DateTime DEFAULT now()
)
ENGINE = ReplacingMergeTree(ingested_at)
ORDER BY (account_id, region, instance_id)
SETTINGS index_granularity = 8192
EOF

echo "ClickHouse initialization complete."



echo " Inserting default alert thresholds..."
curl -sS "http://${CLICKHOUSE_HOST}:${CLICKHOUSE_PORT}/?user=${CLICKHOUSE_USER}&password=${CLICKHOUSE_PASSWORD}" \
  --data-binary @- <<EOF
INSERT INTO ${CLICKHOUSE_DATABASE}.app_settings (setting_key, setting_value)
SELECT key, val
FROM (
    SELECT 'ecr_cost_warning' AS key, '20' AS val
    UNION ALL SELECT 'ecr_cost_error', '50'
    UNION ALL SELECT 'ecr_storage_warning', '100'
    UNION ALL SELECT 'ecr_storage_error', '300'
    UNION ALL SELECT 'ecr_transfer_warning', '50'
    UNION ALL SELECT 'ecr_transfer_error', '150'
    UNION ALL SELECT 'eks_cost_warning', '50'
    UNION ALL SELECT 'eks_cost_error', '200'
) AS defaults
WHERE key NOT IN (SELECT setting_key FROM ${CLICKHOUSE_DATABASE}.app_settings FINAL)
EOF


echo "ClickHouse initialization complete!"

echo "Creating alert_rules table..."
curl -sS "http://${CLICKHOUSE_HOST}:${CLICKHOUSE_PORT}/?user=${CLICKHOUSE_USER}&password=${CLICKHOUSE_PASSWORD}" \
  --data-binary @- <<EOF
CREATE TABLE IF NOT EXISTS ${CLICKHOUSE_DATABASE}.alert_rules
(
    rule_id String, account_id String, service String,
    sensitivity Float32 DEFAULT 2.0, min_impact Float64 DEFAULT 10.0,
    enabled UInt8 DEFAULT 1, created_at DateTime DEFAULT now(), updated_at DateTime DEFAULT now()
)
ENGINE = ReplacingMergeTree(updated_at)
ORDER BY (account_id, service)
EOF

echo "Creating alert_events table..."
curl -sS "http://${CLICKHOUSE_HOST}:${CLICKHOUSE_PORT}/?user=${CLICKHOUSE_USER}&password=${CLICKHOUSE_PASSWORD}" \
  --data-binary @- <<EOF
CREATE TABLE IF NOT EXISTS ${CLICKHOUSE_DATABASE}.alert_events
(
    alert_id String, account_id String, account_name String, service String,
    severity String, cost_today Float64, mean_cost Float64, std_dev Float64, 
    upper_threshold Float64, z_score Float64, pct_above_mean Float64,
    status String DEFAULT 'OPEN', fired_at DateTime DEFAULT now(),
    resolved_at Nullable(DateTime), updated_at DateTime DEFAULT now()
)
ENGINE = ReplacingMergeTree(updated_at)
ORDER BY (account_id, service, toDate(fired_at))
EOF

echo "Creating ec2_criticality_view..."
curl -sS "http://${CLICKHOUSE_HOST}:${CLICKHOUSE_PORT}/?user=${CLICKHOUSE_USER}&password=${CLICKHOUSE_PASSWORD}" \
  --data-binary @- <<EOF
CREATE OR REPLACE VIEW ${CLICKHOUSE_DATABASE}.ec2_criticality_view AS
WITH
    tags_norm AS (
        SELECT
            instance_id,
            account_id,
            launch_time,
            dateDiff('hour', launch_time, now())          AS age_hours,
            transform(
                lower(tags['Environment']),
                [
                    'prod', 'prd', 'production', 'live', 'main',
                    'dev', 'development', 'sandbox', 'test', 'qa', 'uat',
                    'staging', 'stage'
                ],
                [
                    'PROD', 'PROD', 'PROD', 'PROD', 'PROD',
                    'DEV',  'DEV',  'DEV',  'DEV',  'DEV', 'DEV',
                    'STAGING', 'STAGING'
                ],
                'UNKNOWN'
            )                                              AS env_norm
        FROM ${CLICKHOUSE_DATABASE}.aws_ec2_metadata FINAL
    ),

    usage_stats AS (
        SELECT
            CASE
                WHEN resource_id LIKE 'arn:aws:ec2:%'
                    THEN splitByChar('/', resource_id)[-1]
                ELSE resource_id
            END                                                                    AS instance_id,

            countIf(toDate(usage_start_ts), usage_qty > 0)                        AS active_days,
            avgIf(usage_qty, toDayOfWeek(toDate(usage_start_ts)) BETWEEN 1 AND 5) AS avg_weekday_hours,
            avgIf(usage_qty, toDayOfWeek(toDate(usage_start_ts)) IN (6, 7))       AS avg_weekend_hours

        FROM ${CLICKHOUSE_DATABASE}.service_costs FINAL
        WHERE product_code   = 'AmazonEC2'
          AND usage_type     LIKE '%BoxUsage%'
          AND usage_start_ts >= now() - INTERVAL 30 DAY
        GROUP BY instance_id
    ),

    joined AS (
        SELECT
            t.instance_id,
            t.account_id,
            t.launch_time,
            t.age_hours,
            t.env_norm,
            COALESCE(u.active_days, 0)        AS active_days,
            COALESCE(u.avg_weekday_hours, 0)  AS avg_weekday_hours,
            COALESCE(u.avg_weekend_hours, 0)  AS avg_weekend_hours,
            (u.instance_id IS NULL)           AS no_cur_data
        FROM tags_norm t
        LEFT JOIN usage_stats u ON t.instance_id = u.instance_id
    )

SELECT
    instance_id,
    account_id,
    launch_time,
    age_hours,
    env_norm,
    active_days,
    round(avg_weekday_hours, 1) AS avg_weekday_hours,
    round(avg_weekend_hours, 1) AS avg_weekend_hours,
    no_cur_data,

    CASE
        WHEN no_cur_data = true OR age_hours < 48 THEN 'Evaluating'
        WHEN env_norm = 'PROD' AND avg_weekend_hours >= 20 THEN 'Mission-Critical (24x7)'
        WHEN env_norm = 'PROD' AND avg_weekend_hours < 2 THEN 'Reliability Risk'
        WHEN env_norm = 'PROD' THEN 'Mission-Critical'
        WHEN avg_weekday_hours >= 22 AND avg_weekend_hours >= 20 THEN 'Continuous (24x7)'
        WHEN avg_weekday_hours >= 10 AND avg_weekend_hours < 2 THEN 'Business Hours (24x5)'
        WHEN active_days = 0 THEN 'Idle / Zombie'
        WHEN active_days < 10 OR avg_weekday_hours < 5 THEN 'Low Usage'
        ELSE 'Irregular'
    END AS criticality,

    CASE
        WHEN env_norm = 'PROD' AND avg_weekend_hours < 2 THEN 'Prod offline on weekends — reliability risk. Verify backup and failover.'
        WHEN env_norm = 'DEV' AND avg_weekend_hours >= 20 THEN 'Dev instance running 24x7 — add automated start/stop schedule to save cost.'
        WHEN env_norm = 'UNKNOWN' AND avg_weekday_hours >= 20 THEN 'Untagged continuous instance — tag Environment for governance and cost allocation.'
        WHEN active_days = 0 THEN 'Zero usage in 30 days — immediate termination candidate.'
        WHEN no_cur_data = true THEN 'Waiting for CUR data — check if instance is reporting usage.'
        ELSE NULL
    END AS insight
FROM joined
ORDER BY
    CASE criticality
        WHEN 'Mission-Critical (24x7)' THEN 1
        WHEN 'Reliability Risk'        THEN 2
        WHEN 'Mission-Critical'        THEN 3
        WHEN 'Continuous (24x7)'       THEN 4
        WHEN 'Business Hours (24x5)'   THEN 5
        WHEN 'Irregular'               THEN 6
        WHEN 'Low Usage'               THEN 7
        WHEN 'Idle / Zombie'           THEN 8
        WHEN 'Evaluating'              THEN 9
        ELSE 10
    END;
EOF

touch "${STATUS_FILE}"
