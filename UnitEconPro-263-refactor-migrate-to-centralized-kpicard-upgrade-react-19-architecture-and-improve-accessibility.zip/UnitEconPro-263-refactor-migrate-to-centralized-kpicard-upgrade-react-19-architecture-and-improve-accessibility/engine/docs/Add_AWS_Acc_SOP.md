# AWS Account Onboarding SOP
## Complete Guide to Add a New AWS Account to UnitEconPro

**Version:** 1.1
**Last Updated:** April 2026

---

## ✅ Prerequisites Before You Start

Before onboarding any account, collect the following. You will not be able to proceed without these.

### Path A — Account is in the SAME AWS Organization (Quickest)
> Use this if the new account is already a member of the same AWS Org that has CUR enabled.

| # | What you need | Where to find it |
|---|---|---|
| 1 | **12-digit AWS Account ID** | AWS Console → top-right account menu |
| 2 | **Account Name / Alias** | AWS Console → IAM → Account Alias |
| 3 | UnitEconPro server access | SSH / kubectl access to the deployment host |

That's it! CUR data is shared automatically across org accounts.

---

### Path B — Account is OUTSIDE your AWS Organization (Full Setup)
> Use this if the account is standalone or in a different organization.

#### 1. AWS IAM Credentials (MANDATORY)
The account owner must provide a programmatic IAM user or role with at minimum these permissions:

```json
{
  "Effect": "Allow",
  "Action": [
    "athena:StartQueryExecution",
    "athena:GetQueryExecution",
    "athena:GetQueryResults",
    "athena:ListDatabases",
    "athena:ListTableMetadata",
    "glue:GetDatabase",
    "glue:GetTable",
    "glue:GetPartitions",
    "s3:GetObject",
    "s3:ListBucket",
    "s3:PutObject",
    "s3:GetBucketLocation",
    "sts:GetCallerIdentity"
  ],
  "Resource": "*"
}
```

**Collect from the account owner:**
- [ ] `AWS_ACCESS_KEY_ID` (starts with `AKIA` or `ASIA`)
- [ ] `AWS_SECRET_ACCESS_KEY`
- [ ] `AWS_REGION` (e.g. `ap-south-1`, `us-east-1`)

> **Tip:** If you only have the access keys and don't know the Athena details, run the auto-discovery script below to find everything automatically.

#### 2. AWS Cost & Usage Report (CUR) — Must be pre-enabled
CUR takes **8–24 hours to generate the first file** after being enabled, so it must be done in advance.

- [ ] CUR enabled in AWS Billing Console with:
  - Time granularity: **Hourly**
  - File format: **Parquet** with **GZIP** compression
  - Integration: **Amazon Athena** enabled
  - Resource IDs: **Included**
- [ ] At least **1 full day** of CUR data has been generated

#### 3. Athena Configuration (auto-discoverable from keys)

If the account owner doesn't know their Athena config, run this to discover it:

```bash
cd /home/harshitverma/UnitEconPro/engine
set -a && source ../.env && set +a

python3 - << 'EOF'
import boto3
ACCESS_KEY = "PASTE_KEY"
SECRET_KEY = "PASTE_SECRET"
REGION     = "ap-south-1"   # change if needed
session = boto3.Session(aws_access_key_id=ACCESS_KEY, aws_secret_access_key=SECRET_KEY, region_name=REGION)
sts = session.client("sts")
print(f"AWS Account ID : {sts.get_caller_identity()['Account']}")
athena = session.client("athena")
print("\nAthena Databases:")
for db in athena.list_databases(CatalogName="AwsDataCatalog")["DatabaseList"]:
    print(f"  - {db['Name']}")
print("\nWorkgroup Output Buckets:")
for wg in athena.list_work_groups()["WorkGroups"]:
    d = athena.get_work_group(WorkGroup=wg["Name"])
    out = d["WorkGroup"].get("Configuration",{}).get("ResultConfiguration",{}).get("OutputLocation","(not set)")
    print(f"  - {wg['Name']}: {out}")
EOF
```

This will print all the values needed for the onboarding form.

- [ ] `athena_database` (e.g. `athenacurcfn_cur_report007`)
- [ ] `athena_table` (e.g. `cur_report007`)
- [ ] `athena_bucket` (must start with `s3://`, e.g. `s3://cur-queries001/`)

#### 4. Cost Allocation Tags (Optional but recommended)
For full tag-based cost breakdowns, activate these tags under **AWS Billing → Cost Allocation Tags** and wait 24 hours:
- `user:team`, `user:owner`, `user:environment`, `user:application`, `user:project`, `user:name`

---

## 🚀 Quick Start: Which Path Are You On?

### ✅ Path A: Account in SAME AWS Organization (5 minutes)
**Use this if:** Your new account is part of the same AWS Organization that already has CUR enabled.

**Steps:**
1. Add account to ClickHouse: `INSERT INTO cost.account_map VALUES ('new-account-id', 'name', 'env', 'team');`
2. Run ingestion: `python3 app/app.py --mode refresh_days --days 7 --service all --cloud aws`
3. Done! ✅

**Why so simple?** AWS Organization's CUR automatically includes ALL member accounts. No AWS setup needed!

---

### ⚠️ Path B: Account OUTSIDE AWS Organization (60 minutes)
**Use this if:** Your new account is completely separate (different organization or no organization).

**Steps:** Follow the full SOP below (requires CUR setup, Athena, IAM, etc.)

---

## 📋 Table of Contents

1. [Path A: Organization Account (Quick)](#path-a-organization-account-quick-setup)
2. [Path B: Separate Account (Full Setup)](#path-b-separate-account-full-setup)
   - [Prerequisites](#prerequisites)
   - [Phase 1: AWS Setup (30 min)](#phase-1-aws-setup)
   - [Phase 2: UnitEconPro Configuration (10 min)](#phase-2-uniteconpro-configuration)
   - [Phase 3: Data Ingestion (10 min)](#phase-3-data-ingestion)
   - [Phase 4: Validation (10 min)](#phase-4-validation)
3. [Troubleshooting](#troubleshooting)

---

## Path A: Organization Account (Quick Setup)

**Estimated Time:** 5 minutes  
**Difficulty:** Easy

### When to Use This Path
- ✅ New account is in the SAME AWS Organization
- ✅ Organization already has CUR enabled
- ✅ You're using the same management/payer account

### Step 1: Add Account to ClickHouse

```bash
# Connect to ClickHouse
docker exec -it clickhouse clickhouse-client --user dba --password secretPassword
```

```sql
-- Add your new account
INSERT INTO cost.account_map (account_id, account_name, environment, team)
VALUES ('999888777666', 'new-prod-account', 'production', 'platform-team');

-- Verify
SELECT * FROM cost.account_map;
exit;
```

### Step 2: Run Ingestion

```bash
cd /home/harshitverma/UnitEconPro
python3 app/app.py --mode refresh_days --days 7 --service all --cloud aws
```

### Step 3: Verify Data

```bash
docker exec -it clickhouse clickhouse-client --user dba --password secretPassword
```

```sql
SELECT 
  account_id,
  account_name,
  COUNT(*) as records,
  ROUND(SUM(cost_unblended), 2) as total_cost
FROM cost.service_costs
WHERE account_id = '999888777666'
  AND usage_start_ts >= now() - INTERVAL 7 DAY
GROUP BY account_id, account_name;
```

### ✅ Done!

Your new organization account is now in UnitEconPro. Check Grafana dashboards.

---

## Path B: Separate Account (Full Setup)

**Estimated Time:** 45-60 minutes  
**Difficulty:** Intermediate

### When to Use This Path
- ⚠️ Account is NOT in your AWS Organization
- ⚠️ Account is in a different organization
- ⚠️ Account has no organization (standalone)

### Prerequisites

### Information You Need

- [ ] **AWS Account ID** (12-digit number)
- [ ] **AWS Account Name/Alias** (e.g., "production-app")
- [ ] **Team/Owner** (e.g., "platform-team")
- [ ] **Environment** (e.g., "production", "development")
- [ ] **AWS Console Access** (Admin or Billing permissions)
- [ ] **UnitEconPro Server Access**

---

## Phase 1: AWS Setup

### Step 1.1: Enable AWS Cost and Usage Report (CUR)

**Time:** 15 minutes

1. **Login to AWS Console**
   - Go to: https://console.aws.amazon.com/billing/

2. **Navigate to Cost & Usage Reports**
   ```
   AWS Console → Billing → Cost & Usage Reports → Create report
   ```

3. **Configure CUR Settings**
   ```
   Report name: cur-report-uniteconpro
   Additional report details: ✅ Include resource IDs
   Data refresh settings: ✅ Automatically refresh
   Time granularity: Hourly
   Report versioning: Overwrite existing report
   Enable report data integration: ✅ Amazon Athena
   Compression type: GZIP
   Format: Parquet
   ```

4. **Configure S3 Bucket**
   ```
   S3 bucket: s3://your-cur-bucket-name/
   Report path prefix: cur-reports/
   Region: us-east-1
   ```

5. **Wait 8-24 hours** for first CUR file

---

### Step 1.2: Set Up Athena Database

**Time:** 10 minutes

1. **Navigate to Athena Console**

2. **Create Database**
   ```sql
   CREATE DATABASE IF NOT EXISTS athenacurcfn_cur_report007;
   ```

3. **Verify Table Exists**
   ```sql
   SHOW TABLES IN athenacurcfn_cur_report007;
   ```

4. **Test Query**
   ```sql
   SELECT 
     line_item_usage_account_id,
     COUNT(*) as records,
     SUM(line_item_unblended_cost) as total_cost
   FROM athenacurcfn_cur_report007.cur_report007
   WHERE line_item_usage_start_date >= CURRENT_DATE - INTERVAL '7' DAY
   GROUP BY line_item_usage_account_id;
   ```

---

### Step 1.3: Configure IAM Permissions

**Time:** 5 minutes

1. **Create IAM User**
   ```
   AWS Console → IAM → Users → Create user
   Name: uniteconpro-athena-user
   Access type: ✅ Programmatic access
   ```

2. **Attach Policy**
   ```json
   {
     "Version": "2012-10-17",
     "Statement": [
       {
         "Effect": "Allow",
         "Action": [
           "athena:*",
           "glue:GetDatabase",
           "glue:GetTable",
           "glue:GetPartitions"
         ],
         "Resource": "*"
       },
       {
         "Effect": "Allow",
         "Action": [
           "s3:GetObject",
           "s3:ListBucket",
           "s3:PutObject"
         ],
         "Resource": [
           "arn:aws:s3:::your-cur-bucket-name/*",
           "arn:aws:s3:::your-athena-output-bucket/*"
         ]
       }
     ]
   }
   ```

3. **Save Credentials**
   ```
   Access Key ID: AKIA...
   Secret Access Key: wJalrXUtnFEMI/K7MDENG...
   ```

---

### Step 1.4: Activate Cost Allocation Tags

**Time:** 2 minutes

1. **Navigate to Cost Allocation Tags**
   ```
   AWS Console → Billing → Cost Allocation Tags
   ```

2. **Activate Tags**
   ```
   ✅ user:team
   ✅ user:owner
   ✅ user:environment
   ✅ user:application
   ✅ user:project
   ✅ user:name
   ```

3. **Wait 24 hours** for tags to appear in CUR

---

## Phase 2: UnitEconPro Configuration

### Step 2.1: Update Environment Variables

1. **Edit `.env` file**
   ```bash
   cd /home/harshitverma/UnitEconPro
   nano .env
   ```

2. **Add AWS Credentials**
   ```bash
   AWS_ACCESS_KEY_ID=AKIA...
   AWS_SECRET_ACCESS_KEY=wJalrXUtnFEMI/K7MDENG...
   AWS_REGION=us-east-1
   
   ATHENA_DATABASE=athenacurcfn_cur_report007
   ATHENA_TABLE=cur_report007
   ATHENA_OUTPUT_LOCATION=s3://your-athena-output-bucket/
   ```

---

### Step 2.2: Add Account to ClickHouse

1. **Connect to ClickHouse**
   ```bash
   docker exec -it clickhouse clickhouse-client --user dba --password secretPassword
   ```

2. **Add Account**
   ```sql
   INSERT INTO cost.account_map (account_id, account_name, environment, team)
   VALUES ('123456789012', 'production-app', 'production', 'platform-team');
   ```

3. **Verify**
   ```sql
   SELECT * FROM cost.account_map;
   exit;
   ```

---

## Phase 3: Data Ingestion

### Step 3.1: Test Ingestion

```bash
cd /home/harshitverma/UnitEconPro
python3 app/app.py --mode refresh_days --days 7 --service ec2 --cloud aws
```

### Step 3.2: Full Ingestion

```bash
python3 app/app.py --mode refresh_days --days 7 --service all --cloud aws
```

---

## Phase 4: Validation

### Step 4.1: Verify Data in ClickHouse

```bash
docker exec -it clickhouse clickhouse-client --user dba --password secretPassword
```

```sql
SELECT 
  account_id,
  account_name,
  toDate(usage_start_ts) as date,
  COUNT(*) as records,
  ROUND(SUM(cost_unblended), 2) as total_cost
FROM cost.service_costs
WHERE account_id = 123456789012
  AND usage_start_ts >= now() - INTERVAL 7 DAY
GROUP BY account_id, account_name, date
ORDER BY date;
```

### Step 4.2: Verify in Grafana

1. Open: http://localhost:3000
2. Go to "AWS Cost Summary Dashboard"
3. Select your account from dropdown
4. Verify data is visible

### Step 4.3: Run Validation

```bash
python3 scripts/validate_data.py
```

---

## ✅ Onboarding Complete!

### Checklist

- [ ] Data visible in ClickHouse
- [ ] Account in Grafana dashboards
- [ ] Tags captured (if resources tagged)
- [ ] Validation script passes

---

## Troubleshooting

### No Data in Athena

**Fix:**
- Wait 24 hours for CUR generation
- Check S3 bucket has data
- Verify Athena table exists

### Permission Denied

**Fix:**
- Verify AWS credentials in `.env`
- Check IAM policy permissions
- Test with: `aws athena start-query-execution`

### No Data in ClickHouse

**Fix:**
```sql
-- Check ingestion logs
SELECT * FROM cost.ingestion_log 
WHERE status = 'failed' 
ORDER BY started_at DESC;
```

### Tags Not Showing

**Fix:**
- Activate tags in AWS Billing Console
- Wait 24 hours
- Tag your resources
- Re-ingest data

---

## Quick Reference

### Common Commands

```bash
# Test ingestion
python3 app/app.py --mode refresh_days --days 7 --service ec2 --cloud aws

# Full ingestion
python3 app/app.py --mode refresh_days --days 7 --service all --cloud aws

# Validate data
python3 scripts/validate_data.py

# Check ClickHouse
docker exec -it clickhouse clickhouse-client --user dba --password secretPassword
```

### Useful Queries

```sql
-- Check all accounts
SELECT DISTINCT account_id, account_name FROM cost.service_costs;

-- Check cost by account
SELECT account_name, ROUND(SUM(cost_unblended), 2) as cost
FROM cost.service_costs
WHERE usage_start_ts >= now() - INTERVAL 30 DAY
GROUP BY account_name;
```

---

**End of SOP**
