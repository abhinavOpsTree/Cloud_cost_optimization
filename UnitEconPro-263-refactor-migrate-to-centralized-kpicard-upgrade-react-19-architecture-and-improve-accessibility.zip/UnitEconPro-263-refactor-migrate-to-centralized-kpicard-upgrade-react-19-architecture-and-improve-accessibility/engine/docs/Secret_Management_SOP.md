## Purpose

This SOP covers creating, updating, and rotating secrets used by UnitEconPro deployments, including GitHub tokens, AWS credentials, Azure AD secrets, and ClickHouse passwords.

---

## Secret Inventory

| Secret Name | Type | Used By | Rotation Frequency | Expiry Warning |
|-------------|------|---------|-------------------|----------------|
| `grafana-azure-ad-creds` | Azure AD OAuth | Grafana SSO | 90 days | 7 days before |
| `aws-credentials` | AWS IAM | Data Ingestion | 90 days | 7 days before |
| `clickhouse-credentials` | Database | Grafana, CronJobs | 180 days | 14 days before |
| `docker-secret` | Registry Auth | Image Pull | Never (unless compromised) | N/A |
| `github-token` | GitHub PAT | Git Sync (future) | 90 days | 7 days before |

---

## Prerequisites

- [ ] Access to Kubernetes cluster
- [ ] kubectl configured with admin permissions
- [ ] Access to secret source systems (Azure Portal, AWS Console, etc.)
- [ ] Client namespace name

---

## Part 1: Creating New Secrets

### 1.1 Azure AD Credentials

**When to use:** New client onboarding, Azure app registration renewal

**Step 1: Get credentials from Azure Portal**
1. Go to Azure Portal → Azure Active Directory → App Registrations
2. Find or create app: `UnitEconPro-<CLIENT_NAME>`
3. Copy:
   - Application (client) ID
   - Directory (tenant) ID
4. Go to **Certificates & secrets** → New client secret
5. Copy the secret value (only shown once!)

**Step 2: Create Kubernetes secret**
```bash
kubectl create secret generic grafana-azure-ad-creds \
  --from-literal=client-id='<AZURE_CLIENT_ID>' \
  --from-literal=client-secret='<AZURE_CLIENT_SECRET>' \
  --from-literal=tenant-id='<AZURE_TENANT_ID>' \
  --namespace <NAMESPACE> \
  --dry-run=client -o yaml | kubectl apply -f -
```

**Verify:**
```bash
kubectl get secret grafana-azure-ad-creds -n <NAMESPACE>
```

---

### 1.2 AWS Credentials

**When to use:** New client onboarding, IAM user key rotation

**Step 1: Create IAM user (if new client)**
```bash
# In AWS Console or CLI
aws iam create-user --user-name uniteconpro-<CLIENT_NAME>

# Attach policy
aws iam attach-user-policy \
  --user-name uniteconpro-<CLIENT_NAME> \
  --policy-arn arn:aws:iam::aws:policy/AmazonAthenaFullAccess
```

**Step 2: Generate access keys**
```bash
aws iam create-access-key --user-name uniteconpro-<CLIENT_NAME>
```

**Output:**
```json
{
  "AccessKeyId": "AKIA...",
  "SecretAccessKey": "wJalrXUtn..."
}
```

**Step 3: Create Kubernetes secret**
```bash
kubectl create secret generic aws-credentials \
  --from-literal=access-key='<AWS_ACCESS_KEY_ID>' \
  --from-literal=secret-key='<AWS_SECRET_ACCESS_KEY>' \
  --namespace <NAMESPACE> \
  --dry-run=client -o yaml | kubectl apply -f -
```

---

### 1.3 ClickHouse Credentials

**When to use:** New client onboarding, password rotation

**Step 1: Create ClickHouse user**
```bash
# Connect to ClickHouse
docker exec -it clickhouse clickhouse-client --user dba --password secretPassword

# Create user
CREATE USER <CLIENT_NAME> IDENTIFIED BY '<STRONG_PASSWORD>';

# Grant permissions
GRANT SELECT, INSERT ON cost.* TO <CLIENT_NAME>;
```

**Step 2: Create Kubernetes secret**
```bash
kubectl create secret generic clickhouse-credentials \
  --from-literal=password='<CLICKHOUSE_PASSWORD>' \
  --namespace <NAMESPACE> \
  --dry-run=client -o yaml | kubectl apply -f -
```

---

### 1.4 Docker Registry Secret

**When to use:** New client onboarding, registry password change

```bash
kubectl create secret docker-registry docker-secret \
  --docker-server=registry.ldc.opstree.dev \
  --docker-username=<REGISTRY_USERNAME> \
  --docker-password=<REGISTRY_PASSWORD> \
  --docker-email=<EMAIL> \
  --namespace <NAMESPACE> \
  --dry-run=client -o yaml | kubectl apply -f -
```

---

### 1.5 GitHub Personal Access Token (For Git Sync)

**When to use:** New client onboarding, token expiry

**Step 1: Generate Token in GitHub**
1. Log in to the Client's GitHub account (or a Service Account)
2. Go to **Settings** → **Developer settings** → **Personal access tokens** → **Tokens (classic)**
3. Click **Generate new token**
4. Configure:
   - **Note:** `UnitEconPro-GitSync-<CLIENT_NAME>`
   - **Expiration:** 90 Days
   - **Scopes:** Select `repo` (Full control of private repositories)
5. Click **Generate token** and copy it

**Step 2: Create Kubernetes secret**

**Note:** The secret name MUST match the values.yaml reference.

```bash
kubectl create secret generic grafana-git-creds \
  --from-literal=pat='<GITHUB_TOKEN_VALUE>' \
  --namespace <NAMESPACE> \
  --dry-run=client -o yaml | kubectl apply -f -
```

**Verify:**
```bash
kubectl get secret grafana-git-creds -n <NAMESPACE>
```

---

## Part 2: Rotating Existing Secrets

### 2.1 Check Secret Expiry

**List all secrets in namespace:**
```bash
kubectl get secrets -n <NAMESPACE>
```

**Check secret age:**
```bash
kubectl get secret <SECRET_NAME> -n <NAMESPACE> -o jsonpath='{.metadata.creationTimestamp}'
```

**Decode secret (for verification only):**
```bash
kubectl get secret <SECRET_NAME> -n <NAMESPACE> -o jsonpath='{.data.client-id}' | base64 -d
```

---

### 2.2 Rotate Azure AD Secret

**Step 1: Generate new secret in Azure Portal**
1. Azure Portal → App Registrations → Your App
2. Certificates & secrets → New client secret
3. Copy new secret value

**Step 2: Update Kubernetes secret**
```bash
kubectl create secret generic grafana-azure-ad-creds \
  --from-literal=client-id='<SAME_CLIENT_ID>' \
  --from-literal=client-secret='<NEW_CLIENT_SECRET>' \
  --from-literal=tenant-id='<SAME_TENANT_ID>' \
  --namespace <NAMESPACE> \
  --dry-run=client -o yaml | kubectl apply -f -
```

**Step 3: Restart Grafana pod**
```bash
kubectl rollout restart deployment/<GRAFANA_DEPLOYMENT> -n <NAMESPACE>
```

**Step 4: Verify login**
- Access Grafana
- Test Azure AD login
- Confirm successful authentication

**Step 5: Delete old Azure secret**
- Azure Portal → App Registrations → Certificates & secrets
- Delete the old secret

---

### 2.3 Rotate AWS Credentials

**Step 1: Create new access key**
```bash
aws iam create-access-key --user-name uniteconpro-<CLIENT_NAME>
```

**Step 2: Update Kubernetes secret**
```bash
kubectl create secret generic aws-credentials \
  --from-literal=access-key='<NEW_ACCESS_KEY>' \
  --from-literal=secret-key='<NEW_SECRET_KEY>' \
  --namespace <NAMESPACE> \
  --dry-run=client -o yaml | kubectl apply -f -
```

**Step 3: Restart CronJobs**
```bash
# Delete running jobs
kubectl delete jobs -l app=uniteconpro -n <NAMESPACE>

# Trigger manual job to test
kubectl create job --from=cronjob/<CRONJOB_NAME> test-new-creds -n <NAMESPACE>

# Check logs
kubectl logs job/test-new-creds -n <NAMESPACE>
```

**Step 4: Deactivate old access key**
```bash
# List keys
aws iam list-access-keys --user-name uniteconpro-<CLIENT_NAME>

# Deactivate old key
aws iam update-access-key \
  --user-name uniteconpro-<CLIENT_NAME> \
  --access-key-id <OLD_KEY_ID> \
  --status Inactive
```

**Step 5: Delete old key (after 7 days)**
```bash
aws iam delete-access-key \
  --user-name uniteconpro-<CLIENT_NAME> \
  --access-key-id <OLD_KEY_ID>
```

---

### 2.4 Rotate ClickHouse Password

**Step 1: Change password in ClickHouse**
```bash
docker exec -it clickhouse clickhouse-client --user dba --password secretPassword

ALTER USER <CLIENT_NAME> IDENTIFIED BY '<NEW_PASSWORD>';
```

**Step 2: Update Kubernetes secret**
```bash
kubectl create secret generic clickhouse-credentials \
  --from-literal=password='<NEW_PASSWORD>' \
  --namespace <NAMESPACE> \
  --dry-run=client -o yaml | kubectl apply -f -
```

**Step 3: Restart all pods using the secret**
```bash
kubectl rollout restart deployment/<GRAFANA_DEPLOYMENT> -n <NAMESPACE>
kubectl delete jobs -l app=uniteconpro -n <NAMESPACE>
```

**Step 4: Verify connection**
```bash
# Test from Grafana pod
kubectl exec -it <GRAFANA_POD> -n <NAMESPACE> -- \
  curl "http://<CLICKHOUSE_HOST>:8123/?user=<CLIENT_NAME>&password=<NEW_PASSWORD>" \
  --data "SELECT 1"
```

---

### 2.5 Rotate GitHub Token

**Step 1: Generate new Token**

Follow the steps in Section 1.5 to generate a fresh token.

**Step 2: Update Kubernetes Secret**
```bash
kubectl create secret generic grafana-git-creds \
  --from-literal=pat='<NEW_TOKEN_VALUE>' \
  --namespace <NAMESPACE> \
  --dry-run=client -o yaml | kubectl apply -f -
```

**Step 3: Restart Grafana**

Grafana Git Sync requires a restart to pick up the new token environment variable.

```bash
kubectl rollout restart deployment/<GRAFANA_DEPLOYMENT> -n <NAMESPACE>
```

**Step 4: Verify**
1. Log in to Grafana
2. Go to **Administration** → **Provisioning** → **Git Sync**
3. Check the "Status" indicator - should be Green/Connected
4. Verify dashboards are syncing

**Step 5: Delete old GitHub token**
- GitHub → Settings → Developer settings → Personal access tokens
- Delete the old token

---

## Part 3: Emergency Secret Revocation

**When to use:** Secret compromised, security incident

### 3.1 Immediate Actions

**Step 1: Revoke at source**
- **Azure AD:** Delete client secret immediately
- **AWS:** Deactivate access key immediately
- **ClickHouse:** Change password immediately

**Step 2: Delete Kubernetes secret**
```bash
kubectl delete secret <SECRET_NAME> -n <NAMESPACE>
```

**Step 3: Stop affected workloads**
```bash
kubectl scale deployment/<DEPLOYMENT> --replicas=0 -n <NAMESPACE>
kubectl delete jobs -l app=uniteconpro -n <NAMESPACE>
```

**Step 4: Create new secret**
Follow Part 1 procedures to create fresh credentials.

**Step 5: Resume workloads**
```bash
kubectl scale deployment/<DEPLOYMENT> --replicas=1 -n <NAMESPACE>
```

---

## Part 4: Secret Backup & Recovery

### 4.1 Backup Secrets (Encrypted)

**Export secrets to encrypted file:**
```bash
# Export all secrets in namespace
kubectl get secrets -n <NAMESPACE> -o yaml > secrets-backup.yaml

# Encrypt with GPG
gpg --symmetric --cipher-algo AES256 secrets-backup.yaml

# Store encrypted file securely
mv secrets-backup.yaml.gpg /secure/backup/location/
rm secrets-backup.yaml
```

### 4.2 Restore Secrets

**Decrypt and restore:**
```bash
# Decrypt
gpg --decrypt secrets-backup.yaml.gpg > secrets-backup.yaml

# Apply
kubectl apply -f secrets-backup.yaml

# Clean up
rm secrets-backup.yaml
```

---

## Part 5: Monitoring & Alerts

### 5.1 Secret Expiry Monitoring

**Check secret age script:**
```bash
#!/bin/bash
NAMESPACE=$1
THRESHOLD_DAYS=80

kubectl get secrets -n $NAMESPACE -o json | \
jq -r '.items[] | 
  select(.type != "kubernetes.io/service-account-token") |
  "\(.metadata.name) \(.metadata.creationTimestamp)"' | \
while read name timestamp; do
  age_days=$(( ($(date +%s) - $(date -d "$timestamp" +%s)) / 86400 ))
  if [ $age_days -gt $THRESHOLD_DAYS ]; then
    echo "⚠️  $name is $age_days days old - rotation needed!"
  fi
done
```

**Usage:**
```bash
./check-secret-age.sh uniteconpro-acme-corp
```

---

## Troubleshooting

### Issue: Pod fails after secret rotation

**Symptom:** Pods in CrashLoopBackOff after updating secret

**Cause:** Pod didn't pick up new secret

**Fix:**
```bash
kubectl rollout restart deployment/<DEPLOYMENT> -n <NAMESPACE>
```

### Issue: Secret not found

**Symptom:** `Error: secret "xxx" not found`

**Check:**
```bash
# List all secrets
kubectl get secrets -n <NAMESPACE>

# Check if secret exists in different namespace
kubectl get secrets --all-namespaces | grep <SECRET_NAME>
```

**Fix:** Create secret using Part 1 procedures

### Issue: Authentication fails after rotation

**Symptom:** Grafana login fails, CronJob errors

**Check:**
```bash
# Verify secret contents
kubectl get secret <SECRET_NAME> -n <NAMESPACE> -o yaml

# Check pod logs
kubectl logs <POD_NAME> -n <NAMESPACE>
```

**Fix:** Verify credentials at source (Azure Portal, AWS Console)

---

## Security Best Practices

1. ✅ **Never commit secrets to Git**
2. ✅ **Use `--dry-run=client -o yaml | kubectl apply`** for idempotent updates
3. ✅ **Rotate secrets every 90 days**
4. ✅ **Use strong passwords** (min 20 chars, mixed case, numbers, symbols)
5. ✅ **Encrypt secret backups** with GPG
6. ✅ **Limit secret access** with RBAC
7. ✅ **Audit secret access** regularly
8. ✅ **Delete old credentials** after rotation grace period

