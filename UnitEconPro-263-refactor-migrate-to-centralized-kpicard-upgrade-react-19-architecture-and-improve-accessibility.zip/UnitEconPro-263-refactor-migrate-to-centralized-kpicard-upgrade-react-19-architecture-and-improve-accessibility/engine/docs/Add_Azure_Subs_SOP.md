# Azure Subscription Onboarding SOP
## Complete Guide to Add an Azure Subscription to UnitEconPro

## ⚠️ Implementation Status

**Azure support is planned but not yet implemented.**

This document serves as a template for when Azure integration is added to UnitEconPro.

---

## 🚀 Quick Start (When Implemented)

### Path A: Subscription in SAME Azure Tenant (5 minutes)
**Use this if:** Your new subscription is part of the same Azure tenant with consolidated billing.

**Steps:**
1. Add subscription to ClickHouse: `INSERT INTO cost.account_map VALUES ('azure-sub-id', 'name', 'env', 'team');`
2. Run ingestion: `python3 app/app.py --mode refresh_days --days 7 --service all --cloud azure`
3. Done! ✅

---

### Path B: Separate Azure Subscription (60 minutes)
**Use this if:** Your subscription has separate cost export.

**Steps:** Follow the full SOP below.

---

## 📋 Table of Contents

1. [Prerequisites](#prerequisites)
2. [Phase 1: Azure Setup](#phase-1-azure-setup)
3. [Phase 2: UnitEconPro Configuration](#phase-2-uniteconpro-configuration)
4. [Phase 3: Data Ingestion](#phase-3-data-ingestion)
5. [Phase 4: Validation](#phase-4-validation)
6. [Troubleshooting](#troubleshooting)

---

## Prerequisites

### Information You Need

- [ ] **Azure Subscription ID** (GUID format)
- [ ] **Azure Subscription Name** (e.g., "production-subscription")
- [ ] **Tenant ID** (GUID format)
- [ ] **Team/Owner** (e.g., "platform-team")
- [ ] **Environment** (e.g., "production", "development")
- [ ] **Azure Portal Access** (Billing Reader + Storage Account Contributor)
- [ ] **UnitEconPro Server Access**

---

## Phase 1: Azure Setup

### Step 1.1: Enable Cost Export to Storage Account

**Time:** 15 minutes

1. **Login to Azure Portal**
   - Go to: https://portal.azure.com

2. **Navigate to Cost Management**
   ```
   Azure Portal → Cost Management + Billing → Cost Management → Exports
   ```

3. **Create Export**
   ```
   Export name: uniteconpro-cost-export
   Export type: Daily export of month-to-date costs
   Start date: Today
   Storage account: [create or select existing]
   Container: cost-exports
   Directory: uniteconpro/
   File format: CSV
   Compression: Gzip
   ```

4. **Configure Export Settings**
   ```
   ✅ Include resource-level data
   ✅ Include tags
   ✅ Overwrite existing data
   Frequency: Daily
   ```

5. **Wait 24 hours** for first export

---

### Step 1.2: Set Up Storage Account Access

**Time:** 10 minutes

1. **Navigate to Storage Account**
   ```
   Azure Portal → Storage Accounts → [your-storage-account]
   ```

2. **Verify Container Exists**
   ```
   Storage Account → Containers → cost-exports
   ```

3. **Test Access**
   ```bash
   # Using Azure CLI
   az storage blob list \
     --account-name yourstorageaccount \
     --container-name cost-exports \
     --auth-mode login
   ```

---

### Step 1.3: Configure Service Principal

**Time:** 10 minutes

1. **Create Service Principal**
   ```bash
   az ad sp create-for-rbac \
     --name uniteconpro-cost-reader \
     --role "Cost Management Reader" \
     --scopes /subscriptions/{subscription-id}
   ```

2. **Grant Storage Access**
   ```bash
   az role assignment create \
     --assignee {service-principal-id} \
     --role "Storage Blob Data Reader" \
     --scope /subscriptions/{subscription-id}/resourceGroups/{rg}/providers/Microsoft.Storage/storageAccounts/{storage-account}
   ```

3. **Save Credentials**
   ```json
   {
     "appId": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx",
     "displayName": "uniteconpro-cost-reader",
     "password": "xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx",
     "tenant": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
   }
   ```

---

### Step 1.4: Activate Resource Tags

**Time:** 5 minutes

1. **Navigate to Tags**
   ```
   Azure Portal → All Resources → Tags
   ```

2. **Create Standard Tags**
   ```
   Recommended tags:
   ✅ Environment (production, development, staging)
   ✅ Team
   ✅ Application
   ✅ Owner
   ✅ Project
   ```

3. **Apply to Resources**
   ```bash
   # Example: Tag a Virtual Machine
   az resource tag \
     --tags Environment=production Team=platform Application=web \
     --ids /subscriptions/{sub-id}/resourceGroups/{rg}/providers/Microsoft.Compute/virtualMachines/{vm-name}
   ```

4. **Wait 24 hours** for tags to appear in cost export

---

## Phase 2: UnitEconPro Configuration

### Step 2.1: Update Environment Variables

1. **Edit `.env` file**
   ```bash
   cd /home/harshitverma/UnitEconPro
   nano .env
   ```

2. **Add Azure Credentials**
   ```bash
   # Azure Configuration
   AZURE_TENANT_ID=xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
   AZURE_CLIENT_ID=xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
   AZURE_CLIENT_SECRET=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
   AZURE_SUBSCRIPTION_ID=xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
   AZURE_STORAGE_ACCOUNT=yourstorageaccount
   AZURE_STORAGE_CONTAINER=cost-exports
   AZURE_STORAGE_PATH=uniteconpro/
   ```

---

### Step 2.2: Add Subscription to ClickHouse

1. **Connect to ClickHouse**
   ```bash
   docker exec -it clickhouse clickhouse-client --user dba --password secretPassword
   ```

2. **Add Subscription**
   ```sql
   INSERT INTO cost.account_map (account_id, account_name, environment, team)
   VALUES ('xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx', 'production-azure', 'production', 'platform-team');
   ```

3. **Verify**
   ```sql
   SELECT * FROM cost.account_map WHERE account_name LIKE '%azure%';
   exit;
   ```

---

## Phase 3: Data Ingestion

### Step 3.1: Test Ingestion

```bash
cd /home/harshitverma/UnitEconPro
python3 app/app.py --mode refresh_days --days 7 --service virtualmachines --cloud azure
```

### Step 3.2: Full Ingestion

```bash
python3 app/app.py --mode refresh_days --days 7 --service all --cloud azure
```

---

## Phase 4: Validation

### Step 4.1: Verify Data in ClickHouse

```bash
docker exec -it clickhouse clickhouse-client --user dba --password secretPassword
```

```sql
SELECT 
  account_id,
  account_name,
  toDate(usage_start_ts) as date,
  COUNT(*) as records,
  ROUND(SUM(cost_unblended), 2) as total_cost
FROM cost.service_costs
WHERE account_id = 'xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx'
  AND usage_start_ts >= now() - INTERVAL 7 DAY
GROUP BY account_id, account_name, date
ORDER BY date;
```

### Step 4.2: Verify in Grafana

1. Open: http://localhost:3000
2. Go to "Multi-Cloud Cost Summary Dashboard"
3. Select Azure subscription from dropdown
4. Verify data is visible

---

## ✅ Onboarding Complete!

### Checklist

- [ ] Data visible in ClickHouse
- [ ] Subscription in Grafana dashboards
- [ ] Tags captured (if resources tagged)
- [ ] Validation script passes

---

## Troubleshooting

### No Data in Storage Account

**Fix:**
- Wait 24 hours for cost export
- Check export is enabled in Cost Management
- Verify storage account has data

### Permission Denied

**Fix:**
- Verify service principal has Cost Management Reader role
- Check storage account access permissions
- Test with: `az storage blob list --account-name ...`

### No Data in ClickHouse

**Fix:**
```sql
-- Check ingestion logs
SELECT * FROM cost.ingestion_log 
WHERE cloud = 'azure' AND status = 'failed' 
ORDER BY started_at DESC;
```

### Tags Not Showing

**Fix:**
- Create and apply tags to resources
- Wait 24 hours for tags in cost export
- Re-ingest data with `--mode refresh_days`

---

## Azure-Specific Notes

### Service Mapping

| Azure Service | ClickHouse product_code |
|---------------|-------------------------|
| Virtual Machines | Microsoft.Compute/virtualMachines |
| Storage Accounts | Microsoft.Storage/storageAccounts |
| SQL Database | Microsoft.Sql/servers/databases |
| App Service | Microsoft.Web/sites |
| Kubernetes Service | Microsoft.ContainerService/managedClusters |

### Cost Fields

| Azure Export Field | ClickHouse Field |
|--------------------|------------------|
| `Cost` | `cost_unblended` |
| `SubscriptionId` | `account_id` |
| `ServiceName` | `product_code` |
| `ResourceLocation` | `region` |
| `Tags` | `tag_*` fields |

---

## Quick Reference

### Common Commands

```bash
# Test ingestion
python3 app/app.py --mode refresh_days --days 7 --service virtualmachines --cloud azure

# Full ingestion
python3 app/app.py --mode refresh_days --days 7 --service all --cloud azure

# Autocorrect
python3 app/app.py --mode autocorrect --cloud azure

# Validate data
python3 scripts/validate_data.py --cloud azure
```

### Useful Queries

```sql
-- Check all Azure subscriptions
SELECT DISTINCT account_id, account_name 
FROM cost.service_costs 
WHERE account_id LIKE '%-%-%-%-%';

-- Check cost by Azure service
SELECT product_code, ROUND(SUM(cost_unblended), 2) as cost
FROM cost.service_costs
WHERE account_id = 'your-subscription-id'
  AND usage_start_ts >= now() - INTERVAL 30 DAY
GROUP BY product_code
ORDER BY cost DESC;
```

---



