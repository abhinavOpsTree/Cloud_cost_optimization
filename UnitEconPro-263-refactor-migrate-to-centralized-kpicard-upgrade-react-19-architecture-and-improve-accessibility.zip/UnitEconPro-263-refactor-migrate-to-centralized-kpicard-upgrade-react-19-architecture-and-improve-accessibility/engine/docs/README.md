# UnitEconPro Documentation

Complete documentation for multi-cloud cost visualization.

---

## 📚 Documentation Files

| Document | Purpose | Time |
|----------|---------|------|
| **[Add_AWS_Acc_SOP.md](Add_AWS_Acc_SOP.md)** | Add AWS accounts to UnitEconPro | 5-60 min |
| **[Add_GCP_Project_SOP.md](Add_GCP_Project_SOP.md)** | Implement GCP support (step-by-step) | 11 hours |
| **[Add_Azure_Subs_SOP.md](Add_Azure_Subs_SOP.md)** | Implement Azure support (step-by-step) | 11 hours |
| **[New_Cloud_Imp_SOP.md](New_Cloud_Imp_SOP.md)** | Add any new cloud provider (reference) | Varies |

---

## 🚀 Quick Start

### Adding AWS Account
```bash
# Read the guide
cat docs/Add_AWS_Acc_SOP.md

# Organization account: 5 minutes
# Standalone account: 60 minutes
```

### Implementing GCP
```bash
# Read the guide
cat docs/Add_GCP_Project_SOP.md

# Follow Phase 1 → Phase 7
# Total time: 11 hours
```

### Implementing Azure
```bash
# Read the guide
cat docs/Add_Azure_Subs_SOP.md

# Follow Phase 1 → Phase 7
# Total time: 11 hours
```

---

## 📖 File Descriptions

### Add_AWS_Acc_SOP.md
- Add AWS accounts (organization or standalone)
- Production-ready guide
- Path A: 5 minutes | Path B: 60 minutes

### Add_GCP_Project_SOP.md
- Step-by-step GCP implementation
- Complete Python code included
- Config files, integration steps, testing


### Add_Azure_Subs_SOP.md
- Step-by-step Azure implementation
- Complete Python code included
- Config files, integration steps, testing


### New_Cloud_Imp_SOP.md
- Developer reference guide
- Architecture and patterns
- Use when adding other cloud providers

---

## 🎯 Which Guide Do I Need?

**I want to add an AWS account:**
→ `Add_AWS_Acc_SOP.md`

**I want to implement GCP support:**
→ `Add_GCP_Project_SOP.md`

**I want to implement Azure support:**
→ `Add_Azure_Subs_SOP.md`

**I want to add a different cloud:**
→ `New_Cloud_Imp_SOP.md`

---


