## Purpose

This SOP guides you through deploying UnitEconPro for a new client, including configuration, namespace setup, and verification.

---

## Prerequisites

- [ ] Access to Kubernetes cluster
- [ ] Helm 3 installed
- [ ] kubectl configured
- [ ] Client information collected (see checklist below)

---

## Client Information Checklist

Collect this information before starting:

| Item | Example | Your Value |
|------|---------|------------|
| Client Name | `acme-corp` | __________ |
| Grafana Domain | `grafana.acme.com` | __________ |
| Azure Tenant ID | `12345678-1234-...` | __________ |
| Azure Client ID | `87654321-4321-...` | __________ |
| Azure Client Secret | `secret123...` | __________ |
| GitHub Repo URL | `github.com/acme/dashboards` | __________ |
| AWS Account ID | `702037529261` | __________ |
| Namespace | `uniteconpro-acme` | __________ |

---

## Step 1: Create Client Configuration

### 1.1 Copy Template

```bash
cd /home/harshitverma/UnitEconPro/helm-chart

# Create client-specific values file
cp values-local.yaml values-<CLIENT_NAME>.yaml
```

**Example:**
```bash
cp values-local.yaml values-acme-corp.yaml
```

### 1.2 Edit Configuration

Open `values-<CLIENT_NAME>.yaml` and update:

```yaml
namespace: uniteconpro-<CLIENT_NAME>

grafana:
  grafana.ini:
    server:
      domain: <GRAFANA_DOMAIN>
      root_url: https://<GRAFANA_DOMAIN>/
    
    auth.azuread:
      enabled: true
      client_id: "<AZURE_CLIENT_ID>"
      tenant_id: "<AZURE_TENANT_ID>"
      allowed_domains: "<CLIENT_EMAIL_DOMAIN>"

clickhouse:
  host: <CLICKHOUSE_HOST>
  port: 8123
  database: cost
  user: <CLIENT_NAME>
  password: "<CLICKHOUSE_PASSWORD>"
```

**Example:**
```yaml
namespace: uniteconpro-acme-corp

grafana:
  grafana.ini:
    server:
      domain: grafana.acme.com
      root_url: https://grafana.acme.com/
    
    auth.azuread:
      enabled: true
      client_id: "87654321-4321-1234-5678-123456789abc"
      tenant_id: "12345678-1234-5678-9abc-123456789def"
      allowed_domains: "acme.com"

clickhouse:
  host: 192.168.8.56
  port: 8123
  database: cost
  user: acme_corp
  password: "secure_password_here"
```

---

## Step 2: Create Namespace

```bash
kubectl create namespace uniteconpro-<CLIENT_NAME>
```

**Example:**
```bash
kubectl create namespace uniteconpro-acme-corp
```

---

## Step 3: Create Secrets

### 3.1 Azure AD Credentials

```bash
kubectl create secret generic grafana-azure-ad-creds \
  --from-literal=client-id='<AZURE_CLIENT_ID>' \
  --from-literal=client-secret='<AZURE_CLIENT_SECRET>' \
  --from-literal=tenant-id='<AZURE_TENANT_ID>' \
  --namespace uniteconpro-<CLIENT_NAME>
```

### 3.2 AWS Credentials

```bash
kubectl create secret generic aws-credentials \
  --from-literal=AWS_ACCESS_KEY_ID='<AWS_ACCESS_KEY>' \
  --from-literal=AWS_SECRET_ACCESS_KEY='<AWS_SECRET_KEY>' \
  --namespace uniteconpro-<CLIENT_NAME>
```

### 3.3 ClickHouse Credentials

```bash
kubectl create secret generic clickhouse-credentials \
  --from-literal=password='<CLICKHOUSE_PASSWORD>' \
  --namespace uniteconpro-<CLIENT_NAME>
```

### 3.4 Docker Registry Secret (if using private registry)

```bash
kubectl create secret docker-registry docker-secret \
  --docker-server=registry.ldc.opstree.dev \
  --docker-username=<USERNAME> \
  --docker-password=<PASSWORD> \
  --docker-email=<EMAIL> \
  --namespace uniteconpro-<CLIENT_NAME>
```

---

## Step 4: Deploy with Helm

### 4.1 Update Dependencies

```bash
cd /home/harshitverma/UnitEconPro/helm-chart
helm dependency update
```

### 4.2 Install Release

```bash
helm install uniteconpro-<CLIENT_NAME> . \
  --namespace uniteconpro-<CLIENT_NAME> \
  --values values-<CLIENT_NAME>.yaml
```

**Example:**
```bash
helm install uniteconpro-acme-corp . \
  --namespace uniteconpro-acme-corp \
  --values values-acme-corp.yaml
```

### 4.3 Verify Deployment

```bash
# Check pods
kubectl get pods -n uniteconpro-<CLIENT_NAME>

# Check services
kubectl get svc -n uniteconpro-<CLIENT_NAME>

# Check CronJobs
kubectl get cronjobs -n uniteconpro-<CLIENT_NAME>

# Check Ingress/Gateway routes
kubectl get httproute -n uniteconpro-<CLIENT_NAME>
# OR if using Ingress
kubectl get ingress -n uniteconpro-<CLIENT_NAME>
```

**Expected Output:**
```
NAME                                    READY   STATUS    RESTARTS   AGE
uniteconpro-acme-corp-grafana-xxx       1/1     Running   0          2m
uniteconpro-acme-corp-cronjob-xxx       0/1     Completed 0          1m
```

---

## Step 5: Configure Dashboard Sync (GitOps)

**Note:** UnitEconPro uses Grafana's sidecar for dashboard sync. Dashboards are loaded from ConfigMaps with the `grafana_dashboard=1` label.

### 5.1 Create Dashboard ConfigMap

```bash
kubectl create configmap grafana-dashboards \
  --from-file=../Dashboards/ \
  --namespace uniteconpro-<CLIENT_NAME>
```

### 5.2 Label for Sidecar Auto-Discovery

```bash
kubectl label configmap grafana-dashboards \
  grafana_dashboard=1 \
  -n uniteconpro-<CLIENT_NAME>
```

### 5.3 Verify Sync

Dashboards will appear in Grafana within 30 seconds. The sidecar container automatically detects ConfigMaps with the `grafana_dashboard=1` label.

**Check sidecar logs:**
```bash
kubectl logs -n uniteconpro-<CLIENT_NAME> \
  deployment/uniteconpro-<CLIENT_NAME>-grafana \
  -c grafana-sc-dashboards
```

---

## Step 6: Post-Deployment Verification

### 6.1 Access Grafana

```bash
kubectl port-forward -n uniteconpro-<CLIENT_NAME> \
  svc/uniteconpro-<CLIENT_NAME>-grafana 3000:80
```

Open: http://localhost:3000

### 6.2 Verification Checklist

- [ ] Grafana login page loads
- [ ] Azure AD login works
- [ ] ClickHouse datasource shows "Connected"
- [ ] All 15 dashboards visible
- [ ] Dashboard data loads (not empty)
- [ ] CronJob runs successfully

### 6.3 Test ClickHouse Connection

In Grafana:
1. Go to **Connections** → **Data Sources**
2. Click **ClickHouse**
3. Click **Test** button
4. Should show: ✅ "Data source is working"

### 6.4 Verify CronJob Execution

```bash
# Check recent job runs
kubectl get jobs -n uniteconpro-<CLIENT_NAME>

# Check logs
kubectl logs -n uniteconpro-<CLIENT_NAME> \
  job/<JOB_NAME> --tail=50
```

---

## Step 7: Document Deployment

Update the client tracking sheet:

| Client | Namespace | Grafana URL | Deployed Date | Status |
|--------|-----------|-------------|---------------|--------|
| Acme Corp | uniteconpro-acme-corp | grafana.acme.com | 2026-01-22 | ✅ Active |

---

## Troubleshooting

### Issue: Pods not starting

**Check:**
```bash
kubectl describe pod <POD_NAME> -n uniteconpro-<CLIENT_NAME>
```

**Common causes:**
- Missing secrets
- Wrong image pull secret
- Resource limits too low

### Issue: Dashboards not loading

**Check:**
```bash
# Verify ConfigMap exists
kubectl get configmap grafana-dashboards -n uniteconpro-<CLIENT_NAME>

# Check label
kubectl get configmap grafana-dashboards -n uniteconpro-<CLIENT_NAME> --show-labels
```

**Fix:**
```bash
kubectl label configmap grafana-dashboards grafana_dashboard=1 -n uniteconpro-<CLIENT_NAME>
```

### Issue: ClickHouse connection fails

**Check:**
```bash
# Test from pod
kubectl exec -it <GRAFANA_POD> -n uniteconpro-<CLIENT_NAME> -- \
  curl http://<CLICKHOUSE_HOST>:8123/ping
```

**Expected:** `Ok.`

---

## Rollback Procedure

If deployment fails:

```bash
helm uninstall uniteconpro-<CLIENT_NAME> -n uniteconpro-<CLIENT_NAME>
kubectl delete namespace uniteconpro-<CLIENT_NAME>
```