# GCP Project Onboarding SOP
## Complete Guide to Add a GCP Project to UnitEconPro

**Version:** 1.0  
**Last Updated:** January 2025  
**Status:** 🚧 **COMING SOON** - Template for future implementation

---

## ⚠️ Implementation Status

**GCP support is planned but not yet implemented.**

This document serves as a template for when GCP integration is added to UnitEconPro.

**Current Status:**
- ✅ Cloud-agnostic ClickHouse schema ready
- ✅ Multi-cloud architecture in place
- ⚠️ GCP extractor not implemented
- ⚠️ GCP transformer not implemented
- ⚠️ BigQuery connector needed



---

## 🚀 Quick Start (When Implemented)

### Path A: Project in SAME GCP Organization (5 minutes)
**Use this if:** Your new project is part of the same GCP Organization with consolidated billing.

**Steps:**
1. Add project to ClickHouse: `INSERT INTO cost.account_map VALUES ('gcp-project-id', 'name', 'env', 'team');`
2. Run ingestion: `python3 app/app.py --mode refresh_days --days 7 --service all --cloud gcp`
3. Done! ✅

---

### Path B: Separate GCP Project (60 minutes)
**Use this if:** Your project has separate billing export.

**Steps:** Follow the full SOP below.

---

## 📋 Table of Contents

1. [Prerequisites](#prerequisites)
2. [Phase 1: GCP Setup](#phase-1-gcp-setup)
3. [Phase 2: UnitEconPro Configuration](#phase-2-uniteconpro-configuration)
4. [Phase 3: Data Ingestion](#phase-3-data-ingestion)
5. [Phase 4: Validation](#phase-4-validation)
6. [Troubleshooting](#troubleshooting)

---

## Prerequisites

### Information You Need

- [ ] **GCP Project ID** (e.g., "my-project-123456")
- [ ] **GCP Project Name** (e.g., "production-app")
- [ ] **Billing Account ID** (e.g., "012345-6789AB-CDEF01")
- [ ] **Team/Owner** (e.g., "platform-team")
- [ ] **Environment** (e.g., "production", "development")
- [ ] **GCP Console Access** (Billing Admin + BigQuery Admin)
- [ ] **UnitEconPro Server Access**

---

## Phase 1: GCP Setup

### Step 1.1: Enable Billing Export to BigQuery

**Time:** 15 minutes

1. **Login to GCP Console**
   - Go to: https://console.cloud.google.com/billing

2. **Navigate to Billing Export**
   ```
   GCP Console → Billing → Billing Export → BigQuery Export
   ```

3. **Configure Export Settings**
   ```
   Export type: Standard usage cost
   Project: [your-project-id]
   Dataset: billing_export
   Table: gcp_billing_export
   ```

4. **Enable Detailed Usage Cost**
   ```
   ✅ Enable detailed usage cost export
   ✅ Include resource-level data
   ```

5. **Wait 24 hours** for first export

---

### Step 1.2: Set Up BigQuery Dataset

**Time:** 10 minutes

1. **Navigate to BigQuery Console**
   - Go to: https://console.cloud.google.com/bigquery

2. **Verify Dataset Exists**
   ```sql
   SELECT * FROM `your-project-id.billing_export.gcp_billing_export_*`
   LIMIT 10;
   ```

3. **Test Query**
   ```sql
   SELECT 
     project.id as project_id,
     service.description as service,
     COUNT(*) as records,
     SUM(cost) as total_cost
   FROM `your-project-id.billing_export.gcp_billing_export_*`
   WHERE _TABLE_SUFFIX >= FORMAT_DATE('%Y%m%d', DATE_SUB(CURRENT_DATE(), INTERVAL 7 DAY))
   GROUP BY project_id, service
   ORDER BY total_cost DESC;
   ```

---

### Step 1.3: Configure Service Account

**Time:** 10 minutes

1. **Create Service Account**
   ```
   GCP Console → IAM & Admin → Service Accounts → Create Service Account
   Name: uniteconpro-bigquery-reader
   Description: Service account for UnitEconPro cost ingestion
   ```

2. **Grant Permissions**
   ```
   Roles:
   ✅ BigQuery Data Viewer
   ✅ BigQuery Job User
   ✅ Billing Account Viewer
   ```

3. **Create JSON Key**
   ```
   Service Account → Keys → Add Key → Create new key → JSON
   ```

4. **Save Key File**
   ```bash
   # Save to secure location
   mv ~/Downloads/uniteconpro-*.json /home/harshitverma/UnitEconPro/gcp-service-account.json
   chmod 600 /home/harshitverma/UnitEconPro/gcp-service-account.json
   ```

---

### Step 1.4: Activate Resource Labels

**Time:** 5 minutes

1. **Navigate to Labels**
   ```
   GCP Console → Resource Manager → Labels
   ```

2. **Create Standard Labels**
   ```
   Recommended labels:
   ✅ env (environment)
   ✅ team
   ✅ app (application)
   ✅ owner
   ✅ project
   ```

3. **Apply to Resources**
   ```bash
   # Example: Label a Compute Engine instance
   gcloud compute instances add-labels INSTANCE_NAME \
     --labels=env=production,team=platform,app=web
   ```

4. **Wait 24 hours** for labels to appear in billing export

---

## Phase 2: UnitEconPro Configuration

### Step 2.1: Update Environment Variables

1. **Edit `.env` file**
   ```bash
   cd /home/harshitverma/UnitEconPro
   nano .env
   ```

2. **Add GCP Credentials**
   ```bash
   # GCP Configuration
   GCP_PROJECT_ID=your-project-id
   GCP_SERVICE_ACCOUNT_KEY=/home/harshitverma/UnitEconPro/gcp-service-account.json
   GCP_BILLING_DATASET=billing_export
   GCP_BILLING_TABLE=gcp_billing_export
   ```

---

### Step 2.2: Add Project to ClickHouse

1. **Connect to ClickHouse**
   ```bash
   docker exec -it clickhouse clickhouse-client --user dba --password secretPassword
   ```

2. **Add Project**
   ```sql
   INSERT INTO cost.account_map (account_id, account_name, environment, team)
   VALUES ('your-project-id', 'production-gcp', 'production', 'platform-team');
   ```

3. **Verify**
   ```sql
   SELECT * FROM cost.account_map WHERE account_id = 'your-project-id';
   exit;
   ```

---

## Phase 3: Data Ingestion

### Step 3.1: Test Ingestion

```bash
cd /home/harshitverma/UnitEconPro
python3 app/app.py --mode refresh_days --days 7 --service compute --cloud gcp
```

### Step 3.2: Full Ingestion

```bash
python3 app/app.py --mode refresh_days --days 7 --service all --cloud gcp
```

---

## Phase 4: Validation

### Step 4.1: Verify Data in ClickHouse

```bash
docker exec -it clickhouse clickhouse-client --user dba --password secretPassword
```

```sql
SELECT 
  account_id,
  account_name,
  toDate(usage_start_ts) as date,
  COUNT(*) as records,
  ROUND(SUM(cost_unblended), 2) as total_cost
FROM cost.service_costs
WHERE account_id = 'your-project-id'
  AND usage_start_ts >= now() - INTERVAL 7 DAY
GROUP BY account_id, account_name, date
ORDER BY date;
```

### Step 4.2: Verify in Grafana

1. Open: http://localhost:3000
2. Go to "Multi-Cloud Cost Summary Dashboard"
3. Select GCP project from dropdown
4. Verify data is visible

---

## ✅ Onboarding Complete!

### Checklist

- [ ] Data visible in ClickHouse
- [ ] Project in Grafana dashboards
- [ ] Labels captured (if resources labeled)
- [ ] Validation script passes

---

## Troubleshooting

### No Data in BigQuery

**Fix:**
- Wait 24 hours for billing export
- Check billing export is enabled
- Verify dataset exists in BigQuery

### Permission Denied

**Fix:**
- Verify service account has BigQuery Data Viewer role
- Check JSON key file path in `.env`
- Test with: `gcloud auth activate-service-account --key-file=...`

### No Data in ClickHouse

**Fix:**
```sql
-- Check ingestion logs
SELECT * FROM cost.ingestion_log 
WHERE cloud = 'gcp' AND status = 'failed' 
ORDER BY started_at DESC;
```

### Labels Not Showing

**Fix:**
- Create and apply labels to resources
- Wait 24 hours for labels in billing export
- Re-ingest data with `--mode refresh_days`

---

## GCP-Specific Notes

### Service Mapping

| GCP Service | ClickHouse product_code |
|-------------|-------------------------|
| Compute Engine | Compute Engine |
| Cloud Storage | Cloud Storage |
| BigQuery | BigQuery |
| Cloud SQL | Cloud SQL |
| Kubernetes Engine | Kubernetes Engine |

### Cost Fields

| BigQuery Field | ClickHouse Field |
|----------------|------------------|
| `cost` | `cost_unblended` |
| `project.id` | `account_id` |
| `service.description` | `product_code` |
| `location.region` | `region` |
| `labels` | `tag_*` fields |

---

## Quick Reference

### Common Commands

```bash
# Test ingestion
python3 app/app.py --mode refresh_days --days 7 --service compute --cloud gcp

# Full ingestion
python3 app/app.py --mode refresh_days --days 7 --service all --cloud gcp

# Autocorrect
python3 app/app.py --mode autocorrect --cloud gcp

# Validate data
python3 scripts/validate_data.py --cloud gcp
```

### Useful Queries

```sql
-- Check all GCP projects
SELECT DISTINCT account_id, account_name 
FROM cost.service_costs 
WHERE account_id LIKE '%gcp%';

-- Check cost by GCP service
SELECT product_code, ROUND(SUM(cost_unblended), 2) as cost
FROM cost.service_costs
WHERE account_id = 'your-project-id'
  AND usage_start_ts >= now() - INTERVAL 30 DAY
GROUP BY product_code
ORDER BY cost DESC;
```


