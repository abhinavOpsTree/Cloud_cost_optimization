## Purpose

This SOP outlines the procedure for deploying UnitEconPro on Amazon ECS (Fargate). This is an alternative deployment method for clients who prefer a serverless AWS-native architecture over a Kubernetes cluster.

---

## Architecture Differences

| Component | Kubernetes (Standard) | AWS ECS (This SOP) |
|-----------|----------------------|-------------------|
| Orchestrator | EKS / Helm | ECS / Fargate |
| Config | ConfigMaps / Secrets | Environment Variables / AWS Secrets Manager |
| Storage | PVC (EBS) | EFS (Elastic File System) |
| Networking | Ingress / Service | Application Load Balancer (ALB) |
| Deployment | `helm upgrade` | `aws ecs update-service` |
| Scheduling | CronJob | EventBridge Scheduler |

---

## Prerequisites

- [ ] Terraform installed (v1.5+)
- [ ] AWS CLI configured
- [ ] GitHub Token (for Git Sync)
- [ ] Docker Image pushed to ECR (Elastic Container Registry)
- [ ] VPC with private subnets
- [ ] EFS file system created

---

## Phase 1: Infrastructure Setup (Terraform)

**Context:** Unlike Helm, ECS requires building the infrastructure (Networking, Load Balancer, EFS) first.

### 1.1 Terraform Configuration

**Create:** `terraform/clients/acme-corp/main.tf`

```hcl
module "unitecon_ecs" {
  source = "../../modules/ecs-fargate"

  client_name = "acme-corp"
  vpc_id      = "vpc-xxxxxxxx"
  subnet_ids  = ["subnet-xxxxx", "subnet-yyyyy"]
  
  # Grafana Task Settings
  grafana_cpu    = 512
  grafana_memory = 1024
  grafana_image  = "123456789.dkr.ecr.us-east-1.amazonaws.com/unitecon-grafana:12.4.0"
  
  # Ingestion Task Settings
  ingestion_cpu    = 1024
  ingestion_memory = 2048
  ingestion_image  = "123456789.dkr.ecr.us-east-1.amazonaws.com/unitecon-app:latest"
  
  # Persistent Storage (Replaces PVC)
  efs_id = "fs-xxxxxxxx"
  
  # Load Balancer
  certificate_arn = "arn:aws:acm:us-east-1:123456:certificate/xxxxx"
  domain_name     = "grafana.acme.com"
}
```

### 1.2 Apply Infrastructure

```bash
cd terraform/clients/acme-corp
terraform init
terraform plan -out=plan.tfplan
terraform apply plan.tfplan
```

**Expected Output:**
- ECS Cluster: `unitecon-acme-corp`
- ECS Service: `grafana-service`
- ALB: `unitecon-acme-corp-alb`
- Target Group: `grafana-tg`
- Security Groups configured

---

## Phase 2: Configuration Mapping

**Context:** Helm values must be converted into ECS Environment Variables.

### 2.1 Key Mappings

| Helm Value (values.yaml) | ECS Env Var | Value |
|--------------------------|-------------|-------|
| `grafana.ini.server.root_url` | `GF_SERVER_ROOT_URL` | `https://grafana.acme.com` |
| `grafana.ini.auth.azuread.enabled` | `GF_AUTH_AZUREAD_ENABLED` | `true` |
| `grafana.ini.auth.azuread.client_id` | `GF_AUTH_AZUREAD_CLIENT_ID` | `<CLIENT_ID>` |
| `env.GITHUB_TOKEN` | `GITHUB_TOKEN` | (Pull from Secrets Manager) |
| `feature_toggles.enable` | `GF_FEATURE_TOGGLES_ENABLE` | `provisioning,gitSync` |

### 2.2 AWS Secrets Manager Setup

**Do not put passwords in Task Definition JSON. Use AWS Secrets Manager.**

**Create Secret:**
```bash
aws secretsmanager create-secret \
  --name production/acme-corp/grafana \
  --description "Grafana secrets for Acme Corp" \
  --secret-string '{
    "GF_AUTH_AZUREAD_CLIENT_SECRET": "azure_secret_here",
    "GITHUB_TOKEN": "ghp_xxxxxxxxxxxxx",
    "CLICKHOUSE_PASSWORD": "secure_password"
  }'
```

**Verify:**
```bash
aws secretsmanager get-secret-value \
  --secret-id production/acme-corp/grafana \
  --query SecretString --output text | jq
```

### 2.3 Task Definition JSON

**Create:** `task-definitions/grafana-task-def.json`

```json
{
  "family": "unitecon-grafana-acme",
  "networkMode": "awsvpc",
  "requiresCompatibilities": ["FARGATE"],
  "cpu": "512",
  "memory": "1024",
  "executionRoleArn": "arn:aws:iam::123456:role/ecsTaskExecutionRole",
  "taskRoleArn": "arn:aws:iam::123456:role/uniteconTaskRole",
  "containerDefinitions": [
    {
      "name": "grafana",
      "image": "IMAGE_PLACEHOLDER",
      "essential": true,
      "portMappings": [
        {
          "containerPort": 3000,
          "protocol": "tcp"
        }
      ],
      "environment": [
        {
          "name": "GF_SERVER_ROOT_URL",
          "value": "https://grafana.acme.com"
        },
        {
          "name": "GF_AUTH_AZUREAD_ENABLED",
          "value": "true"
        },
        {
          "name": "GF_AUTH_AZUREAD_CLIENT_ID",
          "value": "87654321-4321-1234-5678-123456789abc"
        },
        {
          "name": "GF_AUTH_AZUREAD_TENANT_ID",
          "value": "12345678-1234-5678-9abc-123456789def"
        },
        {
          "name": "GF_FEATURE_TOGGLES_ENABLE",
          "value": "provisioning,gitSync"
        }
      ],
      "secrets": [
        {
          "name": "GF_AUTH_AZUREAD_CLIENT_SECRET",
          "valueFrom": "arn:aws:secretsmanager:us-east-1:123456:secret:production/acme-corp/grafana:GF_AUTH_AZUREAD_CLIENT_SECRET::"
        },
        {
          "name": "GITHUB_TOKEN",
          "valueFrom": "arn:aws:secretsmanager:us-east-1:123456:secret:production/acme-corp/grafana:GITHUB_TOKEN::"
        }
      ],
      "mountPoints": [
        {
          "sourceVolume": "grafana-storage",
          "containerPath": "/var/lib/grafana",
          "readOnly": false
        }
      ],
      "logConfiguration": {
        "logDriver": "awslogs",
        "options": {
          "awslogs-group": "/ecs/unitecon-grafana-acme",
          "awslogs-region": "us-east-1",
          "awslogs-stream-prefix": "grafana"
        }
      },
      "healthCheck": {
        "command": ["CMD-SHELL", "curl -f http://localhost:3000/api/health || exit 1"],
        "interval": 30,
        "timeout": 5,
        "retries": 3,
        "startPeriod": 60
      }
    }
  ],
  "volumes": [
    {
      "name": "grafana-storage",
      "efsVolumeConfiguration": {
        "fileSystemId": "fs-xxxxxxxx",
        "transitEncryption": "ENABLED",
        "authorizationConfig": {
          "iam": "ENABLED"
        }
      }
    }
  ]
}
```

---

## Phase 3: Deployment Pipeline (Jenkins)

**Context:** Jenkins cannot use `helm upgrade` for ECS. It must use AWS CLI to update the service.

### 3.1 Jenkinsfile for ECS

**Create:** `Jenkinsfile.ecs`

```groovy
pipeline {
    agent any
    
    environment {
        AWS_REGION = 'us-east-1'
        AWS_ACCOUNT_ID = credentials('aws-prod-account')
        ECR_REPO = "${AWS_ACCOUNT_ID}.dkr.ecr.${AWS_REGION}.amazonaws.com"
        IMAGE_NAME = "unitecon-grafana"
        CLUSTER_NAME = "unitecon-acme-corp"
        SERVICE_NAME = "grafana-service"
    }
    
    stages {
        stage('Build Docker Image') {
            steps {
                script {
                    sh """
                        docker build -t ${IMAGE_NAME}:${BUILD_NUMBER} \
                          -f deployment/grafana/Dockerfile .
                    """
                }
            }
        }
        
        stage('Push to ECR') {
            steps {
                script {
                    sh """
                        aws ecr get-login-password --region ${AWS_REGION} | \
                          docker login --username AWS --password-stdin ${ECR_REPO}
                        
                        docker tag ${IMAGE_NAME}:${BUILD_NUMBER} \
                          ${ECR_REPO}/${IMAGE_NAME}:${BUILD_NUMBER}
                        
                        docker push ${ECR_REPO}/${IMAGE_NAME}:${BUILD_NUMBER}
                        
                        docker tag ${IMAGE_NAME}:${BUILD_NUMBER} \
                          ${ECR_REPO}/${IMAGE_NAME}:latest
                        
                        docker push ${ECR_REPO}/${IMAGE_NAME}:latest
                    """
                }
            }
        }
        
        stage('Update Task Definition') {
            steps {
                script {
                    sh """
                        # Replace image placeholder with actual image
                        sed -i 's|IMAGE_PLACEHOLDER|${ECR_REPO}/${IMAGE_NAME}:${BUILD_NUMBER}|g' \
                          task-definitions/grafana-task-def.json
                        
                       # Register new task definition
                        aws ecs register-task-definition \
                          --cli-input-json file://task-definitions/grafana-task-def.json \
                          --region ${AWS_REGION} > new-task.json
                        
                        # Extract new revision number
                        TASK_REVISION=\$(cat new-task.json | jq -r '.taskDefinition.revision')
                        echo "New task revision: \$TASK_REVISION"
                    """
                }
            }
        }
        
        stage('Deploy to ECS') {
            steps {
                script {
                    sh """
                        TASK_REVISION=\$(cat new-task.json | jq -r '.taskDefinition.revision')
                        
                        # Update service with new task definition
                        aws ecs update-service \
                          --cluster ${CLUSTER_NAME} \
                          --service ${SERVICE_NAME} \
                          --task-definition unitecon-grafana-acme:\$TASK_REVISION \
                          --force-new-deployment \
                          --region ${AWS_REGION}
                        
                        echo "Deployment initiated. Waiting for service to stabilize..."
                        
                        # Wait for deployment to complete
                        aws ecs wait services-stable \
                          --cluster ${CLUSTER_NAME} \
                          --services ${SERVICE_NAME} \
                          --region ${AWS_REGION}
                        
                        echo "Deployment completed successfully!"
                    """
                }
            }
        }
    }
    
    post {
        success {
            echo "ECS deployment successful for build ${BUILD_NUMBER}"
        }
        failure {
            echo "ECS deployment failed. Check logs for details."
        }
    }
}
```

### 3.2 Manual Deployment (Without Jenkins)

```bash
# 1. Build and push image
docker build -t unitecon-grafana:v1.0 .
aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin 123456.dkr.ecr.us-east-1.amazonaws.com
docker tag unitecon-grafana:v1.0 123456.dkr.ecr.us-east-1.amazonaws.com/unitecon-grafana:v1.0
docker push 123456.dkr.ecr.us-east-1.amazonaws.com/unitecon-grafana:v1.0

# 2. Update task definition
sed -i 's|IMAGE_PLACEHOLDER|123456.dkr.ecr.us-east-1.amazonaws.com/unitecon-grafana:v1.0|g' task-def.json
aws ecs register-task-definition --cli-input-json file://task-def.json

# 3. Update service
aws ecs update-service \
  --cluster unitecon-acme-corp \
  --service grafana-service \
  --task-definition unitecon-grafana-acme:5 \
  --force-new-deployment
```

---

## Phase 4: Scheduled Ingestion (EventBridge)

**Context:** ECS doesn't have CronJobs. Use EventBridge Scheduler to trigger ECS tasks.

### 4.1 Create EventBridge Rule

```bash
aws events put-rule \
  --name unitecon-daily-ingestion-acme \
  --schedule-expression "cron(0 2 * * ? *)" \
  --description "Daily cost ingestion for Acme Corp"
```

### 4.2 Create ECS Task Target

```bash
aws events put-targets \
  --rule unitecon-daily-ingestion-acme \
  --targets '[
    {
      "Id": "1",
      "Arn": "arn:aws:ecs:us-east-1:123456:cluster/unitecon-acme-corp",
      "RoleArn": "arn:aws:iam::123456:role/ecsEventsRole",
      "EcsParameters": {
        "TaskDefinitionArn": "arn:aws:ecs:us-east-1:123456:task-definition/unitecon-ingestion-acme:1",
        "TaskCount": 1,
        "LaunchType": "FARGATE",
        "NetworkConfiguration": {
          "awsvpcConfiguration": {
            "Subnets": ["subnet-xxxxx", "subnet-yyyyy"],
            "SecurityGroups": ["sg-xxxxxxxx"],
            "AssignPublicIp": "DISABLED"
          }
        }
      }
    }
  ]'
```

### 4.3 Verify Schedule

```bash
aws events list-rules --name-prefix unitecon-daily
aws events list-targets-by-rule --rule unitecon-daily-ingestion-acme
```

---

## Phase 5: Git Sync on ECS

**Context:** ECS containers are stateless. Without EFS, the `/var/lib/grafana` folder is wiped on restart.

### 5.1 Persistence Requirement

**CRITICAL:** Ensure your Terraform mounts an EFS Volume to `/var/lib/grafana`.

**Without EFS:**
- Git Sync clones the repo every time the container starts
- Slower startup (30-60 seconds)
- Hits GitHub rate limits (60 requests/hour for unauthenticated)

**With EFS:**
- Git Sync works like Kubernetes (incremental updates)
- Fast startup (5-10 seconds)
- Only pulls changes since last sync

### 5.2 EFS Mount Configuration

Ensure your task definition includes:

```json
"mountPoints": [
  {
    "sourceVolume": "grafana-storage",
    "containerPath": "/var/lib/grafana",
    "readOnly": false
  }
],
"volumes": [
  {
    "name": "grafana-storage",
    "efsVolumeConfiguration": {
      "fileSystemId": "fs-xxxxxxxx",
      "transitEncryption": "ENABLED"
    }
  }
]
```

---

## Verification Checklist

### Post-Deployment Checks

```bash
# 1. Check service status
aws ecs describe-services \
  --cluster unitecon-acme-corp \
  --services grafana-service \
  --query 'services[0].{Status:status,Running:runningCount,Desired:desiredCount}'

# 2. Check task health
aws ecs list-tasks --cluster unitecon-acme-corp --service-name grafana-service
aws ecs describe-tasks --cluster unitecon-acme-corp --tasks <TASK_ARN>

# 3. Check logs
aws logs tail /ecs/unitecon-grafana-acme --follow

# 4. Test ALB endpoint
curl -I https://grafana.acme.com

# 5. Verify EventBridge schedule
aws events list-rules --name-prefix unitecon-daily
```

**Expected Results:**
- Service status: `ACTIVE`
- Running count = Desired count
- Task health status: `HEALTHY`
- ALB returns HTTP 200
- EventBridge rule: `ENABLED`

---

## Troubleshooting

### Issue: "Task stopped (Essential container in task exited)"

**Cause:** Container crashed immediately

**Check:**
```bash
aws ecs describe-tasks --cluster unitecon-acme-corp --tasks <TASK_ARN> \
  --query 'tasks[0].containers[0].reason'

aws logs tail /ecs/unitecon-grafana-acme --since 10m
```

**Common fixes:**
- Check if `GF_INSTALL_PLUGINS` failed to download
- Verify Secrets Manager permissions
- Check EFS mount permissions

### Issue: "Health check failed"

**Cause:** Load Balancer cannot reach port 3000

**Check:**
```bash
# Verify security groups
aws ec2 describe-security-groups --group-ids <ALB_SG> <TASK_SG>
```

**Fix:** Ensure ALB Security Group allows outbound to Task Security Group on port 3000

### Issue: "CannotPullContainerError"

**Cause:** ECR permissions issue

**Check:**
```bash
aws ecr describe-repositories --repository-names unitecon-grafana
aws ecr get-repository-policy --repository-name unitecon-grafana
```

**Fix:** Attach `AmazonEC2ContainerRegistryReadOnly` to task execution role

### Issue: EventBridge not triggering tasks

**Cause:** IAM role missing permissions

**Check:**
```bash
aws iam get-role --role-name ecsEventsRole
```

**Fix:** Ensure role has `ecs:RunTask` permission

---

## Cost Optimization

### ECS Fargate Pricing (us-east-1)

| Resource | Price | Monthly Cost (Grafana 24/7) |
|----------|-------|----------------------------|
| 0.5 vCPU | $0.04048/hour | ~$29.15 |
| 1 GB Memory | $0.004445/hour | ~$3.20 |
| **Total** | | **~$32.35/month** |

**Ingestion Task (runs 1 hour/day):**
- 1 vCPU + 2 GB Memory = ~$2.50/month

**Total Monthly Cost:** ~$35/month (vs. EKS ~$75/month for cluster + nodes)

