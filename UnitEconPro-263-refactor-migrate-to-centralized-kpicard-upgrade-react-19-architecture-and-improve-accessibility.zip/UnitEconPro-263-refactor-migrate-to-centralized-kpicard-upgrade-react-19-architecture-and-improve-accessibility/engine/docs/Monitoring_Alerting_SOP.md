## Purpose

This SOP defines monitoring procedures, health checks, and alerting thresholds for UnitEconPro production environments to ensure data accuracy, system availability, and early detection of issues.

---

## Part 1: Daily Health Checks

### 1.1 CronJob Status Check

**Check all scheduled jobs:**
```bash
kubectl get cronjobs -n <NAMESPACE>
```

**Expected output:**
- SCHEDULE: `0 2 * * *` (daily at 2 AM)
- SUSPEND: False
- ACTIVE: 0 (when not running)
- LAST SCHEDULE: < 24h ago

**Check recent job executions:**
```bash
kubectl get jobs -n <NAMESPACE> --sort-by=.metadata.creationTimestamp
```

**Check for failures:**
```bash
kubectl get jobs -n <NAMESPACE> -o json | \
  jq -r '.items[] | select(.status.failed > 0) | .metadata.name'
```

**View failed job logs:**
```bash
kubectl logs job/<JOB_NAME> -n <NAMESPACE>
```

---

### 1.2 Data Freshness Check

**Check latest ingested data in ClickHouse:**
```sql
SELECT 
    max(usage_start_date) AS latest_data,
    now() - max(usage_start_date) AS data_age_hours
FROM cost.service_costs
WHERE account_id = <ACCOUNT_ID>;
```

**Alert if:**
- `data_age_hours > 48` → Data ingestion likely failed

**Check ingestion volume (last 7 days):**
```sql
SELECT 
    toDate(usage_start_date) AS date,
    count() AS records,
    sum(unblended_cost) AS total_cost
FROM cost.service_costs
WHERE account_id = <ACCOUNT_ID>
  AND usage_start_date >= today() - 7
GROUP BY date
ORDER BY date DESC;
```

**Alert if:**
- Any day has 0 records
- Cost drops > 50% unexpectedly

---

### 1.3 ClickHouse Health Check

**Check ClickHouse is responding:**
```bash
curl "http://<CLICKHOUSE_HOST>:8123/?user=<USER>&password=<PASSWORD>" \
  --data "SELECT 1"
```

**Expected:** `1`

**Check database size:**
```sql
SELECT 
    database,
    formatReadableSize(sum(bytes_on_disk)) AS size,
    sum(rows) AS total_rows
FROM system.parts
WHERE database = 'cost' AND active = 1
GROUP BY database;
```

**Check table partitions:**
```sql
SELECT 
    table,
    count(DISTINCT partition) AS partition_count,
    formatReadableSize(sum(bytes_on_disk)) AS total_size
FROM system.parts
WHERE database = 'cost' AND active = 1
GROUP BY table;
```

**Check PVC disk usage (CRITICAL):**
```bash
# Get PVC status
kubectl get pvc -n <NAMESPACE>

# Check actual disk usage inside pod
kubectl exec -it <CLICKHOUSE_POD> -n <NAMESPACE> -- df -h /var/lib/clickhouse
```

**Alert if:**
- Database size > 80% of allocated storage
- **PVC usage > 85%** (ClickHouse needs space for background merges - hitting 100% causes crashes and data corruption)
- Partition count grows unexpectedly (> 100 partitions)

---

### 1.4 Grafana Dashboard Health

**Check Grafana is accessible:**
```bash
curl -s -o /dev/null -w "%{http_code}" https://<GRAFANA_URL>/api/health
```

**Expected:** `200`

**Check datasource connectivity:**
1. Login to Grafana
2. Configuration → Data sources → ClickHouse
3. Click "Test" button
4. Expected: "Data source is working"

**Check dashboard load time:**
- Open "AWS Cost Summary" dashboard
- Should load within 5 seconds
- If > 10 seconds, investigate query performance

**Check Git Sync status (CRITICAL for GitOps):**
1. Login to Grafana
2. Navigate to **Administration** → **Provisioning** → **Git Sync**
3. Verify:
   - **Status Indicator:** Must be Green / Connected
   - **Last Sync:** Should be within last 5-10 minutes
   - **Error Log:** Check for "Authentication failed" or "Rate limit exceeded"

**Alert if:**
- Status is Red / Disconnected
- Last sync > 15 minutes ago
- Authentication errors (GitHub token expired)

**Why this matters:** If Git Sync breaks, Grafana serves stale dashboards. Dashboard updates won't deploy until connection is restored.

---

## Part 2: Weekly Health Checks

### 2.1 Partition Health Check

**Check for stale partitions:**
```sql
SELECT 
    partition AS week_start,
    count() AS part_count,
    sum(rows) AS total_rows,
    formatReadableSize(sum(bytes_on_disk)) AS size,
    min(toDate(min_time)) AS first_date,
    max(toDate(max_time)) AS last_date
FROM system.parts
WHERE database = 'cost' 
  AND table = 'service_costs'
  AND active = 1
GROUP BY partition
ORDER BY week_start DESC
LIMIT 10;
```

**Alert if:**
- `first_date` or `last_date` outside partition week range → Run autocorrect

**Check for duplicate data:**
```sql
SELECT 
    usage_start_date,
    resource_id,
    count(*) AS duplicate_count
FROM cost.service_costs
WHERE account_id = <ACCOUNT_ID>
  AND usage_start_date >= today() - 7
GROUP BY usage_start_date, resource_id
HAVING count(*) > 1
LIMIT 10;
```

**Alert if:** Any duplicates found → Investigate ingestion logic

---

### 2.2 Cost Anomaly Detection

**Check for cost spikes (> 30% increase):**
```sql
WITH daily_costs AS (
    SELECT 
        toDate(usage_start_date) AS date,
        sum(unblended_cost) AS cost
    FROM cost.service_costs
    WHERE account_id = <ACCOUNT_ID>
      AND usage_start_date >= today() - 14
    GROUP BY date
)
SELECT 
    date,
    cost,
    lagInFrame(cost) OVER (ORDER BY date) AS prev_cost,
    round((cost - prev_cost) / prev_cost * 100, 2) AS pct_change
FROM daily_costs
WHERE pct_change > 30
ORDER BY date DESC;
```

**Alert if:** Any day shows > 30% increase → Notify client

**Check top cost drivers:**
```sql
SELECT 
    product_code,
    sum(unblended_cost) AS total_cost,
    count() AS record_count
FROM cost.service_costs
WHERE account_id = <ACCOUNT_ID>
  AND usage_start_date >= today() - 7
GROUP BY product_code
ORDER BY total_cost DESC
LIMIT 10;
```

---

### 2.3 Secret Expiry Check

**Run secret age monitoring script:**
```bash
#!/bin/bash
NAMESPACE=$1
THRESHOLD_DAYS=80

kubectl get secrets -n $NAMESPACE -o json | \
jq -r '.items[] | 
  select(.type != "kubernetes.io/service-account-token") |
  "\(.metadata.name) \(.metadata.creationTimestamp)"' | \
while read name timestamp; do
  age_days=$(( ($(date +%s) - $(date -d "$timestamp" +%s)) / 86400 ))
  if [ $age_days -gt $THRESHOLD_DAYS ]; then
    echo "⚠️  $name is $age_days days old - rotation needed!"
  fi
done
```

**Alert if:** Any secret > 80 days old → Schedule rotation (SOP-002)

---

## Part 3: Real-Time Monitoring

### 3.1 CronJob Failure Alerts

**Monitor job completion:**
```bash
kubectl get jobs -n <NAMESPACE> -w
```

**Check for failures in real-time:**
```bash
kubectl get events -n <NAMESPACE> --watch | grep -i error
```

**Alert conditions:**
- Job status: `Failed`
- Job duration > 30 minutes
- Job restarts > 3 times

**Immediate action:**
```bash
# Get failed job logs
kubectl logs job/<JOB_NAME> -n <NAMESPACE> --tail=100

# Check for common errors
kubectl logs job/<JOB_NAME> -n <NAMESPACE> | grep -i "error\|exception\|failed"
```

---

### 3.2 ClickHouse Query Performance

**Monitor slow queries:**
```sql
SELECT 
    query_id,
    user,
    query_duration_ms,
    read_rows,
    formatReadableSize(read_bytes) AS data_read,
    substring(query, 1, 100) AS query_preview
FROM system.query_log
WHERE type = 'QueryFinish'
  AND query_duration_ms > 5000
  AND event_time >= now() - INTERVAL 1 HOUR
ORDER BY query_duration_ms DESC
LIMIT 10;
```

**Alert if:**
- Query duration > 10 seconds
- Read rows > 10M for dashboard queries

**Optimization actions:**
- Review query in Grafana dashboard
- Add indexes if needed
- Optimize date range filters

---

### 3.3 Pod Resource Monitoring

**Check pod resource usage:**
```bash
kubectl top pods -n <NAMESPACE>
```

**Alert if:**
- CPU > 80% sustained
- Memory > 80% of limit

**Check pod restarts:**
```bash
kubectl get pods -n <NAMESPACE> -o json | \
  jq -r '.items[] | "\(.metadata.name) \(.status.containerStatuses[0].restartCount)"'
```

**Alert if:** Restart count > 5 in 24 hours

**View pod events:**
```bash
kubectl describe pod <POD_NAME> -n <NAMESPACE> | grep -A 10 Events
```

---

## Part 4: Alert Thresholds & Escalation

### 4.1 Severity Levels

**Critical (P1) - Immediate Response Required**
- CronJob failed 2+ consecutive days
- Data age > 72 hours
- ClickHouse unreachable
- Grafana down
- Cost spike > 100%

**High (P2) - Response within 4 hours**
- CronJob failed once
- Data age > 48 hours
- Slow queries (> 10s)
- Pod restarts > 5
- Cost spike > 50%

**Medium (P3) - Response within 24 hours**
- Secret expiry < 10 days
- Partition health issues
- Dashboard load time > 10s
- Cost spike > 30%

**Low (P4) - Response within 1 week**
- Secret expiry < 30 days
- Storage usage > 60%
- Minor query optimizations needed

---

### 4.2 Escalation Matrix

| Severity | First Response | Escalate After | Escalate To |
|----------|---------------|----------------|-------------|
| P1 | On-call Engineer | 30 minutes | Team Lead |
| P2 | On-call Engineer | 4 hours | Team Lead |
| P3 | Assigned Engineer | 24 hours | Team Lead |
| P4 | Assigned Engineer | 1 week | N/A |

---

## Part 5: Monitoring Scripts

### 5.1 Complete Health Check Script

**Save as:** `health-check.sh`

```bash
#!/bin/bash
set -e

NAMESPACE=$1
ACCOUNT_ID=$2
CLICKHOUSE_HOST=$3
CLICKHOUSE_USER=$4
CLICKHOUSE_PASS=$5

echo "=== UnitEconPro Health Check ==="
echo "Namespace: $NAMESPACE"
echo "Account: $ACCOUNT_ID"
echo ""

# 1. CronJob Status
echo "1. Checking CronJobs..."
FAILED_JOBS=$(kubectl get jobs -n $NAMESPACE -o json | jq -r '.items[] | select(.status.failed > 0) | .metadata.name' | wc -l)
if [ $FAILED_JOBS -gt 0 ]; then
  echo "❌ $FAILED_JOBS failed jobs found"
else
  echo "✅ All jobs successful"
fi

# 2. Data Freshness
echo ""
echo "2. Checking data freshness..."
DATA_AGE=$(curl -s "http://$CLICKHOUSE_HOST:8123/?user=$CLICKHOUSE_USER&password=$CLICKHOUSE_PASS" \
  --data "SELECT dateDiff('hour', max(usage_start_date), now()) FROM cost.service_costs WHERE account_id=$ACCOUNT_ID")
if [ $DATA_AGE -gt 48 ]; then
  echo "❌ Data is $DATA_AGE hours old"
else
  echo "✅ Data is fresh ($DATA_AGE hours old)"
fi

# 3. ClickHouse Health
echo ""
echo "3. Checking ClickHouse..."
CH_RESPONSE=$(curl -s "http://$CLICKHOUSE_HOST:8123/?user=$CLICKHOUSE_USER&password=$CLICKHOUSE_PASS" --data "SELECT 1")
if [ "$CH_RESPONSE" == "1" ]; then
  echo "✅ ClickHouse responding"
else
  echo "❌ ClickHouse not responding"
fi

# 4. Pod Health
echo ""
echo "4. Checking pods..."
RESTART_COUNT=$(kubectl get pods -n $NAMESPACE -o json | jq -r '.items[].status.containerStatuses[]?.restartCount' | awk '{s+=$1} END {print s}')
if [ $RESTART_COUNT -gt 10 ]; then
  echo "⚠️  High restart count: $RESTART_COUNT"
else
  echo "✅ Pod restarts normal: $RESTART_COUNT"
fi

# 5. PVC Disk Pressure
echo ""
echo "5. Checking ClickHouse disk usage..."
CLICKHOUSE_POD=$(kubectl get pods -n $NAMESPACE -l app=clickhouse -o jsonpath='{.items[0].metadata.name}')
DISK_USAGE=$(kubectl exec -it $CLICKHOUSE_POD -n $NAMESPACE -- df -h /var/lib/clickhouse | tail -1 | awk '{print $5}' | sed 's/%//')
if [ $DISK_USAGE -gt 85 ]; then
  echo "❌ CRITICAL: Disk usage at ${DISK_USAGE}% - ClickHouse crash risk!"
else
  echo "✅ Disk usage healthy: ${DISK_USAGE}%"
fi

echo ""
echo "=== Health Check Complete ==="
```

**Usage:**
```bash
./health-check.sh uniteconpro-acme 123456789012 clickhouse.local dba secretPassword
```

---

### 5.2 Cost Anomaly Detection Script

**Save as:** `check-cost-anomaly.sh`

```bash
#!/bin/bash
CLICKHOUSE_HOST=$1
CLICKHOUSE_USER=$2
CLICKHOUSE_PASS=$3
ACCOUNT_ID=$4
THRESHOLD=30

QUERY="
WITH daily_costs AS (
    SELECT 
        toDate(usage_start_date) AS date,
        sum(unblended_cost) AS cost
    FROM cost.service_costs
    WHERE account_id=$ACCOUNT_ID
      AND usage_start_date >= today() - 7
    GROUP BY date
)
SELECT 
    date,
    round(cost, 2) AS cost,
    round((cost - lagInFrame(cost) OVER (ORDER BY date)) / lagInFrame(cost) OVER (ORDER BY date) * 100, 2) AS pct_change
FROM daily_costs
WHERE pct_change > $THRESHOLD
ORDER BY date DESC
FORMAT JSONCompact
"

RESULT=$(curl -s "http://$CLICKHOUSE_HOST:8123/?user=$CLICKHOUSE_USER&password=$CLICKHOUSE_PASS" --data "$QUERY")

if [ "$RESULT" != '{"meta":[],"data":[],"rows":0}' ]; then
  echo "⚠️  Cost anomaly detected for account $ACCOUNT_ID:"
  echo "$RESULT" | jq -r '.data[] | "Date: \(.[0]) | Cost: $\(.[1]) | Change: \(.[2])%"'
else
  echo "✅ No cost anomalies detected"
fi
```

**Usage:**
```bash
./check-cost-anomaly.sh clickhouse.local dba secretPassword 123456789012
```

---

## Part 6: Grafana Alerting Setup

### 6.1 Create Alert Rules

**Navigate to:** Grafana → Alerting → Alert rules → New alert rule

**Alert 1: Data Freshness**
- **Name:** Data Age > 48 Hours
- **Query:**
  ```sql
  SELECT dateDiff('hour', max(usage_start_date), now()) AS hours
  FROM cost.service_costs
  WHERE account_id = ${account_id}
  ```
- **Condition:** `hours > 48`
- **Severity:** High
- **Notification:** Email + Slack

**Alert 2: Daily Cost Spike**
- **Name:** Cost Increase > 30%
- **Query:**
  ```sql
  WITH daily AS (
      SELECT toDate(usage_start_date) AS d, sum(unblended_cost) AS c
      FROM cost.service_costs
      WHERE account_id = ${account_id} AND d >= today() - 2
      GROUP BY d
  )
  SELECT (c - lag(c) OVER (ORDER BY d)) / lag(c) OVER (ORDER BY d) * 100 AS pct
  FROM daily
  ORDER BY d DESC LIMIT 1
  ```
- **Condition:** `pct > 30`
- **Severity:** Medium
- **Notification:** Email

**Alert 3: Git Sync Failure**
- **Name:** Grafana Git Sync Disconnected
- **Check:** Manual verification in Grafana UI (Administration → Provisioning → Git Sync)
- **Condition:** Status = Red/Disconnected OR Last Sync > 15 minutes
- **Severity:** High
- **Notification:** Email + Slack
- **Action:** Check GitHub token expiry (SOP-002 Section 2.5)

---

## Troubleshooting

### Issue: False positive alerts

**Symptom:** Alerts triggering during expected maintenance

**Fix:** Set maintenance windows in Grafana alerting

### Issue: Missing data not detected

**Symptom:** Data gap but no alert

**Check:** Verify alert rule query returns correct values

### Issue: Alert fatigue

**Symptom:** Too many low-priority alerts

**Fix:** Adjust thresholds, group similar alerts, use notification policies



