# Implementation SOP: Adding GCP/Azure to UnitEconPro
## Step-by-Step Manual for Implementing New Cloud Providers

**Version:** 1.0  
**Last Updated:** January 2025  
**Purpose:** Practical guide to implement GCP/Azure support in UnitEconPro  
**Time:** 1-2 days per cloud provider

---

## 🎯 What This SOP Does

This is your **implementation checklist** - follow it step-by-step to add GCP or Azure support to UnitEconPro.

**You will:**
1. Create config files
2. Write Python code for extractor and transformer
3. Test with real data
4. Deploy and validate

**Prerequisites:**
- [ ] Python knowledge
- [ ] Access to GCP/Azure account with billing enabled
- [ ] UnitEconPro running locally
- [ ] 1-2 days of focused work time

---

## 📋 Implementation Checklist

Use this to track your progress:

### GCP Implementation
- [ ] Phase 1: Research & Setup 
- [ ] Phase 2: Config Files 
- [ ] Phase 3: Extractor Code 
- [ ] Phase 4: Transformer Code 
- [ ] Phase 5: Integration 
- [ ] Phase 6: Testing 
- [ ] Phase 7: Documentation 

### Azure Implementation
- [ ] Phase 1: Research & Setup 
- [ ] Phase 2: Config Files 
- [ ] Phase 3: Extractor Code 
- [ ] Phase 4: Transformer Code 
- [ ] Phase 5: Integration 
- [ ] Phase 6: Testing 
- [ ] Phase 7: Documentation 

---

## 🚀 PHASE 1: Research & Setup 

### Step 1.1: Enable Billing Export

**For GCP:**
```bash
# 1. Go to GCP Console → Billing → Billing Export
# 2. Enable "BigQuery Export"
# 3. Create dataset: billing_export
# 4. Wait 24 hours for data
```

**For Azure:**
```bash
# 1. Go to Azure Portal → Cost Management → Exports
# 2. Create daily export to Storage Account
# 3. Format: CSV, Container: cost-exports
# 4. Wait 24 hours for data
```

### Step 1.2: Query Sample Data

**For GCP:**
```sql
-- In BigQuery console, run:
SELECT 
  project.id,
  service.description,
  usage_start_time,
  cost,
  labels
FROM `your-project.billing_export.gcp_billing_export_*`
WHERE _TABLE_SUFFIX >= FORMAT_DATE('%Y%m%d', DATE_SUB(CURRENT_DATE(), INTERVAL 7 DAY))
LIMIT 10;
```

**For Azure:**
```bash
# Download sample CSV from Storage Account
az storage blob download \
  --account-name youraccount \
  --container-name cost-exports \
  --name uniteconpro/export.csv \
  --file sample.csv

# Open sample.csv and note column names
```

### Step 1.3: Document Available Fields

Create a file: `notes_{cloud}_fields.txt`

**Example for GCP:**
```
Available fields in BigQuery:
- project.id → account_id
- usage_start_time → usage_start_ts
- usage_end_time → usage_end_ts
- service.description → product_code
- cost → cost_unblended
- location.region → region
- labels.env → tag_env
- labels.team → tag_team
```

**Example for Azure:**
```
Available fields in CSV:
- SubscriptionId → account_id
- Date → usage_start_ts
- ServiceName → product_code
- Cost → cost_unblended
- ResourceLocation → region
- Tags → parse to tag_*
```

✅ **Checkpoint:** You have sample data and know which fields exist.

---

## 📝 PHASE 2: Config Files

### Step 2.1: Create Directory Structure

```bash
cd /home/harshitverma/UnitEconPro

# For GCP
mkdir -p app/config/gcp
mkdir -p app/engine/gcp

# For Azure
mkdir -p app/config/azure
mkdir -p app/engine/azure
```

### Step 2.2: Create Column Mapping

**File:** `app/config/gcp/column_mapping.json`

```json
{
  "project.id": "account_id",
  "usage_start_time": "usage_start_ts",
  "usage_end_time": "usage_end_ts",
  "service.description": "product_code",
  "sku.description": "operation",
  "resource.name": "resource_id",
  "usage.amount": "usage_qty",
  "cost": "cost_unblended",
  "location.region": "region",
  "system_labels.compute_instance_type": "instance_type"
}
```

**File:** `app/config/azure/column_mapping.json`

```json
{
  "SubscriptionId": "account_id",
  "Date": "usage_start_ts",
  "Date": "usage_end_ts",
  "ServiceName": "product_code",
  "MeterCategory": "operation",
  "ResourceId": "resource_id",
  "Quantity": "usage_qty",
  "Cost": "cost_unblended",
  "ResourceLocation": "region",
  "MeterName": "usage_type"
}
```

### Step 2.3: Create Service Config

**File:** `app/config/gcp/config.yml`

```yaml
gcp:
  service_mapping:
    compute:
      product_code: Compute Engine
      operation_filter: null
    storage:
      product_code: Cloud Storage
      operation_filter: null
    bigquery:
      product_code: BigQuery
      operation_filter: null
  
  bigquery:
    columns:
      - project.id
      - usage_start_time
      - usage_end_time
      - service.description
      - sku.description
      - resource.name
      - usage.amount
      - cost
      - location.region
      - labels.env
      - labels.team
      - labels.app
    
    queries:
      - service: compute
        enabled: true
        sql: |
          SELECT {{ columns | join(', ') }}
          FROM `{{ project_id }}.{{ dataset }}.{{ table }}_*`
          WHERE _TABLE_SUFFIX >= FORMAT_DATE('%Y%m%d', DATE '{{ start_date_str }}')
            AND _TABLE_SUFFIX < FORMAT_DATE('%Y%m%d', DATE '{{ end_date_str }}')
            AND service.description = 'Compute Engine'
  
  tag_mapping:
    common_tags:
      env: labels.env
      team: labels.team
      app: labels.app
    extract_all_user_tags: true
```

**File:** `app/config/azure/config.yml`

```yaml
azure:
  service_mapping:
    virtualmachines:
      product_code: Virtual Machines
      operation_filter: null
    storage:
      product_code: Storage
      operation_filter: null
  
  storage:
    columns:
      - SubscriptionId
      - Date
      - ServiceName
      - MeterCategory
      - ResourceId
      - Quantity
      - Cost
      - ResourceLocation
      - Tags
    
    queries:
      - service: virtualmachines
        enabled: true
        # Azure uses CSV files, not SQL
  
  tag_mapping:
    common_tags:
      env: Tags.Environment
      team: Tags.Team
      app: Tags.Application
    extract_all_user_tags: true
```

✅ **Checkpoint:** Config files created with correct field mappings.

---

## 💻 PHASE 3: Extractor Code 

### Step 3.1: Install Dependencies

```bash
cd /home/harshitverma/UnitEconPro

# For GCP
pip install google-cloud-bigquery

# For Azure
pip install azure-storage-blob azure-identity

# Update requirements.txt
echo "google-cloud-bigquery>=3.0.0" >> app/requirements.txt
echo "azure-storage-blob>=12.0.0" >> app/requirements.txt
echo "azure-identity>=1.12.0" >> app/requirements.txt
```

### Step 3.2: Create GCP Extractor

**File:** `app/engine/gcp_engine.py`

```python
import logging
import os
from typing import List, Dict, Any
from google.cloud import bigquery
from .engine import BaseEngine

logger = logging.getLogger(__name__)

class GCPBigQueryEngine(BaseEngine):
    """
    Extractor for GCP billing data from BigQuery.
    """
    
    def __init__(self, project_id: str, credentials_path: str):
        self.project_id = project_id
        self.credentials_path = credentials_path
        self.client = None
    
    def connection(self):
        """Establish connection to BigQuery."""
        try:
            os.environ['GOOGLE_APPLICATION_CREDENTIALS'] = self.credentials_path
            self.client = bigquery.Client(project=self.project_id)
            logger.info(f"Connected to GCP BigQuery project: {self.project_id}")
        except Exception as e:
            logger.error(f"Failed to connect to BigQuery: {e}")
            raise
    
    def fetch(self, query: str) -> List[Dict[str, Any]]:
        """
        Execute BigQuery query and return results.
        
        Args:
            query: SQL query string
        
        Returns:
            List of dictionaries with billing data
        """
        try:
            logger.info("Executing BigQuery query...")
            query_job = self.client.query(query)
            results = query_job.result()
            
            # Convert to list of dicts
            data = []
            for row in results:
                data.append(dict(row))
            
            logger.info(f"Fetched {len(data)} rows from BigQuery")
            return data
        except Exception as e:
            logger.error(f"BigQuery query failed: {e}")
            raise
    
    def ingest(self, data: List[Dict]):
        """Not used - handled by DataManager."""
        pass
    
    def save(self, data: List[Dict], table: str):
        """Not used - handled by ClickHouseEngine."""
        pass
```

### Step 3.3: Create Azure Extractor

**File:** `app/engine/azure_engine.py`

```python
import logging
import csv
import io
from typing import List, Dict, Any
from azure.storage.blob import BlobServiceClient
from azure.identity import ClientSecretCredential
from .engine import BaseEngine

logger = logging.getLogger(__name__)

class AzureStorageEngine(BaseEngine):
    """
    Extractor for Azure billing data from Storage Account.
    """
    
    def __init__(self, storage_account: str, container: str, tenant_id: str, 
                 client_id: str, client_secret: str):
        self.storage_account = storage_account
        self.container = container
        self.credential = ClientSecretCredential(tenant_id, client_id, client_secret)
        self.blob_service_client = None
    
    def connection(self):
        """Establish connection to Azure Storage."""
        try:
            account_url = f"https://{self.storage_account}.blob.core.windows.net"
            self.blob_service_client = BlobServiceClient(
                account_url=account_url,
                credential=self.credential
            )
            logger.info(f"Connected to Azure Storage: {self.storage_account}")
        except Exception as e:
            logger.error(f"Failed to connect to Azure Storage: {e}")
            raise
    
    def fetch(self, blob_path: str) -> List[Dict[str, Any]]:
        """
        Download and parse CSV from Azure Storage.
        
        Args:
            blob_path: Path to CSV file in container
        
        Returns:
            List of dictionaries with billing data
        """
        try:
            logger.info(f"Downloading blob: {blob_path}")
            container_client = self.blob_service_client.get_container_client(self.container)
            blob_client = container_client.get_blob_client(blob_path)
            
            # Download blob content
            blob_data = blob_client.download_blob().readall()
            
            # Parse CSV
            csv_content = blob_data.decode('utf-8')
            csv_reader = csv.DictReader(io.StringIO(csv_content))
            
            data = list(csv_reader)
            logger.info(f"Parsed {len(data)} rows from CSV")
            return data
        except Exception as e:
            logger.error(f"Failed to fetch Azure data: {e}")
            raise
    
    def ingest(self, data: List[Dict]):
        """Not used - handled by DataManager."""
        pass
    
    def save(self, data: List[Dict], table: str):
        """Not used - handled by ClickHouseEngine."""
        pass
```

✅ **Checkpoint:** Extractor code written and can connect to cloud provider.

---

## 🔄 PHASE 4: Transformer Code 

### Step 4.1: Create GCP Transformer

**File:** `app/engine/gcp/transformer.py`

```python
import logging
from datetime import datetime
from typing import Dict, Any, Optional
from ..transformer_base import Transformer

logger = logging.getLogger(__name__)

class GCPToClickHouseTransformer(Transformer):
    """
    Transforms GCP BigQuery billing data to ClickHouse schema.
    """
    
    DATETIME_COLUMNS = {
        "usage_start_time",
        "usage_end_time"
    }
    
    FLOAT_COLUMNS = {
        "cost",
        "usage.amount"
    }
    
    def __init__(self, mapping: Dict[str, str], tag_mapping: Optional[Dict] = None):
        super().__init__(mapping)
        self.tag_mapping = tag_mapping or {}
        self.common_tags = self.tag_mapping.get('common_tags', {})
    
    def parse_datetime(self, value: Optional[str]) -> Optional[datetime]:
        """Parse GCP datetime (ISO 8601 format)."""
        if not value:
            return None
        try:
            # GCP uses ISO 8601: 2025-01-15T00:00:00Z
            dt = datetime.fromisoformat(value.replace('Z', '+00:00'))
            return dt.replace(tzinfo=None)  # Remove timezone for ClickHouse
        except ValueError:
            logger.warning(f"Invalid datetime: {value}")
            return None
    
    def extract_tags(self, row: Dict[str, Any]) -> tuple:
        """Extract GCP labels."""
        common = {}
        extra = {}
        
        # Extract common tags from labels
        for tag_name, column_name in self.common_tags.items():
            # GCP labels are like: labels.env, labels.team
            value = row.get(column_name, '').strip() if row.get(column_name) else ''
            common[tag_name] = value
        
        # Extract all other labels
        for key, value in row.items():
            if key.startswith('labels.'):
                label_name = key.replace('labels.', '')
                if label_name not in ['env', 'team', 'app']:
                    if value and str(value).strip():
                        extra[label_name] = str(value).strip()
        
        return common, extra
    
    def transform(self, row: Dict[str, Any]) -> Dict[str, Any]:
        """Transform single row from GCP to ClickHouse format."""
        transformed = {}
        
        # Map columns
        for src_col, target_col in self.mapping.items():
            val = row.get(src_col)
            
            if src_col in self.DATETIME_COLUMNS:
                transformed[target_col] = self.parse_datetime(val)
            elif src_col in self.FLOAT_COLUMNS:
                try:
                    transformed[target_col] = float(val)
                except (TypeError, ValueError):
                    transformed[target_col] = 0.0
            else:
                transformed[target_col] = str(val).strip() if val else ""
        
        # Extract tags
        common_tags, extra_tags = self.extract_tags(row)
        
        # Add cloud-agnostic tag fields
        transformed["tag_env"] = common_tags.get('env', '')
        transformed["tag_team"] = common_tags.get('team', '')
        transformed["tag_app"] = common_tags.get('app', '')
        transformed["tags_map"] = extra_tags
        
        # GCP-specific fields
        transformed["autoscaling_group_name"] = ""
        transformed["scaling_type"] = "Static"
        
        return transformed
```

### Step 4.2: Create Azure Transformer

**File:** `app/engine/azure/transformer.py`

```python
import logging
import json
from datetime import datetime
from typing import Dict, Any, Optional
from ..transformer_base import Transformer

logger = logging.getLogger(__name__)

class AzureToClickHouseTransformer(Transformer):
    """
    Transforms Azure CSV billing data to ClickHouse schema.
    """
    
    DATETIME_COLUMNS = {
        "Date"
    }
    
    FLOAT_COLUMNS = {
        "Cost",
        "Quantity"
    }
    
    def __init__(self, mapping: Dict[str, str], tag_mapping: Optional[Dict] = None):
        super().__init__(mapping)
        self.tag_mapping = tag_mapping or {}
        self.common_tags = self.tag_mapping.get('common_tags', {})
    
    def parse_datetime(self, value: Optional[str]) -> Optional[datetime]:
        """Parse Azure datetime."""
        if not value:
            return None
        try:
            # Azure CSV format: 2025-01-15
            dt = datetime.strptime(value, "%Y-%m-%d")
            return dt
        except ValueError:
            logger.warning(f"Invalid datetime: {value}")
            return None
    
    def extract_tags(self, row: Dict[str, Any]) -> tuple:
        """Extract Azure tags from Tags column."""
        common = {}
        extra = {}
        
        # Azure tags are in JSON format in Tags column
        tags_str = row.get('Tags', '{}')
        try:
            tags = json.loads(tags_str) if tags_str else {}
        except json.JSONDecodeError:
            tags = {}
        
        # Extract common tags
        common['env'] = tags.get('Environment', '')
        common['team'] = tags.get('Team', '')
        common['app'] = tags.get('Application', '')
        
        # Extract extra tags
        for key, value in tags.items():
            if key not in ['Environment', 'Team', 'Application']:
                extra[key] = str(value)
        
        return common, extra
    
    def transform(self, row: Dict[str, Any]) -> Dict[str, Any]:
        """Transform single row from Azure to ClickHouse format."""
        transformed = {}
        
        # Map columns
        for src_col, target_col in self.mapping.items():
            val = row.get(src_col)
            
            if src_col in self.DATETIME_COLUMNS:
                transformed[target_col] = self.parse_datetime(val)
            elif src_col in self.FLOAT_COLUMNS:
                try:
                    transformed[target_col] = float(val)
                except (TypeError, ValueError):
                    transformed[target_col] = 0.0
            else:
                transformed[target_col] = str(val).strip() if val else ""
        
        # Azure CSV has same date for start and end
        if 'usage_start_ts' in transformed:
            transformed['usage_end_ts'] = transformed['usage_start_ts']
        
        # Extract tags
        common_tags, extra_tags = self.extract_tags(row)
        
        # Add cloud-agnostic tag fields
        transformed["tag_env"] = common_tags.get('env', '')
        transformed["tag_team"] = common_tags.get('team', '')
        transformed["tag_app"] = common_tags.get('app', '')
        transformed["tags_map"] = extra_tags
        
        # Azure-specific fields
        transformed["autoscaling_group_name"] = ""
        transformed["scaling_type"] = "Static"
        
        return transformed
```

✅ **Checkpoint:** Transformer code written and can map provider fields to ClickHouse.

---

## 🔗 PHASE 5: Integration 

### Step 5.1: Update transform.py

**File:** `app/engine/transform.py`

**CHANGE:** Add GCP/Azure transformer imports and cases

```python
# EXISTING CODE (keep as-is):
import json
import os
import yaml
from engine.aws.transformer import AthenaToClickHouseTransformer
from engine.transformer_base import Transformer

# ADD THESE NEW IMPORTS:
from engine.gcp.transformer import GCPToClickHouseTransformer
from engine.azure.transformer import AzureToClickHouseTransformer

def get_transformer_for_cloud(cloud: str) -> Transformer:
    # EXISTING CODE (keep as-is):
    base_dir = os.path.dirname(os.path.abspath(__file__)) 
    mapping_path = os.path.join(base_dir, "..", "config", cloud, "column_mapping.json")
    config_path = os.path.join(base_dir, "..", "config", cloud, "config.yml")

    if not os.path.exists(mapping_path):
        raise FileNotFoundError(f"Column mapping file not found: {mapping_path}")

    with open(mapping_path, "r") as f:
        mapping = json.load(f)
    
    # Load tag mapping from config
    tag_mapping = {}
    if os.path.exists(config_path):
        with open(config_path, "r") as f:
            config = yaml.safe_load(f)
            tag_mapping = config.get(cloud, {}).get('tag_mapping', {})

    # EXISTING AWS CASE (keep as-is):
    if cloud == "aws":
        return AthenaToClickHouseTransformer(mapping, tag_mapping)
    
    # ADD THESE NEW CASES:
    elif cloud == "gcp":
        return GCPToClickHouseTransformer(mapping, tag_mapping)
    elif cloud == "azure":
        return AzureToClickHouseTransformer(mapping, tag_mapping)
    
    # EXISTING ERROR (keep as-is):
    else:
        raise ValueError(f"Unsupported cloud provider: {cloud}")
```

---

### Step 5.2: Update data_manager.py

**File:** `app/engine/data_manager.py`

**CHANGE 1:** Modify `__init__` method to support GCP/Azure

```python
# FIND THIS LINE (around line 18):
class CloudToClickHouseIngestor:
    def __init__(self, cloud: str, config: dict, ch_engine: ClickHouseEngine):
        self.cloud = cloud
        self.config = config
        
        # REPLACE THIS LINE:
        # self.queries = config[cloud]["athena"]["queries"]
        
        # WITH THIS:
        if cloud == "aws":
            self.queries = config[cloud]["athena"]["queries"]
        elif cloud == "gcp":
            self.queries = config[cloud]["bigquery"]["queries"]
        elif cloud == "azure":
            self.queries = config[cloud]["storage"]["queries"]
        else:
            self.queries = []
        
        # REPLACE THIS BLOCK:
        # self.source = AthenaEngine(
        #     database=os.getenv("ATHENA_DATABASE"),
        #     output_location=os.getenv("ATHENA_OUTPUT_LOCATION"),
        #     region_name=os.getenv("AWS_REGION")
        # )
        
        # WITH THIS:
        if cloud == "aws":
            self.source = AthenaEngine(
                database=os.getenv("ATHENA_DATABASE"),
                output_location=os.getenv("ATHENA_OUTPUT_LOCATION"),
                region_name=os.getenv("AWS_REGION")
            )
        elif cloud == "gcp":
            from engine.gcp_engine import GCPBigQueryEngine
            self.source = GCPBigQueryEngine(
                project_id=os.getenv("GCP_PROJECT_ID"),
                credentials_path=os.getenv("GCP_SERVICE_ACCOUNT_KEY")
            )
        elif cloud == "azure":
            from engine.azure_engine import AzureStorageEngine
            self.source = AzureStorageEngine(
                storage_account=os.getenv("AZURE_STORAGE_ACCOUNT"),
                container=os.getenv("AZURE_STORAGE_CONTAINER"),
                tenant_id=os.getenv("AZURE_TENANT_ID"),
                client_id=os.getenv("AZURE_CLIENT_ID"),
                client_secret=os.getenv("AZURE_CLIENT_SECRET")
            )
        
        # KEEP REST OF __init__ AS-IS:
        self.target = ch_engine
        self.transformer = get_transformer_for_cloud(cloud)
        # ... etc
```

**CHANGE 2:** Update `_render_query` method for GCP/Azure

```python
# FIND THIS METHOD around line 300):
def _render_query(self, service: str, start_date: datetime.date, end_date: datetime.date, account_id) -> str:
    # EXISTING CODE (keep as-is):
    query_obj = next((q for q in self.queries if q["service"] == service and q.get("enabled", True)), None)

    if not query_obj:
        logger.warning(f"No enabled query found for service: {service}")
        return ""

    # EXISTING CODE (keep as-is):
    columns = self.config[self.cloud]["athena"].get("columns", []) if self.cloud == "aws" else []
    columns_str = ", ".join(columns) if columns else "*"
    
    template = query_obj["sql"]
    
    # REPLACE THIS BLOCK:
    # rendered = (
    #     template.replace("{{ database }}", os.getenv("ATHENA_DATABASE"))
    #             .replace("{{ table }}", os.getenv("ATHENA_TABLE"))
    #             .replace("{{ start_date_str }}", str(start_date))
    #             .replace("{{ end_date_str }}", str(end_date))
    #             .replace("{{ columns | join(', ') }}", columns_str)
    #             .replace("{{ account_id }}", str(account_id))  
    # )
    
    # WITH THIS:
    if self.cloud == "aws":
        rendered = (
            template.replace("{{ database }}", os.getenv("ATHENA_DATABASE"))
                    .replace("{{ table }}", os.getenv("ATHENA_TABLE"))
                    .replace("{{ start_date_str }}", str(start_date))
                    .replace("{{ end_date_str }}", str(end_date))
                    .replace("{{ columns | join(', ') }}", columns_str)
                    .replace("{{ account_id }}", str(account_id))  
        )
    elif self.cloud == "gcp":
        rendered = (
            template.replace("{{ project_id }}", os.getenv("GCP_PROJECT_ID"))
                    .replace("{{ dataset }}", os.getenv("GCP_BILLING_DATASET"))
                    .replace("{{ table }}", os.getenv("GCP_BILLING_TABLE"))
                    .replace("{{ start_date_str }}", str(start_date))
                    .replace("{{ end_date_str }}", str(end_date))
                    .replace("{{ columns | join(', ') }}", columns_str)
        )
    elif self.cloud == "azure":
        # Azure uses CSV files, not SQL queries
        rendered = f"{os.getenv('AZURE_STORAGE_PATH')}{start_date.strftime('%Y%m%d')}.csv"
    
    return rendered
```

---

### Step 5.3: Update utils.py

**File:** `app/utils.py`

**CHANGE:** Update allowed_clouds list

```python
# FIND THIS LINE (around line 10):
allowed_clouds = ['aws', 'gcp', 'azure']

# ALREADY CORRECT! No changes needed.
# But verify it includes 'gcp' and 'azure'
```

---

### Step 5.4: Update .env

**File:** `.env`

**ADD:** GCP and Azure credentials

```bash
# EXISTING AWS CONFIG (keep as-is):
AWS_REGION=ap-south-1
AWS_ACCESS_KEY_ID=...
AWS_SECRET_ACCESS_KEY=...
ATHENA_DATABASE=athenacurcfn_cur_report007
ATHENA_TABLE=cur_report007
ATHENA_OUTPUT_LOCATION=s3://cur-queries001/

# ADD THESE NEW SECTIONS:

# ============================================
# GCP Configuration
# ============================================
GCP_PROJECT_ID=your-project-id
GCP_SERVICE_ACCOUNT_KEY=/home/harshitverma/UnitEconPro/gcp-service-account.json
GCP_BILLING_DATASET=billing_export
GCP_BILLING_TABLE=gcp_billing_export

# ============================================
# Azure Configuration
# ============================================
AZURE_TENANT_ID=xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
AZURE_CLIENT_ID=xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
AZURE_CLIENT_SECRET=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
AZURE_SUBSCRIPTION_ID=xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
AZURE_STORAGE_ACCOUNT=yourstorageaccount
AZURE_STORAGE_CONTAINER=cost-exports
AZURE_STORAGE_PATH=uniteconpro/
```

---

### Step 5.5: Update .env.example

**File:** `.env.example`

**ADD:** Template for GCP/Azure credentials

```bash
# EXISTING AWS SECTION (keep as-is):
# AWS
AWS_REGION=ap-south-1
AWS_ACCESS_KEY_ID=YOUR_ACCESS_KEY
AWS_SECRET_ACCESS_KEY=YOUR_SECRET_KEY
ATHENA_DATABASE=athenacurcfn_cur_report007
ATHENA_TABLE=cur_report007
ATHENA_OUTPUT_S3=s3://your-athena-output-bucket/

# ADD THESE NEW SECTIONS:

# GCP (optional - only if using GCP)
GCP_PROJECT_ID=your-gcp-project-id
GCP_SERVICE_ACCOUNT_KEY=/path/to/gcp-service-account.json
GCP_BILLING_DATASET=billing_export
GCP_BILLING_TABLE=gcp_billing_export

# Azure (optional - only if using Azure)
AZURE_TENANT_ID=your-tenant-id
AZURE_CLIENT_ID=your-client-id
AZURE_CLIENT_SECRET=your-client-secret
AZURE_SUBSCRIPTION_ID=your-subscription-id
AZURE_STORAGE_ACCOUNT=your-storage-account
AZURE_STORAGE_CONTAINER=cost-exports
AZURE_STORAGE_PATH=uniteconpro/
```

---

### Step 5.6: Create __init__.py files

**IMPORTANT:** Python needs these files to recognize directories as packages.

```bash
# Create empty __init__.py files
touch app/engine/gcp/__init__.py
touch app/engine/azure/__init__.py
```

---

### Step 5.7: Update requirements.txt

**File:** `app/requirements.txt`

**ADD:** New dependencies at the end

```bash
# EXISTING DEPENDENCIES (keep as-is):
# boto3==1.26.137
# clickhouse-connect==0.6.8
# ... etc

# ADD THESE NEW LINES:

# GCP dependencies
google-cloud-bigquery>=3.0.0
google-auth>=2.0.0

# Azure dependencies
azure-storage-blob>=12.0.0
azure-identity>=1.12.0
```

---

### Step 5.8: Summary of All File Changes

**Files to CREATE (new):**
- ✅ `app/config/gcp/config.yml`
- ✅ `app/config/gcp/column_mapping.json`
- ✅ `app/config/azure/config.yml`
- ✅ `app/config/azure/column_mapping.json`
- ✅ `app/engine/gcp_engine.py`
- ✅ `app/engine/azure_engine.py`
- ✅ `app/engine/gcp/transformer.py`
- ✅ `app/engine/azure/transformer.py`
- ✅ `app/engine/gcp/__init__.py`
- ✅ `app/engine/azure/__init__.py`

**Files to MODIFY (existing):**
- ✅ `app/engine/transform.py` - Add GCP/Azure imports and cases
- ✅ `app/engine/data_manager.py` - Add GCP/Azure engine initialization
- ✅ `app/utils.py` - Verify allowed_clouds includes gcp/azure
- ✅ `.env` - Add GCP/Azure credentials
- ✅ `.env.example` - Add GCP/Azure templates
- ✅ `app/requirements.txt` - Add google-cloud-bigquery, azure-storage-blob

**Files to KEEP AS-IS (no changes):**
- ✅ `app/app.py` - Already supports --cloud parameter
- ✅ `app/engine/clickhouse.py` - Cloud-agnostic
- ✅ `clickhouse-init/init.sql` - Cloud-agnostic schema
- ✅ `app/engine/engine.py` - Base class, no changes
- ✅ `app/engine/transformer_base.py` - Base class, no changes

✅ **Checkpoint:** All code integrated and ready to test.

---

## 🧪 PHASE 6: Testing 
### Step 6.1: Test GCP Connection

```bash
cd /home/harshitverma/UnitEconPro

# Test BigQuery connection
python3 -c "
from engine.gcp_engine import GCPBigQueryEngine
import os
from dotenv import load_dotenv
load_dotenv()

engine = GCPBigQueryEngine(
    project_id=os.getenv('GCP_PROJECT_ID'),
    credentials_path=os.getenv('GCP_SERVICE_ACCOUNT_KEY')
)
engine.connection()
print('✅ GCP connection successful!')
"
```

### Step 6.2: Test Azure Connection

```bash
# Test Azure Storage connection
python3 -c "
from engine.azure_engine import AzureStorageEngine
import os
from dotenv import load_dotenv
load_dotenv()

engine = AzureStorageEngine(
    storage_account=os.getenv('AZURE_STORAGE_ACCOUNT'),
    container=os.getenv('AZURE_STORAGE_CONTAINER'),
    tenant_id=os.getenv('AZURE_TENANT_ID'),
    client_id=os.getenv('AZURE_CLIENT_ID'),
    client_secret=os.getenv('AZURE_CLIENT_SECRET')
)
engine.connection()
print('✅ Azure connection successful!')
"
```

### Step 6.3: Test Small Ingestion

```bash
# Add account to ClickHouse first
docker exec -it clickhouse clickhouse-client --user dba --password secretPassword

# For GCP
INSERT INTO cost.account_map VALUES ('your-gcp-project', 'gcp-test', 'dev', 'platform');

# For Azure
INSERT INTO cost.account_map VALUES ('your-azure-sub-id', 'azure-test', 'dev', 'platform');
exit;

# Test ingestion (1 day only)
python3 app/app.py --mode refresh_days --days 1 --service compute --cloud gcp
python3 app/app.py --mode refresh_days --days 1 --service virtualmachines --cloud azure
```

### Step 6.4: Validate Data

```sql
-- Check GCP data
SELECT COUNT(*), SUM(cost_unblended) 
FROM cost.service_costs 
WHERE account_id = 'your-gcp-project';

-- Check Azure data
SELECT COUNT(*), SUM(cost_unblended) 
FROM cost.service_costs 
WHERE account_id = 'your-azure-sub-id';
```

### Step 6.5: Full Ingestion

```bash
# If test successful, run full ingestion
python3 app/app.py --mode refresh_days --days 7 --service all --cloud gcp
python3 app/app.py --mode refresh_days --days 7 --service all --cloud azure
```

✅ **Checkpoint:** Data successfully ingested and visible in ClickHouse.

---

## 📖 PHASE 7: Documentation 
### Step 7.1: Update Provider SOPs

Update these files with real steps:
- `docs/GCP_PROJECT_ONBOARDING_SOP.md`
- `docs/AZURE_SUBSCRIPTION_ONBOARDING_SOP.md`

Change status from "🚧 COMING SOON" to "✅ Production Ready"

### Step 7.2: Update Main README

**File:** `README.md`

Update cloud support section:

```markdown
## Supported Cloud Providers

| Cloud | Status | Services |
|-------|--------|----------|
| AWS | ✅ Production | EC2, EBS, S3, RDS, VPC, CloudWatch, EKS, ECS, ECR, ELB |
| GCP | ✅ Production | Compute Engine, Cloud Storage, BigQuery |
| Azure | ✅ Production | Virtual Machines, Storage, SQL Database |
```

### Step 7.3: Create Migration Guide

Document any breaking changes or migration steps for existing users.

✅ **Checkpoint:** Documentation updated and complete.

---

## ✅ Final Checklist

Before considering implementation complete:

### Code Quality
- [ ] All Python files have proper imports
- [ ] Error handling in place
- [ ] Logging statements added
- [ ] Code follows existing patterns

### Testing
- [ ] Connection tests pass
- [ ] Small ingestion works
- [ ] Full ingestion works
- [ ] Data matches cloud console (within 5%)
- [ ] Tags/labels captured correctly

### Documentation
- [ ] Provider SOP updated
- [ ] README updated
- [ ] .env.example updated
- [ ] Comments in code

### Deployment
- [ ] Code committed to git
- [ ] Dependencies in requirements.txt
- [ ] Credentials secured (not in git)
- [ ] Team notified

---

## 🆘 Troubleshooting

### Import Errors
```bash
# Make sure __init__.py exists
touch app/engine/gcp/__init__.py
touch app/engine/azure/__init__.py
```

### Authentication Failures
```bash
# Test credentials with cloud CLI first
gcloud auth application-default login  # GCP
az login  # Azure
```

### No Data Ingested
```sql
-- Check logs
SELECT * FROM cost.ingestion_log 
WHERE cloud IN ('gcp', 'azure') 
ORDER BY started_at DESC;
```

### Schema Mismatches
```python
# Print raw data before transformation
print(f"Raw row: {row}")
transformed = transformer.transform(row)
print(f"Transformed: {transformed}")
```

---

## 📊 Time Tracking

Use this to track your actual time:

| Phase | Estimated | Actual | Notes |
|-------|-----------|--------|-------|
| Research & Setup | 2h | | |
| Config Files | 1h | | |
| Extractor Code | 2h | | |
| Transformer Code | 2h | | |
| Integration | 1h | | |
| Testing | 2h | | |
| Documentation | 1h | | |
| **Total** | **11h** | | |

---

## 🎯 Success Criteria

You're done when:

1. ✅ `python3 app/app.py --cloud gcp` works
2. ✅ `python3 app/app.py --cloud azure` works
3. ✅ Data appears in ClickHouse
4. ✅ Costs match cloud console
5. ✅ Grafana shows multi-cloud data
6. ✅ Documentation updated

---

**Ready to start?** Begin with Phase 1 and work through systematically. Good luck! 🚀

**Questions during implementation?** Refer to existing AWS code in:
- `app/engine/athena.py` (extractor example)
- `app/engine/aws/transformer.py` (transformer example)
- `app/config/aws/config.yml` (config example)

