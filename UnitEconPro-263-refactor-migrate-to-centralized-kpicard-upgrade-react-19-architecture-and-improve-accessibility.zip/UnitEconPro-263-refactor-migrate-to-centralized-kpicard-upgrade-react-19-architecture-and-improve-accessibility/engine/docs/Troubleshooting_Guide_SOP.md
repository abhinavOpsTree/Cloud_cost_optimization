

## Purpose

This SOP provides step-by-step troubleshooting procedures for common production issues, root cause analysis, and resolution steps with decision trees for quick diagnosis.

---

## Quick Diagnosis Decision Tree

```
Issue Reported
├── No Data in Dashboards
│   ├── Check CronJob Status → Section 1.1
│   ├── Check ClickHouse Connection → Section 1.2
│   └── Check AWS Credentials → Section 1.3
├── Dashboard Won't Load
│   ├── Check Grafana Pod Status → Section 2.1
│   ├── Check Git Sync Status → Section 2.2
│   └── Check Load Balancer → Section 2.3
├── Slow Performance
│   ├── Check ClickHouse Queries → Section 3.1
│   ├── Check Resource Usage → Section 3.2
│   └── Check Disk Space → Section 3.3
└── Authentication Issues
    ├── Check Azure AD Config → Section 4.1
    ├── Check Secret Expiry → Section 4.2
    └── Check Network Access → Section 4.3
```

---

## Section 1: Data Issues

### 1.1 Missing Data / No Recent Ingestion

**Symptoms:**
- Dashboards show "No data" or stale data
- Latest data > 48 hours old
- Empty cost metrics

**Diagnosis Steps:**

**Step 1: Check CronJob Status**
```bash
# Kubernetes
kubectl get cronjobs -n <NAMESPACE>
kubectl get jobs -n <NAMESPACE> --sort-by=.metadata.creationTimestamp

# ECS
aws events list-rules --name-prefix unitecon-daily
aws ecs list-tasks --cluster <CLUSTER> --service-name ingestion-service
```

**Step 2: Check Recent Job Logs**
```bash
# Kubernetes
kubectl logs job/<LATEST_JOB> -n <NAMESPACE> --tail=100

# ECS - List log streams first to find the right one
aws logs describe-log-streams \
  --log-group-name /ecs/unitecon-ingestion-<CLIENT> \
  --order-by LastEventTime \
  --descending \
  --limit 1

# Then tail that specific stream
aws logs get-log-events \
  --log-group-name /ecs/unitecon-ingestion-<CLIENT> \
  --log-stream-name <STREAM_NAME_FROM_ABOVE>
```

**Common Error Patterns:**

| Error Message | Root Cause | Solution |
|---------------|------------|----------|
| `AccessDenied: User: arn:aws:iam::xxx` | AWS credentials expired/invalid | Update AWS secret (SOP-002 Section 2.3) |
| `INVALID_QUERY: line 1:8: Table 'xxx' doesn't exist` | Athena table missing | Check AWS CUR setup |
| `Connection refused` | ClickHouse unreachable | Check ClickHouse status (Section 1.2) |
| `Authentication failed` | ClickHouse password wrong | Update ClickHouse secret (SOP-002 Section 2.4) |

**Resolution:**
```bash
# Force manual job run (Kubernetes)
kubectl create job --from=cronjob/<CRONJOB_NAME> manual-test-$(date +%s) -n <NAMESPACE>

# Force manual task run (ECS)
aws ecs run-task \
  --cluster <CLUSTER> \
  --task-definition <TASK_DEF> \
  --launch-type FARGATE \
  --network-configuration "awsvpcConfiguration={subnets=[subnet-xxx],securityGroups=[sg-xxx]}"
```

---

### 1.2 ClickHouse Connection Issues

**Symptoms:**
- Grafana datasource test fails
- "Database connection error" in logs
- Queries timeout

**Diagnosis Steps:**

**Step 1: Test ClickHouse Connectivity**
```bash
# From local machine
curl "http://<CLICKHOUSE_HOST>:8123/?user=<USER>&password=<PASSWORD>" --data "SELECT 1"

# From Grafana pod (Kubernetes)
kubectl exec -it <GRAFANA_POD> -n <NAMESPACE> -- \
  curl "http://<CLICKHOUSE_HOST>:8123/?user=<USER>&password=<PASSWORD>" --data "SELECT 1"

# From ECS task
aws ecs execute-command \
  --cluster <CLUSTER> \
  --task <TASK_ID> \
  --container grafana \
  --interactive \
  --command "curl http://<CLICKHOUSE_HOST>:8123/ping"
```

**Expected Response:** `1` or `Ok.`

**Step 2: Check ClickHouse Status**
```bash
# If ClickHouse is in Docker
docker ps | grep clickhouse
docker logs clickhouse --tail=50

# Check ClickHouse processes
docker exec -it clickhouse clickhouse-client --user dba --password secretPassword -q "SHOW PROCESSLIST"
```

**Step 3: Verify Database and User**
```sql
-- Connect as admin
docker exec -it clickhouse clickhouse-client --user dba --password secretPassword

-- Check if database exists
SHOW DATABASES;

-- Check if user exists
SELECT name FROM system.users WHERE name = '<CLIENT_USER>';

-- Check user permissions
SHOW GRANTS FOR <CLIENT_USER>;
```

**Common Issues:**

| Issue | Symptoms | Solution |
|-------|----------|----------|
| User doesn't exist | `Authentication failed` | Create user: `CREATE USER <name> IDENTIFIED BY '<password>'` |
| No database access | `Database doesn't exist` | Grant access: `GRANT ALL ON cost.* TO <user>` |
| Wrong password | `Authentication failed` | Reset: `ALTER USER <name> IDENTIFIED BY '<new_password>'` |
| Network unreachable | `Connection refused` | Check firewall/security groups |

---

### 1.3 AWS Athena Query Failures

**Symptoms:**
- Ingestion job fails with Athena errors
- "Table not found" errors
- "Access denied" to S3 bucket

**Diagnosis Steps:**

**Step 1: Test AWS Credentials**
```bash
# From ingestion pod/task
aws sts get-caller-identity
aws s3 ls s3://<CUR_BUCKET>/
aws athena list-databases --catalog-name AwsDataCatalog
```

**Step 2: Check CUR Table**
```bash
aws athena start-query-execution \
  --query-string "SHOW TABLES IN <DATABASE>" \
  --result-configuration "OutputLocation=s3://<RESULTS_BUCKET>/" \
  --work-group primary
```

**Step 3: Test Sample Query**
```sql
SELECT account_id, line_item_usage_start_date, line_item_unblended_cost
FROM <CUR_TABLE>
WHERE line_item_usage_start_date >= current_date - interval '1' day
LIMIT 10;
```

**Common Issues:**

| Error | Cause | Solution |
|-------|-------|---------|
| `Table xxx doesn't exist` | CUR not configured | Enable AWS Cost and Usage Report |
| `Access Denied` to S3 | IAM permissions missing | Add `s3:GetObject` permission to CUR bucket |
| `HIVE_PARTITION_SCHEMA_MISMATCH` | CUR schema changed | Run `MSCK REPAIR TABLE <table>` |
| `Query timeout` | Large date range | Reduce query date range |

---

## Section 2: Dashboard Issues

### 2.1 Grafana Pod/Container Not Starting

**Symptoms:**
- Grafana UI unreachable
- Pod in CrashLoopBackOff
- Container exits immediately

**Diagnosis Steps:**

**Step 1: Check Pod Status (Kubernetes)**
```bash
kubectl get pods -n <NAMESPACE>
kubectl describe pod <GRAFANA_POD> -n <NAMESPACE>
kubectl logs <GRAFANA_POD> -n <NAMESPACE> --tail=100

# Check Init Container Logs (Crucial for startup issues)
kubectl logs <GRAFANA_POD> -c init-grafana -n <NAMESPACE>
kubectl logs <CLICKHOUSE_POD> -c init-clickhouse -n <NAMESPACE>
```

**Step 2: Check Task Status (ECS)**
```bash
aws ecs describe-services --cluster <CLUSTER> --services grafana-service
aws ecs list-tasks --cluster <CLUSTER> --service-name grafana-service
aws ecs describe-tasks --cluster <CLUSTER> --tasks <TASK_ARN>
aws logs tail /ecs/unitecon-grafana-<CLIENT> --since 30m
```

**Common Error Patterns:**

| Log Message | Root Cause | Solution |
|-------------|------------|----------|
| `failed to install plugin` | Plugin download failed | Remove plugin or fix network access |
| `database is locked` | Multiple Grafana instances | Check for duplicate deployments |
| `permission denied` | File system permissions | Check volume mount permissions |
| `secret not found` | Missing Kubernetes secret | Create missing secret (SOP-002) |
| `valueFrom secret not found` | Missing ECS secret | Create in AWS Secrets Manager |

**Resolution Steps:**
```bash
# Kubernetes: Restart deployment
kubectl rollout restart deployment/<GRAFANA_DEPLOYMENT> -n <NAMESPACE>

# ECS: Force new deployment
aws ecs update-service \
  --cluster <CLUSTER> \
  --service grafana-service \
  --force-new-deployment
```

---

### 2.2 Git Sync Not Working

**Symptoms:**
- Dashboards not updating
- Old dashboard versions
- Git Sync status shows "Disconnected"

**Diagnosis Steps:**

**Step 1: Check Git Sync Status (Grafana UI)**
1. Login to Grafana
2. Administration → Provisioning → Git Sync
3. Check status indicator and last sync time

**Step 2: Check Native Git Sync Logs (Kubernetes)**
```bash
# Filter main grafana logs for git sync messages
kubectl logs <GRAFANA_POD> -n <NAMESPACE> | grep -i "git"
# Look for errors like "authentication failed" or "repository not found"
```

**Step 3: Check GitHub Token**
```bash
# Test token manually
curl -H "Authorization: token <GITHUB_TOKEN>" \
  https://api.github.com/repos/<ORG>/<REPO>
```

**Common Issues:**

| Issue | Symptoms | Solution |
|-------|----------|----------|
| Token expired | `401 Unauthorized` | Rotate GitHub token (SOP-002 Section 2.5) |
| Rate limit exceeded | `403 Forbidden` | Wait or use authenticated token |
| Repository not found | `404 Not Found` | Check repo URL and permissions |
| Network blocked | `Connection timeout` | Check firewall/proxy settings |

**Resolution:**
```bash
# Kubernetes: Restart Grafana to reload token
kubectl rollout restart deployment/<GRAFANA_DEPLOYMENT> -n <NAMESPACE>

# ECS: Update secret and restart service
aws secretsmanager update-secret \
  --secret-id production/<CLIENT>/grafana \
  --secret-string '{"GITHUB_TOKEN":"<NEW_TOKEN>"}'

aws ecs update-service --cluster <CLUSTER> --service grafana-service --force-new-deployment
```

---

### 2.3 Load Balancer / Ingress Issues

**Symptoms:**
- Grafana URL returns 502/503/504
- SSL certificate errors
- Timeout errors

**Diagnosis Steps:**

**Step 1: Check Load Balancer Status**
```bash
# Kubernetes (Ingress)
kubectl get ingress -n <NAMESPACE>
kubectl describe ingress <INGRESS_NAME> -n <NAMESPACE>

# ECS (ALB)
aws elbv2 describe-load-balancers --names <ALB_NAME>
aws elbv2 describe-target-health --target-group-arn <TG_ARN>
```

**Step 2: Test Backend Connectivity**
```bash
# Kubernetes: Port forward to bypass ingress
kubectl port-forward svc/<GRAFANA_SERVICE> 3000:80 -n <NAMESPACE>

# ECS: Check target group health
aws elbv2 describe-target-health --target-group-arn <TG_ARN>
```

**Step 3: Check SSL Certificate**
```bash
openssl s_client -connect <DOMAIN>:443 -servername <DOMAIN>
```

**Common Issues:**

| Issue | Symptoms | Solution |
|-------|----------|----------|
| Unhealthy targets | 502 Bad Gateway | Check Grafana health endpoint |
| SSL certificate expired | SSL errors | Renew certificate |
| Security group blocked | Connection timeout | Allow port 3000 in security groups |
| DNS not resolving | Name resolution failed | Check DNS records |

---

## Section 3: Performance Issues

### 3.1 Slow Dashboard Queries

**Symptoms:**
- Dashboards take > 10 seconds to load
- Query timeout errors
- High CPU on ClickHouse

**Diagnosis Steps:**

**Step 1: Identify Slow Queries**
```sql
SELECT 
    query_id,
    user,
    query_duration_ms,
    read_rows,
    formatReadableSize(read_bytes) AS data_read,
    substring(query, 1, 200) AS query_preview
FROM system.query_log
WHERE type = 'QueryFinish'
  AND query_duration_ms > 5000
  AND event_time >= now() - INTERVAL 1 HOUR
ORDER BY query_duration_ms DESC
LIMIT 10;
```

**Step 2: Check Query Patterns**
```sql
-- Look for queries without proper date filters
SELECT query_id, query
FROM system.query_log
WHERE query NOT LIKE '%usage_start_date%'
  AND query LIKE '%service_costs%'
  AND event_time >= now() - INTERVAL 1 HOUR;
```

**Step 3: Analyze Table Statistics**
```sql
SELECT 
    table,
    count() AS parts,
    sum(rows) AS total_rows,
    formatReadableSize(sum(bytes_on_disk)) AS size
FROM system.parts
WHERE database = 'cost' AND active = 1
GROUP BY table;
```

**Optimization Actions:**

| Issue | Solution |
|-------|----------|
| Missing date filters | Add `WHERE usage_start_date >= ...` to all queries |
| Too many partitions | Run autocorrect to merge partitions |
| Large time ranges | Limit dashboard default time range |
| Missing indexes | Add `ORDER BY` clause to table definition |

---

### 3.2 High Resource Usage

**Symptoms:**
- Pod/container OOMKilled
- High CPU usage
- Slow response times

**Diagnosis Steps:**

**Step 1: Check Resource Usage**
```bash
# Kubernetes
kubectl top pods -n <NAMESPACE>
kubectl describe pod <POD_NAME> -n <NAMESPACE> | grep -A 5 "Limits\|Requests"

# ECS
aws ecs describe-services --cluster <CLUSTER> --services <SERVICE>
aws cloudwatch get-metric-statistics \
  --namespace AWS/ECS \
  --metric-name CPUUtilization \
  --dimensions Name=ServiceName,Value=<SERVICE> \
  --start-time $(date -u -d '1 hour ago' +%Y-%m-%dT%H:%M:%S) \
  --end-time $(date -u +%Y-%m-%dT%H:%M:%S) \
  --period 300 \
  --statistics Average
```

**Step 2: Check Memory Usage Patterns**
```bash
# Look for memory leaks in logs
kubectl logs <POD_NAME> -n <NAMESPACE> | grep -i "memory\|oom"
```

**Resolution:**
```yaml
# Increase resource limits (Kubernetes)
resources:
  limits:
    memory: "2Gi"
    cpu: "1000m"
  requests:
    memory: "1Gi"
    cpu: "500m"
```

```json
// Increase task resources (ECS)
{
  "cpu": "1024",
  "memory": "2048"
}
```

---

### 3.3 Disk Space Issues

**Symptoms:**
- ClickHouse crashes
- "No space left on device" errors
- Write failures

**Diagnosis Steps:**

**Step 1: Check Disk Usage**
```bash
# ClickHouse container
docker exec -it clickhouse df -h /var/lib/clickhouse

# Kubernetes PVC
kubectl exec -it <CLICKHOUSE_POD> -n <NAMESPACE> -- df -h /var/lib/clickhouse

# ECS EFS
kubectl exec -it <POD> -n <NAMESPACE> -- df -h /var/lib/grafana
```

**Step 2: Check ClickHouse Disk Usage**
```sql
SELECT 
    database,
    table,
    formatReadableSize(sum(bytes_on_disk)) AS size,
    count() AS parts
FROM system.parts
WHERE active = 1
GROUP BY database, table
ORDER BY sum(bytes_on_disk) DESC;
```

**Step 3: Identify Large Partitions**
```sql
SELECT 
    partition,
    formatReadableSize(sum(bytes_on_disk)) AS size,
    count() AS parts,
    min(min_date) AS oldest_date,
    max(max_date) AS newest_date
FROM system.parts
WHERE database = 'cost' AND table = 'service_costs' AND active = 1
GROUP BY partition
ORDER BY sum(bytes_on_disk) DESC
LIMIT 10;
```

**Resolution:**
```bash
# Clean old partitions (be careful!)
ALTER TABLE cost.service_costs DROP PARTITION '2024-01-01';

# Optimize table to merge parts
OPTIMIZE TABLE cost.service_costs;

# Increase PVC size (Kubernetes)
kubectl patch pvc <PVC_NAME> -p '{"spec":{"resources":{"requests":{"storage":"100Gi"}}}}'
```

---

## Section 4: Authentication Issues

### 4.1 Azure AD Login Failures

**Symptoms:**
- "Login failed" errors
- Redirect loops
- "Invalid client" errors

**Diagnosis Steps:**

**Step 1: Check Azure AD Configuration**
```bash
# Check Grafana config
kubectl get configmap <GRAFANA_CONFIG> -n <NAMESPACE> -o yaml | grep -A 10 azuread
```

**Step 2: Test Azure AD App Registration**
```bash
# Check app registration exists
az ad app list --display-name "UnitEconPro-<CLIENT>"

# Check redirect URIs
az ad app show --id <CLIENT_ID> --query "web.redirectUris"
```

**Step 3: Check Secret Expiry**
```bash
az ad app credential list --id <CLIENT_ID>
```

**Common Issues:**

| Error | Cause | Solution |
|-------|-------|---------|
| `invalid_client` | Client ID wrong | Verify client ID in Azure Portal |
| `invalid_client_secret` | Secret expired | Rotate secret (SOP-002 Section 2.2) |
| `redirect_uri_mismatch` | Wrong redirect URI | Update in Azure AD app registration |
| `invalid_scope` | Wrong permissions | Add required Graph API permissions |

---

### 4.2 Secret Expiry Issues

**Symptoms:**
- Authentication suddenly stops working
- "Unauthorized" errors
- Token validation failures

**Diagnosis Steps:**

**Step 1: Check Secret Age**
```bash
# Kubernetes
kubectl get secret <SECRET_NAME> -n <NAMESPACE> -o jsonpath='{.metadata.creationTimestamp}'

# Calculate age
kubectl get secrets -n <NAMESPACE> -o json | \
jq -r '.items[] | "\(.metadata.name) \(.metadata.creationTimestamp)"' | \
while read name timestamp; do
  age_days=$(( ($(date +%s) - $(date -d "$timestamp" +%s)) / 86400 ))
  echo "$name: $age_days days old"
done
```

**Step 2: Test Credentials**
```bash
# Test Azure AD secret
curl -X POST https://login.microsoftonline.com/<TENANT_ID>/oauth2/v2.0/token \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "client_id=<CLIENT_ID>&client_secret=<CLIENT_SECRET>&scope=https://graph.microsoft.com/.default&grant_type=client_credentials"

# Test GitHub token
curl -H "Authorization: token <GITHUB_TOKEN>" https://api.github.com/user
```

**Resolution:**
Follow SOP-002 for secret rotation procedures.

---

## Emergency Procedures

### Complete System Outage

**Step 1: Immediate Assessment**
```bash
# Check all critical components
kubectl get pods -n <NAMESPACE>
curl -I https://<GRAFANA_URL>
curl "http://<CLICKHOUSE_HOST>:8123/ping"
```

**Step 2: Identify Root Cause**
- Check recent deployments
- Review monitoring alerts
- Check infrastructure changes

**Step 3: Rollback if Needed**
```bash
# Kubernetes rollback
kubectl rollout undo deployment/<DEPLOYMENT> -n <NAMESPACE>

# ECS rollback
aws ecs update-service \
  --cluster <CLUSTER> \
  --service <SERVICE> \
  --task-definition <PREVIOUS_TASK_DEF>
```

### Data Corruption Recovery

**Step 1: Stop Ingestion**
```bash
# Kubernetes
kubectl patch cronjob <CRONJOB> -p '{"spec":{"suspend":true}}' -n <NAMESPACE>

# ECS
aws events disable-rule --name <RULE_NAME>
```

**Step 2: Backup Current State**
```sql
-- Export affected data
SELECT * FROM cost.service_costs 
WHERE usage_start_date >= '<AFFECTED_DATE>'
INTO OUTFILE '/tmp/backup.csv'
FORMAT CSV;
```

**Step 3: Restore from Backup**
```sql
-- Drop corrupted partition
ALTER TABLE cost.service_costs DROP PARTITION '<PARTITION>';

-- Re-run ingestion for affected period
```
