# Deployment Guide - UnitEconPro

## 🚀 Quick Start on Ubuntu

### Prerequisites
```bash
sudo apt update
sudo apt install -y git docker.io docker-compose python3 python3-pip python3-venv
sudo usermod -aG docker $USER
newgrp docker
```

### Clone and Setup
```bash
# Clone from private repo
git clone https://github.com/<your-org>/UnitEconPro.git
cd UnitEconPro

# Configure environment
cp .env.example .env
nano .env  # Fill in real credentials

# Start ClickHouse and Grafana
docker-compose up -d

# Verify ClickHouse is running
docker exec clickhouse clickhouse-client --user dba --password secretPassword -q "SHOW DATABASES"
```

### Run Application
```bash
# Create virtual environment
python3 -m venv venv
source venv/bin/activate
pip install -r app/requirements.txt

# Test daily ingestion
cd app
python app.py --mode ingest_daily --cloud aws --service ec2

# Test new refresh_days feature
python app.py --mode refresh_days --days 3 --service ec2 --cloud aws
```

---

## 📋 Available Modes

### 1. Daily Ingestion
```bash
python app.py --mode ingest_daily --cloud aws --service all
```

### 2. Autocorrect (Weekly Partition Refresh)
```bash
python app.py --mode autocorrect --cloud aws --service all
```

### 3. Refresh Days (NEW FEATURE)
```bash
# Refresh last 3 days
python app.py --mode refresh_days --days 3 --service ec2 --cloud aws

# Refresh last 7 days for all services
python app.py --mode refresh_days --days 7 --service all --cloud aws
```

### 4. Retry Failed
```bash
python app.py --mode ingest_daily --retry --cloud aws --service all
```

---

## 🧪 Testing Commands

### Test 1: Minimal Test (Single Service, 1 Day)
```bash
python app.py --mode refresh_days --days 1 --service ec2 --cloud aws
```

### Test 2: Verify Data in ClickHouse
```bash
docker exec -it clickhouse clickhouse-client --user dba --password secretPassword

# Check record count
SELECT 
    toDate(usage_start_ts) as date,
    service,
    COUNT(*) as records,
    SUM(cost) as total_cost
FROM cost.service_costs
WHERE toDate(usage_start_ts) >= today() - 3
GROUP BY date, service
ORDER BY date DESC;
```

### Test 3: Check Grafana
```
1. Open http://localhost:3000
2. Login: admin / admin
3. Check EC2 Cost Analytics dashboard
4. Verify data for last 3 days
```

---

## 🐳 Docker Deployment

### Build Image
```bash
cd app
docker build -t uniteconpro:latest .
```

### Run in Docker
```bash
docker run -it --rm \
  --env-file ../.env \
  uniteconpro:latest \
  python app.py --mode refresh_days --days 3 --service ec2 --cloud aws
```

---

## ☸️ Kubernetes Deployment

### Deploy with Helm
```bash
cd helm-chart

# Update values.yaml with your config
nano values.yaml

# Install
helm install uniteconpro . --namespace uniteconpro --create-namespace

# Check status
kubectl get cronjobs -n uniteconpro
kubectl get pods -n uniteconpro
```

### Manual Pod Deployment
```bash
# Update deployment files
cd deployment/opstree

# Apply
kubectl apply -f config.yaml
kubectl apply -f pod.yml

# Check logs
kubectl logs -n uniteconpro <pod-name> --tail=100
```

---

## 🔧 Troubleshooting

### ClickHouse Connection Issues
```bash
# Check if ClickHouse is running
docker ps | grep clickhouse

# Check logs
docker logs clickhouse

# Restart ClickHouse
docker-compose restart clickhouse
```

### Database Not Found
```bash
# Create database manually
docker exec -it clickhouse clickhouse-client --user dba --password secretPassword

CREATE DATABASE IF NOT EXISTS cost;
SHOW DATABASES;
```

### Table Not Found
```bash
# Run init script
docker exec -i clickhouse clickhouse-client --user dba --password secretPassword < clickhouse-init/init.sql
```

---

## 📊 Monitoring

### Check Ingestion Logs
```sql
SELECT 
    cloud,
    service,
    run_date,
    status,
    started_at,
    error_message
FROM cost.ingestion_log
WHERE run_date >= today() - 7
ORDER BY started_at DESC
LIMIT 20;
```

### Check Data Volume
```sql
SELECT 
    service,
    COUNT(*) as records,
    SUM(cost) as total_cost,
    min(usage_start_ts) as first_date,
    max(usage_start_ts) as last_date
FROM cost.service_costs
GROUP BY service;
```

---

## 🔐 Security Notes

- Never commit `.env` file (already in .gitignore)
- Use IAM roles in production instead of access keys
- Rotate credentials regularly
- Use Kubernetes secrets for sensitive data

---

## 📝 Production Checklist

- [ ] Update `.env` with production credentials
- [ ] Test in dev/staging first
- [ ] Start with small scope (--days 1 --service ec2)
- [ ] Monitor ClickHouse disk space
- [ ] Set up alerts for failed ingestions
- [ ] Schedule refresh_days during off-hours
- [ ] Document rollback procedure
- [ ] Notify team before first production run
