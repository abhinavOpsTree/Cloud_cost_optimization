import logging
from engine.clickhouse import ClickHouseEngine
from engine.anomaly_detector import AnomalyDetector

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format='[%(asctime)s] %(levelname)s - %(message)s')
    print("Testing Z-Score Anomaly Detection Pipeline manually...")
    ch = ClickHouseEngine()
    ch.connection()
    detector = AnomalyDetector(ch)
    detector.run_daily_detection()
