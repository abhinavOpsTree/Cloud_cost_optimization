import yaml  # type: ignore
import os
from dotenv import load_dotenv  # type: ignore

def load_config(cloud: str):
    """
    Load config YAML from app/config/{cloud}/config.yml.
    Environment variables are loaded from .env if it exists in CWD or parent dirs.
    No substitution into YAML — use os.getenv() in code.
    """
    # Validate cloud parameter to prevent path traversal
    allowed_clouds = ['aws', 'gcp', 'azure']
    if cloud not in allowed_clouds:
        raise ValueError(f"Invalid cloud provider: {cloud}. Allowed: {allowed_clouds}")
    
    # Load .env from current working directory or its parents
    load_dotenv(override=True)

    # Build path to YAML config (safe after validation)
    base_dir = os.path.dirname(os.path.abspath(__file__))
    config_path = os.path.join(base_dir, "config", cloud, "config.yml")
    
    # Verify the resolved path is within expected directory
    config_dir = os.path.join(base_dir, "config")
    if not os.path.abspath(config_path).startswith(os.path.abspath(config_dir)):
        raise ValueError(f"Invalid config path: {config_path}")

    if not os.path.exists(config_path):
        raise FileNotFoundError(f"Config file not found at {config_path}")

    try:
        with open(config_path, "r") as f:
            return yaml.safe_load(f)
    except yaml.YAMLError as e:
        raise ValueError(f"Invalid YAML in {config_path}: {e}")
    except Exception as e:
        raise IOError(f"Failed to load config from {config_path}: {e}")





