import argparse
import logging
import os
import boto3
from datetime import datetime, timedelta, timezone
from engine.data_manager import CloudToClickHouseIngestor
from engine.aws.ecr_metadata import ECRMetadataExtractor
from engine.aws.eks_metadata import EKSMetadataExtractor
from engine.aws.ecs_metadata import ECSMetadataExtractor
from engine.aws.ec2_metadata import EC2MetadataExtractor
from engine.aws.ebs_metadata import EBSMetadataExtractor
from engine.aws.s3_metadata import S3MetadataExtractor
from engine.aws.rds_metadata import RDSMetadataExtractor
from engine.aws.vpc_metadata import VPCMetadataExtractor
from engine.aws.elb_metadata import ELBMetadataExtractor
from utils import load_config
from engine.clickhouse import ClickHouseEngine
from engine.security import decrypt_string
from engine.athena import AthenaEngine
from dotenv import load_dotenv  # type: ignore

load_dotenv()


logging.basicConfig(
    format='[%(asctime)s] %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)


def _is_clickhouse_connectivity_error(exc: Exception) -> bool:
    msg = str(exc)
    markers = [
        "No route to host",
        "Connection refused",
        "Max retries exceeded",
        "HTTPConnectionPool",
        "Read timed out",
        "SESSION_IS_LOCKED",
    ]
    return any(m in msg for m in markers)


ch_client = None

raw_users = os.getenv("ALLOWED_USERS_FOR_OVERRIDE", "")
ALLOWED_USERS_FOR_OVERRIDE = {u.strip() for u in raw_users.split(",") if u.strip()}


def parse_args():
    parser = argparse.ArgumentParser(description="Data pipeline CLI")

    parser.add_argument(
        "--mode",
        choices=["ingest_daily", "autocorrect", "refresh_days", "vm_utilization", "metadata_only"],
        required=True,
        help="Mode to run: 'ingest_daily' (backfill), 'autocorrect' (weekly fix), 'refresh_days' (near-realtime refresh), or 'vm_utilization' (find underutilized VMs)"
    )

    parser.add_argument(
        "--cloud",
        choices=["aws", "gcp", "azure"],
        required=True,
        help="Cloud provider"
    )

    parser.add_argument(
        "--start-date",
        type=str,
        help="Start date for ingestion in YYYY-MM-DD format (optional for ingest_daily, defaults to yesterday)"
    )

    parser.add_argument(
        "--end-date",
        type=str,
        help="End date for ingestion in YYYY-MM-DD format (optional for ingest_daily, defaults to today)"
    )

    parser.add_argument(
        "--service",
        type=str,
        default="all",
        help="Service name for ingestion (default: all). Use 'all' to ingest all services."
    )

    parser.add_argument(
        "--days",
        type=int,
        default=1,
        help="Number of past days to refresh with latest AWS CUR data (default: 1 for yesterday). Use with refresh_days mode to handle incomplete/updating data."
    )

    parser.add_argument(
        "--force-autocorrect",
        action="store_true",
        help="Force run autocorrect even if today is not Sunday (allowed users only)"
    )

    parser.add_argument(
        "--account-id",
        type=int, nargs='*',
        help="(Optional) Specific account ID to run autocorrect for"
    )

    return parser.parse_args()


def get_enabled_services(config, cloud):
    try:
        queries = config[cloud]["athena"].get("queries", [])
        return [q["service"] for q in queries if q.get("enabled", False)]
    except Exception as e:
        logger.error(f"Failed to retrieve enabled services: {e}")
        return []

def get_active_accounts(ch_client):
    try:
        query = """
            SELECT account_name, aws_account_id, access_key_id, secret_access_key, 
                   athena_database, athena_table, athena_bucket, aws_region
            FROM cost.accounts FINAL
            WHERE is_deleted = 0 AND upper(status) = 'ACTIVE'
        """
        rows = ch_client.client.query(query).result_rows
        return rows
    except Exception as e:
        logger.error(f"Failed to fetch accounts from DB: {e}")
        return []


def update_account_status(ch_client, aws_account_id: str, status: str, error_msg: str = ""):
    """Update account status and last_error in ClickHouse."""
    _VALID_STATUSES = {"ACTIVE", "ERROR", "INACTIVE", "PENDING"}
    if status not in _VALID_STATUSES:
        raise ValueError(f"Invalid status: {status!r}")
    if not aws_account_id.isdigit():
        raise ValueError(f"Invalid account ID: {aws_account_id!r}")
    db = os.getenv("CLICKHOUSE_DATABASE", "cost")
    now = datetime.now(timezone.utc).strftime('%Y-%m-%d %H:%M:%S')
    escaped_error = str(error_msg).replace("\\", "\\\\").replace("'", "''")
    try:
        ch_client.client.command(
            f"ALTER TABLE {db}.accounts UPDATE status = '{status}', "
            f"last_error = '{escaped_error}', last_validated = '{now}' "
            f"WHERE aws_account_id = '{aws_account_id}'"
        )
        logger.info(f"Account {aws_account_id} status updated to '{status}'")
    except Exception as e:
        logger.warning(f"Could not update account status for {aws_account_id}: {e}")

def get_account_permissions(ch_client, account_id: str) -> dict:
    """Fetches all permissions for an account in ONE network call."""
    try:
        rows = ch_client.client.query(
            "SELECT service, enabled FROM cost.account_service_permissions FINAL "
            "WHERE account_id = {account_id:String}",
            parameters={"account_id": account_id},
        ).result_rows
        return {row[0]: (row[1] == 1) for row in rows}
    except Exception as e:
        logger.warning(f"[Permissions] bulk check failed for {account_id}: {e}")
        return {}

def _run_metadata_extractors(ch_client, access_key, secret_key, acc_name, aws_acc_id, aws_region, cloud, permissions_map):
    """
    Run all enabled metadata extractors for one account.
    Called from both ingest_daily and refresh_days modes to avoid duplication.
    Scans ALL AWS regions for ECR/EKS resources.
    """
    if cloud != "aws":
        return

    logger.info(f"\n{'─'*80}\n Starting metadata extraction for Account: {acc_name} ({aws_acc_id})\n{'─'*80}")

    # Create boto3 session once
    if access_key == 'STS_MANAGED':
        base_session = boto3.Session()
    else:
        base_session = boto3.Session(
            aws_access_key_id=access_key,
            aws_secret_access_key=secret_key,
        )

    # Get all AWS regions to scan
    try:
        ec2 = base_session.client('ec2', region_name='us-east-1')
        all_regions = [region['RegionName'] for region in ec2.describe_regions()['Regions']]
        logger.info(f"[Metadata] Scanning {len(all_regions)} AWS regions for resources...")
    except Exception as e:
        logger.warning(f"[Metadata] Could not fetch region list, falling back to default region {aws_region}: {e}")
        all_regions = [aws_region]


    if permissions_map.get("ecr", False):
        logger.info(f"[Metadata] Starting ECR metadata extraction for '{acc_name}'...")
        for region in all_regions:
            try:
                if access_key == 'STS_MANAGED':
                    regional_session = boto3.Session(region_name=region)
                else:
                    regional_session = boto3.Session(
                        aws_access_key_id=access_key,
                        aws_secret_access_key=secret_key,
                        region_name=region,
                    )
                
                ecr_extractor = ECRMetadataExtractor(ch_client)
                ecr_extractor.ingest(
                    session=regional_session,
                    account_id=aws_acc_id,
                    account_name=acc_name,
                    region=region,
                )
            except Exception as ecr_err:
                logger.warning(
                    f"ECR metadata ingestion failed for '{acc_name}' in {region} (non-fatal): {ecr_err}",
                    exc_info=False,
                )
    else:
        logger.info(f"[Permissions] ECR metadata is DISABLED for '{acc_name}' — skipping.")


    if permissions_map.get("eks", False):
        logger.info(f"[Metadata] Starting EKS metadata extraction for '{acc_name}'...")
        for region in all_regions:
            try:
                if access_key == 'STS_MANAGED':
                    regional_session = boto3.Session(region_name=region)
                else:
                    regional_session = boto3.Session(
                        aws_access_key_id=access_key,
                        aws_secret_access_key=secret_key,
                        region_name=region,
                    )
                
                eks_extractor = EKSMetadataExtractor(ch_client)
                eks_extractor.ingest(
                    session=regional_session,
                    account_id=aws_acc_id,
                    account_name=acc_name,
                    region=region,
                )
            except Exception as eks_err:
                logger.warning(
                    f"EKS metadata ingestion failed for '{acc_name}' in {region} (non-fatal): {eks_err}",
                    exc_info=False,
                )
    else:
        logger.info(f"[Permissions] EKS metadata is DISABLED for '{acc_name}' — skipping.")

    if permissions_map.get("ecs", False):
        logger.info(f"[Metadata] Starting ECS metadata extraction for '{acc_name}'...")
        for region in all_regions:
            try:
                if access_key == 'STS_MANAGED':
                    regional_session = boto3.Session(region_name=region)
                else:
                    regional_session = boto3.Session(
                        aws_access_key_id=access_key,
                        aws_secret_access_key=secret_key,
                        region_name=region,
                    )
                ECSMetadataExtractor(ch_client).ingest(
                    session=regional_session,
                    account_id=aws_acc_id,
                    account_name=acc_name,
                    region=region,
                )
            except Exception as ecs_err:
                logger.warning(
                    f"ECS metadata ingestion failed for '{acc_name}' in {region} (non-fatal): {ecs_err}",
                    exc_info=False,
                )
    else:
        logger.info(f"[Permissions] ECS metadata is DISABLED for '{acc_name}' — skipping.")

    if permissions_map.get("ec2", False):
        logger.info(f"[Metadata] Starting EC2 metadata extraction for '{acc_name}'...")
        for region in all_regions:
            try:
                if access_key == 'STS_MANAGED':
                    regional_session = boto3.Session(region_name=region)
                else:
                    regional_session = boto3.Session(
                        aws_access_key_id=access_key,
                        aws_secret_access_key=secret_key,
                        region_name=region,
                    )

                EC2MetadataExtractor(ch_client).ingest(
                    session=regional_session,
                    account_id=aws_acc_id,
                    account_name=acc_name,
                    region=region,
                )
            except Exception as ec2_err:
                logger.warning(
                    f"EC2 metadata ingestion failed for '{acc_name}' in {region} (non-fatal): {ec2_err}",
                    exc_info=False,
                )
    else:
        logger.info(f"[Permissions] EC2 metadata is DISABLED for '{acc_name}' — skipping.")

    # EBS Metadata - scan all regions
    if permissions_map.get("ebs", False):
        logger.info(f"[Metadata] Starting EBS metadata extraction for '{acc_name}'...")
        for region in all_regions:
            try:
                if access_key == 'STS_MANAGED':
                    regional_session = boto3.Session(region_name=region)
                else:
                    regional_session = boto3.Session(
                        aws_access_key_id=access_key,
                        aws_secret_access_key=secret_key,
                        region_name=region,
                    )
                EBSMetadataExtractor(ch_client).ingest(
                    session=regional_session,
                    account_id=aws_acc_id,
                    account_name=acc_name,
                    region=region,
                )
            except Exception as ebs_err:
                logger.warning(
                    f"EBS metadata ingestion failed for '{acc_name}' in {region} (non-fatal): {ebs_err}",
                    exc_info=False,
                )
    else:
        logger.info(f"[Permissions] EBS metadata is DISABLED for '{acc_name}' — skipping.")

    
    if permissions_map.get("s3", False):
        logger.info(f"[Metadata] Starting S3 metadata extraction for '{acc_name}'...")
        try:
            if access_key == 'STS_MANAGED':
                s3_session = boto3.Session()
            else:
                s3_session = boto3.Session(
                    aws_access_key_id=access_key,
                    aws_secret_access_key=secret_key,
                )
            S3MetadataExtractor(ch_client).ingest(
                session=s3_session,
                account_id=aws_acc_id,
                account_name=acc_name,
            )
        except Exception as s3_err:
            logger.warning(
                f"S3 metadata ingestion failed for '{acc_name}' (non-fatal): {s3_err}",
                exc_info=False,
            )
    else:
        logger.info(f"[Permissions] S3 metadata is DISABLED for '{acc_name}' — skipping.")

    if permissions_map.get("rds", False):
        logger.info(f"[Metadata] Starting RDS metadata extraction for '{acc_name}'...")
        for region in all_regions:
            try:
                if access_key == 'STS_MANAGED':
                    regional_session = boto3.Session(region_name=region)
                else:
                    regional_session = boto3.Session(
                        aws_access_key_id=access_key,
                        aws_secret_access_key=secret_key,
                        region_name=region,
                    )
                RDSMetadataExtractor(ch_client).ingest(
                    session=regional_session,
                    account_id=aws_acc_id,
                    account_name=acc_name,
                    region=region,
                )
            except Exception as rds_err:
                logger.warning(
                    f"RDS metadata ingestion failed for '{acc_name}' in {region} (non-fatal): {rds_err}",
                    exc_info=False,
                )
    else:
        logger.info(f"[Permissions] RDS metadata is DISABLED for '{acc_name}' — skipping.")

    if permissions_map.get("vpc", False):
        logger.info(f"[Metadata] Starting VPC metadata extraction for '{acc_name}'...")
        for region in all_regions:
            try:
                if access_key == 'STS_MANAGED':
                    regional_session = boto3.Session(region_name=region)
                else:
                    regional_session = boto3.Session(
                        aws_access_key_id=access_key,
                        aws_secret_access_key=secret_key,
                        region_name=region,
                    )
                VPCMetadataExtractor(ch_client).ingest(
                    session=regional_session,
                    account_id=aws_acc_id,
                    account_name=acc_name,
                    region=region,
                )
            except Exception as vpc_err:
                logger.warning(
                    f"VPC metadata ingestion failed for '{acc_name}' in {region} (non-fatal): {vpc_err}",
                    exc_info=False,
                )
    else:
        logger.info(f"[Permissions] VPC metadata is DISABLED for '{acc_name}' — skipping.")

    if permissions_map.get("elb", False):
        logger.info(f"[Metadata] Starting ELB metadata extraction for '{acc_name}'...")
        for region in all_regions:
            try:
                if access_key == 'STS_MANAGED':
                    regional_session = boto3.Session(region_name=region)
                else:
                    regional_session = boto3.Session(
                        aws_access_key_id=access_key,
                        aws_secret_access_key=secret_key,
                        region_name=region,
                    )
                ELBMetadataExtractor(ch_client).ingest(
                    session=regional_session,
                    account_id=aws_acc_id,
                    account_name=acc_name,
                    region=region,
                )
            except Exception as elb_err:
                logger.warning(
                    f"ELB metadata ingestion failed for '{acc_name}' in {region} (non-fatal): {elb_err}",
                    exc_info=False,
                )
    else:
        logger.info(f"[Permissions] ELB metadata is DISABLED for '{acc_name}' — skipping.")

def run_pipeline(ch_client, config, cloud, args, account_row):
    acc_name, aws_acc_id, access_key, enc_secret, athena_db, athena_table, athena_bucket, aws_region = account_row
    secret_key = None  # Defined here so it's always in scope; set below for non-STS accounts
    logger.info(f"\n{'='*80}\nStarting pipeline for Account: {acc_name} ({aws_acc_id})\n{'='*80}")
    
   
    if access_key == 'STS_MANAGED':
        logger.info(f"Account '{acc_name}' uses STS role assumption from environment.")
        athena_engine = AthenaEngine(
            database=athena_db,
            output_location=athena_bucket,
            region_name=aws_region
        )
    else:
        try:
            secret_key = decrypt_string(enc_secret)
        except Exception as e:
            err = f"Credential decryption failed: {e}"
            logger.error(f"{err} for account '{acc_name}'")
            update_account_status(ch_client, aws_acc_id, 'ERROR', err)
            return
        athena_engine = AthenaEngine(
            database=athena_db,
            output_location=athena_bucket,
            region_name=aws_region,
            aws_access_key_id=access_key,
            aws_secret_access_key=secret_key
        )
    
    pipeline = CloudToClickHouseIngestor(
        cloud=cloud, config=config, ch_engine=ch_client,
        athena_engine=athena_engine, athena_database=athena_db,
        athena_table=athena_table, account_id=aws_acc_id
    )
    account_kwargs = {"account_id": aws_acc_id}

    if args.mode == "ingest_daily":
        try:
            end_date = datetime.strptime(args.end_date, "%Y-%m-%d").date() if args.end_date else datetime.today().date()
            start_date = datetime.strptime(args.start_date, "%Y-%m-%d").date() if args.start_date else end_date - timedelta(days=1)
        except ValueError as ve:
            logger.error(f"Invalid date format: {ve}")
            return

        services = get_enabled_services(config, cloud) if args.service == "all" else [args.service]
        if not services:
            logger.warning("No enabled services found for ingestion.")
            return

        failed_services = []
        succeeded_services = []
        for service_name in services:
            logger.info(f" Starting ingestion for '{service_name}' from {start_date} to {end_date}")
            try:
                pipeline.ingest(service_name, start_date, end_date, save_data=True, **account_kwargs)
                logger.info(f" Ingestion completed for '{service_name}'")
                succeeded_services.append(service_name)
            except Exception as e:
                failed_services.append(service_name)
                logger.error(f" Ingestion failed for '{service_name}': {e}", exc_info=True)
        
        if aws_acc_id:
            if not succeeded_services:
                # All services failed — mark account ERROR
                err_summary = f"All services failed: {', '.join(failed_services)}"
                update_account_status(ch_client, aws_acc_id, 'ERROR', err_summary)
            else:
                # At least one service succeeded — keep account ACTIVE so next run can retry failures
                if failed_services:
                    logger.warning(f" Partial ingestion: {len(succeeded_services)} succeeded, {len(failed_services)} failed ({', '.join(failed_services)}). Account stays ACTIVE.")
                update_account_status(ch_client, aws_acc_id, 'ACTIVE')


        permissions_map = get_account_permissions(ch_client, aws_acc_id)
        _run_metadata_extractors(ch_client, access_key, secret_key, acc_name, aws_acc_id, aws_region, cloud, permissions_map)

    elif args.mode == "autocorrect":
        today = datetime.today()
        if today.weekday() != 6 and not args.force_autocorrect:
            logger.info("Today is not Sunday. Skipping autocorrect.")
            return
        elif today.weekday() != 6 and args.force_autocorrect:
            logger.warning("Force auto-correct flag is enabled, executing data refresh although it's not Sunday...")

        services = get_enabled_services(config, cloud) if args.service == "all" else [args.service]
        account_ids = args.account_id if args.account_id else None
        
        if account_row and not account_ids:
             account_ids = [account_kwargs["account_id"]]

        for service_name in services:
            logger.info(f"Refreshing data for service '{service_name}'...")
            try:
                pipeline.autocorrect(current_date=today, service=service_name, account_ids=account_ids)
                logger.info(f"Autocorrect and refresh completed for service '{service_name}'.")
            except Exception as e:
                logger.error(f"Autocorrect failed for service '{service_name}': {e}", exc_info=True)

    elif args.mode == "refresh_days":
        services = get_enabled_services(config, cloud) if args.service == "all" else [args.service]
        connectivity_failed = False
        for service_name in services:
             try:
                 pipeline.refresh_last_n_days(days=args.days, service=service_name)
                 logger.info(f"Refresh completed for service '{service_name}'")
             except Exception as e:
                 logger.error(f"Refresh failed for service '{service_name}': {e}", exc_info=True)
                 if _is_clickhouse_connectivity_error(e):
                     connectivity_failed = True
                     logger.error(
                         "ClickHouse is unreachable during refresh; "
                         "stopping remaining services for this account."
                     )
                     break

        if connectivity_failed:
            return

        permissions_map = get_account_permissions(ch_client, aws_acc_id)
        _run_metadata_extractors(ch_client, access_key, secret_key, acc_name, aws_acc_id, aws_region, cloud, permissions_map)


def main():
    global ch_client
    
    args = parse_args()
    cloud = args.cloud.lower()
    config = load_config(cloud)

    if cloud not in config:
        logger.error(f"Cloud provider '{cloud}' is not supported in config.")
        return

    
    service_mapping = config.get(cloud, {}).get('service_mapping', {})
    ch_client = ClickHouseEngine(service_mapping=service_mapping)
    ch_client.connection()

    if args.mode in ["ingest_daily", "autocorrect", "refresh_days"]:
        accounts = get_active_accounts(ch_client)
        if args.account_id:
            target_ids = {str(i) for i in args.account_id}
            accounts = [acc for acc in accounts if str(acc[1]) in target_ids]
        if not accounts:
            logger.warning("No active accounts found in database. Please add an account via the API/Frontend to begin ingestion.")
            return

        for acc in accounts:
            run_pipeline(ch_client, config, cloud, args, acc)
        if args.mode in ["ingest_daily", "refresh_days"]:
            logger.info("Triggering Z-Score Anomaly Detection...")
            try:
                from engine.anomaly_detector import AnomalyDetector
                detector = AnomalyDetector(ch_client)
                detector.run_daily_detection()
            except Exception as e:
                logger.error(f"Anomaly detection failed: {e}", exc_info=True)

    elif args.mode == "metadata_only":
        """
        Run ONLY metadata extractors (EC2, ECR, EKS, S3) — skips Athena billing ingestion entirely.
        Useful for testing metadata extraction or re-syncing metadata without re-running billing.
        """
        accounts = get_active_accounts(ch_client)
        if not accounts:
            logger.warning("No active accounts found. Please add an account first.")
            return

        for account_row in accounts:
            acc_name, aws_acc_id, access_key, enc_secret, *_ = account_row
            aws_region = account_row[7] if len(account_row) > 7 else "ap-south-1"

            secret_key = None
            if access_key != 'STS_MANAGED':
                try:
                    secret_key = decrypt_string(enc_secret)
                except Exception as e:
                    logger.error(f"Could not decrypt credentials for '{acc_name}': {e}")
                    continue

            permissions_map = get_account_permissions(ch_client, aws_acc_id)
            logger.info(
                f"[metadata_only] Permissions for '{acc_name}': "
                f"ec2={permissions_map.get('ec2')}, "
                f"ecr={permissions_map.get('ecr')}, "
                f"eks={permissions_map.get('eks')}, "
                f"ecs={permissions_map.get('ecs')}, "
                f"ebs={permissions_map.get('ebs')}, "
                f"s3={permissions_map.get('s3')}, "
                f"rds={permissions_map.get('rds')}, "
                f"vpc={permissions_map.get('vpc')}, "
                f"elb={permissions_map.get('elb')}"
            )
            _run_metadata_extractors(
                ch_client, access_key, secret_key,
                acc_name, aws_acc_id, aws_region, cloud, permissions_map
            )

    elif args.mode == "vm_utilization":
        import yaml
        from engine.victoria_metrics import VictoriaMetricsEngine
        from engine.vm_utilization_analyzer import VMUtilizationAnalyzer
        
        logger.info(f"═══════════════════════════════════════════════")
        logger.info(f"  MODE: VM Utilization Analysis")
        logger.info(f"  Cloud: {cloud.upper()}")
        logger.info(f"  Lookback: {args.days} days")
        logger.info(f"═══════════════════════════════════════════════")
        
        try:
           
            obs_config_path = 'app/config/observability.yml'
            if not os.path.exists(obs_config_path):
                logger.error(f"Observability config not found: {obs_config_path}")
                logger.error("Please copy observability.yml.example to observability.yml and configure")
                return
            
            with open(obs_config_path, 'r') as f:
                obs_config = yaml.safe_load(f)
            
          
            vm_config = obs_config['victoria_metrics']
            vm_engine = VictoriaMetricsEngine(
                base_url=vm_config['base_url'],
                username=vm_config.get('username'),
                password=vm_config.get('password')
            )
            
          
            analyzer = VMUtilizationAnalyzer(vm_engine=vm_engine, ch_engine=ch_client)
            
           
            analyzer.create_table()
            
          
            logger.info("\n📊 Querying VictoriaMetrics for VM utilization...")
            analyzer.ingest_daily_metrics(
                provider=cloud,
                lookback_hours=args.days * 24
            )
            
           
            logger.info("\n📈 Generating underutilized VMs report...")
            report = analyzer.get_underutilized_report(days=args.days)
            
          
            if 'error' in report:
                logger.error(f"Report generation failed: {report['error']}")
                return
            
            logger.info(f"\n{'='*70}")
            logger.info(f"  UNDERUTILIZED VMs REPORT")
            logger.info(f"{'='*70}")
            logger.info(f"Total Underutilized VMs: {report['total_underutilized']}")
            logger.info(f"Total Wasted Cost ({args.days}d): ${report['total_wasted_cost']:.2f}")
            logger.info(f"Potential Monthly Savings: ${report['potential_monthly_savings']:.2f}")
            logger.info(f"\n{'='*70}")
            logger.info(f"  TOP 10 UNDERUTILIZED VMs")
            logger.info(f"{'='*70}")
            
            for i, vm in enumerate(report['underutilized_vms'][:10], 1):
                logger.info(f"\n{i}. {vm['resource_id']} ({vm['instance_type'] or 'unknown'})")
                logger.info(f"   CPU: {vm['avg_cpu_percent']:.1f}% | Memory: {vm['avg_mem_percent']:.1f}%")
                logger.info(f"   Score: {vm['utilization_score']:.1f}/100")
                logger.info(f"   Cost ({args.days}d): ${vm[f'total_cost_{args.days}d']:.2f}")
                logger.info(f"   Potential Savings: ${vm['potential_savings']:.2f}")
                logger.info(f"   Reason: {vm['underutilization_reason']}")
            
            logger.info(f"\n{'='*70}")
            logger.info(f"✅ VM utilization analysis complete. View full report in Grafana.")
            logger.info(f"{'='*70}")
            
        except Exception as e:
            logger.error(f"VM utilization analysis failed: {e}", exc_info=True)

    else:
        logger.error(f"Unknown mode: {args.mode}")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        logger.info("\nOperation cancelled by user")
    except Exception as e:
        logger.error(f"Fatal error: {e}", exc_info=True)
        exit(1)








