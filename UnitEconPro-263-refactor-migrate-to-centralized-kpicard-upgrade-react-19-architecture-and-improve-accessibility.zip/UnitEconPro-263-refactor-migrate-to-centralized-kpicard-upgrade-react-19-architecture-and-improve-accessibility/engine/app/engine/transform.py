import json
import os
import yaml
from engine.aws.transformer import AthenaToClickHouseTransformer
from engine.transformer_base import Transformer

def get_transformer_for_cloud(cloud: str) -> Transformer:
    base_dir = os.path.dirname(os.path.abspath(__file__)) 
    mapping_path = os.path.join(base_dir, "..", "config", cloud, "column_mapping.json")
    config_path = os.path.join(base_dir, "..", "config", cloud, "config.yml")

    if not os.path.exists(mapping_path):
        raise FileNotFoundError(f"Column mapping file not found: {mapping_path}")

    with open(mapping_path, "r") as f:
        mapping = json.load(f)
    
    # Load tag mapping from config
    tag_mapping = {}
    if os.path.exists(config_path):
        with open(config_path, "r") as f:
            config = yaml.safe_load(f)
            tag_mapping = config.get(cloud, {}).get('tag_mapping', {})

    if cloud == "aws":
        return AthenaToClickHouseTransformer(mapping, tag_mapping)
    elif cloud == "gcp":
        raise NotImplementedError("GCP transformer not implemented yet")
    elif cloud == "azure":
        raise NotImplementedError("Azure transformer not implemented yet")
    else:
        raise ValueError(f"Unsupported cloud provider: {cloud}")
