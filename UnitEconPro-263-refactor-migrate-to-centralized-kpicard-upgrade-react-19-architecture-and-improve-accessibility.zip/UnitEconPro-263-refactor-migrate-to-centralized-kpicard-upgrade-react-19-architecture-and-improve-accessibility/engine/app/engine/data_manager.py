import logging
import hashlib
import json
from datetime import datetime, timedelta, date
from typing import List, Optional
import os

from engine.athena import AthenaEngine
from engine.clickhouse import ClickHouseEngine
from engine.transform import get_transformer_for_cloud
from engine.account_mapping import AccountMapper

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


def _is_clickhouse_connectivity_error(exc: Exception) -> bool:
    msg = str(exc)
    markers = [
        "No route to host",
        "Connection refused",
        "Max retries exceeded",
        "HTTPConnectionPool",
        "Read timed out",
    ]
    return any(m in msg for m in markers)

class CloudToClickHouseIngestor:
    def __init__(self, cloud: str, config: dict, ch_engine: ClickHouseEngine, athena_engine: Optional[AthenaEngine] = None, athena_database: str = None, athena_table: str = None, account_id: str = None):
        self.cloud = cloud
        self.config = config
        self.queries = config[cloud]["athena"]["queries"]
        self.account_id = account_id  # Used to scope deletes in multi-account mode
        
        self.athena_database = athena_database or os.getenv("ATHENA_DATABASE")
        self.athena_table = athena_table or os.getenv("ATHENA_TABLE")
        
        if athena_engine:
            self.source = athena_engine
        else:
            self.source = AthenaEngine(
                database=self.athena_database,
                output_location=os.getenv("ATHENA_OUTPUT_LOCATION") or os.getenv("ATHENA_OUTPUT_S3"),
                region_name=os.getenv("AWS_REGION")
            )
            
        self.target = ch_engine
        self.transformer = get_transformer_for_cloud(cloud)
        self.table_name = os.getenv("CLICKHOUSE_TABLE")
        
        if not self.table_name:
            raise ValueError("CLICKHOUSE_TABLE not found in environment variables.")
        
        self.mapper = AccountMapper()

    def ingest(self, service: str, start_date: date, end_date: date, save_data=True, account_id=None):
        """
        Pull data from Athena, transform, hash securely, and ingest to ClickHouse.
        """
        try:
            date_str = str(start_date)
            self.target.log_ingestion_status(self.cloud, service, date_str, "started")

            query = self._render_query(service, start_date, end_date, account_id=account_id)
            if not query:
                logger.warning(f"No query found for service: {service}")
                return

            logger.info(f"\n{'='*80}")
            logger.info(f"ATHENA QUERY for {service} ({start_date} to {end_date}):")
            logger.info(f"{'='*80}")
            logger.info(query)
            logger.info(f"{'='*80}\n")
            
            logger.info(f"Fetching data from Athena for {service}...")
            raw_data = self.source.fetch(query=query)

            if not raw_data:
                logger.info("Athena returned no rows.")
                self.target.log_ingestion_status(self.cloud, service, date_str, "success")
                return

            logger.info(f"Athena returned {len(raw_data)} rows")
            data = [self.transformer.transform(row) for row in raw_data]

            # Override product_code with mapped value from service_mapping
            mapped_product_code = self._get_product_code(service)
            
            # Add account_name before ingestion
            data = self.mapper.add_account_name(data)

            for i, row in enumerate(data):
                row['product_code'] = mapped_product_code
                
                # --- STABLE HASHING FOR DEDUPLICATION ---
                aws_id = raw_data[i].get('identity_line_item_id')
                
                if aws_id:
                    row['row_hash'] = aws_id
                else:
                    # Force a strict, consistent format for dates before hashing
                    def _format_dt(val):
                        if not val:
                            return ""
                        # If it's already a string, slice off milliseconds to normalize
                        if isinstance(val, str):
                            return val.split('.')[0] 
                        # If it's a datetime object, format it strictly
                        if hasattr(val, 'strftime'):
                            return val.strftime("%Y-%m-%d %H:%M:%S")
                        return str(val)

                    unique_fields = {
                        'account_id':        str(raw_data[i].get('line_item_usage_account_id', '')),
                        'usage_start':       _format_dt(raw_data[i].get('line_item_usage_start_date')),
                        'usage_end':         _format_dt(raw_data[i].get('line_item_usage_end_date')),
                        'product_code':      mapped_product_code,
                        'operation':         str(raw_data[i].get('line_item_operation', '')),
                        'resource_id':       str(raw_data[i].get('line_item_resource_id', '')),
                        'usage_type':        str(raw_data[i].get('product_usagetype', '')),
                        'region':            str(raw_data[i].get('product_region', '')),
                        'availability_zone': str(raw_data[i].get('line_item_availability_zone', '')),
                        'product_family':    str(raw_data[i].get('product_product_family', '')),
                        'instance_type':     str(raw_data[i].get('product_instance_type', '')),
                        'pricing_term':      str(raw_data[i].get('pricing_term', '')),
                    }
                    
                    # Removed default=str, ensuring our strict formatting is respected
                    hash_input = json.dumps(unique_fields, sort_keys=True)
                    row['row_hash'] = hashlib.md5(hash_input.encode()).hexdigest()

            if save_data:
                logger.info(f"Ingesting into ClickHouse table: {self.table_name}")
                logger.info(f"Ingesting data into ClickHouse for {service}...")
                self.target.ingest(data, table=self.table_name)
                
                # Log verification query for ClickHouse
                product_code = self._get_product_code(service)
                logger.info(f"\n{'='*80}")
                logger.info(f"CLICKHOUSE VERIFICATION QUERY for {service}:")
                logger.info(f"{'='*80}")
                logger.info(f"SELECT toDate(usage_start_ts) AS date, COUNT(*) as count")
                logger.info(f"FROM {self.table_name}")
                logger.info(f"WHERE product_code = '{product_code}'")
                logger.info(f"  AND usage_start_ts >= '{start_date} 00:00:00'")
                logger.info(f"  AND usage_start_ts < '{end_date} 00:00:00'")
                logger.info(f"GROUP BY date ORDER BY date;")
                logger.info(f"{'='*80}\n")

            self.target.log_ingestion_status(self.cloud, service, date_str, "success")

        except Exception as e:
            logger.exception(f"Ingestion failed for {service} on {start_date}")
            self.target.log_ingestion_status(self.cloud, service, str(start_date), "failed", error_message=str(e))
            raise

    def refresh_last_n_days(self, days: int = 7, service: str = None):
        """
        Refreshes data day-by-day to ensure 0% data loss and correct updates.
        Uses synchronous mutations to safely delete before inserting.
        """
        if days < 0:
            raise ValueError(f"days must be >= 0, got {days}")
        
        today = datetime.today().date()
        start_date = today - timedelta(days=days)
        services = [service] if service else self._get_enabled_services()
        
        logger.info(f"=== REFRESH MODE: {start_date} to {today} ({days} days) ===")

        # Ensure a live connection and apply best-effort lightweight delete sync.
        try:
            self.target.ensure_connection()
            self.target.client.command("SET lightweight_deletes_sync = 1")
        except Exception:
            logger.warning("Could not set lightweight_deletes_sync=1. Proceeding with caution.")

        for svc in services:
            logger.info(f"Processing Service: {svc}")
            try:
                current = start_date
                
                # Loop day by day to manage memory pressure
                while current < today:
                    next_day = current + timedelta(days=1)
                    
                    # 1. DELETE existing data for this day — method handles count + no-op internally
                    logger.info(f"  Checking and deleting existing records for {current} (account={self.account_id or 'ALL'})")
                    self.target.delete_by_date(target_date=current, service=svc, account_id=self.account_id)
                    
                    # 2. INGEST fresh data
                    logger.info(f"  Ingesting {current}")
                    self.ingest(
                        service=svc,
                        start_date=current,
                        end_date=next_day,
                        save_data=True,
                        account_id=self.account_id,
                    )
                    
                    current = next_day

                # 3. DEDUPLICATION NOTE:
                # OPTIMIZE TABLE FINAL DEDUPLICATE removed — on large tables it
                # triggers a full part merge and causes MEMORY_LIMIT_EXCEEDED.
                # DELETE FROM (lightweight delete) used upstream already removes
                # the old rows before re-inserting, so dedup is not needed here.
                logger.info(f"\nSkipping OPTIMIZE FINAL — handled by lightweight deletes upstream.")

                # 4. Verification
                product_code = self._get_product_code(svc)
                verify_sql = (
                    f"SELECT count() as rows, round(SUM(cost_unblended), 4) as cost "
                    f"FROM {self.table_name} WHERE product_code = %(product_code)s "
                    f"AND toDate(usage_start_ts) >= %(start_date)s AND toDate(usage_start_ts) < %(today)s"
                )
                try:
                    verify_result = self.target.client.query(
                        verify_sql,
                        parameters={
                            "product_code": product_code,
                            "start_date": str(start_date),
                            "today": str(today),
                        },
                    )
                    v_rows = verify_result.result_rows[0][0] if verify_result.result_rows else 0
                    v_cost = verify_result.result_rows[0][1] if verify_result.result_rows else 0.0
                    logger.info(f"\nVerification: {v_rows} rows ingested, ${float(v_cost):.4f} total cost")
                except Exception as ve:
                    logger.warning(f"Verification query failed (non-fatal): {ve}")
                logger.info(f"Service '{svc}' completed\n")

            except Exception as e:
                logger.error(f"Refresh failed for {svc}: {e}", exc_info=True)
                if _is_clickhouse_connectivity_error(e):
                    logger.error(
                        "ClickHouse connectivity issue detected during refresh; "
                        "aborting remaining refresh work for this run."
                    )
                    raise

        logger.info(f"\n{'='*60}")
        logger.info(f"Refresh operation complete")
        logger.info(f"{'='*60}")

    def autocorrect(self, current_date: datetime, service: str, account_ids: Optional[List[int]] = None):
        """
        Refresh ClickHouse partitions from 2 and 3 Sundays ago.
        """
        sundays = self._get_past_sundays(current_date)
        services = [service] if service else self._get_enabled_services()

        for svc in services:
            for sunday in sundays:
                logger.info(f" Autocorrecting for service='{svc}' on partition starting {sunday}")
                try:
                    if account_ids:
                        for acc_id in account_ids:
                            logger.info(f"Dropping partition for account_id={acc_id} on {sunday}")
                            self.target.drop_partition(partition_date=sunday, account_id=acc_id)

                            logger.info(f"Ingesting data for account_id={acc_id} from {sunday} to {sunday + timedelta(days=6)}")
                            self.ingest(
                                service=svc,
                                start_date=sunday,
                                end_date=sunday + timedelta(days=6),
                                save_data=True,
                                account_id=acc_id
                            )
                    else:
                        logger.info(f"Dropping global partition on {sunday} (no account_id filter)")
                        self.target.drop_partition(partition_date=sunday)
                        
                        # Delete data by date range — scoped to this account to prevent cross-account wipes
                        end_date = sunday + timedelta(days=6)
                        logger.info(f"Deleting existing data for date range {sunday} to {end_date} (account={self.account_id or 'ALL'})")
                        current = sunday
                        while current <= end_date:
                            count = self.target.count_records_by_date(current, svc, account_id=self.account_id)
                            if count > 0:
                                logger.info(f"  Deleting {count} records for {current}")
                                self.target.delete_by_date(target_date=current, service=svc, account_id=self.account_id)
                            current += timedelta(days=1)

                        logger.info(f" Ingesting global data for service={svc} from {sunday} to {sunday + timedelta(days=6)}")
                        self.ingest(
                            service=svc,
                            start_date=sunday,
                            end_date=sunday + timedelta(days=6),
                            save_data=True,
                            account_id=self.account_id,
                        )

                    logger.info(f" Autocorrect completed for service='{svc}' on {sunday}")

                except Exception as e:
                    logger.error(f" Autocorrect failed for service='{svc}' on {sunday}: {e}", exc_info=True)

    def ingest_missing_or_failed_dates(self, service: str, expected_dates: list):
        """
        Detect and retry ingestion for dates that are missing or previously failed.
        """
        pending = self.target.get_pending_ingestion_dates(self.cloud, service, expected_dates)
        for date_str in pending:
            date = datetime.strptime(date_str, "%Y-%m-%d").date()
            self.ingest(service, start_date=date, end_date=date + timedelta(days=1), save_data=True)

    def retry_failed_ingestions(self, service: str, retry_dates: list):
        """
        Retry ingestion only for dates that were explicitly marked as 'failed'.
        """
        failed_dates = self.target.get_failed_ingestion_dates(self.cloud, service, retry_dates)
        for date_str in failed_dates:
            date = datetime.strptime(date_str, "%Y-%m-%d").date()
            self.ingest(service, start_date=date, end_date=date + timedelta(days=1), save_data=True)

    # --- Helpers ---

    def _get_product_code(self, service: str) -> str:
        service_config = self.config.get(self.cloud, {}).get('service_mapping', {}).get(service.lower())
        if isinstance(service_config, dict):
            return service_config.get('product_code', service)
        return service_config if service_config else service

    def _get_enabled_services(self):
        queries = self.config[self.cloud]["athena"].get("queries", [])
        return [q["service"] for q in queries if q.get("enabled", False)]

    def _get_past_sundays(self, today: datetime):
        days_since_sunday = (today.weekday() + 1) % 7
        last_sunday = today.date() - timedelta(days=days_since_sunday)
        return [last_sunday - timedelta(weeks=1), last_sunday - timedelta(weeks=2)]

    def _get_available_columns(self, config_columns: list) -> list:
        """
        Intersect config columns with actual columns in the Athena/Glue table.
        Falls back to config columns if Glue check fails.
        """
        try:
            import boto3
            session_kwargs = {}
            if hasattr(self.source, 'aws_access_key_id') and self.source.aws_access_key_id:
                session_kwargs = {
                    'aws_access_key_id': self.source.aws_access_key_id,
                    'aws_secret_access_key': self.source.aws_secret_access_key,
                    'region_name': self.source.region_name,
                }
            glue = boto3.client('glue', **session_kwargs) if session_kwargs else boto3.client('glue', region_name=self.source.region_name)
            response = glue.get_table(DatabaseName=self.athena_database, Name=self.athena_table)
            table_columns = {col['Name'] for col in response['Table']['StorageDescriptor']['Columns']}
            # Also include partition keys
            table_columns.update(col['Name'] for col in response['Table'].get('PartitionKeys', []))
            available = [col for col in config_columns if col in table_columns]
            missing = [col for col in config_columns if col not in table_columns]
            if missing:
                logger.info(f"[Columns] Skipping {len(missing)} columns not in {self.athena_table}: {missing}")
            return available if available else config_columns
        except Exception as e:
            logger.warning(f"[Columns] Could not fetch Glue schema, using config columns as-is: {e}")
            return config_columns

    def _render_query(self, service: str, start_date: date, end_date: date, account_id) -> str:
        query_obj = next((q for q in self.queries if q["service"] == service and q.get("enabled", True)), None)
        if not query_obj:
            return ""

        config_columns = self.config[self.cloud]["athena"].get("columns", [])
        columns = self._get_available_columns(config_columns)
        columns_str = ", ".join(columns) if columns else "*"
        
        template = query_obj["sql"]
        return (
            template.replace("{{ database }}", self.athena_database or "")
                    .replace("{{ table }}", self.athena_table or "")
                    .replace("{{ start_date_str }}", str(start_date))
                    .replace("{{ end_date_str }}", str(end_date))
                    .replace("{{ columns | join(', ') }}", columns_str)
                    .replace("{{ account_id }}", str(account_id) if account_id else "")
        )
