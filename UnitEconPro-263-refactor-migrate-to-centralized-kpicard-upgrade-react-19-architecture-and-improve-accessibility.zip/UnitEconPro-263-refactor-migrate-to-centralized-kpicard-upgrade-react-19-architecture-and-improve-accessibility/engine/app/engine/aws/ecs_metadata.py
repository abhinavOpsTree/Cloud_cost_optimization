"""
ECS Metadata Extractor — Boto3 Operational Snapshot
Runs daily alongside Athena cost ingestion in the master loop.

Data collected per cluster:
  - cluster_status, cluster_arn
  - active_services_count, running_tasks_count, pending_tasks_count
  - registered_container_instances (EC2 launch type)
  - fargate_task_count, ec2_task_count
  - has_fargate_spot, capacity_providers, default_capacity_provider
  - tags

All stored in cost.aws_ecs_metadata (ReplacingMergeTree).
"""

import logging
import time
from datetime import datetime
from botocore.config import Config
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)

_RETRY_CFG = Config(retries={"max_attempts": 5, "mode": "adaptive"})


class ECSMetadataExtractor:

    TABLE = "cost.aws_ecs_metadata"
    COLUMNS = [
        "account_id", "account_name", "region", "cluster_name", "cluster_arn",
        "cluster_status", "active_services_count", "running_tasks_count",
        "pending_tasks_count", "registered_container_instances",
        "fargate_task_count", "ec2_task_count", "has_fargate_spot",
        "capacity_providers", "default_capacity_provider", "tags", "ingested_at",
    ]

    def __init__(self, ch_engine):
        self.ch_engine = ch_engine

    def _list_clusters(self, ecs_client):
        arns = []
        try:
            paginator = ecs_client.get_paginator("list_clusters")
            for page in paginator.paginate():
                arns.extend(page.get("clusterArns", []))
        except ClientError as e:
            logger.warning(f"[ECS Metadata] Could not list clusters: {e}")
        return arns

    def _describe_clusters(self, ecs_client, cluster_arns):
        results = []
        # describe_clusters accepts up to 100 at a time
        for i in range(0, len(cluster_arns), 100):
            batch = cluster_arns[i:i + 100]
            try:
                resp = ecs_client.describe_clusters(
                    clusters=batch,
                    include=["TAGS", "STATISTICS", "CONFIGURATIONS", "SETTINGS"]
                )
                results.extend(resp.get("clusters", []))
            except ClientError as e:
                logger.warning(f"[ECS Metadata] describe_clusters failed: {e}")
        return results

    def _get_task_counts(self, ecs_client, cluster_name):
        """Count running Fargate vs EC2 tasks."""
        fargate_count = 0
        ec2_count = 0
        try:
            for launch_type in ["FARGATE", "EC2"]:
                paginator = ecs_client.get_paginator("list_tasks")
                count = 0
                for page in paginator.paginate(cluster=cluster_name, launchType=launch_type, desiredStatus="RUNNING"):
                    count += len(page.get("taskArns", []))
                if launch_type == "FARGATE":
                    fargate_count = count
                else:
                    ec2_count = count
                time.sleep(0.05)
        except ClientError as e:
            logger.warning(f"[ECS Metadata] Could not list tasks for '{cluster_name}': {e}")
        return fargate_count, ec2_count

    def _has_fargate_spot(self, capacity_providers):
        return 1 if "FARGATE_SPOT" in capacity_providers else 0

    def ingest(self, session, account_id: str, account_name: str, region: str):
        start_ts = time.time()
        logger.info(
            f"[ECS Metadata] ── START ──────────────────────────────────────\n"
            f"[ECS Metadata]   Account : {account_name} ({account_id})\n"
            f"[ECS Metadata]   Region  : {region}"
        )

        rows = []
        try:
            ecs = session.client("ecs", region_name=region, config=_RETRY_CFG)
            cluster_arns = self._list_clusters(ecs)

            if not cluster_arns:
                logger.info(f"[ECS Metadata] No clusters in '{account_name}' / {region} — skipping.")
                return

            logger.info(f"[ECS Metadata] Found {len(cluster_arns)} clusters — scanning...")
            clusters = self._describe_clusters(ecs, cluster_arns)

            for i, cluster in enumerate(clusters):
                cluster_name = cluster.get("clusterName", "")
                cluster_arn  = cluster.get("clusterArn", "")
                status       = cluster.get("status", "UNKNOWN")

                logger.info(f"[ECS Metadata]   [{i+1}/{len(clusters)}] {cluster_name} (status={status})")

                try:
                    # AWS ECS returns counts as top-level fields, not in statistics array
                    active_services = cluster.get("activeServicesCount", 0) or 0
                    running_tasks   = cluster.get("runningTasksCount", 0) or 0
                    pending_tasks   = cluster.get("pendingTasksCount", 0) or 0
                    container_insts = cluster.get("registeredContainerInstancesCount", 0) or 0

                    # Capacity providers
                    cap_providers    = cluster.get("capacityProviders", [])
                    default_cap      = cluster.get("defaultCapacityProviderStrategy", [{}])[0].get("capacityProvider", "") if cluster.get("defaultCapacityProviderStrategy") else ""
                    has_spot         = self._has_fargate_spot(cap_providers)

                    # Task counts per launch type
                    fargate_tasks, ec2_tasks = self._get_task_counts(ecs, cluster_name)

                    # Tags
                    tags = {t["key"]: t["value"] for t in cluster.get("tags", [])}

                    rows.append([
                        account_id, account_name, region,
                        cluster_name, cluster_arn, status,
                        active_services, running_tasks, pending_tasks, container_insts,
                        fargate_tasks, ec2_tasks, has_spot,
                        cap_providers, default_cap, tags,
                        datetime.utcnow(),
                    ])

                    logger.info(
                        f"[ECS Metadata]   [{i+1}/{len(clusters)}] {cluster_name} — OK "
                        f"(services={active_services}, running={running_tasks}, "
                        f"fargate={fargate_tasks}, ec2={ec2_tasks})"
                    )

                except Exception as e:
                    logger.warning(f"[ECS Metadata]   [{i+1}/{len(clusters)}] Error on {cluster_name}: {e}")

                time.sleep(0.05)

        except ClientError as e:
            logger.error(f"[ECS Metadata] AWS API error for '{account_name}': {e}")
            return
        except Exception as e:
            logger.error(f"[ECS Metadata] Unexpected error for '{account_name}': {e}", exc_info=True)
            return

        try:
            if rows:
                self.ch_engine.client.insert(self.TABLE, rows, column_names=self.COLUMNS)
        except Exception as e:
            logger.error(f"[ECS Metadata] ClickHouse insert failed ({len(rows)} rows): {e}", exc_info=True)
            return

        elapsed = round(time.time() - start_ts, 1)
        logger.info(
            f"[ECS Metadata] ── DONE ───────────────────────────────────────\n"
            f"[ECS Metadata]   Account : {account_name} ({account_id})\n"
            f"[ECS Metadata]   Clusters: {len(rows)} ingested\n"
            f"[ECS Metadata]   Duration: {elapsed}s"
        )
