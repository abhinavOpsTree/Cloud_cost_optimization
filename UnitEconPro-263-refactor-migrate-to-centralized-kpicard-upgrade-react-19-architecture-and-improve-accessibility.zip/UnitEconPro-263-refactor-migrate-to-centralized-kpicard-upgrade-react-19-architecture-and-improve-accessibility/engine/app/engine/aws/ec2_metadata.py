"""
engine/aws/ec2_metadata.py

EC2 FinOps Metadata Extractor — Production Ready.
Includes free CloudWatch CPU/Network utilization (no agent needed).
"""

import logging
import time
from datetime import datetime, timedelta, timezone
from botocore.config import Config
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)

_RETRY_CFG = Config(retries={"max_attempts": 5, "mode": "adaptive"})
_LOG_EVERY_N = 50


class EC2MetadataExtractor:
    """
    Fetches FinOps-critical metadata for all EC2 instances in one account/region.

    Usage (called from app.py run_pipeline):
        EC2MetadataExtractor(ch_client).ingest(session, account_id, account_name, region)
    """

    TABLE = "cost.aws_ec2_metadata"
    COLUMNS = [
        "account_id", "account_name", "region", "availability_zone",
        "instance_id", "instance_state", "instance_lifecycle",
        "platform", "architecture", "launch_time",
        "tenancy", "ebs_optimized", "detailed_monitoring", "has_public_ip",
        "attached_ebs_count", "root_volume_type", "root_volume_size_gb",
        "tags", "ingested_at",
        "instance_type",
        "cpu_avg_pct", "cpu_max_pct", "cpu_p95_pct",
        "net_in_mbps", "net_out_mbps",
        "rightsizing_signal", "utilization_days", "utilization_updated",
    ]

    # Rightsizing thresholds (matches AWS Compute Optimizer logic)
    _CPU_SEVERELY_OVER  = (5,  10)   # (avg, p95)
    _CPU_OVER           = (10, 20)
    _CPU_UNDER          = (90, 95)   # (avg, p95)

    _IDX_ROOT_TYPE = COLUMNS.index("root_volume_type")
    _IDX_ROOT_SIZE = COLUMNS.index("root_volume_size_gb")

    def __init__(self, ch_engine):
        self.ch_engine = ch_engine

    # ─────────────────────────────────────────────────────────────
    # Public entry point
    # ─────────────────────────────────────────────────────────────

    def ingest(self, session, account_id: str, account_name: str, region: str) -> None:
        start_ts = time.time()

        logger.info(
            f"[EC2 Metadata] ── START ──────────────────────────────────────\n"
            f"[EC2 Metadata]   Account : {account_name} ({account_id})\n"
            f"[EC2 Metadata]   Region  : {region}"
        )

        rows = []
        instances = []

        # ── AWS extraction block ──────────────────────────────────
        try:
            ec2 = session.client("ec2", region_name=region, config=_RETRY_CFG)
            cw  = session.client("cloudwatch", region_name=region, config=_RETRY_CFG)

            instances = self._list_instances(ec2, region)

            if not instances:
                logger.info(
                    f"[EC2 Metadata] No instances found for '{account_name}' "
                    f"in {region} — skipping."
                )
                return

            logger.info(
                f"[EC2 Metadata] Found {len(instances)} instances — building rows..."
            )

            for i, instance in enumerate(instances):
                try:
                    row = self._build_row(instance, account_id, account_name, region)
                    rows.append(row)

                    if (i + 1) % _LOG_EVERY_N == 0 or (i + 1) == len(instances):
                        logger.info(
                            f"[EC2 Metadata]   [{i+1}/{len(instances)}] rows built..."
                        )
                except Exception as e:
                    iid = instance.get("InstanceId", "unknown")
                    logger.warning(f"[EC2 Metadata] Failed to parse instance '{iid}': {e}")

            logger.info(
                f"[EC2 Metadata] Enriching root volume details for {len(rows)} instances..."
            )
            rows = self._enrich_root_volumes(ec2, rows, instances)

            logger.info(
                f"[EC2 Metadata] Fetching CloudWatch CPU/Network for {len(rows)} instances..."
            )
            rows = self._enrich_cloudwatch(cw, rows, instances)

        except ClientError as e:
            logger.error(
                f"[EC2 Metadata] AWS API error for '{account_name}': {e}",
                exc_info=True,
            )
            return
        except Exception as e:
            logger.error(
                f"[EC2 Metadata] Unexpected extraction error for '{account_name}': {e}",
                exc_info=True,
            )
            return

        # ── ClickHouse insert block ───────────────────────────────
        if not rows:
            logger.info(f"[EC2 Metadata] No rows to insert for '{account_name}'.")
            return

        try:
            self.ch_engine.client.insert(self.TABLE, rows, column_names=self.COLUMNS)
        except Exception as e:
            logger.error(
                f"[EC2 Metadata] ClickHouse insert failed for '{account_name}' "
                f"({len(rows)} rows): {e}",
                exc_info=True,
            )
            return

        elapsed = round(time.time() - start_ts, 1)
        logger.info(
            f"[EC2 Metadata] ── DONE ───────────────────────────────────────\n"
            f"[EC2 Metadata]   Account  : {account_name} ({account_id})\n"
            f"[EC2 Metadata]   Instances: {len(rows)} ingested\n"
            f"[EC2 Metadata]   Duration : {elapsed}s"
        )

    # ─────────────────────────────────────────────────────────────
    # AWS API helpers
    # ─────────────────────────────────────────────────────────────

    def _list_instances(self, ec2, region: str) -> list:
        """Paginated describe_instances — returns all non-terminated instances."""
        instances = []
        try:
            paginator = ec2.get_paginator("describe_instances")
            for page in paginator.paginate(
                Filters=[{
                    "Name":   "instance-state-name",
                    "Values": ["pending", "running", "stopping", "stopped"],
                }]
            ):
                for reservation in page.get("Reservations", []):
                    instances.extend(reservation.get("Instances", []))
        except ClientError as e:
            logger.warning(f"[EC2 Metadata] Could not list instances in {region}: {e}")

        return instances

    def _enrich_root_volumes(self, ec2, rows: list, instances: list) -> list:
        """
        Fetch root volume type and size for all instances in one paginated
        describe_volumes batch — updates rows in-place.
        """
        volume_to_row: dict = {}
        for row_idx, instance in enumerate(instances):
            root_device = instance.get("RootDeviceName", "")
            for bdm in instance.get("BlockDeviceMappings", []):
                if bdm.get("DeviceName") == root_device:
                    vol_id = bdm.get("Ebs", {}).get("VolumeId")
                    if vol_id:
                        volume_to_row[vol_id] = row_idx
                    break

        if not volume_to_row:
            logger.debug("[EC2 Metadata] No root volume IDs found — skipping enrichment.")
            return rows

        logger.info(
            f"[EC2 Metadata] Fetching root volume details for {len(volume_to_row)} volumes..."
        )

        # describe_volumes accepts max 200 VolumeIds per call — batch accordingly
        _VOLUME_BATCH = 200
        vol_ids = list(volume_to_row.keys())
        try:
            paginator = ec2.get_paginator("describe_volumes")
            for batch_start in range(0, len(vol_ids), _VOLUME_BATCH):
                batch = vol_ids[batch_start:batch_start + _VOLUME_BATCH]
                for page in paginator.paginate(VolumeIds=batch):
                    for vol in page.get("Volumes", []):
                        vol_id = vol.get("VolumeId")
                        if vol_id in volume_to_row:
                            idx = volume_to_row[vol_id]
                            rows[idx][self._IDX_ROOT_TYPE] = vol.get("VolumeType", "unknown")
                            rows[idx][self._IDX_ROOT_SIZE] = vol.get("Size", 0)
        except ClientError as e:
            logger.warning(
                f"[EC2 Metadata] Could not enrich root volumes (non-fatal, will be 'unknown'/0): {e}"
            )

        return rows

    # ─────────────────────────────────────────────────────────────
    # Row builder
    # ─────────────────────────────────────────────────────────────

    def _enrich_cloudwatch(self, cw, rows: list, instances: list, lookback_days: int = 30) -> list:
        """
        Batch-fetch CPU + Network from CloudWatch free metrics.
        Default 30-day window — captures monthly patterns and weekly cycles.
        Single GetMetricData call per 100 instances — stays in free tier.
        """
        # Index: instance_id → row index
        id_to_idx = {
            instances[i].get("InstanceId", ""): i
            for i in range(len(instances))
        }

        # Indices of the new columns in COLUMNS list
        idx = {col: self.COLUMNS.index(col) for col in [
            "instance_type", "cpu_avg_pct", "cpu_max_pct", "cpu_p95_pct",
            "net_in_mbps", "net_out_mbps",
            "rightsizing_signal", "utilization_days", "utilization_updated",
        ]}

        # Fill instance_type from describe_instances data
        for i, instance in enumerate(instances):
            rows[i][idx["instance_type"]] = instance.get("InstanceType", "")

        end_time   = datetime.now(timezone.utc)
        start_time = end_time - timedelta(days=lookback_days)
        instance_ids = list(id_to_idx.keys())

        # Build batch queries — 4 metrics × N instances, max 500 per call
        def _build_queries(iids):
            queries, qmap = [], {}
            for iid in iids:
                safe = iid.replace("-", "_")
                for metric, stat, qid_suffix in [
                    ("CPUUtilization", "Average", "cpu_avg"),
                    ("CPUUtilization", "Maximum", "cpu_max"),
                    ("NetworkIn",      "Average", "net_in"),
                    ("NetworkOut",     "Average", "net_out"),
                ]:
                    qid = f"{safe}_{qid_suffix}"
                    queries.append({
                        "Id": qid,
                        "MetricStat": {
                            "Metric": {
                                "Namespace": "AWS/EC2",
                                "MetricName": metric,
                                "Dimensions": [{"Name": "InstanceId", "Value": iid}],
                            },
                            "Period": 3600,  # 1-hour — free tier
                            "Stat": stat,
                        },
                        "ReturnData": True,
                    })
                    qmap[qid] = (iid, qid_suffix)
            return queries, qmap

        # 4 metrics per instance (cpu_avg, cpu_max, net_in, net_out) → 100 × 4 = 400 ≤ 500 limit
        for chunk_start in range(0, len(instance_ids), 100):
            chunk = instance_ids[chunk_start:chunk_start + 100]
            queries, qmap = _build_queries(chunk)

            try:
                resp = cw.get_metric_data(
                    MetricDataQueries=queries,
                    StartTime=start_time,
                    EndTime=end_time,
                )
            except ClientError as e:
                logger.warning(f"[EC2 Metadata] CloudWatch batch failed: {e}")
                continue

            # Collect raw values per instance
            raw = {}  # instance_id → {cpu_avg: [...], cpu_max: [...], ...}
            for result in resp.get("MetricDataResults", []):
                iid, metric_key = qmap[result["Id"]]
                raw.setdefault(iid, {})[metric_key] = result.get("Values", [])

            # Write into rows
            for iid, metrics in raw.items():
                row_idx = id_to_idx.get(iid)
                if row_idx is None:
                    continue

                cpu_avg_vals = metrics.get("cpu_avg", [])
                cpu_max_vals = metrics.get("cpu_max", [])
                net_in_vals  = metrics.get("net_in",  [])
                net_out_vals = metrics.get("net_out", [])

                if not cpu_avg_vals:
                    continue  # instance stopped/terminated — leave defaults

                cpu_avg = sum(cpu_avg_vals) / len(cpu_avg_vals)
                cpu_max = max(cpu_max_vals) if cpu_max_vals else cpu_avg
                cpu_p95 = self._p95(cpu_avg_vals)

                # Network: bytes/s average → Mbps
                net_in  = (sum(net_in_vals)  / len(net_in_vals)  * 8 / 1e6) if net_in_vals  else 0.0
                net_out = (sum(net_out_vals) / len(net_out_vals) * 8 / 1e6) if net_out_vals else 0.0

                signal = self._classify(cpu_avg, cpu_max, cpu_p95)

                rows[row_idx][idx["cpu_avg_pct"]]        = round(cpu_avg, 2)
                rows[row_idx][idx["cpu_max_pct"]]        = round(cpu_max, 2)
                rows[row_idx][idx["cpu_p95_pct"]]        = round(cpu_p95, 2)
                rows[row_idx][idx["net_in_mbps"]]        = round(net_in,  3)
                rows[row_idx][idx["net_out_mbps"]]       = round(net_out, 3)
                rows[row_idx][idx["rightsizing_signal"]] = signal
                rows[row_idx][idx["utilization_days"]]   = lookback_days
                rows[row_idx][idx["utilization_updated"]] = datetime.utcnow()

        logger.info("[EC2 Metadata] CloudWatch enrichment complete.")
        return rows

    @staticmethod
    def _p95(values: list) -> float:
        if not values:
            return 0.0
        s = sorted(values)
        return s[min(int(len(s) * 0.95), len(s) - 1)]

    @classmethod
    def _classify(cls, avg: float, max_: float, p95: float) -> str:
        if avg < 5 and p95 < 10 and max_ < 20:
            return "SEVERELY_OVER_PROVISIONED"
        if avg < 10 and p95 < 20:
            return "OVER_PROVISIONED"
        if avg > 90 or p95 > 95:
            return "UNDER_PROVISIONED"
        if avg > 70:
            return "MODERATELY_UTILIZED"
        return "OPTIMIZED"

    @staticmethod
    def _build_row(instance: dict, account_id: str, account_name: str, region: str) -> list:
        """Extract all FinOps fields from one instance dict."""
        instance_state     = instance.get("State", {}).get("Name", "unknown")
        lifecycle_raw      = instance.get("InstanceLifecycle", "")
        instance_lifecycle = lifecycle_raw if lifecycle_raw else "on-demand"

        platform_raw = instance.get("Platform", "")
        platform     = "windows" if str(platform_raw).lower() == "windows" else "linux"
        architecture = instance.get("Architecture", "x86_64")

        launch_time = instance.get("LaunchTime")
        if launch_time and hasattr(launch_time, "tzinfo") and launch_time.tzinfo:
            launch_time = launch_time.replace(tzinfo=None)

        placement         = instance.get("Placement", {})
        tenancy           = placement.get("Tenancy", "default")
        availability_zone = placement.get("AvailabilityZone", "")

        ebs_optimized       = 1 if instance.get("EbsOptimized") else 0
        detailed_monitoring = 1 if instance.get("Monitoring", {}).get("State") == "enabled" else 0
        has_public_ip       = 1 if instance.get("PublicIpAddress") else 0

        block_devices      = instance.get("BlockDeviceMappings", [])
        attached_ebs_count = len(block_devices)

        tags_raw = instance.get("Tags", [])
        tags = {t["Key"]: t["Value"] for t in tags_raw if "Key" in t and "Value" in t}

        return [
            account_id,
            account_name,
            region,
            availability_zone,
            instance.get("InstanceId", ""),
            instance_state,
            instance_lifecycle,
            platform,
            architecture,
            launch_time,
            tenancy,
            ebs_optimized,
            detailed_monitoring,
            has_public_ip,
            attached_ebs_count,
            "unknown",     # root_volume_type  — filled by _enrich_root_volumes
            0,             # root_volume_size_gb — filled by _enrich_root_volumes
            tags,
            datetime.utcnow(),
            # new columns — filled by _enrich_root_volumes / _enrich_cloudwatch
            "",    # instance_type
            -1.0,  # cpu_avg_pct
            -1.0,  # cpu_max_pct
            -1.0,  # cpu_p95_pct
            -1.0,  # net_in_mbps
            -1.0,  # net_out_mbps
            "",    # rightsizing_signal
            0,     # utilization_days
            None,  # utilization_updated
        ]
