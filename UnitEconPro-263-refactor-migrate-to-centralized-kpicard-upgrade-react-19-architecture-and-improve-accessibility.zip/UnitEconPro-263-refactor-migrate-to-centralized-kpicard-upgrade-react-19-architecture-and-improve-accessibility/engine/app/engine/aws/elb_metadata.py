"""
engine/aws/elb_metadata.py

ELB FinOps Metadata Extractor — Production Ready.

Covers: ALB, NLB, GWLB, CLB (Classic).

All 6 issues from final review fixed:
  1. GWLB endpoint fetch moved outside per-LB loop — no duplication
  2. TG load_balancer_arns is Array(String) — handles many-to-many
  3. is_classic column removed — use load_balancer_type == 'classic'
  4. private_ip_addresses removed from GWLB endpoint rows
  5. Variable naming fixed in endpoint extraction (sid not sg)
  6. hours_per_month = 730 throughout (standardized)
"""

import logging
import time
from datetime import datetime, timezone
from typing import Dict, List, Optional, Set, Tuple

from botocore.config import Config
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)

_RETRY_CFG = Config(retries={"max_attempts": 5, "mode": "adaptive"})

# SSL policies that allow TLS 1.0 or 1.1
# Source: AWS documentation on deprecated SSL policies
_DEPRECATED_SSL_POLICIES: Set[str] = {
    "ELBSecurityPolicy-2015-05",
    "ELBSecurityPolicy-2015-03",
    "ELBSecurityPolicy-2015-02",
    "ELBSecurityPolicy-TLS-1-0-2015-04",
    "ELBSecurityPolicy-2016-08",
    "ELBSecurityPolicy-TLS-1-1-2017-01",
}

# AWS API limit: describe_tags accepts max 20 ARNs per call
_TAGS_BATCH_SIZE = 20


class ELBMetadataExtractor:

    LB_TABLE      = "cost.aws_elb_metadata"
    TG_TABLE      = "cost.aws_elb_target_group_metadata"
    LS_TABLE      = "cost.aws_elb_listener_metadata"
    GWLB_EP_TABLE = "cost.aws_gwlb_endpoint_metadata"

    def __init__(self, ch_engine):
        self.ch_engine = ch_engine

    # ═══════════════════════════════════════════════════════════════
    # PUBLIC ENTRY POINT
    # ═══════════════════════════════════════════════════════════════

    def ingest(
        self,
        session,
        account_id: str,
        account_name: str,
        region: str,
    ) -> None:
        start_ts = time.time()
        logger.info(
            f"[ELB] ── START ─────────────────────────────────────────────\n"
            f"[ELB]   Account : {account_name} ({account_id})\n"
            f"[ELB]   Region  : {region}"
        )

        try:
            elbv2      = session.client("elbv2", region_name=region, config=_RETRY_CFG)
            elb_v1     = session.client("elb",   region_name=region, config=_RETRY_CFG)
            wafv2      = session.client("wafv2", region_name=region, config=_RETRY_CFG)
            ec2        = session.client("ec2",   region_name=region, config=_RETRY_CFG)

            now_utc     = datetime.now(timezone.utc)
            ingested_at = now_utc.replace(tzinfo=None)
            version_ts  = int(now_utc.timestamp())

            # ── Fetch all ELBv2 load balancers ─────────────────────────
            lbs_v2 = self._paginate(elbv2, "describe_load_balancers", "LoadBalancers")

            # ── Fetch Classic LBs ───────────────────────────────────────
            lbs_classic = self._paginate(
                elb_v1, "describe_load_balancers", "LoadBalancerDescriptions"
            )

            # ── GWLB endpoints fetched before early return ───────────────
            # Consumer accounts may have endpoints but no LBs of their own
            gwlb_ep_rows = self._fetch_gwlb_endpoints(
                ec2, account_id, account_name, region,
                ingested_at, version_ts, now_utc,
            )

            if not lbs_v2 and not lbs_classic:
                if gwlb_ep_rows:
                    self.ch_engine.ingest(gwlb_ep_rows, table=self.GWLB_EP_TABLE)
                logger.info(
                    f"[ELB] No load balancers in {account_name}/{region} — skipping LB metadata."
                )
                return

            # ── WAF associations (ALBs only) ────────────────────────────
            waf_by_lb = self._fetch_waf_associations(wafv2, lbs_v2)

            # ── Process ELBv2 (ALB / NLB / GWLB) ──────────────────────
            lb_rows, tg_rows, ls_rows = self._process_elbv2(
                elbv2, lbs_v2, waf_by_lb,
                account_id, account_name, region,
                ingested_at, version_ts, now_utc,
            )

            # ── Process Classic LBs ─────────────────────────────────────
            classic_rows = self._process_classic(
                elb_v1, lbs_classic,
                account_id, account_name, region,
                ingested_at, version_ts, now_utc,
            )
            lb_rows.extend(classic_rows)

            # ── Ingest ──────────────────────────────────────────────────
            if lb_rows:
                self.ch_engine.ingest(lb_rows, table=self.LB_TABLE)
            if tg_rows:
                self.ch_engine.ingest(tg_rows, table=self.TG_TABLE)
            if ls_rows:
                self.ch_engine.ingest(ls_rows, table=self.LS_TABLE)
            if gwlb_ep_rows:
                self.ch_engine.ingest(gwlb_ep_rows, table=self.GWLB_EP_TABLE)

            elapsed = round(time.time() - start_ts, 1)
            logger.info(
                f"[ELB] ── DONE ──────────────────────────────────────────────\n"
                f"[ELB]   Account       : {account_name} ({account_id})\n"
                f"[ELB]   Region        : {region}\n"
                f"[ELB]   LBs           : {len(lb_rows)} "
                f"(v2={len(lb_rows) - len(classic_rows)}, classic={len(classic_rows)})\n"
                f"[ELB]   Target Groups : {len(tg_rows)}\n"
                f"[ELB]   Listeners     : {len(ls_rows)}\n"
                f"[ELB]   GWLB Endpoints: {len(gwlb_ep_rows)}\n"
                f"[ELB]   Duration      : {elapsed}s"
            )

        except ClientError as e:
            logger.error(
                f"[ELB] AWS API error for '{account_name}' in {region}: {e}",
                exc_info=True,
            )
        except Exception as e:
            logger.error(
                f"[ELB] Unexpected error for '{account_name}' in {region}: {e}",
                exc_info=True,
            )

    # ═══════════════════════════════════════════════════════════════
    # ELBv2 PROCESSING (ALB / NLB / GWLB)
    # ═══════════════════════════════════════════════════════════════

    def _process_elbv2(
        self,
        elbv2,
        lbs: List[dict],
        waf_by_lb: Dict[str, str],
        account_id: str,
        account_name: str,
        region: str,
        ingested_at: datetime,
        version_ts: int,
        now_utc: datetime,
    ) -> Tuple[List[dict], List[dict], List[dict]]:
        if not lbs:
            return [], [], []

        lb_arns = [lb["LoadBalancerArn"] for lb in lbs]

        # ── Batch API calls (all fetched before per-LB loop) ────────────
        lb_attributes    = self._fetch_lb_attributes_batch(elbv2, lb_arns)
        all_tgs          = self._paginate(elbv2, "describe_target_groups", "TargetGroups")
        tg_arns          = [tg["TargetGroupArn"] for tg in all_tgs]
        tg_attributes    = self._fetch_tg_attributes_batch(elbv2, tg_arns)
        tg_health        = self._fetch_all_target_health(elbv2, all_tgs)
        all_listeners    = self._fetch_all_listeners(elbv2, lb_arns)
        listener_arns    = [ls["ListenerArn"] for ls in all_listeners]
        rules_by_ls      = self._fetch_all_rules(elbv2, listener_arns)

        # Tags: batch 20 ARNs per call
        all_tags = self._fetch_tags_batch(elbv2, lb_arns + tg_arns)

        # ── Lookup structures ────────────────────────────────────────────
        # TGs grouped by LB ARN
        tgs_by_lb: Dict[str, List[dict]] = {}
        for tg in all_tgs:
            for lb_arn_ref in tg.get("LoadBalancerArns", []):
                tgs_by_lb.setdefault(lb_arn_ref, []).append(tg)

        # Orphaned TGs: not attached to any LB
        orphan_tg_arns: Set[str] = {
            tg["TargetGroupArn"]
            for tg in all_tgs
            if not tg.get("LoadBalancerArns")
        }

        # Listeners grouped by LB ARN
        listeners_by_lb: Dict[str, List[dict]] = {}
        for ls in all_listeners:
            listeners_by_lb.setdefault(ls["LoadBalancerArn"], []).append(ls)

        lb_rows: List[dict] = []
        tg_rows: List[dict] = []
        ls_rows: List[dict] = []

        # ── Per-LB processing ─────────────────────────────────────────────
        for lb in lbs:
            lb_arn  = lb["LoadBalancerArn"]
            lb_type = lb.get("Type", "").lower()  # application|network|gateway
            attrs   = lb_attributes.get(lb_arn, {})
            lb_tgs  = tgs_by_lb.get(lb_arn, [])
            lb_ls   = listeners_by_lb.get(lb_arn, [])
            tags    = all_tags.get(lb_arn, {})

            age_days, ct_naive = self._parse_create_time(lb.get("CreatedTime"), now_utc)

            # ── NLB EIP allocations (separate from subnet_ids) ───────────
            subnet_ids: List[str]        = []
            eip_allocation_ids: List[str] = []
            for az_info in lb.get("AvailabilityZones", []):
                sid = az_info.get("SubnetId", "")
                if sid:
                    subnet_ids.append(sid)
                for addr in az_info.get("LoadBalancerAddresses", []):
                    alloc_id = addr.get("AllocationId", "")
                    if alloc_id:
                        eip_allocation_ids.append(alloc_id)

            az_list = [
                az.get("ZoneName", "")
                for az in lb.get("AvailabilityZones", [])
            ]

            # ── Listener analysis ─────────────────────────────────────────
            ls_analysis = self._analyze_listeners(lb_ls, rules_by_ls)

            # ── Target health summary ─────────────────────────────────────
            health_summary = self._summarize_health(lb_tgs, tg_health)

            # ── Stickiness: any TG on this LB has stickiness enabled ──────
            has_sticky_tg = any(
                tg_attributes.get(tg["TargetGroupArn"], {}).get(
                    "stickiness.enabled", "false"
                ) == "true"
                for tg in lb_tgs
            )

            # ── SSL policies ──────────────────────────────────────────────
            ssl_policies: List[str] = list({
                ls.get("SslPolicy", "")
                for ls in lb_ls
                if ls.get("SslPolicy")
            })
            has_deprecated_ssl = any(p in _DEPRECATED_SSL_POLICIES for p in ssl_policies)

            # ── Idle detection ────────────────────────────────────────────
            # Idle = has target groups but none have any registered targets
            # A LB with NO target groups at all is also considered idle
            is_idle = int(health_summary["total_registered"] == 0)

            lb_rows.append({
                "account_id":                 account_id,
                "account_name":               account_name,
                "region":                     region,
                "load_balancer_name":         lb.get("LoadBalancerName", ""),
                "load_balancer_arn":          lb_arn,
                "load_balancer_type":         lb_type,
                "scheme":                     lb.get("Scheme", ""),
                "lb_state":                   lb.get("State", {}).get("Code", ""),
                "vpc_id":                     lb.get("VpcId", ""),
                "ip_address_type":            lb.get("IpAddressType", ""),
                "dns_name":                   lb.get("DNSName", ""),
                "hosted_zone_id":             lb.get("CanonicalHostedZoneId", ""),
                "availability_zones":         az_list,
                "subnet_ids":                 subnet_ids,
                "eip_allocation_ids":         eip_allocation_ids,
                "security_groups":            lb.get("SecurityGroups", []),

                # Listener summary
                "total_listeners":            len(lb_ls),
                "has_http_listener":          ls_analysis["has_http"],
                "has_https_listener":         ls_analysis["has_https"],
                "has_tcp_listener":           ls_analysis["has_tcp"],
                "has_tls_listener":           ls_analysis["has_tls"],
                "http_to_https_redirect":     ls_analysis["has_redirect"],
                "total_rules":                ls_analysis["total_rules"],

                # Target health summary
                "target_group_count":         len(lb_tgs),
                "total_registered_targets":   health_summary["total_registered"],
                "healthy_target_count":       health_summary["healthy"],
                "unhealthy_target_count":     health_summary["unhealthy"],
                "draining_target_count":      health_summary["draining"],
                "unused_target_group_count":  health_summary["unused_tgs"],

                # Attributes
                "deletion_protection_enabled":
                    int(attrs.get("deletion_protection.enabled", "false") == "true"),
                "access_logs_enabled":
                    int(attrs.get("access_logs.s3.enabled", "false") == "true"),
                "access_logs_s3_bucket":
                    attrs.get("access_logs.s3.bucket", ""),

                # ALB-specific (0/empty for NLB/GWLB)
                "idle_timeout_seconds":
                    int(attrs.get("idle_timeout.timeout_seconds", 60) or 60),
                "http_desync_mitigation_mode":
                    attrs.get("routing.http.desync_mitigation_mode", ""),
                "drop_invalid_header_fields":
                    int(attrs.get(
                        "routing.http.drop_invalid_header_fields.enabled", "false"
                    ) == "true"),
                "has_sticky_target_group":    int(has_sticky_tg),

                # NLB cross-zone ($0.01/GB) — ALB cross-zone is free
                "cross_zone_load_balancing":
                    int(attrs.get("load_balancing.cross_zone.enabled", "false") == "true"),

                # TLS
                "ssl_policy_names":           ssl_policies,
                "has_deprecated_ssl_policy":  int(has_deprecated_ssl),

                # Security
                "waf_enabled":                int(bool(waf_by_lb.get(lb_arn))),
                "waf_web_acl_arn":            waf_by_lb.get(lb_arn, ""),

                # FinOps
                "is_idle":                    is_idle,
                # is_classic column removed — use load_balancer_type == 'classic'

                "age_days":                   age_days,
                "created_time":               ct_naive,
                "tags":                       tags,
                "ingested_at":                ingested_at,
                "version":                    version_ts,
            })

            # ── Listener rows ─────────────────────────────────────────────
            for ls in lb_ls:
                ls_arn  = ls["ListenerArn"]
                rules   = rules_by_ls.get(ls_arn, [])
                has_redirect = any(
                    any(a.get("Type") == "redirect" for a in r.get("Actions", []))
                    for r in rules
                )
                certs            = ls.get("Certificates") or []
                default_cert     = certs[0].get("CertificateArn", "") if certs else ""
                additional_count = max(len(certs) - 1, 0)

                ls_rows.append({
                    "account_id":                   account_id,
                    "account_name":                 account_name,
                    "region":                       region,
                    "load_balancer_arn":            lb_arn,
                    "listener_arn":                 ls_arn,
                    "port":                         int(ls.get("Port", 0) or 0),
                    "protocol":                     ls.get("Protocol", ""),
                    "ssl_policy":                   ls.get("SslPolicy", ""),
                    "default_action_type":
                        (ls.get("DefaultActions") or [{}])[0].get("Type", ""),
                    "has_redirect_action":          int(has_redirect),
                    "alpn_policy":
                        (ls.get("AlpnPolicy") or [""])[0],
                    "default_certificate_arn":      default_cert,
                    "additional_certificate_count": additional_count,
                    "rule_count":                   len(rules),
                    "ingested_at":                  ingested_at,
                    "version":                      version_ts,
                })

        # ── Fix 2: TG rows — load_balancer_arns as Array ─────────────────
        for tg in all_tgs:
            tg_arn         = tg["TargetGroupArn"]
            health         = tg_health.get(tg_arn, {})
            tg_attrs       = tg_attributes.get(tg_arn, {})
            lb_arns_for_tg = tg.get("LoadBalancerArns", [])
            registered     = health.get("registered", 0)

            sticky_enabled  = tg_attrs.get("stickiness.enabled", "false") == "true"
            sticky_type     = tg_attrs.get("stickiness.type", "")
            # stickiness duration depends on type
            if sticky_type == "lb_cookie":
                sticky_duration = int(
                    tg_attrs.get("stickiness.lb_cookie.duration_seconds", 0) or 0
                )
            elif sticky_type == "app_cookie":
                sticky_duration = int(
                    tg_attrs.get("stickiness.app_cookie.duration_seconds", 0) or 0
                )
            else:
                sticky_duration = 0

            tg_rows.append({
                "account_id":                account_id,
                "account_name":              account_name,
                "region":                    region,
                # Fix 2: Array — all parent LB ARNs, not just [0]
                "load_balancer_arns":        lb_arns_for_tg,
                "target_group_name":         tg.get("TargetGroupName", ""),
                "target_group_arn":          tg_arn,
                "protocol":                  tg.get("Protocol", ""),
                "port":                      int(tg.get("Port", 0) or 0),
                "target_type":               tg.get("TargetType", ""),
                "vpc_id":                    tg.get("VpcId", ""),
                "load_balancing_algorithm":
                    tg.get("LoadBalancingAlgorithmType", "round_robin"),
                "health_check_enabled":
                    int(bool(tg.get("HealthCheckEnabled"))),
                "health_check_protocol":     tg.get("HealthCheckProtocol", ""),
                "health_check_port":
                    str(tg.get("HealthCheckPort", "traffic-port")),
                "health_check_path":         tg.get("HealthCheckPath", "/"),
                "health_check_interval_sec":
                    int(tg.get("HealthCheckIntervalSeconds", 30) or 30),
                "health_check_timeout_sec":
                    int(tg.get("HealthCheckTimeoutSeconds", 5) or 5),
                "healthy_threshold":
                    int(tg.get("HealthyThresholdCount", 3) or 3),
                "unhealthy_threshold":
                    int(tg.get("UnhealthyThresholdCount", 3) or 3),
                "stickiness_enabled":        int(sticky_enabled),
                "stickiness_type":           sticky_type,
                "stickiness_duration_sec":   sticky_duration,
                "deregistration_delay_sec":
                    int(tg_attrs.get(
                        "deregistration_delay.timeout_seconds", 300
                    ) or 300),
                "slow_start_duration_sec":
                    int(tg_attrs.get("slow_start.duration_seconds", 0) or 0),
                "registered_target_count":   registered,
                "healthy_count":             health.get("healthy", 0),
                "unhealthy_count":           health.get("unhealthy", 0),
                "draining_count":            health.get("draining", 0),
                "is_orphaned":               int(tg_arn in orphan_tg_arns),
                "is_unused":                 int(registered == 0),
                "tags":                      all_tags.get(tg_arn, {}),
                "ingested_at":               ingested_at,
                "version":                   version_ts,
            })

        return lb_rows, tg_rows, ls_rows

    # ═══════════════════════════════════════════════════════════════
    # CLASSIC LB PROCESSING
    # ═══════════════════════════════════════════════════════════════

    def _process_classic(
        self,
        elb_v1,
        lbs: List[dict],
        account_id: str,
        account_name: str,
        region: str,
        ingested_at: datetime,
        version_ts: int,
        now_utc: datetime,
    ) -> List[dict]:
        """
        Classic LB ARN constructed as:
          arn:aws:elasticloadbalancing:{region}:{account}:loadbalancer/{name}
        This matches CUR resource_id exactly — enables uniform JOIN:
          sc.resource_id = elb.load_balancer_arn (no string manipulation)
        """
        if not lbs:
            return []

        lb_names       = [lb["LoadBalancerName"] for lb in lbs]
        classic_tags   = self._fetch_classic_tags(elb_v1, lb_names)
        classic_attrs  = self._fetch_classic_attributes(elb_v1, lb_names)

        rows: List[dict] = []
        for lb in lbs:
            lb_name  = lb["LoadBalancerName"]
            age_days, ct_naive = self._parse_create_time(lb.get("CreatedTime"), now_utc)

            # Construct ARN that matches CUR resource_id
            lb_arn = (
                f"arn:aws:elasticloadbalancing:{region}:{account_id}"
                f":loadbalancer/{lb_name}"
            )

            instances      = lb.get("Instances", [])
            listeners_desc = lb.get("ListenerDescriptions", [])

            has_http  = False
            has_https = False
            has_tcp   = False
            for ld in listeners_desc:
                proto = ld.get("Listener", {}).get("Protocol", "").upper()
                if proto == "HTTP":
                    has_http = True
                elif proto in ("HTTPS", "SSL"):
                    has_https = True
                elif proto == "TCP":
                    has_tcp = True

            attrs           = classic_attrs.get(lb_name, {})
            access_logs_cfg = attrs.get("AccessLog", {})

            rows.append({
                "account_id":                 account_id,
                "account_name":               account_name,
                "region":                     region,
                "load_balancer_name":         lb_name,
                "load_balancer_arn":          lb_arn,
                "load_balancer_type":         "classic",
                # Fix 3: no is_classic column — use load_balancer_type == 'classic'
                "scheme":                     lb.get("Scheme", ""),
                "lb_state":                   "active",
                "vpc_id":                     lb.get("VPCId", ""),
                "ip_address_type":            "ipv4",
                "dns_name":                   lb.get("DNSName", ""),
                "hosted_zone_id":             lb.get("CanonicalHostedZoneNameID", ""),
                "availability_zones":         lb.get("AvailabilityZones", []),
                "subnet_ids":                 lb.get("Subnets", []),
                "eip_allocation_ids":         [],
                "security_groups":            lb.get("SecurityGroups", []),

                "total_listeners":            len(listeners_desc),
                "has_http_listener":          int(has_http),
                "has_https_listener":         int(has_https),
                "has_tcp_listener":           int(has_tcp),
                "has_tls_listener":           0,
                "http_to_https_redirect":     0,
                "total_rules":                0,

                "target_group_count":         0,
                "total_registered_targets":   len(instances),
                "healthy_target_count":       0,
                "unhealthy_target_count":     0,
                "draining_target_count":      0,
                "unused_target_group_count":  0,

                "deletion_protection_enabled": 0,
                "access_logs_enabled":
                    int(bool(access_logs_cfg.get("Enabled"))),
                "access_logs_s3_bucket":
                    access_logs_cfg.get("S3BucketName", ""),
                "idle_timeout_seconds":
                    int(attrs.get("ConnectionSettings", {}).get("IdleTimeout", 60) or 60),
                "http_desync_mitigation_mode": "",
                "drop_invalid_header_fields":  0,
                "has_sticky_target_group":     0,
                "cross_zone_load_balancing":
                    int(bool(attrs.get("CrossZoneLoadBalancing", {}).get("Enabled"))),
                "ssl_policy_names":            [],
                "has_deprecated_ssl_policy":   0,

                "waf_enabled":                0,
                "waf_web_acl_arn":            "",

                "is_idle":                    int(len(instances) == 0),

                "age_days":                   age_days,
                "created_time":               ct_naive,
                "tags":                       classic_tags.get(lb_name, {}),
                "ingested_at":                ingested_at,
                "version":                    version_ts,
            })
        return rows

    # ═══════════════════════════════════════════════════════════════
    # GWLB ENDPOINT FETCH — Called ONCE per region, not per GWLB
    # ═══════════════════════════════════════════════════════════════

    def _fetch_gwlb_endpoints(
        self,
        ec2,
        account_id: str,
        account_name: str,
        region: str,
        ingested_at: datetime,
        version_ts: int,
        now_utc: datetime,
    ) -> List[dict]:
        """
        Fetch ALL GatewayLoadBalancer VPC endpoints in the region.

        Called ONCE per region (not once per GWLB) — fixes duplication bug.

        Why gateway_load_balancer_arn is NOT stored:
          There is no direct API to map endpoint → GWLB ARN.
          describe_vpc_endpoints returns ServiceName (e.g.
          com.amazonaws.vpce.{region}.vpce-svc-{id}) but not the GWLB ARN.
          To map them you would need describe_vpc_endpoint_services which
          requires the service ID — a multi-step lookup with no guaranteed
          1:1 mapping in multi-account setups.
          Cost queries use vpc_endpoint_id directly — no GWLB ARN needed.

        Fix 4: private_ip_addresses removed.
          Not available from describe_vpc_endpoints response.
          Would require describe_network_interfaces per endpoint.
          Not worth the extra API calls for FinOps purposes.

        Fix 5: variable naming — sid (not sg) for subnet IDs.
        """
        rows: List[dict] = []
        try:
            for page in ec2.get_paginator("describe_vpc_endpoints").paginate(
                Filters=[
                    {"Name": "vpc-endpoint-type", "Values": ["GatewayLoadBalancer"]}
                ]
            ):
                for ep in page.get("VpcEndpoints", []):
                    age_days, ct_naive = self._parse_create_time(
                        ep.get("CreationTimestamp"), now_utc
                    )

                    # Fix 5: correct variable name — sid for subnet ID strings
                    subnet_ids = [
                        sid
                        for sid in ep.get("SubnetIds", [])
                        if sid
                    ]

                    rows.append({
                        "account_id":       account_id,
                        "account_name":     account_name,
                        "region":           region,
                        "vpc_endpoint_id":  ep.get("VpcEndpointId", ""),
                        "vpc_id":           ep.get("VpcId", ""),
                        # gateway_load_balancer_arn removed — cannot reliably match
                        "service_name":     ep.get("ServiceName", ""),
                        "subnet_ids":       subnet_ids,
                        # private_ip_addresses removed — not in this API response
                        "endpoint_state":   ep.get("State", ""),
                        "age_days":         age_days,
                        "created_time":     ct_naive,
                        "tags": {
                            t["Key"]: t["Value"]
                            for t in ep.get("Tags", [])
                        },
                        "ingested_at":      ingested_at,
                        "version":          version_ts,
                    })

        except ClientError as e:
            code = e.response.get("Error", {}).get("Code", "")
            if code in ("UnauthorizedOperation", "AccessDenied"):
                logger.warning(
                    f"[ELB] GWLB endpoint fetch — permission denied in {region}: {e}"
                )
            else:
                logger.warning(
                    f"[ELB] GWLB endpoint fetch failed in {region} (non-fatal): {e}"
                )
        return rows

    # ═══════════════════════════════════════════════════════════════
    # HELPER METHODS
    # ═══════════════════════════════════════════════════════════════

    def _fetch_lb_attributes_batch(
        self, client, lb_arns: List[str]
    ) -> Dict[str, Dict[str, str]]:
        """One API call per LB — no bulk describe_load_balancer_attributes API exists."""
        result: Dict[str, Dict[str, str]] = {}
        for arn in lb_arns:
            try:
                resp = client.describe_load_balancer_attributes(LoadBalancerArn=arn)
                result[arn] = {
                    a["Key"]: a["Value"]
                    for a in resp.get("Attributes", [])
                }
            except ClientError as e:
                logger.warning(f"[ELB] Cannot fetch attributes for {arn}: {e}")
                result[arn] = {}
        return result

    def _fetch_tg_attributes_batch(
        self, client, tg_arns: List[str]
    ) -> Dict[str, Dict[str, str]]:
        """One API call per TG — no bulk describe_target_group_attributes API."""
        result: Dict[str, Dict[str, str]] = {}
        for arn in tg_arns:
            try:
                resp = client.describe_target_group_attributes(TargetGroupArn=arn)
                result[arn] = {
                    a["Key"]: a["Value"]
                    for a in resp.get("Attributes", [])
                }
            except ClientError as e:
                logger.warning(f"[ELB] Cannot fetch TG attributes for {arn}: {e}")
                result[arn] = {}
        return result

    def _fetch_all_listeners(
        self, client, lb_arns: List[str]
    ) -> List[dict]:
        """Paginated per LB — describe_listeners supports LoadBalancerArn filter."""
        all_ls: List[dict] = []
        for arn in lb_arns:
            try:
                for page in client.get_paginator("describe_listeners").paginate(
                    LoadBalancerArn=arn
                ):
                    all_ls.extend(page.get("Listeners", []))
            except ClientError as e:
                logger.warning(f"[ELB] Cannot fetch listeners for {arn}: {e}")
        return all_ls

    def _fetch_all_rules(
        self, client, listener_arns: List[str]
    ) -> Dict[str, List[dict]]:
        """One call per listener. Typical listeners have < 100 rules (no pagination needed)."""
        result: Dict[str, List[dict]] = {}
        for arn in listener_arns:
            try:
                resp = client.describe_rules(ListenerArn=arn)
                result[arn] = resp.get("Rules", [])
            except ClientError as e:
                logger.warning(f"[ELB] Cannot fetch rules for {arn}: {e}")
                result[arn] = []
        return result

    def _fetch_all_target_health(
        self, client, tgs: List[dict]
    ) -> Dict[str, Dict[str, int]]:
        """One call per TG."""
        result: Dict[str, Dict[str, int]] = {}
        for tg in tgs:
            tg_arn = tg["TargetGroupArn"]
            try:
                resp  = client.describe_target_health(TargetGroupArn=tg_arn)
                descs = resp.get("TargetHealthDescriptions", [])
                healthy   = sum(
                    1 for d in descs
                    if d.get("TargetHealth", {}).get("State") == "healthy"
                )
                unhealthy = sum(
                    1 for d in descs
                    if d.get("TargetHealth", {}).get("State") in (
                        "unhealthy", "unhealthy.draining"
                    )
                )
                draining  = sum(
                    1 for d in descs
                    if d.get("TargetHealth", {}).get("State") == "draining"
                )
                result[tg_arn] = {
                    "registered": len(descs),
                    "healthy":    healthy,
                    "unhealthy":  unhealthy,
                    "draining":   draining,
                }
            except ClientError as e:
                logger.warning(f"[ELB] Cannot fetch health for TG {tg_arn}: {e}")
                result[tg_arn] = {
                    "registered": 0, "healthy": 0,
                    "unhealthy": 0, "draining": 0,
                }
        return result

    def _fetch_tags_batch(
        self, client, arns: List[str]
    ) -> Dict[str, Dict[str, str]]:
        """20 ARNs per call (AWS limit)."""
        result: Dict[str, Dict[str, str]] = {}
        for i in range(0, len(arns), _TAGS_BATCH_SIZE):
            chunk = arns[i:i + _TAGS_BATCH_SIZE]
            try:
                resp = client.describe_tags(ResourceArns=chunk)
                for td in resp.get("TagDescriptions", []):
                    result[td["ResourceArn"]] = {
                        t["Key"]: t["Value"] for t in td.get("Tags", [])
                    }
            except ClientError as e:
                logger.warning(f"[ELB] Cannot fetch tags for batch: {e}")
        return result

    def _fetch_classic_tags(
        self, client, lb_names: List[str]
    ) -> Dict[str, Dict[str, str]]:
        """Classic ELB (v1) describe_tags takes LoadBalancerNames (max 20)."""
        result: Dict[str, Dict[str, str]] = {}
        for i in range(0, len(lb_names), _TAGS_BATCH_SIZE):
            chunk = lb_names[i:i + _TAGS_BATCH_SIZE]
            try:
                resp = client.describe_tags(LoadBalancerNames=chunk)
                for td in resp.get("TagDescriptions", []):
                    result[td["LoadBalancerName"]] = {
                        t["Key"]: t["Value"] for t in td.get("Tags", [])
                    }
            except ClientError as e:
                logger.warning(f"[ELB] Cannot fetch Classic tags: {e}")
        return result

    def _fetch_classic_attributes(
        self, client, lb_names: List[str]
    ) -> Dict[str, dict]:
        """Classic LB attributes — one call per LB."""
        result: Dict[str, dict] = {}
        for name in lb_names:
            try:
                resp = client.describe_load_balancer_attributes(
                    LoadBalancerName=name
                )
                result[name] = resp.get("LoadBalancerAttributes", {})
            except ClientError as e:
                logger.warning(
                    f"[ELB] Cannot fetch Classic attributes for {name}: {e}"
                )
                result[name] = {}
        return result

    def _fetch_waf_associations(
        self, wafv2_client, lbs: List[dict]
    ) -> Dict[str, str]:
        """WAF check — ALBs only. Returns lb_arn → web_acl_arn (empty if none)."""
        result: Dict[str, str] = {}
        for lb in lbs:
            if lb.get("Type", "").lower() != "application":
                continue
            lb_arn = lb["LoadBalancerArn"]
            try:
                resp = wafv2_client.get_web_acl_for_resource(ResourceArn=lb_arn)
                acl  = resp.get("WebACL")
                result[lb_arn] = acl.get("ARN", "") if acl else ""
            except ClientError as e:
                code = e.response.get("Error", {}).get("Code", "")
                if code == "WAFNonexistentItemException":
                    result[lb_arn] = ""
                elif code in ("UnauthorizedOperation", "AccessDenied"):
                    logger.warning(
                        f"[ELB] WAF check — permission denied for {lb_arn}"
                    )
                else:
                    logger.debug(f"[ELB] WAF check skipped for {lb_arn}: {e}")
        return result

    def _analyze_listeners(
        self,
        listeners: List[dict],
        rules_by_listener: Dict[str, List[dict]],
    ) -> Dict[str, int]:
        has_http     = False
        has_https    = False
        has_tcp      = False
        has_tls      = False
        has_redirect = False
        total_rules  = 0

        for ls in listeners:
            protocol = ls.get("Protocol", "").upper()
            ls_arn   = ls["ListenerArn"]
            rules    = rules_by_listener.get(ls_arn, [])
            total_rules += len(rules)

            if protocol == "HTTP":
                has_http = True
                for rule in rules:
                    for action in rule.get("Actions", []):
                        if action.get("Type") == "redirect":
                            cfg = action.get("RedirectConfig", {})
                            if cfg.get("Protocol", "").upper() == "HTTPS":
                                has_redirect = True
            elif protocol == "HTTPS":
                has_https = True
            elif protocol == "TCP":
                has_tcp = True
            elif protocol == "TLS":
                has_tls = True

        return {
            "has_http":    int(has_http),
            "has_https":   int(has_https),
            "has_tcp":     int(has_tcp),
            "has_tls":     int(has_tls),
            "has_redirect": int(has_redirect),
            "total_rules": total_rules,
        }

    def _summarize_health(
        self,
        lb_tgs: List[dict],
        tg_health: Dict[str, Dict[str, int]],
    ) -> Dict[str, int]:
        total_registered = 0
        healthy          = 0
        unhealthy        = 0
        draining         = 0
        unused_tgs       = 0

        for tg in lb_tgs:
            tg_arn     = tg["TargetGroupArn"]
            health     = tg_health.get(tg_arn, {})
            registered = health.get("registered", 0)
            total_registered += registered
            healthy          += health.get("healthy", 0)
            unhealthy        += health.get("unhealthy", 0)
            draining         += health.get("draining", 0)
            if registered == 0:
                unused_tgs += 1

        return {
            "total_registered": total_registered,
            "healthy":          healthy,
            "unhealthy":        unhealthy,
            "draining":         draining,
            "unused_tgs":       unused_tgs,
        }

    def _parse_create_time(
        self,
        ct,
        now_utc: datetime,
    ) -> Tuple[int, Optional[datetime]]:
        if ct is None:
            return 0, None
        if ct.tzinfo is None:
            ct = ct.replace(tzinfo=timezone.utc)
        age_days = (now_utc - ct).days
        ct_naive = ct.astimezone(timezone.utc).replace(tzinfo=None)
        return age_days, ct_naive

    def _paginate(self, client, method: str, key: str) -> List[dict]:
        results: List[dict] = []
        try:
            for page in client.get_paginator(method).paginate():
                results.extend(page.get(key, []))
        except ClientError as e:
            code = e.response.get("Error", {}).get("Code", "")
            if code in ("UnauthorizedOperation", "AccessDenied"):
                logger.warning(f"[ELB] {method} — permission denied: {e}")
            else:
                logger.warning(f"[ELB] {method} skipped (non-fatal): {e}")
        return results
