"""
engine/aws/s3_metadata.py

S3 FinOps Metadata Extractor — Production Ready.

Architecture decisions:
  - S3 is a GLOBAL service. list_buckets() returns ALL buckets in one call
    regardless of region. Called ONCE per account, not once per region.

  - get_bucket_location() resolves each bucket's true region. A regional
    client is then created per-bucket to avoid AuthorizationHeaderMalformed
    errors on cross-region path-style requests.

  - list_objects / list_objects_v2 is NEVER called. Storage GB comes from CUR.

  - Rows are dicts (not lists) — safe against column reordering, and required
    by ch_engine.ingest() which expects List[Dict].

  - ch_engine.ingest() is used (not client.insert()) — has adaptive batching
    and MEMORY_LIMIT_EXCEEDED retries built in.

  - 50ms throttle between buckets prevents ThrottlingException on large accounts.

  - Two separate try/except blocks: AWS extraction + ClickHouse insert.

Fields collected (FinOps-only):
  versioning_status           — Enabled versions = double storage cost
  has_lifecycle_rules         — No rules = data accumulates forever
  clears_incomplete_multipart — Failed uploads = invisible storage cost
  is_public                   — Public = unexpected egress cost risk
  encryption_type             — SSE-S3 | SSE-KMS | DSSE-KMS | None
  tags                        — Cost allocation / showback by team/env/project
"""

import logging
import time
from datetime import datetime
from typing import Dict, List, Tuple

from botocore.config import Config
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)

_RETRY_CFG = Config(retries={"max_attempts": 5, "mode": "adaptive"})


class S3MetadataExtractor:
    """
    Fetches FinOps-critical metadata for all S3 buckets in one account.

    Usage (called from app.py _run_metadata_extractors):
        S3MetadataExtractor(ch_client).ingest(session, account_id, account_name)

    NOTE: Called ONCE per account — NOT once per region.
    """

    TABLE = "cost.aws_s3_metadata"

    def __init__(self, ch_engine):
        self.ch_engine = ch_engine

    def ingest(self, session, account_id: str, account_name: str) -> None:
        start_ts = time.time()

        logger.info(
            f"[S3 Metadata] ── START ──────────────────────────────────────\n"
            f"[S3 Metadata]   Account : {account_name} ({account_id})"
        )

        rows: List[Dict] = []

    
        try:
            global_s3 = session.client("s3", region_name="us-east-1", config=_RETRY_CFG)

            try:
                buckets = global_s3.list_buckets().get("Buckets", [])
            except ClientError as e:
                logger.error(
                    f"[S3 Metadata] list_buckets failed for '{account_name}': {e}",
                    exc_info=True,
                )
                return

            if not buckets:
                logger.info(f"[S3 Metadata] No buckets found for '{account_name}' — skipping.")
                return

            logger.info(f"[S3 Metadata] Found {len(buckets)} buckets — building rows...")

            for i, bucket in enumerate(buckets):
                bucket_name = bucket["Name"]
                try:
                    row = self._build_row(
                        session, global_s3, bucket_name, account_id, account_name
                    )
                    rows.append(row)

                 
                    flags = []
                    if row["versioning_status"] == "Enabled" and not row["has_lifecycle_rules"]:
                        flags.append("VERSIONING_WASTE")
                    if not row["clears_incomplete_multipart"]:
                        flags.append("MULTIPART_RISK")
                    if row["is_public"]:
                        flags.append("PUBLIC")
                    if row["encryption_type"] == "None":
                        flags.append("UNENCRYPTED")

                    flag_str = f"  ⚠ {', '.join(flags)}" if flags else "  ✓ clean"
                    logger.info(
                        f"[S3 Metadata]   [{i+1:>3}/{len(buckets)}] {bucket_name:<45} "
                        f"{row['region']:<15} v={row['versioning_status'][0]} "
                        f"lc={row['has_lifecycle_rules']} enc={row['encryption_type']}{flag_str}"
                    )

                except Exception as e:
                    logger.warning(f"[S3 Metadata] Skipping bucket '{bucket_name}': {e}")
                    continue

              
                if i < len(buckets) - 1:
                    time.sleep(0.05)

        except Exception as e:
            logger.error(
                f"[S3 Metadata] Unexpected extraction error for '{account_name}': {e}",
                exc_info=True,
            )
            return

       
        if not rows:
            logger.info(f"[S3 Metadata] No rows to insert for '{account_name}'.")
            return

        try:
          
            self.ch_engine.ingest(rows, table=self.TABLE)
        except Exception as e:
            logger.error(
                f"[S3 Metadata] ClickHouse insert failed for '{account_name}' "
                f"({len(rows)} rows): {e}",
                exc_info=True,
            )
            return

        elapsed = round(time.time() - start_ts, 1)

        # FinOps summary — computed from dict keys, never hardcoded indices
        versioning_waste = sum(1 for r in rows if r["versioning_status"] == "Enabled" and not r["has_lifecycle_rules"])
        multipart_risk   = sum(1 for r in rows if not r["clears_incomplete_multipart"])
        public_buckets   = sum(1 for r in rows if r["is_public"])
        unencrypted      = sum(1 for r in rows if r["encryption_type"] == "None")

        logger.info(
            f"[S3 Metadata] ── DONE ───────────────────────────────────────\n"
            f"[S3 Metadata]   Account          : {account_name} ({account_id})\n"
            f"[S3 Metadata]   Buckets ingested : {len(rows)}\n"
            f"[S3 Metadata]   Versioning waste : {versioning_waste} (versioning ON, no lifecycle)\n"
            f"[S3 Metadata]   Multipart risk   : {multipart_risk} (no AbortIncompleteMultipartUpload)\n"
            f"[S3 Metadata]   Public buckets   : {public_buckets}\n"
            f"[S3 Metadata]   Unencrypted      : {unencrypted}\n"
            f"[S3 Metadata]   Duration         : {elapsed}s"
        )

    def _build_row(
        self,
        session,
        global_s3,
        bucket_name: str,
        account_id: str,
        account_name: str,
    ) -> Dict:
        """Extract all FinOps fields for one bucket and return as dict."""
        region = self._get_bucket_region(global_s3, bucket_name)
        regional_s3 = session.client("s3", region_name=region, config=_RETRY_CFG)

        versioning_status           = self._get_versioning(regional_s3, bucket_name)
        has_lifecycle, clears_mp    = self._get_lifecycle(regional_s3, bucket_name)
        encryption_type             = self._get_encryption(regional_s3, bucket_name)
        is_public                   = self._get_public_access(regional_s3, bucket_name)
        tags                        = self._get_tags(regional_s3, bucket_name)

        return {
            "bucket_name":                 bucket_name,
            "account_id":                  account_id,
            "account_name":                account_name,
            "region":                      region,
            "versioning_status":           versioning_status,
            "has_lifecycle_rules":         has_lifecycle,
            "clears_incomplete_multipart": clears_mp,
            "is_public":                   is_public,
            "encryption_type":             encryption_type,
            "tags":                        tags,
            "ingested_at":                 datetime.utcnow(),
            "version":                     int(datetime.utcnow().timestamp()),
        }

    def _get_bucket_region(self, s3, bucket_name: str) -> str:
        """
        Resolve the bucket's true region via get_bucket_location.
        AWS returns None for us-east-1 (legacy behaviour) — normalised to string.
        AWS returns 'EU' for the legacy eu-west-1 alias — normalised too.
        """
        try:
            location = s3.get_bucket_location(Bucket=bucket_name).get("LocationConstraint")
            if not location:
                return "us-east-1"
            if location == "EU":
                return "eu-west-1"
            return location
        except ClientError as e:
            logger.warning(f"[S3 Metadata] Could not get region for '{bucket_name}': {e}")
            return "us-east-1"

    def _get_versioning(self, s3, bucket_name: str) -> str:
        """Returns: Enabled | Suspended | Disabled"""
        try:
            status = s3.get_bucket_versioning(Bucket=bucket_name).get("Status", "")
            return status if status else "Disabled"
        except ClientError:
            return "Disabled"

    def _get_lifecycle(self, s3, bucket_name: str) -> Tuple[int, int]:
        """
        Returns (has_lifecycle_rules, clears_incomplete_multipart).
        clears_incomplete_multipart = 1 if any rule has AbortIncompleteMultipartUpload.
        """
        try:
            rules = s3.get_bucket_lifecycle_configuration(Bucket=bucket_name).get("Rules", [])
            has_rules = int(len(rules) > 0)
            clears_mp = int(any("AbortIncompleteMultipartUpload" in rule for rule in rules))
            return has_rules, clears_mp
        except ClientError as e:
            if e.response["Error"]["Code"] == "NoSuchLifecycleConfiguration":
                return 0, 0
            logger.warning(f"[S3 Metadata] lifecycle error for '{bucket_name}': {e}")
            return 0, 0

    def _get_encryption(self, s3, bucket_name: str) -> str:
        """
        Returns: SSE-S3 | SSE-KMS | DSSE-KMS | None

        Fix 3: check SSEAlgorithm directly — not the KMS key ID.
        DSSE-KMS uses the distinct algorithm value 'aws:kms:dsse'.
        The old approach of checking 'dsse' in key_id never matched real ARNs.
        """
        try:
            rules = (
                s3.get_bucket_encryption(Bucket=bucket_name)
                .get("ServerSideEncryptionConfiguration", {})
                .get("Rules", [])
            )
            if not rules:
                return "None"
            algo = rules[0].get("ApplyServerSideEncryptionByDefault", {}).get("SSEAlgorithm", "")
            if algo == "aws:kms:dsse":
                return "DSSE-KMS"
            if algo == "aws:kms":
                return "SSE-KMS"
            if algo == "AES256":
                return "SSE-S3"
            return algo or "None"
        except ClientError as e:
            if e.response["Error"]["Code"] in (
                "ServerSideEncryptionConfigurationNotFoundError",
                "NoSuchEncryptionConfiguration",
            ):
                return "None"
            return "None"

    def _get_public_access(self, s3, bucket_name: str) -> int:
        """
        Returns 0 if all four public-access blocks are enabled (bucket is private).
        Returns 1 if any block is missing or disabled (bucket may be public).
        NoSuchPublicAccessBlockConfiguration = no config set = public risk = 1.
        """
        try:
            config = s3.get_public_access_block(Bucket=bucket_name).get(
                "PublicAccessBlockConfiguration", {}
            )
            all_blocked = all([
                config.get("BlockPublicAcls", False),
                config.get("IgnorePublicAcls", False),
                config.get("BlockPublicPolicy", False),
                config.get("RestrictPublicBuckets", False),
            ])
            return 0 if all_blocked else 1
        except ClientError as e:
            if e.response["Error"]["Code"] == "NoSuchPublicAccessBlockConfiguration":
                return 1
            return 0

    def _get_tags(self, s3, bucket_name: str) -> Dict[str, str]:
        try:
            tag_set = s3.get_bucket_tagging(Bucket=bucket_name).get("TagSet", [])
            return {t["Key"]: t["Value"] for t in tag_set}
        except ClientError as e:
            if e.response["Error"]["Code"] == "NoSuchTagSet":
                return {}
            return {}
