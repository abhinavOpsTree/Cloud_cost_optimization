import logging
from datetime import datetime, timedelta
from decimal import Decimal, InvalidOperation
from typing import Dict, Any, Optional
from ..transformer_base import Transformer

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


class AthenaToClickHouseTransformer(Transformer):
    DATETIME_COLUMNS = {
        "line_item_usage_start_date",
        "line_item_usage_end_date"
    }

    # These map to Decimal(18,8) columns in ClickHouse — must use Decimal not float
    DECIMAL_COLUMNS = {
        "line_item_usage_amount",
        "line_item_unblended_cost",
        "line_item_blended_cost"
    }

    def __init__(self, mapping: Dict[str, str], tag_mapping: Optional[Dict] = None):
        super().__init__(mapping)
        self.tag_mapping = tag_mapping or {}
        self.common_tags = self.tag_mapping.get('common_tags', {})
        self.extract_all = self.tag_mapping.get('extract_all_user_tags', False)

    def parse_datetime(self, value: Optional[str]) -> Optional[datetime]:
        if not value:
            return None
        for fmt in ("%Y-%m-%d %H:%M:%S.%f", "%Y-%m-%d %H:%M:%S"):
            try:
                dt = datetime.strptime(value, fmt)
                # Keep UTC time - removed timezone offset for accurate cost tracking
                return dt
            except ValueError:
                continue
        logger.warning(f"Invalid datetime format: '{value}'")
        return None

    def extract_tags(self, row: Dict[str, Any]) -> tuple:
        """Extract common tags and extra tags from row data"""
        common = {}
        extra = {}
        
        # Extract common tags based on mapping
        for tag_name, column_name in self.common_tags.items():
            value = row.get(column_name, '').strip() if row.get(column_name) else ''
            common[tag_name] = value
        
        # Extract all other user tags if enabled
        if self.extract_all:
            for key, value in row.items():
                if key.startswith('resource_tags_user_'):
                    tag_name = key.replace('resource_tags_user_', '')
                    # Skip if already in common tags
                    if tag_name not in self.common_tags:
                        if value and str(value).strip():
                            extra[tag_name] = str(value).strip()
        
        return common, extra

    # Maps usage_type prefix → AWS region
    USAGE_TYPE_REGION_MAP = {
        "USE1": "us-east-1",   "USE2": "us-east-2",
        "USW1": "us-west-1",   "USW2": "us-west-2",
        "APS1": "ap-southeast-1", "APS2": "ap-southeast-2", "APS3": "ap-south-1", "APS4": "ap-south-2",
        "APN1": "ap-northeast-1", "APN2": "ap-northeast-2", "APN3": "ap-northeast-3",
        "APE1": "ap-east-1",
        "EUW1": "eu-west-1",   "EUW2": "eu-west-2",   "EUW3": "eu-west-3",
        "EUC1": "eu-central-1", "EUC2": "eu-central-2",
        "EUN1": "eu-north-1",  "EUS1": "eu-south-1",  "EUS2": "eu-south-2",
        "SAE1": "sa-east-1",
        "CAC1": "ca-central-1", "CAW1": "ca-west-1",
        "MES1": "me-south-1",  "MEC1": "me-central-1",
        "AFS1": "af-south-1",
        "ILL1": "il-central-1",
    }

    def _region_from_usage_type(self, usage_type: str) -> str:
        """Derive region from usage_type prefix when product_region is blank."""
        prefix = usage_type.split("-")[0].upper()
        return self.USAGE_TYPE_REGION_MAP.get(prefix, "")

    def transform(self, row: Dict[str, Any]) -> Dict[str, Any]:
        transformed = {}
        for src_col, target_col in self.mapping.items():
            val = row.get(src_col)

            if src_col in self.DATETIME_COLUMNS:
                transformed[target_col] = self.parse_datetime(val)
            elif src_col in self.DECIMAL_COLUMNS:
                # Use Decimal(str(val)) — Decimal(float) can introduce IEEE 754 artifacts
                try:
                    transformed[target_col] = Decimal(str(val)) if val is not None else Decimal("0")
                except (InvalidOperation, ValueError):
                    logger.warning(f"Invalid decimal for {src_col}: {val}. Defaulting to 0")
                    transformed[target_col] = Decimal("0")
            else:
                transformed[target_col] = str(val).strip() if val else ""

        # Fallback: derive region from usage_type prefix if product_region is blank
        if not transformed.get("region"):
            transformed["region"] = self._region_from_usage_type(transformed.get("usage_type", ""))

        # ASG logic
        asg_name = row.get("resource_tags_aws_autoscaling_group_name", "").strip()
        transformed["autoscaling_group_name"] = asg_name
        transformed["scaling_type"] = "Static" if asg_name == "" else "ASG"

        # Extract tags
        common_tags, extra_tags = self.extract_tags(row)
        
        # Add common tags to transformed data (cloud-agnostic names)
        transformed["tag_env"] = common_tags.get('env', '')
        transformed["tag_team"] = common_tags.get('team', '')
        transformed["tag_app"] = common_tags.get('app', '')
        transformed["tag_name"] = common_tags.get('name', '')
        transformed["tags_map"] = extra_tags

        return transformed