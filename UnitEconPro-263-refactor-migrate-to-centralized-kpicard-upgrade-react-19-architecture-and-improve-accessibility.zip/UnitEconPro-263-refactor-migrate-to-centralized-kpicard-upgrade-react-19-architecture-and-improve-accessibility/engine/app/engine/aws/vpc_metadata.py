"""
engine/aws/vpc_metadata.py

Zero-cost VPC FinOps Metadata Extractor.
Uses only free AWS EC2/VPC describe_* APIs. No CloudWatch, no Flow Logs storage.

Bug fixes applied vs original design:
  1. describe_network_interfaces filtered to status=in-use — prevents timeout on large accounts
  2. NAT Gateway's own ENIs excluded from subnet_active_eni_count — zombie flag now fires correctly
  3. igw_vpcs derived from route table's VpcId directly — not from association/route cross-product
  4. flow_log_vpcs includes subnet-level flow logs mapped back to VPC
  5. describe_nat_gateways filtered to available/pending — deleted NATs excluded
  6. _paginate logs permission errors with context — false positive flags surfaced
  7. create_time timezone: uses astimezone() not replace() — correct for tz-aware boto3 datetimes
  8. vpc_endpoint_count added to VPC rows
"""

import logging
import time
from datetime import datetime, timezone
from typing import Dict, List
from botocore.config import Config
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)
_RETRY_CFG = Config(retries={"max_attempts": 5, "mode": "adaptive"})


class VPCMetadataExtractor:

    VPC_TABLE = "cost.aws_vpc_metadata"
    NAT_TABLE = "cost.aws_nat_gateway_metadata"
    EIP_TABLE = "cost.aws_eip_metadata"
    ENI_TABLE = "cost.aws_eni_metadata"

    def __init__(self, ch_engine):
        self.ch_engine = ch_engine

    def ingest(self, session, account_id: str, account_name: str, region: str) -> None:
        start_ts = time.time()
        logger.info(
            f"[VPC Metadata] ── START ──────────────────────────────────────\n"
            f"[VPC Metadata]   Account : {account_name} ({account_id})\n"
            f"[VPC Metadata]   Region  : {region}"
        )

        try:
            ec2 = session.client("ec2", region_name=region, config=_RETRY_CFG)

            # ── Fetch all resources (100% free APIs) ──────────────────────
            vpcs      = self._paginate(ec2, "describe_vpcs", "Vpcs")
            subnets   = self._paginate(ec2, "describe_subnets", "Subnets")
            rts       = self._paginate(ec2, "describe_route_tables", "RouteTables")
            endpoints = self._paginate(ec2, "describe_vpc_endpoints", "VpcEndpoints")
            flow_logs = self._paginate(ec2, "describe_flow_logs", "FlowLogs")
            eips      = self._describe_addresses(ec2)

            # Bug fix #5: filter deleted/failed NATs at API level
            nats = self._paginate_filtered(ec2, "describe_nat_gateways", "NatGateways",
                Filters=[{"Name": "state", "Values": ["available", "pending"]}]
            )

            # Bug fix #1: filter ENIs at API level — prevents timeout on large accounts
            enis = self._paginate_filtered(ec2, "describe_network_interfaces", "NetworkInterfaces",
                Filters=[{"Name": "status", "Values": ["in-use"]}]
            )

            if not vpcs:
                logger.info(f"[VPC Metadata] No VPCs found for '{account_name}' in {region} — skipping.")
                return

            # ── Lookup maps ───────────────────────────────────────────────
            subnet_to_az  = {s["SubnetId"]: s.get("AvailabilityZone", region) for s in subnets}
            subnet_to_vpc = {s["SubnetId"]: s["VpcId"] for s in subnets}

            # Bug fix #4: flow logs at VPC level + subnet level mapped back to VPC
            # Only count ACTIVE flow logs — errored/deleting logs don't actually capture traffic
            flow_log_vpcs = {
                fl["ResourceId"] for fl in flow_logs
                if fl.get("ResourceId", "").startswith("vpc-")
                and fl.get("FlowLogStatus") == "ACTIVE"
            }
            for fl in flow_logs:
                rid = fl.get("ResourceId", "")
                if rid.startswith("subnet-") and rid in subnet_to_vpc and fl.get("FlowLogStatus") == "ACTIVE":
                    flow_log_vpcs.add(subnet_to_vpc[rid])

            s3_vpcs     = {ep["VpcId"] for ep in endpoints if ep.get("VpcEndpointType") == "Gateway" and ".s3" in ep.get("ServiceName", "")}
            dynamo_vpcs = {ep["VpcId"] for ep in endpoints if ep.get("VpcEndpointType") == "Gateway" and ".dynamodb" in ep.get("ServiceName", "")}

            # Bug fix #3: derive igw_vpcs from route table's own VpcId — not from association cross-product
            igw_vpcs = set()
            for rt in rts:
                if any(r.get("GatewayId", "").startswith("igw-") for r in rt.get("Routes", [])):
                    igw_vpcs.add(rt.get("VpcId", ""))

            # Subnet type classification
            subnet_type: Dict[str, str] = {}
            for rt in rts:
                has_igw = any(r.get("GatewayId", "").startswith("igw-") for r in rt.get("Routes", []))
                has_nat = any(r.get("NatGatewayId", "").startswith("nat-") for r in rt.get("Routes", []))
                for assoc in rt.get("Associations", []):
                    sid = assoc.get("SubnetId")
                    if sid:
                        subnet_type[sid] = "public" if has_igw else ("private" if has_nat else "isolated")

            # Bug fix #2: exclude NAT Gateway's own ENIs from subnet ENI count
            eni_count: Dict[str, int] = {}
            for eni in enis:
                if eni.get("InterfaceType") == "nat_gateway":
                    continue
                sid = eni.get("SubnetId")
                if sid:
                    eni_count[sid] = eni_count.get(sid, 0) + 1

            # vpc_endpoint_count per VPC (bug fix #8)
            endpoint_count: Dict[str, int] = {}
            for ep in endpoints:
                vid = ep.get("VpcId", "")
                if vid:
                    endpoint_count[vid] = endpoint_count.get(vid, 0) + 1

            # NATs grouped by VPC
            nat_by_vpc: Dict[str, list] = {}
            for nat in nats:
                nat_by_vpc.setdefault(nat.get("VpcId", ""), []).append(nat)

            now_utc = datetime.now(timezone.utc)

            # ── VPC rows ──────────────────────────────────────────────────
            # Pre-group subnets by VPC once — avoids O(n²) list scan per VPC
            subnets_by_vpc: Dict[str, list] = {}
            for s in subnets:
                subnets_by_vpc.setdefault(s["VpcId"], []).append(s)

            vpc_rows = []
            for vpc in vpcs:
                vid = vpc["VpcId"]
                vpc_subnets = subnets_by_vpc.get(vid, [])
                vpc_nats    = nat_by_vpc.get(vid, [])
                vpc_rows.append({
                    "account_id":   account_id,
                    "account_name": account_name,
                    "region":       region,
                    "vpc_id":       vid,
                    "vpc_name":     next((t["Value"] for t in vpc.get("Tags", []) if t["Key"] == "Name"), ""),
                    "cidr_block":   vpc.get("CidrBlock", ""),
                    "is_default_vpc": 1 if vpc.get("IsDefault") else 0,
                    "subnet_count":           len(vpc_subnets),
                    "public_subnet_count":    sum(1 for s in vpc_subnets if subnet_type.get(s["SubnetId"]) == "public"),
                    "private_subnet_count":   sum(1 for s in vpc_subnets if subnet_type.get(s["SubnetId"]) == "private"),
                    "isolated_subnet_count":  sum(1 for s in vpc_subnets if subnet_type.get(s["SubnetId"]) == "isolated"),
                    "nat_gateway_count":        len(vpc_nats),
                    "active_nat_gateway_count": sum(1 for n in vpc_nats if n.get("State") == "available"),
                    "has_s3_gateway_endpoint":       1 if vid in s3_vpcs else 0,
                    "has_dynamodb_gateway_endpoint": 1 if vid in dynamo_vpcs else 0,
                    "has_internet_gateway":          1 if vid in igw_vpcs else 0,
                    "flow_logs_enabled":             1 if vid in flow_log_vpcs else 0,
                    "vpc_endpoint_count":            endpoint_count.get(vid, 0),
                    "tags":       {t["Key"]: t["Value"] for t in vpc.get("Tags", [])},
                    "ingested_at": now_utc.replace(tzinfo=None),
                    "version":     int(now_utc.timestamp()),
                })

            # ── NAT rows ──────────────────────────────────────────────────
            nat_rows = []
            for nat in nats:
                sid = nat.get("SubnetId", "")
                az  = subnet_to_az.get(sid, region)
                ct  = nat.get("CreateTime")

                # Bug fix #7: correct timezone handling for boto3 tz-aware datetimes
                if ct is not None:
                    if ct.tzinfo is None:
                        ct = ct.replace(tzinfo=timezone.utc)
                    age_days     = (now_utc - ct).days
                    ct_naive     = ct.astimezone(timezone.utc).replace(tzinfo=None)
                else:
                    age_days = 0
                    ct_naive = None

                addrs = nat.get("NatGatewayAddresses") or []
                nat_rows.append({
                    "account_id":   account_id,
                    "account_name": account_name,
                    "region":       region,
                    "availability_zone": az,
                    "nat_gateway_id":    nat["NatGatewayId"],
                    "vpc_id":            nat.get("VpcId", ""),
                    "subnet_id":         sid,
                    "state":             nat.get("State", ""),
                    "connectivity_type": nat.get("ConnectivityType", "public"),
                    "elastic_ip_address":      addrs[0].get("PublicIp", "")      if addrs else "",
                    "elastic_ip_allocation_id": addrs[0].get("AllocationId", "") if addrs else "",
                    "create_time":             ct_naive,
                    "age_days":                age_days,
                    "subnet_active_eni_count": eni_count.get(sid, 0),
                    "tags":       {t["Key"]: t["Value"] for t in nat.get("Tags", [])},
                    "ingested_at": now_utc.replace(tzinfo=None),
                    "version":     int(now_utc.timestamp()),
                })

            # ── ENI → VPC lookup map (built from already-fetched enis) ──
            eni_to_vpc = {e["NetworkInterfaceId"]: e.get("VpcId", "") for e in enis}

            # Fill gaps for EIP-attached ENIs that may be in 'available' state (not in in-use filter)
            # Fetch individually — batch call fails entirely if any single ENI ID is deleted (poison pill)
            eip_eni_ids = {eip.get("NetworkInterfaceId") for eip in eips if eip.get("NetworkInterfaceId")}
            missing_eni_ids = eip_eni_ids - set(eni_to_vpc.keys())
            for eni_id in missing_eni_ids:
                try:
                    resp = ec2.describe_network_interfaces(NetworkInterfaceIds=[eni_id])
                    nifs = resp.get("NetworkInterfaces", [])
                    if nifs:
                        eni_to_vpc[eni_id] = nifs[0].get("VpcId", "")
                except ClientError:
                    pass  # deleted ENI — skip, vpc_id stays empty which is correct

            # ── ENI rows ──────────────────────────────────────────────────
            eni_rows = []
            for eni in enis:
                attachment = eni.get("Attachment") or {}
                eni_rows.append({
                    "account_id":     account_id,
                    "account_name":   account_name,
                    "region":         region,
                    "eni_id":         eni["NetworkInterfaceId"],
                    "vpc_id":         eni.get("VpcId", ""),
                    "subnet_id":      eni.get("SubnetId", ""),
                    "instance_id":    attachment.get("InstanceId", ""),
                    "interface_type": eni.get("InterfaceType", ""),
                    "description":    eni.get("Description", ""),
                    "tags":           {t["Key"]: t["Value"] for t in eni.get("TagSet", [])},
                    "ingested_at":    now_utc.replace(tzinfo=None),
                    "version":        int(now_utc.timestamp()),
                })

            # ── EIP rows ──────────────────────────────────────────────────
            eip_rows = []
            for eip in eips:
                assoc_id = eip.get("AssociationId", "")
                eni_id   = eip.get("NetworkInterfaceId", "")
                eip_rows.append({
                    "account_id":           account_id,
                    "account_name":         account_name,
                    "region":               region,
                    "allocation_id":        eip.get("AllocationId", ""),
                    "public_ip":            eip.get("PublicIp", ""),
                    "association_id":       assoc_id,
                    "network_interface_id": eni_id,
                    "vpc_id":               eni_to_vpc.get(eni_id, ""),
                    "is_attached":          1 if assoc_id else 0,
                    "tags":                 {t["Key"]: t["Value"] for t in eip.get("Tags", [])},
                    "ingested_at":          now_utc.replace(tzinfo=None),
                    "version":              int(now_utc.timestamp()),
                })

            # ── Ingest ────────────────────────────────────────────────────
            if vpc_rows:
                self.ch_engine.ingest(vpc_rows, table=self.VPC_TABLE)
            if nat_rows:
                self.ch_engine.ingest(nat_rows, table=self.NAT_TABLE)
            if eip_rows:
                self.ch_engine.ingest(eip_rows, table=self.EIP_TABLE)
            if eni_rows:
                self.ch_engine.ingest(eni_rows, table=self.ENI_TABLE)

            elapsed = round(time.time() - start_ts, 1)
            logger.info(
                f"[VPC Metadata] ── DONE ───────────────────────────────────────\n"
                f"[VPC Metadata]   Account : {account_name} ({account_id})\n"
                f"[VPC Metadata]   Region  : {region}\n"
                f"[VPC Metadata]   VPCs    : {len(vpc_rows)} | NATs: {len(nat_rows)} | EIPs: {len(eip_rows)} | ENIs: {len(eni_rows)}\n"
                f"[VPC Metadata]   Duration: {elapsed}s"
            )

        except ClientError as e:
            logger.error(f"[VPC Metadata] AWS API error for '{account_name}' in {region}: {e}", exc_info=True)
        except Exception as e:
            logger.error(f"[VPC Metadata] Unexpected error for '{account_name}' in {region}: {e}", exc_info=True)

    def _describe_addresses(self, client) -> List[dict]:
        """describe_addresses does not support pagination — single call returns all EIPs."""
        try:
            return client.describe_addresses().get("Addresses", [])
        except ClientError as e:
            code = e.response.get("Error", {}).get("Code", "")
            if code in ("UnauthorizedOperation", "AccessDenied"):
                logger.warning(f"[VPC Metadata] describe_addresses — permission denied (check IAM policy): {e}")
            else:
                logger.warning(f"[VPC Metadata] describe_addresses skipped (non-fatal): {e}")
            return []

    def _paginate(self, client, method: str, key: str) -> List[dict]:
        """Paginate without filters. Logs permission errors with context."""
        results = []
        try:
            for page in client.get_paginator(method).paginate():
                results.extend(page.get(key, []))
        except ClientError as e:
            # Bug fix #6: log with context so ops can distinguish permission errors from real failures
            code = e.response.get("Error", {}).get("Code", "")
            if code in ("UnauthorizedOperation", "AccessDenied"):
                logger.warning(f"[VPC Metadata] {method} — permission denied (check IAM policy): {e}")
            else:
                logger.warning(f"[VPC Metadata] {method} skipped (non-fatal): {e}")
        return results

    def _paginate_filtered(self, client, method: str, key: str, **kwargs) -> List[dict]:
        """Paginate with filters passed as kwargs (e.g. Filters=[...])."""
        results = []
        try:
            for page in client.get_paginator(method).paginate(**kwargs):
                results.extend(page.get(key, []))
        except ClientError as e:
            code = e.response.get("Error", {}).get("Code", "")
            if code in ("UnauthorizedOperation", "AccessDenied"):
                logger.warning(f"[VPC Metadata] {method} — permission denied (check IAM policy): {e}")
            else:
                logger.warning(f"[VPC Metadata] {method} skipped (non-fatal): {e}")
        return results
