
EOL_VERSIONS = {
    "mysql":             ["5.6", "5.7"],
    "aurora-mysql":      ["5.6", "5.7"],
    "postgres":          ["9.6", "10", "11"],
    "aurora-postgresql": ["9.6", "10", "11"],
    "mariadb":           ["10.3", "10.4", "10.5"],
    "oracle-ee":         ["12.1", "12.2"],
    "oracle-se2":        ["12.1", "12.2"],
    "sqlserver-se":      ["13.00"],
    "sqlserver-ee":      ["13.00"],
}

GRAVITON_FAMILIES = {
    "m6g", "m7g", "m8g",
    "r6g", "r7g", "r8g",
    "t4g", "x2g", "c6g", "c7g",
}
