"""
engine/aws/rds_metadata.py

RDS FinOps Metadata Extractor — Production Ready.

Architecture decisions:
  - describe_db_instances() paginated — full region scan, FREE.
  - CloudWatch utilization: ONE batched get_metric_data() call per instance
    fetching ALL 7 metrics simultaneously. FREE — RDS publishes these automatically.
    Period: 3600s (1 hour), window: 14 days = 336 data points per metric.
    Well under the 1,440 CloudWatch limit per call.
  - Aurora guard: storage-type flags skip Aurora instances entirely.
    Aurora uses proprietary distributed storage — gp2/gp3/io1 don't apply.
  - instance_family derived by parsing instance_class (e.g. db.r5.2xlarge → r5).
  - Two separate try/except blocks: AWS extraction + ClickHouse insert.
"""

import logging
import time
from datetime import datetime, timezone, timedelta
from typing import Dict, List

from botocore.config import Config
from botocore.exceptions import ClientError
from .rds_constants import EOL_VERSIONS as _EOL_VERSIONS, GRAVITON_FAMILIES as _GRAVITON_FAMILIES

logger = logging.getLogger(__name__)

_RETRY_CFG = Config(retries={"max_attempts": 5, "mode": "adaptive"})

_CW_WINDOW_DAYS = 14
_CW_PERIOD_SEC  = 3600  # 1 hour — 336 points per metric, well under 1440 limit


class RDSMetadataExtractor:
    """
    Fetches FinOps-critical metadata + CloudWatch utilization for all RDS
    instances in one account/region.

    Usage (called from app.py _run_metadata_extractors):
        RDSMetadataExtractor(ch_client).ingest(session, account_id, account_name, region)
    """

    TABLE = "cost.aws_rds_metadata"

    def __init__(self, ch_engine):
        self.ch_engine = ch_engine

    def ingest(self, session, account_id: str, account_name: str, region: str) -> None:
        start_ts = time.time()

        logger.info(
            f"[RDS Metadata] ── START ──────────────────────────────────────\n"
            f"[RDS Metadata]   Account : {account_name} ({account_id})\n"
            f"[RDS Metadata]   Region  : {region}"
        )

        rows: List[Dict] = []

        try:
            rds_client = session.client("rds", region_name=region, config=_RETRY_CFG)
            cw_client  = session.client("cloudwatch", region_name=region, config=_RETRY_CFG)

            instances = self._list_instances(rds_client)

            if not instances:
                logger.info(f"[RDS Metadata] No instances found for '{account_name}' in {region} — skipping.")
                return

            logger.info(f"[RDS Metadata] Found {len(instances)} instances — building rows...")

            for i, inst in enumerate(instances):
                try:
                    utilization = self._fetch_utilization(cw_client, inst["DBInstanceIdentifier"])
                    row = self._build_row(inst, account_id, account_name, region, utilization)
                    rows.append(row)

                    flags = self._quick_flags(row)
                    flag_str = f"  ⚠ {', '.join(flags)}" if flags else "  ✓ clean"
                    logger.info(
                        f"[RDS Metadata]   [{i+1:>3}/{len(instances)}] "
                        f"{row['db_instance_id']:<35} "
                        f"{row['engine']:<12} "
                        f"{row['instance_class']:<20} "
                        f"cpu={row['avg_cpu_pct']:.1f}%"
                        f"{flag_str}"
                    )

                    # Rate limit: pause every 20 instances to avoid CloudWatch ThrottlingException
                    if (i + 1) % 20 == 0 and (i + 1) < len(instances):
                        time.sleep(0.5)

                except Exception as e:
                    logger.warning(f"[RDS Metadata] Skipping instance '{inst.get('DBInstanceIdentifier', 'unknown')}': {e}")
                    continue

        except ClientError as e:
            logger.error(f"[RDS Metadata] AWS API error for '{account_name}' in {region}: {e}", exc_info=True)
            return
        except Exception as e:
            logger.error(f"[RDS Metadata] Unexpected extraction error for '{account_name}': {e}", exc_info=True)
            return

        if not rows:
            logger.info(f"[RDS Metadata] No rows to insert for '{account_name}' in {region}.")
            return

        try:
            self.ch_engine.ingest(rows, table=self.TABLE)
        except Exception as e:
            logger.error(f"[RDS Metadata] ClickHouse insert failed for '{account_name}' ({len(rows)} rows): {e}", exc_info=True)
            return

        elapsed = round(time.time() - start_ts, 1)

        eol_count      = sum(1 for r in rows if self._is_eol(r["engine"], r["engine_version"]))
        downsize_count = sum(1 for r in rows if 0 <= r["avg_cpu_pct"] < 10)
        graviton_count = sum(1 for r in rows if r["instance_family"] not in _GRAVITON_FAMILIES and "aurora" not in r["engine"])
        multi_az_count = sum(1 for r in rows if r["multi_az"])

        logger.info(
            f"[RDS Metadata] ── DONE ───────────────────────────────────────\n"
            f"[RDS Metadata]   Account      : {account_name} ({account_id})\n"
            f"[RDS Metadata]   Region       : {region}\n"
            f"[RDS Metadata]   Instances    : {len(rows)} ingested\n"
            f"[RDS Metadata]   EOL engine   : {eol_count}\n"
            f"[RDS Metadata]   Downsize     : {downsize_count} (CPU <10%)\n"
            f"[RDS Metadata]   Graviton     : {graviton_count} (savings available)\n"
            f"[RDS Metadata]   Multi-AZ     : {multi_az_count}\n"
            f"[RDS Metadata]   Duration     : {elapsed}s"
        )

    def _list_instances(self, rds_client) -> List[dict]:
        instances = []
        try:
            paginator = rds_client.get_paginator("describe_db_instances")
            for page in paginator.paginate():
                instances.extend(page.get("DBInstances", []))
        except ClientError as e:
            logger.warning(f"[RDS Metadata] Could not list instances: {e}")
        return instances

    def _fetch_utilization(self, cw_client, db_instance_id: str) -> Dict:
        """
        ONE batched get_metric_data() call — all 7 metrics simultaneously.
        FREE — RDS publishes these to CloudWatch automatically.
        Returns -1.0 for any metric with no data.
        """
        now   = datetime.now(timezone.utc)
        start = now - timedelta(days=_CW_WINDOW_DAYS)
        dims  = [{"Name": "DBInstanceIdentifier", "Value": db_instance_id}]

        def _q(metric_id, metric_name, stat):
            return {
                "Id": metric_id,
                "MetricStat": {
                    "Metric": {"Namespace": "AWS/RDS", "MetricName": metric_name, "Dimensions": dims},
                    "Period": _CW_PERIOD_SEC,
                    "Stat": stat,
                },
                "ReturnData": True,
            }

        queries = [
            _q("cpu_avg",   "CPUUtilization",      "Average"),
            _q("cpu_max",   "CPUUtilization",      "Maximum"),
            _q("conn_avg",  "DatabaseConnections", "Average"),
            _q("conn_max",  "DatabaseConnections", "Maximum"),
            _q("mem_avg",   "FreeableMemory",      "Average"),
            _q("riops_avg", "ReadIOPS",            "Average"),
            _q("wiops_avg", "WriteIOPS",           "Average"),
        ]

        result = {
            "avg_cpu_pct":               -1.0,
            "max_cpu_pct":               -1.0,
            "avg_connections":           -1.0,
            "max_connections":           -1.0,
            "avg_freeable_memory_bytes": -1.0,
            "avg_read_iops":             -1.0,
            "avg_write_iops":            -1.0,
            "utilization_last_updated":  now.replace(tzinfo=None),
        }

        key_map = {
            "cpu_avg":   "avg_cpu_pct",
            "cpu_max":   "max_cpu_pct",
            "conn_avg":  "avg_connections",
            "conn_max":  "max_connections",
            "mem_avg":   "avg_freeable_memory_bytes",
            "riops_avg": "avg_read_iops",
            "wiops_avg": "avg_write_iops",
        }

        try:
            # Handle NextToken pagination — silent data loss if ignored
            accumulated: dict = {mid: [] for mid in key_map}
            next_token = None

            while True:
                kwargs: dict = {"MetricDataQueries": queries, "StartTime": start, "EndTime": now}
                if next_token:
                    kwargs["NextToken"] = next_token
                response   = cw_client.get_metric_data(**kwargs)
                next_token = response.get("NextToken")

                for mr in response.get("MetricDataResults", []):
                    values = mr.get("Values", [])
                    if values and mr["Id"] in accumulated:
                        accumulated[mr["Id"]].extend(values)

                if not next_token:
                    break

            # Peak metrics use max(), average metrics use mean()
            _peak_ids = {"cpu_max", "conn_max"}
            for mid, values in accumulated.items():
                if values:
                    field = key_map[mid]
                    result[field] = round(max(values) if mid in _peak_ids else sum(values) / len(values), 2)

        except ClientError as e:
            logger.warning(f"[RDS Metadata] CloudWatch fetch failed for '{db_instance_id}' (non-fatal): {e}")

        return result

    @staticmethod
    def _build_row(inst: dict, account_id: str, account_name: str, region: str, utilization: Dict) -> Dict:
        now            = datetime.now(timezone.utc)
        instance_class  = inst.get("DBInstanceClass", "")
        parts           = instance_class.split(".")
        instance_family = parts[1] if len(parts) >= 2 else ""

        read_replica_ids = inst.get("ReadReplicaDBInstanceIdentifiers", [])
        source_id        = inst.get("ReadReplicaSourceDBInstanceIdentifier", "") or ""

        create_time = inst.get("InstanceCreateTime")
        if create_time:
            if create_time.tzinfo is None:
                create_time = create_time.replace(tzinfo=timezone.utc)
            age_days = (now - create_time).days
            create_time_naive = create_time.replace(tzinfo=None)
        else:
            age_days = 0
            create_time_naive = None

        tags = {
            str(t["Key"]): str(t.get("Value") or "")
            for t in inst.get("TagList", [])
            if t.get("Key")
        }
        subnet_group = inst.get("DBSubnetGroup", {})
        db_subnet_group = subnet_group.get("DBSubnetGroupName", "") if subnet_group else ""

        return {
            "account_id":           account_id,
            "account_name":         account_name,
            "region":               region,
            "availability_zone":    inst.get("AvailabilityZone", ""),
            "db_instance_id":       inst.get("DBInstanceIdentifier", ""),
            "db_cluster_identifier": inst.get("DBClusterIdentifier") or None,
            "db_arn":               inst.get("DBInstanceArn", ""),
            "engine":               inst.get("Engine", ""),
            "engine_version":       inst.get("EngineVersion", ""),
            "license_model":        inst.get("LicenseModel", ""),
            "instance_class":       instance_class,
            "instance_family":      instance_family,
            "db_instance_status":   inst.get("DBInstanceStatus", ""),
            "storage_type":         inst.get("StorageType", ""),
            "allocated_storage_gb": inst.get("AllocatedStorage", 0),
            "max_allocated_storage_gb": inst.get("MaxAllocatedStorage", 0) or 0,
            "provisioned_iops":     inst.get("Iops", 0) or 0,
            "storage_throughput":   inst.get("StorageThroughput", 0) or 0,
            "storage_encrypted":    1 if inst.get("StorageEncrypted", False) else 0,
            "multi_az":             1 if inst.get("MultiAZ", False) else 0,
            "read_replica_count":   len(read_replica_ids),
            "source_db_instance_id": source_id,
            "publicly_accessible":  1 if inst.get("PubliclyAccessible", False) else 0,
            "backup_retention_period": inst.get("BackupRetentionPeriod", 0) or 0,
            "backup_window":           inst.get("PreferredBackupWindow", ""),
            "maintenance_window":      inst.get("PreferredMaintenanceWindow", ""),
            "instance_create_time":    create_time_naive,
            "age_days":                age_days,
            "auto_minor_version_upgrade": 1 if inst.get("AutoMinorVersionUpgrade", False) else 0,
            "deletion_protection":     1 if inst.get("DeletionProtection", False) else 0,
            "performance_insights_enabled":   1 if inst.get("PerformanceInsightsEnabled", False) else 0,
            "performance_insights_retention": inst.get("PerformanceInsightsRetentionPeriod", 0) or 0,
            "enhanced_monitoring_interval":   inst.get("MonitoringInterval", 0) or 0,
            "ca_certificate_identifier": inst.get("CACertificateIdentifier", ""),
            "iam_db_auth_enabled":       1 if inst.get("IAMDatabaseAuthenticationEnabled", False) else 0,
            "db_subnet_group": db_subnet_group,
            "tags":            tags,
            "avg_cpu_pct":               float(utilization.get("avg_cpu_pct", -1.0)),
            "max_cpu_pct":               float(utilization.get("max_cpu_pct", -1.0)),
            "avg_connections":           float(utilization.get("avg_connections", -1.0)),
            "max_connections":           float(utilization.get("max_connections", -1.0)),
            "avg_freeable_memory_bytes": float(utilization.get("avg_freeable_memory_bytes", -1.0)),
            "avg_read_iops":             float(utilization.get("avg_read_iops", -1.0)),
            "avg_write_iops":            float(utilization.get("avg_write_iops", -1.0)),
            "utilization_window_days":   _CW_WINDOW_DAYS,
            "utilization_last_updated":  utilization.get("utilization_last_updated"),
            "ingested_at": now.replace(tzinfo=None),
            "version":     int(now.timestamp()),
        }

    @staticmethod
    def _is_eol(engine: str, engine_version: str) -> bool:
        for prefix in _EOL_VERSIONS.get(engine.lower(), []):
            if engine_version.startswith(prefix):
                return True
        return False

    @staticmethod
    def _quick_flags(row: dict) -> List[str]:
        flags = []
        engine        = row.get("engine", "").lower()
        is_aurora     = "aurora" in engine
        is_serverless = "serverless" in row.get("instance_class", "").lower()
        if RDSMetadataExtractor._is_eol(engine, row.get("engine_version", "")):
            flags.append("EOL")
        if 0 <= row.get("avg_cpu_pct", -1) < 10:
            flags.append("LOW_CPU")
        if 0 <= row.get("avg_connections", -1) < 5:
            flags.append("LOW_CONN")
        if not is_aurora and row.get("storage_type", "") in ["gp2", "io1", "io2"]:
            flags.append("GP2/IO1")
        if row.get("instance_family", "") not in _GRAVITON_FAMILIES and not is_serverless:
            flags.append("NO_GRAVITON")
        if row.get("multi_az") and row.get("tags", {}).get("Environment", "").lower() in ["dev", "staging", "test"]:
            flags.append("MULTI_AZ_DEV")
        return flags
