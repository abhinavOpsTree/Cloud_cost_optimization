"""
ECR Metadata Extractor — Boto3 Operational Snapshot
Runs daily alongside Athena cost ingestion in the master loop.

Data collected per repository:
  - image_count, untagged_images, latest_push
  - critical_vulnerabilities, high_vulnerabilities
  - lifecycle_policy_enabled

All stored in cost.aws_ecr_metadata (ReplacingMergeTree).
"""

import logging
import time
from datetime import datetime
from botocore.config import Config
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)

# Adaptive retry config — handles ECR throttling (20 req/s limit) automatically
_RETRY_CFG = Config(retries={"max_attempts": 5, "mode": "adaptive"})


class ECRMetadataExtractor:
    """
    Fetches ECR operational metadata via the live AWS ECR Boto3 API
    and inserts a nightly snapshot into ClickHouse.
    """

    TABLE = "cost.aws_ecr_metadata"
    COLUMNS = [
        "account_id", "account_name", "region", "repository_name",
        "image_count", "untagged_images", "latest_push",
        "critical_vulnerabilities", "high_vulnerabilities",
        "lifecycle_policy_enabled", "ingested_at"
    ]

    def __init__(self, ch_engine):
        self.ch_engine = ch_engine

    # ──────────────────────────────────────────────
    # Internal helpers with pagination
    # ──────────────────────────────────────────────

    def _list_repositories(self, ecr_client):
        """Paginated describe_repositories — handles any account size."""
        repos = []
        paginator = ecr_client.get_paginator("describe_repositories")
        for page in paginator.paginate():
            repos.extend(page.get("repositories", []))
        return repos

    def _describe_images(self, ecr_client, repo_name):
        """Paginated describe_images — handles repos with 100+ images."""
        images = []
        try:
            paginator = ecr_client.get_paginator("describe_images")
            for page in paginator.paginate(repositoryName=repo_name):
                images.extend(page.get("imageDetails", []))
        except ClientError as e:
            logger.warning(f"Could not describe images for repo '{repo_name}': {e}")
        return images

    def _check_lifecycle_policy(self, ecr_client, repo_name):
        """
        Returns 1 if a lifecycle policy exists, 0 otherwise.
        Uses ClientError + error code check — the safe, universally reliable pattern.
        boto3 client exception classes (ecr_client.exceptions.*) are only guaranteed
        to be loaded after the first successful API call; accessing them on a fresh
        client risks AttributeError. Error code strings are always present in the response.
        """
        try:
            ecr_client.get_lifecycle_policy(repositoryName=repo_name)
            return 1
        except ClientError as e:
            code = e.response.get("Error", {}).get("Code", "")
            if code in ("LifecyclePolicyNotFoundException", "RepositoryNotFoundException"):
                return 0
            logger.warning(f"Lifecycle policy check failed for '{repo_name}': {e}")
            return 0

    # ──────────────────────────────────────────────
    # Public ingestion method
    # ──────────────────────────────────────────────

    def ingest(self, session, account_id: str, account_name: str, region: str):
        """
        Called once per account per daily run.
        Fetches all ECR repositories and their metadata, then batch-inserts into ClickHouse.
        """
        start_ts = time.time()

        # ── START banner ────────────────────────────────────────────────────
        logger.info(
            f"[ECR Metadata] ── START ──────────────────────────────────────\n"
            f"[ECR Metadata]   Account : {account_name} ({account_id})\n"
            f"[ECR Metadata]   Region  : {region}"
        )

        rows = []

        try:
            # Attach adaptive retry config to avoid throttling on large accounts
            ecr = session.client("ecr", region_name=region, config=_RETRY_CFG)
            repos = self._list_repositories(ecr)

            if not repos:
                logger.info(
                    f"[ECR Metadata] No repositories found for '{account_name}' "
                    f"in {region} — skipping."
                )
                return

            # ── Repository count ─────────────────────────────────────────
            logger.info(
                f"[ECR Metadata] Found {len(repos)} repositories — "
                f"starting metadata scan..."
            )

            for i, repo in enumerate(repos):
                repo_name = repo["repositoryName"]

                # Per-repo progress — every repo logged at DEBUG,
                # milestones (every 10) logged at INFO to avoid log flood
                if (i + 1) % 10 == 0 or i == 0 or (i + 1) == len(repos):
                    logger.info(
                        f"[ECR Metadata]   [{i+1}/{len(repos)}] {repo_name}"
                    )
                else:
                    logger.debug(
                        f"[ECR Metadata]   [{i+1}/{len(repos)}] {repo_name}"
                    )

                # Fetch all images (paginated)
                images = self._describe_images(ecr, repo_name)
                total_images = len(images)
                untagged = sum(1 for img in images if "imageTags" not in img)

                # Safely aggregate vulnerability counts across all images
                crit_vulns = 0
                high_vulns = 0
                for img in images:
                    findings = (
                        img
                        .get("imageScanFindingsSummary", {})
                        .get("findingSeverityCounts", {})
                    )
                    crit_vulns += findings.get("CRITICAL", 0)
                    high_vulns += findings.get("HIGH", 0)

                # Latest push date — None for repos with no images (semantically correct)
                push_dates = [
                    img["imagePushedAt"]
                    for img in images
                    if "imagePushedAt" in img
                ]
                latest_push = None
                if push_dates:
                    latest_push = max(push_dates)
                    # Strip timezone — ECR SDK returns tz-aware datetimes (UTC);
                    # ClickHouse DateTime columns reject tz-aware Python datetimes.
                    if hasattr(latest_push, "tzinfo") and latest_push.tzinfo is not None:
                        latest_push = latest_push.replace(tzinfo=None)

                lifecycle_enabled = self._check_lifecycle_policy(ecr, repo_name)

                rows.append([
                    account_id,
                    account_name,
                    region,
                    repo_name,
                    total_images,
                    untagged,
                    latest_push,
                    crit_vulns,
                    high_vulns,
                    lifecycle_enabled,
                    datetime.utcnow(),
                ])

                # Inter-repo sleep — throttle guard between repos, skip after the last one.
                # Rate limit pressure is highest right after the lifecycle policy call.
                if i < len(repos) - 1:
                    time.sleep(0.05)

        except ClientError as e:
            logger.error(f"[ECR Metadata] AWS API error for '{account_name}': {e}", exc_info=True)
            return
        except Exception as e:
            logger.error(f"[ECR Metadata] Unexpected extraction error for '{account_name}': {e}", exc_info=True)
            return

        # ── ClickHouse insert — separate try/except for distinct observability ──
        # An insert failure looks completely different from an AWS API failure.
        try:
            if rows:
                self.ch_engine.client.insert(
                    self.TABLE,
                    rows,
                    column_names=self.COLUMNS,
                )
        except Exception as e:
            logger.error(
                f"[ECR Metadata] ClickHouse insert failed for '{account_name}' "
                f"({len(rows)} rows): {e}",
                exc_info=True,
            )
            return

        # ── FINISH summary ────────────────────────────────────────────────
        elapsed = round(time.time() - start_ts, 1)
        logger.info(
            f"[ECR Metadata] ── DONE ───────────────────────────────────────\n"
            f"[ECR Metadata]   Account     : {account_name} ({account_id})\n"
            f"[ECR Metadata]   Repositories: {len(rows)} ingested\n"
            f"[ECR Metadata]   Duration    : {elapsed}s"
        )

