"""
EKS Metadata Extractor — Boto3 Operational Snapshot
Runs daily alongside Athena cost ingestion in the master loop.

Data collected per cluster:
  - kubernetes_version, cluster_status
  - nodegroup_count, fargate_profiles_count, total_nodes
  - has_spot_nodes, has_degraded_nodegroup, node_instance_types
  - addon_count, has_degraded_addon

All stored in cost.aws_eks_metadata (ReplacingMergeTree).
"""

import logging
import time
from datetime import datetime
from botocore.config import Config
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)

# Adaptive retry config — handles EKS throttling automatically
_RETRY_CFG = Config(retries={"max_attempts": 5, "mode": "adaptive"})


class EKSMetadataExtractor:
    """
    Fetches EKS operational metadata via the live AWS EKS Boto3 API
    and inserts a nightly snapshot into ClickHouse.
    """

    TABLE = "cost.aws_eks_metadata"
    COLUMNS = [
        "account_id", "account_name", "region", "cluster_name",
        "kubernetes_version", "cluster_status",
        "nodegroup_count", "fargate_profiles_count", "total_nodes",
        "has_spot_nodes", "has_degraded_nodegroup", "node_instance_types",
        "addon_count", "has_degraded_addon", "ingested_at"
    ]

    def __init__(self, ch_engine):
        self.ch_engine = ch_engine

    # ──────────────────────────────────────────────
    # Internal helpers with pagination
    # ──────────────────────────────────────────────

    def _list_clusters(self, eks_client):
        """Paginated list_clusters — handles any account size."""
        clusters = []
        try:
            paginator = eks_client.get_paginator("list_clusters")
            for page in paginator.paginate():
                clusters.extend(page.get("clusters", []))
        except ClientError as e:
            logger.warning(f"Could not list EKS clusters: {e}")
        return clusters

    def _describe_cluster(self, eks_client, cluster_name):
        """Fetch cluster baseline details."""
        try:
            response = eks_client.describe_cluster(name=cluster_name)
            return response.get("cluster", {})
        except ClientError as e:
            logger.warning(f"Could not describe cluster '{cluster_name}': {e}")
            return None

    def _get_addon_details(self, eks_client, cluster_name):
        """
        Returns (addon_count, has_degraded_addon).
        Checks addon status to detect degraded addons.
        """
        addon_names = []
        has_degraded = 0

        try:
            paginator = eks_client.get_paginator("list_addons")
            for page in paginator.paginate(clusterName=cluster_name):
                addon_names.extend(page.get("addons", []))
        except ClientError as e:
            logger.warning(f"Could not list addons for cluster '{cluster_name}': {e}")
            return 0, 0

        addon_count = len(addon_names)

        # Check each addon status
        for addon_name in addon_names:
            time.sleep(0.05)  # Unified sleep time with nodegroups
            try:
                addon_detail = eks_client.describe_addon(
                    clusterName=cluster_name, addonName=addon_name
                )
                status = addon_detail.get("addon", {}).get("status", "")
                if status not in ("ACTIVE", "CREATING", "UPDATING"):
                    has_degraded = 1
            except ClientError:
                pass  # Skip if describe fails

        return addon_count, has_degraded

    def _get_fargate_profile_count(self, eks_client, cluster_name):
        """Returns count of Fargate profiles."""
        count = 0
        try:
            paginator = eks_client.get_paginator("list_fargate_profiles")
            for page in paginator.paginate(clusterName=cluster_name):
                count += len(page.get("fargateProfileNames", []))
        except ClientError as e:
            logger.warning(f"Could not list Fargate profiles for '{cluster_name}': {e}")
        return count

    def _get_nodegroup_details(self, eks_client, cluster_name):
        """
        Returns dict with:
          - nodegroup_count
          - total_nodes
          - has_spot_nodes
          - has_degraded_nodegroup
          - node_instance_types (set)
        """
        details = {
            "nodegroup_count": 0,
            "total_nodes": 0,
            "has_spot_nodes": 0,
            "has_degraded_nodegroup": 0,
            "node_instance_types": set(),
        }

        try:
            paginator = eks_client.get_paginator("list_nodegroups")
            nodegroup_names = []
            for page in paginator.paginate(clusterName=cluster_name):
                nodegroup_names.extend(page.get("nodegroups", []))

            details["nodegroup_count"] = len(nodegroup_names)

            for ng_name in nodegroup_names:
                time.sleep(0.05)  # Throttle protection
                try:
                    ng_resp = eks_client.describe_nodegroup(
                        clusterName=cluster_name, nodegroupName=ng_name
                    )
                    ng = ng_resp.get("nodegroup", {})

                    # Check status
                    status = ng.get("status", "UNKNOWN")
                    if status not in ("ACTIVE", "CREATING", "UPDATING"):
                        details["has_degraded_nodegroup"] = 1

                    # Accumulate nodes
                    details["total_nodes"] += ng.get("scalingConfig", {}).get("desiredSize", 0)

                    # Check for spot
                    if ng.get("capacityType") == "SPOT":
                        details["has_spot_nodes"] = 1

                    # Collect instance types
                    for itype in ng.get("instanceTypes", []):
                        details["node_instance_types"].add(itype)

                except ClientError as ng_err:
                    logger.warning(f"Could not describe nodegroup '{ng_name}': {ng_err}")

        except ClientError as e:
            logger.warning(f"Could not list nodegroups for '{cluster_name}': {e}")

        return details

    # ──────────────────────────────────────────────
    # Public ingestion method
    # ──────────────────────────────────────────────

    def ingest(self, session, account_id: str, account_name: str, region: str):
        """
        Called once per account per daily run.
        Fetches all EKS clusters and their metadata, then batch-inserts into ClickHouse.
        """
        start_ts = time.time()

        # ── START banner ────────────────────────────────────────────────────
        logger.info(
            f"[EKS Metadata] ── START ──────────────────────────────────────\n"
            f"[EKS Metadata]   Account : {account_name} ({account_id})\n"
            f"[EKS Metadata]   Region  : {region}"
        )

        rows = []

        try:
            # Attach adaptive retry config to avoid throttling
            eks = session.client("eks", region_name=region, config=_RETRY_CFG)
            clusters = self._list_clusters(eks)

            if not clusters:
                logger.info(
                    f"[EKS Metadata] No clusters found for '{account_name}' "
                    f"in {region} — skipping."
                )
                return

            # ── Cluster count ─────────────────────────────────────────────
            logger.info(
                f"[EKS Metadata] Found {len(clusters)} clusters — "
                f"starting metadata scan..."
            )

            for i, cluster_name in enumerate(clusters):

                # Every cluster logged at INFO — clusters are fewer than repos
                logger.info(
                    f"[EKS Metadata]   [{i+1}/{len(clusters)}] Scanning: {cluster_name}"
                )

                try:
                    # 1. Cluster baseline
                    cluster = self._describe_cluster(eks, cluster_name)
                    if not cluster:
                        logger.warning(
                            f"[EKS Metadata]   [{i+1}/{len(clusters)}] "
                            f"describe_cluster returned empty — skipping {cluster_name}"
                        )
                        continue

                    kubernetes_version = cluster.get("version", "unknown")
                    cluster_status = cluster.get("status", "UNKNOWN")

                    logger.debug(
                        f"[EKS Metadata]     k8s={kubernetes_version} "
                        f"status={cluster_status}"
                    )

                    # 2. Addon health
                    addon_count, has_degraded_addon = self._get_addon_details(eks, cluster_name)
                    logger.debug(
                        f"[EKS Metadata]     addons={addon_count} "
                        f"degraded={bool(has_degraded_addon)}"
                    )

                    # 3. Fargate profiles
                    fargate_count = self._get_fargate_profile_count(eks, cluster_name)
                    logger.debug(
                        f"[EKS Metadata]     fargate_profiles={fargate_count}"
                    )

                    # 4. Node groups
                    ng_details = self._get_nodegroup_details(eks, cluster_name)
                    logger.debug(
                        f"[EKS Metadata]     nodegroups={ng_details['nodegroup_count']} "
                        f"nodes={ng_details['total_nodes']} "
                        f"spot={bool(ng_details['has_spot_nodes'])} "
                        f"types={sorted(ng_details['node_instance_types'])}"
                    )

                    rows.append([
                        account_id,
                        account_name,
                        region,
                        cluster_name,
                        kubernetes_version,
                        cluster_status,
                        ng_details["nodegroup_count"],
                        fargate_count,
                        ng_details["total_nodes"],
                        ng_details["has_spot_nodes"],
                        ng_details["has_degraded_nodegroup"],
                        list(ng_details["node_instance_types"]),  # ClickHouse Array(String)
                        addon_count,
                        has_degraded_addon,
                        datetime.utcnow(),
                    ])

                    logger.info(
                        f"[EKS Metadata]   [{i+1}/{len(clusters)}] "
                        f"{cluster_name} — OK "
                        f"(k8s={kubernetes_version}, "
                        f"nodes={ng_details['total_nodes']}, "
                        f"spot={bool(ng_details['has_spot_nodes'])})"
                    )

                except ClientError as cluster_err:
                    logger.warning(
                        f"[EKS Metadata]   [{i+1}/{len(clusters)}] "
                        f"AWS error on {cluster_name} — skipping: {cluster_err}"
                    )
                except Exception as cluster_err:
                    logger.warning(
                        f"[EKS Metadata]   [{i+1}/{len(clusters)}] "
                        f"Unexpected error on {cluster_name} — skipping: {cluster_err}",
                        exc_info=True,
                    )

                # Inter-cluster sleep
                if i < len(clusters) - 1:
                    time.sleep(0.05)

        except ClientError as e:
            logger.error(f"[EKS Metadata] AWS API error for '{account_name}': {e}", exc_info=True)
            return
        except Exception as e:
            logger.error(f"[EKS Metadata] Unexpected extraction error for '{account_name}': {e}", exc_info=True)
            return

        # ── ClickHouse insert — separate try/except for distinct observability ──
        try:
            if rows:
                self.ch_engine.client.insert(
                    self.TABLE,
                    rows,
                    column_names=self.COLUMNS,
                )
        except Exception as e:
            logger.error(
                f"[EKS Metadata] ClickHouse insert failed for '{account_name}' "
                f"({len(rows)} rows): {e}",
                exc_info=True,
            )
            return

        # ── FINISH summary ────────────────────────────────────────────────
        elapsed = round(time.time() - start_ts, 1)
        skipped = len(clusters) - len(rows) if clusters else 0
        logger.info(
            f"[EKS Metadata] ── DONE ───────────────────────────────────────\n"
            f"[EKS Metadata]   Account : {account_name} ({account_id})\n"
            f"[EKS Metadata]   Clusters: {len(rows)} ingested, {skipped} skipped\n"
            f"[EKS Metadata]   Duration: {elapsed}s"
        )
