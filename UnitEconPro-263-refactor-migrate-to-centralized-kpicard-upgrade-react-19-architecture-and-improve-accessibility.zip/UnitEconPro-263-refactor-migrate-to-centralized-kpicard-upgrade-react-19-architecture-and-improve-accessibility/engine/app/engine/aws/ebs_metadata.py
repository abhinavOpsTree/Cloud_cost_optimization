import logging
import time
from collections import defaultdict
from datetime import datetime, timezone
from typing import Dict, List, Optional

from botocore.config import Config
from botocore.exceptions import ClientError

logger = logging.getLogger(__name__)

_RETRY_CFG = Config(retries={"max_attempts": 5, "mode": "adaptive"})
_LOG_EVERY_N = 50


class EBSMetadataExtractor:
    """
    Fetches FinOps-critical metadata for all EBS volumes in one account/region.

    Usage (called from app.py _run_metadata_extractors):
        EBSMetadataExtractor(ch_client).ingest(session, account_id, account_name, region)
    """

    TABLE = "cost.aws_ebs_metadata"

    def __init__(self, ch_engine):
        self.ch_engine = ch_engine

    
    def ingest(self, session, account_id: str, account_name: str, region: str) -> None:
        start_ts = time.time()

        logger.info(
            f"[EBS Metadata] ── START ──────────────────────────────────────\n"
            f"[EBS Metadata]   Account : {account_name} ({account_id})\n"
            f"[EBS Metadata]   Region  : {region}"
        )

        rows: List[Dict] = []

        # ── AWS extraction block ──────────────────────────────────
        try:
            ec2 = session.client("ec2", region_name=region, config=_RETRY_CFG)

            # Step 1 — batch load ALL snapshots for this region in ONE call (zero N+1)
            logger.info(f"[EBS Metadata] Loading snapshot map for {region}...")
            snapshot_map = self._load_snapshot_map(ec2, account_id)
            logger.info(f"[EBS Metadata] Snapshot map loaded: {len(snapshot_map)} volumes have snapshots")

            # Step 2 — paginated volume sweep
            volumes = self._list_volumes(ec2)

            if not volumes:
                logger.info(
                    f"[EBS Metadata] No volumes found for '{account_name}' in {region} — skipping."
                )
                return

            logger.info(f"[EBS Metadata] Found {len(volumes)} volumes — building rows...")

            for i, vol in enumerate(volumes):
                try:
                    row = self._build_row(vol, account_id, account_name, region, snapshot_map)
                    rows.append(row)

                    # Per-volume log with key FinOps signals
                    flags = []
                    if row["state"] == "available":
                        flags.append("ORPHAN")
                    if row["volume_type"] == "gp2":
                        flags.append("GP2→GP3")
                    if not row["delete_on_termination"] and row["state"] == "in-use":
                        flags.append("DOT_RISK")
                    if not row["encrypted"]:
                        flags.append("UNENCRYPTED")

                    flag_str = f"  ⚠ {', '.join(flags)}" if flags else "  ✓ clean"
                    logger.info(
                        f"[EBS Metadata]   [{i+1:>3}/{len(volumes)}] {row['volume_id']:<25} "
                        f"{row['volume_type']:<6} {row['size_gb']:>5}GB "
                        f"state={row['state']:<12}{flag_str}"
                    )

                except Exception as e:
                    logger.warning(
                        f"[EBS Metadata] Skipping volume '{vol.get('VolumeId', 'unknown')}': {e}"
                    )
                    continue

        except ClientError as e:
            logger.error(
                f"[EBS Metadata] AWS API error for '{account_name}' in {region}: {e}",
                exc_info=True,
            )
            return
        except Exception as e:
            logger.error(
                f"[EBS Metadata] Unexpected extraction error for '{account_name}': {e}",
                exc_info=True,
            )
            return

        # ── ClickHouse insert block ───────────────────────────────
        if not rows:
            logger.info(f"[EBS Metadata] No rows to insert for '{account_name}' in {region}.")
            return

        try:
            # ch_engine.ingest() — adaptive batching + MEMORY_LIMIT_EXCEEDED retries
            self.ch_engine.ingest(rows, table=self.TABLE)
        except Exception as e:
            logger.error(
                f"[EBS Metadata] ClickHouse insert failed for '{account_name}' "
                f"({len(rows)} rows): {e}",
                exc_info=True,
            )
            return

        elapsed = round(time.time() - start_ts, 1)

        # FinOps summary from dict keys — no hardcoded indices
        orphans     = sum(1 for r in rows if r["state"] == "available")
        gp2_count   = sum(1 for r in rows if r["volume_type"] == "gp2")
        unencrypted = sum(1 for r in rows if not r["encrypted"])
        no_backup   = sum(1 for r in rows if r["last_snapshot_age_days"] < 0 or r["last_snapshot_age_days"] > 90)

        logger.info(
            f"[EBS Metadata] ── DONE ───────────────────────────────────────\n"
            f"[EBS Metadata]   Account    : {account_name} ({account_id})\n"
            f"[EBS Metadata]   Region     : {region}\n"
            f"[EBS Metadata]   Volumes    : {len(rows)} ingested\n"
            f"[EBS Metadata]   Orphans    : {orphans} (state=available)\n"
            f"[EBS Metadata]   GP2→GP3    : {gp2_count} (20% savings available)\n"
            f"[EBS Metadata]   Unencrypted: {unencrypted}\n"
            f"[EBS Metadata]   No backup  : {no_backup} (last snapshot >90d or none)\n"
            f"[EBS Metadata]   Duration   : {elapsed}s"
        )

    # ─────────────────────────────────────────────────────────────
    # AWS API helpers
    # ─────────────────────────────────────────────────────────────

    def _list_volumes(self, ec2) -> List[dict]:
        """Paginated describe_volumes — returns all volumes in the region."""
        volumes = []
        try:
            paginator = ec2.get_paginator("describe_volumes")
            for page in paginator.paginate():
                volumes.extend(page.get("Volumes", []))
        except ClientError as e:
            logger.warning(f"[EBS Metadata] Could not list volumes: {e}")
        return volumes

    def _load_snapshot_map(self, ec2, account_id: str) -> Dict[str, Dict]:
        """
        ONE paginated describe_snapshots call for the entire region.
        Returns: { volume_id: {"count": int, "last_snapshot_age_days": int} }

        Zero N+1 — all snapshots loaded into memory, grouped by volume_id.
        Same approach EC2 used for root volume detection.
        """
        raw: Dict[str, List] = defaultdict(list)

        try:
            paginator = ec2.get_paginator("describe_snapshots")
            for page in paginator.paginate(
                OwnerIds=[account_id],
                Filters=[{"Name": "status", "Values": ["completed"]}],
            ):
                for snap in page.get("Snapshots", []):
                    vol_id = snap.get("VolumeId", "")
                    if vol_id:
                        raw[vol_id].append(snap.get("StartTime"))
        except ClientError as e:
            logger.warning(f"[EBS Metadata] describe_snapshots failed (non-fatal): {e}")
            return {}

        now = datetime.now(timezone.utc)
        result = {}
        for vol_id, times in raw.items():
            valid = [t for t in times if t is not None]
            if valid:
                latest = max(valid)
                age_days = (now - latest).days
            else:
                age_days = -1  # snapshots exist but no valid timestamps
            result[vol_id] = {"count": len(times), "last_snapshot_age_days": age_days}

        return result


    @staticmethod
    def _build_row(
        vol: dict,
        account_id: str,
        account_name: str,
        region: str,
        snapshot_map: Dict[str, Dict],
    ) -> Dict:
        """Extract all FinOps fields for one volume and return as dict."""
        now = datetime.now(timezone.utc)
        volume_id = vol.get("VolumeId", "")

        # ── Attachment fields — None for orphan volumes (correct ClickHouse NULL) ──
        attachments = vol.get("Attachments", [])
        if attachments:
            att = attachments[0]
            attached_instance_id  = att.get("InstanceId")   # None if missing
            attached_device       = att.get("Device")        # None if missing
            delete_on_termination = 1 if att.get("DeleteOnTermination") else 0
        else:
            attached_instance_id  = None  # orphan — no instance attached
            attached_device       = None
            delete_on_termination = 0

        # ── Age ──
        create_time = vol.get("CreateTime")
        if create_time:
            if create_time.tzinfo is None:
                create_time = create_time.replace(tzinfo=timezone.utc)
            age_days = (now - create_time).days
            create_time_naive = create_time.replace(tzinfo=None)  # ClickHouse DateTime
        else:
            age_days = 0
            create_time_naive = None

        # ── Snapshot data from pre-loaded map (zero N+1) ──
        snap_data              = snapshot_map.get(volume_id, {})
        snapshot_count         = snap_data.get("count", 0)
        last_snapshot_age_days = snap_data.get("last_snapshot_age_days", -1)

        # ── Tags ──
        tags = {
            t["Key"]: t["Value"]
            for t in vol.get("Tags", [])
            if "Key" in t and "Value" in t
        }

        return {
            # Identity
            "account_id":           account_id,
            "account_name":         account_name,
            "region":               region,
            "availability_zone":    vol.get("AvailabilityZone", ""),
            "volume_id":            volume_id,
            # Cost drivers
            "volume_type":          vol.get("VolumeType", ""),
            "size_gb":              vol.get("Size", 0),
            "iops":                 vol.get("Iops", 0),
            "throughput":           vol.get("Throughput", 0),
            # State
            "state":                vol.get("State", ""),
            "attached_instance_id": attached_instance_id,
            "attached_device":      attached_device,
            # Lifecycle risk
            "delete_on_termination": delete_on_termination,
            "age_days":              age_days,
            # Snapshot health
            "snapshot_count":           snapshot_count,
            "last_snapshot_age_days":   last_snapshot_age_days,
            # Security
            "encrypted":            1 if vol.get("Encrypted", False) else 0,
            "kms_key_id":           vol.get("KmsKeyId", ""),
            # Features
            "multi_attach_enabled": 1 if vol.get("MultiAttachEnabled", False) else 0,
            # fast_restored is a snapshot attribute, not volume-level — removed from schema.
            # Cost allocation
            "tags":                 tags,
            # Housekeeping
            "create_time":  create_time_naive,
            "ingested_at":  now.replace(tzinfo=None),
            "version":      int(now.timestamp()),
        }
