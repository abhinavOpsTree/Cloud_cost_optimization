import os
import logging
import socket
from clickhouse_connect import get_client # type: ignore
from typing import List, Dict

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


class AccountMapper:
    def __init__(self):
        host = os.getenv("CLICKHOUSE_HOST", "clickhouse")
        # Auto-detect: if 'clickhouse' hostname fails to resolve, use 'localhost'
        if host == "clickhouse":
            try:
                socket.gethostbyname(host)
            except socket.gaierror:
                host = "localhost"
                logger.info("'clickhouse' hostname not resolvable, using 'localhost'")
        
        self.client = get_client(
            host=host,
            port=os.getenv("CLICKHOUSE_PORT"),
            username=os.getenv("CLICKHOUSE_USER"),
            password=os.getenv("CLICKHOUSE_PASSWORD"),
            database=os.getenv("CLICKHOUSE_DATABASE")
        )
        self.account_map = self.load_account_map()

    def load_account_map(self) -> Dict[str, str]:
        """
        Fetch account_id to account_name mapping from ClickHouse table `account_map`.
        Returns a dictionary {account_id: account_name}.
        """
        try:
            logger.info("Loading account ID to name mapping from ClickHouse...")
            query = "SELECT account_id, account_name FROM account_map"
            result = self.client.query(query)
            mapping = {str(row[0]): row[1] for row in result.result_rows}
            logger.info(f"Loaded {len(mapping)} account mappings.")
            return mapping
        except Exception as e:
            logger.error(f"Failed to load account mapping: {e}")
            return {}

    def add_account_name(self, data: List[dict]) -> List[dict]:
        """
        For each row in service_costs data, add `account_name` using the map.
        If not found, adds as 'Unknown'.
        """

        for row in data:
            account_id = row.get("account_id")
            account_id_str = str(account_id) if account_id is not None else None

            if account_id_str:
                account_name = self.account_map.get(account_id_str, "Unknown")
            else:
                account_name = "Unknown"

            if account_name == "Unknown":
                logger.warning(f"Account ID {account_id} not found in mapping. Setting to 'Unknown'.")
            else:
                logger.debug(f"Row mapped: {account_id} -> {account_name}")

            row["account_name"] = account_name

        return data


    def refresh_mapping(self):
        """
        Reload the account_map from ClickHouse (in case it was updated).
        """
        self.account_map = self.load_account_map()


