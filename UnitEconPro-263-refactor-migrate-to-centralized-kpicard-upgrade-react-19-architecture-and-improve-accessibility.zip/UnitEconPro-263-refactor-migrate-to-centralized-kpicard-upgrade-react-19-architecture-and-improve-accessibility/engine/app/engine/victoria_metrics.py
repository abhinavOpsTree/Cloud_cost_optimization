import logging
import requests
from datetime import datetime, timedelta
from typing import List, Dict, Optional

logger = logging.getLogger(__name__)

class VictoriaMetricsEngine:
    """
    Query VictoriaMetrics for VM utilization metrics.
    Generic implementation - works with any VictoriaMetrics setup.
    """
    
    def __init__(self, base_url: str, username: Optional[str] = None, password: Optional[str] = None):
        """
        Initialize VictoriaMetrics client.
        
        Args:
            base_url: VictoriaMetrics URL (e.g., http://victoria-metrics:8428)
            username: Optional basic auth username
            password: Optional basic auth password
        """
        self.base_url = base_url.rstrip('/')
        self.auth = (username, password) if username and password else None
        logger.info(f"Initialized VictoriaMetrics engine: {self.base_url}")
    
    def query(self, query: str, time: Optional[datetime] = None) -> Dict:
        """
        Execute instant query against VictoriaMetrics.
        
        Args:
            query: MetricsQL/PromQL query string
            time: Optional timestamp (defaults to now)
        
        Returns:
            Query result as dict
        """
        url = f"{self.base_url}/api/v1/query"
        params = {'query': query}
        
        if time:
            params['time'] = int(time.timestamp())
        
        try:
            response = requests.get(url, params=params, auth=self.auth, timeout=30)
            response.raise_for_status()
            data = response.json()
            
            if data.get('status') != 'success':
                raise Exception(f"Query failed: {data.get('error', 'Unknown error')}")
            
            return data['data']
        
        except requests.exceptions.RequestException as e:
            logger.error(f"VictoriaMetrics query failed: {e}")
            raise
    
    def query_range(self, query: str, start: datetime, end: datetime, step: str = '1h') -> Dict:
        """
        Execute range query against VictoriaMetrics.
        
        Args:
            query: MetricsQL/PromQL query string
            start: Start time
            end: End time
            step: Query resolution (e.g., '1h', '5m')
        
        Returns:
            Query result as dict
        """
        url = f"{self.base_url}/api/v1/query_range"
        params = {
            'query': query,
            'start': int(start.timestamp()),
            'end': int(end.timestamp()),
            'step': step
        }
        
        try:
            response = requests.get(url, params=params, auth=self.auth, timeout=60)
            response.raise_for_status()
            data = response.json()
            
            if data.get('status') != 'success':
                raise Exception(f"Range query failed: {data.get('error', 'Unknown error')}")
            
            return data['data']
        
        except requests.exceptions.RequestException as e:
            logger.error(f"VictoriaMetrics range query failed: {e}")
            raise
    
    def get_vm_utilization(self, lookback_hours: int = 24, 
                          cpu_metric: str = 'node_cpu_seconds_total',
                          mem_metric: str = 'node_memory_MemAvailable_bytes',
                          instance_label: str = 'instance') -> List[Dict]:
        """
        Get VM utilization metrics for last N hours.
        
        Args:
            lookback_hours: Hours to look back (default: 24)
            cpu_metric: CPU metric name (configurable)
            mem_metric: Memory metric name (configurable)
            instance_label: Label containing instance ID (configurable)
        
        Returns:
            List of dicts with utilization data per VM
        """
        end_time = datetime.utcnow()
        start_time = end_time - timedelta(hours=lookback_hours)
        
        logger.info(f"Querying VM utilization from {start_time} to {end_time}")
        
        # Query 1: CPU utilization (average idle time over period)
        cpu_query = f'avg_over_time({cpu_metric}{{mode="idle"}}[{lookback_hours}h])'
        
        try:
            cpu_data = self.query(cpu_query, time=end_time)
            
            # Query 2: Memory utilization
            mem_query = f'(1 - avg_over_time({mem_metric}[{lookback_hours}h]) / node_memory_MemTotal_bytes) * 100'
            mem_data = self.query(mem_query, time=end_time)
            
            # Combine results
            results = []
            cpu_by_instance = {r['metric'].get(instance_label): r['value'][1] for r in cpu_data.get('result', [])}
            mem_by_instance = {r['metric'].get(instance_label): r['value'][1] for r in mem_data.get('result', [])}
            
            for instance_id in cpu_by_instance.keys():
                cpu_idle = float(cpu_by_instance.get(instance_id, 0))
                cpu_usage = (1 - cpu_idle) * 100  # Convert idle to usage percentage
                mem_usage = float(mem_by_instance.get(instance_id, 0))
                
                results.append({
                    'instance_id': instance_id,
                    'avg_cpu_percent': round(cpu_usage, 2),
                    'avg_mem_percent': round(mem_usage, 2),
                    'period_start': start_time,
                    'period_end': end_time
                })
            
            logger.info(f"Retrieved metrics for {len(results)} VMs")
            return results
        
        except Exception as e:
            logger.error(f"Failed to get VM utilization: {e}")
            return []
    
    def get_underutilized_vms(self, cpu_threshold: float = 2.0, mem_threshold: float = 10.0, 
                              lookback_hours: int = 24) -> List[Dict]:
        """
        Find underutilized VMs (low CPU and low memory usage).
        
        Args:
            cpu_threshold: CPU usage threshold (default: 2%)
            mem_threshold: Memory usage threshold (default: 10%)
            lookback_hours: Hours to analyze (default: 24)
        
        Returns:
            List of underutilized VMs with utilization data
        """
        all_vms = self.get_vm_utilization(lookback_hours=lookback_hours)
        
        underutilized = [
            vm for vm in all_vms 
            if vm['avg_cpu_percent'] < cpu_threshold and vm['avg_mem_percent'] < mem_threshold
        ]
        
        logger.info(f"Found {len(underutilized)} underutilized VMs out of {len(all_vms)} total")
        return underutilized
