import boto3 # type: ignore
import time
import os
import logging
from typing import List, Dict
from botocore.exceptions import BotoCoreError, ClientError # type: ignore
from engine.engine import BaseEngine

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

try:
    from aws_session_manager.session_setup import setup_session   # type: ignore
    STS_AVAILABLE = True
except ImportError:
    STS_AVAILABLE = False
    logger.warning("aws_session_manager not installed. STS mode will not be available.")

class AthenaEngine(BaseEngine):
    def __init__(self, database: str, output_location: str, region_name: str, aws_access_key_id: str = None, aws_secret_access_key: str = None):
        self.database = database
        self.output_location = output_location
        self.region_name = region_name
        self.aws_access_key_id = aws_access_key_id
        self.aws_secret_access_key = aws_secret_access_key
        self.client = None
        self.query_execution_id = None

    def connection(self):
        """Establish a boto3 Athena client connection using explicit credentials, IAM or STS."""

        try:
            if self.aws_access_key_id and self.aws_secret_access_key:
                logger.info("Connecting to Athena using explicit dynamic credentials.")
                self.client = boto3.client(
                    "athena",
                    region_name=self.region_name,
                    aws_access_key_id=self.aws_access_key_id,
                    aws_secret_access_key=self.aws_secret_access_key
                )
                return

            mode = os.getenv("MODE")
            if mode is None:
                raise EnvironmentError("Missing required environment variable: MODE (must be 'IAM' or 'STS')")

            mode = mode.upper()
            if mode not in {"IAM", "STS"}:
                raise ValueError(f"Invalid MODE value: '{mode}'. Must be 'IAM' or 'STS'.")

            logger.info(f"Connecting to Athena using mode: {mode}")

            if mode == "STS":
                if not STS_AVAILABLE:
                    raise ImportError("STS mode requires aws_session_manager package. Install with: pip install git+https://github.com/OT-PYTHON-UTILS/ot-aws-libs.git@sts-autoassume")
                session_mgr = setup_session()

                def _refresh_client():
                    new_creds = session_mgr.get_current_credentials()
                    self.client = boto3.client(
                        "athena",
                        region_name=self.region_name,
                        aws_access_key_id=new_creds["aws_access_key_id"],
                        aws_secret_access_key=new_creds["aws_secret_access_key"],
                        aws_session_token=new_creds["aws_session_token"]
                    )
                    logger.info("Athena client refreshed via STS role assumption.")

                    # Log the caller identity after creating the client
                    sts_client = boto3.client(
                        "sts",
                        aws_access_key_id=new_creds["aws_access_key_id"],
                        aws_secret_access_key=new_creds["aws_secret_access_key"],
                        aws_session_token=new_creds["aws_session_token"],
                        region_name=self.region_name
                    )
                    identity = sts_client.get_caller_identity()
                    logger.info(f"AWS caller identity -> Account={identity['Account']}, Arn={identity['Arn']}, UserId={identity['UserId']}")

                _refresh_client()
                self._refresh_athena_client = _refresh_client

            else:  # IAM
                # Fallback to os.getenv if dynamic keys weren't passed (though they should have been caught in lines 33-41)
                final_access_key = self.aws_access_key_id or os.getenv("AWS_ACCESS_KEY_ID")
                final_secret_key = self.aws_secret_access_key or os.getenv("AWS_SECRET_ACCESS_KEY")
                
                self.client = boto3.client(
                    "athena",
                    region_name=self.region_name,
                    aws_access_key_id=final_access_key,
                    aws_secret_access_key=final_secret_key
                )
                logger.info("Connected to Athena using explicit IAM keys.")

                # Log the caller identity after creating the client
                sts_client = boto3.client(
                    "sts",
                    aws_access_key_id=final_access_key,
                    aws_secret_access_key=final_secret_key,
                    region_name=self.region_name
                )
                identity = sts_client.get_caller_identity()
                logger.info(f"AWS caller identity -> Account={identity['Account']}, Arn={identity['Arn']}, UserId={identity['UserId']}")

        except (BotoCoreError, ClientError) as e:
            logger.error(f"Failed to connect to Athena: {e}")
            raise

    def fetch(self, query: str) -> List[Dict]:
        """
        Run a query in Athena and return the results as a list of dictionaries.
        """
        if not self.client:
            self.connection()

        logger.info("Executing Athena query...")
        try:
            self.query_execution_id = self.client.start_query_execution(
                QueryString=query,
                QueryExecutionContext={"Database": self.database},
                ResultConfiguration={"OutputLocation": self.output_location}
            )["QueryExecutionId"]
        except ClientError as e:
            if "ExpiredToken" in str(e) and hasattr(self, "_refresh_athena_client"):
                logger.warning("Token expired, refreshing Athena client...")
                self._refresh_athena_client()
                return self.fetch(query)
            logger.error(f"Failed to start Athena query: {e}")
            raise


        # Wait for query to finish
        self._wait_for_query()

        return self._parse_results()

    def ingest(self, data: List[Dict]):
        """
        Athena doesn't ingest; method required by interface.
        """
        logger.warning("Ingest not applicable to AthenaEngine.")

    def save(self, data: List[Dict], table: str):
        """
        Athena is read-only in this context; saving not implemented.
        """
        logger.warning("Save not implemented for AthenaEngine.")

    def _wait_for_query(self):
        """Poll Athena until query finishes."""
        while True:
            response = self.client.get_query_execution(QueryExecutionId=self.query_execution_id)
            state = response["QueryExecution"]["Status"]["State"]

            if state in ["SUCCEEDED", "FAILED", "CANCELLED"]:
                if state != "SUCCEEDED":
                    reason = response["QueryExecution"]["Status"].get("StateChangeReason", "No reason provided.")
                    raise RuntimeError(f"Athena query failed with state: {state}. Reason: {reason}")

                break
            time.sleep(2)

    def _parse_results(self) -> List[Dict]:
        """
        Parse the Athena results into a list of dictionaries.
        First row contains column headers.
        """
        results_paginator = self.client.get_paginator("get_query_results")
        results_iter = results_paginator.paginate(QueryExecutionId=self.query_execution_id)

        rows = []
        columns = []

        for page_index, page in enumerate(results_iter):
            result_set = page["ResultSet"]["Rows"]
            for i, row in enumerate(result_set):
                values = [field.get("VarCharValue", None) for field in row["Data"]]

                if page_index == 0 and i == 0:
                    columns = values
                    continue  # header row

                rows.append(dict(zip(columns, values)))

        logger.info(f"Athena returned {len(rows)} data rows.")
        return rows
