import logging
import uuid
from datetime import datetime, timezone

logger = logging.getLogger(__name__)

NO_BASELINE = -1.0

COLS = [
    'alert_id', 'account_id', 'account_name', 'service', 'severity',
    'cost_today', 'mean_cost', 'std_dev', 'upper_threshold', 'z_score',
    'pct_above_mean', 'status', 'signal_type',
    'fired_at', 'acknowledged_at', 'resolved_at', 'updated_at',
]


class AnomalyDetector:
    def __init__(self, ch_client):
        self.ch = ch_client

    def run_daily_detection(self):
        logger.info("\n" + "="*80)
        logger.info("Starting Anomaly Detection Pipeline")
        logger.info("="*80)

        rules = self._get_active_rules()
        if not rules:
            logger.warning("No custom alert rules found. Using defaults: sensitivity=2.0, min_impact=$10, dod_pct=0.40.")

        anomalies = self._detect_anomalies(rules)
        if anomalies is None:
            logger.warning("Anomaly detection skipped due to ClickHouse query failure.")
        elif not anomalies:
            logger.info("No anomalies detected for yesterday.")
        else:
            self._process_anomalies(anomalies)

        logger.info("Anomaly detection completed.\n")

    # ── Rules ─────────────────────────────────────────────────────────────────

    def _get_active_rules(self):
        try:
            result = self.ch.client.query(
                "SELECT account_id, service, sensitivity, min_impact, dod_pct_threshold "
                "FROM cost.alert_rules FINAL WHERE enabled = 1"
            )
            rule_map = {}
            for acc, svc, sens, min_imp, dod_pct in result.result_rows:
                rule_map.setdefault(acc, {})[svc] = {
                    'sensitivity':     float(sens),
                    'min_impact':      float(min_imp),
                    'dod_pct_threshold': float(dod_pct),
                }
            return rule_map
        except Exception as e:
            logger.error(f"Failed to fetch alert rules: {e}")
            return {}

    def _get_rule_for_service(self, rules, account_id, service):
        acc_rules = rules.get(account_id, {})
        if service in acc_rules:
            return acc_rules[service]
        if 'ALL' in acc_rules:
            return acc_rules['ALL']
        return {'sensitivity': 2.0, 'min_impact': 10.0, 'dod_pct_threshold': 0.40}

    # ── Signal 1 + 2: Z-score & Low-history ───────────────────────────────────

    def _detect_anomalies(self, rules):
        query = """
        WITH daily_costs AS (
            SELECT
                account_id, account_name,
                product_code AS service,
                toDate(usage_start_ts) AS usage_date,
                ROUND(SUM(cost_unblended), 2) AS daily_cost
            FROM cost.service_costs FINAL
            WHERE usage_start_ts >= today() - 31
              AND usage_start_ts < today()
            GROUP BY account_id, account_name, service, usage_date
        ),
        moving_stats AS (
            SELECT
                account_id, account_name, service, usage_date, daily_cost,
                ROUND(avg(daily_cost) OVER w, 2)                    AS rolling_mean,
                ROUND(COALESCE(stddevSamp(daily_cost) OVER w, 0), 2) AS rolling_stddev,
                COUNT(daily_cost) OVER w                             AS days_of_history
            FROM daily_costs
            WINDOW w AS (
                PARTITION BY account_id, account_name, service
                ORDER BY usage_date
                RANGE BETWEEN 30 PRECEDING AND 1 PRECEDING
            )
        )
        SELECT
            account_id, account_name, service,
            daily_cost AS actual_cost,
            rolling_mean, rolling_stddev, days_of_history,
            ROUND(daily_cost - rolling_mean, 2) AS absolute_dollar_impact
        FROM moving_stats
        WHERE usage_date = today() - 1
        """

        try:
            logger.info("Executing Z-score query...")
            rows = self.ch.client.query(query).result_rows
            anomalies = []

            for row in rows:
                acc_id, acc_name, svc, actual_cost, r_mean, r_stddev, days_of_history, abs_impact = row
                actual_cost     = float(actual_cost)
                r_mean          = float(r_mean)
                r_stddev        = float(r_stddev)
                days_of_history = int(days_of_history)
                abs_impact      = float(abs_impact)

                rule        = self._get_rule_for_service(rules, acc_id, svc)
                sensitivity = float(rule['sensitivity'])
                min_impact  = float(rule['min_impact'])

                # Signal 2 — Low-history (<7 days)
                if days_of_history < 7:
                    if r_mean > 0:
                        pct_change = ((actual_cost - r_mean) / r_mean) * 100.0
                        if pct_change >= 50.0 and abs_impact >= min_impact:
                            anomalies.append({
                                'account_id': acc_id, 'account_name': acc_name, 'service': svc,
                                'severity': 'WARNING', 'signal_type': 'low_history',
                                'cost_today': actual_cost, 'mean_cost': r_mean,
                                'std_dev': r_stddev, 'upper_threshold': r_mean * 1.5,
                                'z_score': round(pct_change / 10.0, 2),
                                'pct_above_mean': round(pct_change, 1),
                            })
                    continue

                # Signal 1 — Z-score
                upper_bound = r_mean + (sensitivity * r_stddev)
                if actual_cost <= upper_bound or abs_impact < min_impact:
                    continue

                if r_stddev == 0:
                    if actual_cost <= r_mean:
                        continue
                    pct_change = ((actual_cost - r_mean) / r_mean) * 100.0 if r_mean > 0 else 100.0
                    z_score  = round(pct_change / 10.0, 2)
                    severity = 'WARNING'
                else:
                    z_score = round((actual_cost - r_mean) / r_stddev, 2)
                    severity = 'CRITICAL' if z_score >= 5.0 else 'HIGH' if z_score >= 3.0 else 'WARNING'

                pct_above = round(((actual_cost - r_mean) / r_mean) * 100.0, 1) if r_mean > 0 else 999.9

                anomalies.append({
                    'account_id': acc_id, 'account_name': acc_name, 'service': svc,
                    'severity': severity, 'signal_type': 'z_score',
                    'cost_today': actual_cost, 'mean_cost': r_mean,
                    'std_dev': r_stddev, 'upper_threshold': upper_bound,
                    'z_score': z_score, 'pct_above_mean': pct_above,
                })

            # Signal 3 & 4
            self._detect_new_services(anomalies, rules)
            self._detect_new_instance_types(anomalies, rules)

            # Signal 5 — Day-over-Day
            self._detect_day_over_day(anomalies, rules)

            return anomalies

        except Exception as e:
            logger.error(f"Failed to detect anomalies: {e}", exc_info=True)
            return None

    # ── Signal 3: New Service ─────────────────────────────────────────────────

    def _detect_new_services(self, anomalies, rules):
        query = """
        WITH prev_14 AS (
            SELECT DISTINCT account_id, product_code
            FROM cost.service_costs FINAL
            WHERE usage_start_ts >= today() - 15 AND usage_start_ts < today() - 1
        ),
        yesterday AS (
            SELECT account_id, account_name, product_code, ROUND(SUM(cost_unblended), 2) AS cost
            FROM cost.service_costs FINAL
            WHERE toDate(usage_start_ts) = today() - 1
            GROUP BY account_id, account_name, product_code
        )
        SELECT y.account_id, y.account_name, y.product_code, y.cost
        FROM yesterday y
        LEFT JOIN prev_14 p ON y.account_id = p.account_id AND y.product_code = p.product_code
        WHERE p.product_code IS NULL
        """
        try:
            existing_keys = {(a['account_id'], a['service']) for a in anomalies}
            for acc_id, acc_name, svc, cost in self.ch.client.query(query).result_rows:
                if (acc_id, svc) in existing_keys:
                    continue
                rule = self._get_rule_for_service(rules, acc_id, svc)
                if float(cost) < float(rule['min_impact']):
                    continue
                anomalies.append({
                    'account_id': acc_id, 'account_name': acc_name, 'service': svc,
                    'severity': 'CRITICAL', 'signal_type': 'new_service',
                    'cost_today': float(cost), 'mean_cost': NO_BASELINE,
                    'std_dev': NO_BASELINE, 'upper_threshold': NO_BASELINE,
                    'z_score': 99.9, 'pct_above_mean': 999.9,
                })
                existing_keys.add((acc_id, svc))
        except Exception as e:
            logger.error(f"Failed to detect new services: {e}")

    # ── Signal 4: New Instance Type ───────────────────────────────────────────

    def _detect_new_instance_types(self, anomalies, rules):
        query = """
        WITH prev_14 AS (
            SELECT DISTINCT account_id, product_code, instance_type, operation
            FROM cost.service_costs FINAL
            WHERE usage_start_ts >= today() - 15 AND usage_start_ts < today() - 1
              AND instance_type != ''
        ),
        yesterday AS (
            SELECT account_id, account_name, product_code, instance_type, operation,
                   ROUND(SUM(cost_unblended), 2) AS cost
            FROM cost.service_costs FINAL
            WHERE toDate(usage_start_ts) = today() - 1 AND instance_type != ''
            GROUP BY account_id, account_name, product_code, instance_type, operation
        )
        SELECT y.account_id, y.account_name, y.product_code, y.instance_type, y.operation, y.cost
        FROM yesterday y
        LEFT JOIN prev_14 p
            ON y.account_id = p.account_id AND y.product_code = p.product_code
           AND y.instance_type = p.instance_type AND y.operation = p.operation
        WHERE p.instance_type IS NULL
        """
        try:
            grouped = {}
            for acc_id, acc_name, svc, itype, op, cost in self.ch.client.query(query).result_rows:
                key = (acc_id, svc)
                grouped.setdefault(key, {'acc_name': acc_name, 'cost': 0.0, 'combos': []})
                grouped[key]['cost'] += float(cost)
                grouped[key]['combos'].append(f"{itype}/{op}")

            existing_keys = {(a['account_id'], a['service']) for a in anomalies}

            for (acc_id, svc), info in grouped.items():
                rule = self._get_rule_for_service(rules, acc_id, svc)
                total = round(info['cost'], 2)
                if total < float(rule['min_impact']):
                    continue
                if (acc_id, svc) in existing_keys:
                    for a in anomalies:
                        if a['account_id'] == acc_id and a['service'] == svc and a['severity'] != 'CRITICAL':
                            a['severity'] = 'HIGH'
                    continue
                anomalies.append({
                    'account_id': acc_id, 'account_name': info['acc_name'], 'service': svc,
                    'severity': 'HIGH', 'signal_type': 'new_instance_type',
                    'cost_today': total, 'mean_cost': NO_BASELINE,
                    'std_dev': NO_BASELINE, 'upper_threshold': NO_BASELINE,
                    'z_score': 99.9, 'pct_above_mean': 999.9,
                })
                existing_keys.add((acc_id, svc))
        except Exception as e:
            logger.error(f"Failed to detect new instance types: {e}")

    # ── Signal 5: Day-over-Day / Weekend Baseline ─────────────────────────────

    def _detect_day_over_day(self, anomalies, rules):
        """
        Compares yesterday's cost against the average of the same weekday
        over the last 4 weeks. Eliminates false positives from weekly cycles
        (e.g. Monday always costs more than Friday).
        Falls back to z-score if fewer than 4 same-weekday data points exist.
        """
        query = """
        WITH daily AS (
            SELECT
                account_id, account_name,
                product_code AS service,
                toDate(usage_start_ts) AS usage_date,
                toDayOfWeek(usage_date) AS dow,
                ROUND(SUM(cost_unblended), 2) AS daily_cost
            FROM cost.service_costs FINAL
            WHERE usage_start_ts >= today() - 29
              AND usage_start_ts < today()
            GROUP BY account_id, account_name, service, usage_date
        ),
        yesterday_dow AS (
            SELECT toDayOfWeek(today() - 1) AS target_dow
        ),
        same_weekday_baseline AS (
            SELECT
                account_id, account_name, service,
                AVG(daily_cost) AS weekday_mean,
                COUNT() AS weekday_points
            FROM daily
            WHERE dow = (SELECT target_dow FROM yesterday_dow)
              AND usage_date < today() - 1
            GROUP BY account_id, account_name, service
        ),
        yesterday AS (
            SELECT account_id, account_name, service, daily_cost
            FROM daily
            WHERE usage_date = today() - 1
        )
        SELECT
            y.account_id, y.account_name, y.service,
            y.daily_cost AS actual_cost,
            b.weekday_mean,
            b.weekday_points
        FROM yesterday y
        JOIN same_weekday_baseline b
            ON y.account_id = b.account_id AND y.service = b.service
        WHERE b.weekday_points >= 2
        """
        try:
            existing_keys = {(a['account_id'], a['service']) for a in anomalies}
            rows = self.ch.client.query(query).result_rows

            for acc_id, acc_name, svc, actual_cost, weekday_mean, weekday_points in rows:
                actual_cost  = float(actual_cost)
                weekday_mean = float(weekday_mean)
                weekday_points = int(weekday_points)

                if weekday_mean <= 0:
                    continue

                rule      = self._get_rule_for_service(rules, acc_id, svc)
                dod_pct   = float(rule['dod_pct_threshold'])
                min_impact = float(rule['min_impact'])

                ratio      = actual_cost / weekday_mean
                abs_impact = actual_cost - weekday_mean

                if ratio < (1 + dod_pct) or abs_impact < min_impact:
                    continue

                pct_above = round((ratio - 1) * 100, 1)
                severity  = 'CRITICAL' if pct_above >= 100 else 'HIGH' if pct_above >= 60 else 'WARNING'

                # Only add if not already detected by z-score (avoid duplicate alerts)
                if (acc_id, svc) in existing_keys:
                    # Escalate existing if DoD is more severe
                    for a in anomalies:
                        if a['account_id'] == acc_id and a['service'] == svc:
                            RANK = {'WARNING': 1, 'HIGH': 2, 'CRITICAL': 3}
                            if RANK.get(severity, 0) > RANK.get(a['severity'], 0):
                                a['severity'] = severity
                                a['signal_type'] = 'day_over_day'
                    continue

                anomalies.append({
                    'account_id': acc_id, 'account_name': acc_name, 'service': svc,
                    'severity': severity, 'signal_type': 'day_over_day',
                    'cost_today': actual_cost, 'mean_cost': round(weekday_mean, 2),
                    'std_dev': NO_BASELINE, 'upper_threshold': round(weekday_mean * (1 + dod_pct), 2),
                    'z_score': round(ratio, 2), 'pct_above_mean': pct_above,
                })
                existing_keys.add((acc_id, svc))

            logger.info(f"[DoD] Checked {len(rows)} service/account pairs for weekday baseline anomalies.")

        except Exception as e:
            logger.error(f"Failed to detect day-over-day anomalies: {e}", exc_info=True)

    # ── Process & Persist ─────────────────────────────────────────────────────

    def _process_anomalies(self, anomalies):
        logger.info(f"Processing {len(anomalies)} detected cost anomalies...")

        from datetime import timedelta
        now_utc    = datetime.now(timezone.utc).replace(tzinfo=None)
        alert_date = datetime.now(timezone.utc).date() - timedelta(days=1)

        already_fired = {
            (r[0], r[1]) for r in self.ch.client.query("""
                SELECT account_id, service FROM cost.alert_events FINAL
                WHERE toDate(fired_at) = today() - 1
            """).result_rows
        }

        open_alerts = {}
        for r in self.ch.client.query("""
            SELECT alert_id, account_id, account_name, service, severity,
                   cost_today, mean_cost, std_dev, upper_threshold, z_score,
                   pct_above_mean, fired_at, acknowledged_at
            FROM cost.alert_events FINAL
            WHERE status = 'OPEN'
        """).result_rows:
            open_alerts[(r[1], r[3])] = {
                'alert_id': r[0], 'account_id': r[1], 'account_name': r[2],
                'service': r[3], 'severity': r[4], 'cost_today': float(r[5]),
                'mean_cost': float(r[6]), 'std_dev': float(r[7]),
                'upper_threshold': float(r[8]), 'z_score': float(r[9]),
                'pct_above_mean': float(r[10]), 'fired_at': r[11],
                'acknowledged_at': r[12],
            }

        SEVERITY_RANK = {'WARNING': 1, 'HIGH': 2, 'CRITICAL': 3}
        inserts = []

        for a in anomalies:
            key = (a['account_id'], a['service'])

            if key in already_fired:
                logger.debug(f"Same-day dedup: {a['account_name']} - {a['service']} on {alert_date}")
                continue

            existing = open_alerts.get(key)

            if existing:
                old_cost = existing['cost_today']
                new_cost = float(a['cost_today'])
                cost_change_pct    = abs(new_cost - old_cost) / old_cost * 100 if old_cost > 0 else 100
                severity_escalated = SEVERITY_RANK.get(a['severity'], 0) > SEVERITY_RANK.get(existing['severity'], 0)

                if severity_escalated or cost_change_pct >= 20.0:
                    self._set_alert_status(existing, 'ESCALATED', now_utc)
                    inserts.append(self._build_insert(a, now_utc))
                    logger.warning(
                        f"🔺 ESCALATED: {a['account_name']} - {a['service']} | "
                        f"${old_cost:.2f} → ${new_cost:.2f} | {existing['severity']} → {a['severity']}"
                    )
                else:
                    self._update_open_alert(existing, a, now_utc)
                    logger.info(f"↻ Updated ongoing: {a['account_name']} - {a['service']} | ${old_cost:.2f} → ${new_cost:.2f}")
            else:
                inserts.append(self._build_insert(a, now_utc))
                logger.warning(
                    f"🚨 NEW [{alert_date}] [{a.get('signal_type','?')}]: "
                    f"{a['account_name']} - {a['service']} | "
                    f"Cost: ${a['cost_today']} | Severity: {a['severity']}"
                )

        if inserts:
            try:
                self.ch.client.insert('cost.alert_events', [list(i.values()) for i in inserts], column_names=list(inserts[0].keys()))
                logger.info(f"Saved {len(inserts)} new alerts.")
                self._send_notifications(inserts)
            except Exception as e:
                logger.error(f"Failed to insert alerts: {e}", exc_info=True)

    def _build_insert(self, a: dict, now_utc) -> dict:
        return {
            'alert_id':        str(uuid.uuid4()),
            'account_id':      str(a['account_id']),
            'account_name':    str(a['account_name']),
            'service':         str(a['service']),
            'severity':        str(a['severity']),
            'cost_today':      float(a['cost_today']),
            'mean_cost':       float(a['mean_cost']),
            'std_dev':         float(a['std_dev']),
            'upper_threshold': float(a['upper_threshold']),
            'z_score':         float(a['z_score']),
            'pct_above_mean':  float(a['pct_above_mean']),
            'status':          'OPEN',
            'signal_type':     str(a.get('signal_type', 'z_score')),
            'fired_at':        now_utc,
            'acknowledged_at': None,
            'resolved_at':     None,
            'updated_at':      now_utc,
        }

    def _strip_tz(self, dt):
        return dt.replace(tzinfo=None) if dt and hasattr(dt, 'tzinfo') and dt.tzinfo else dt

    def _set_alert_status(self, existing: dict, status: str, now_utc):
        self.ch.client.insert('cost.alert_events', [[
            existing['alert_id'], existing['account_id'], existing['account_name'],
            existing['service'], existing['severity'],
            existing['cost_today'], existing['mean_cost'], existing['std_dev'],
            existing['upper_threshold'], existing['z_score'], existing['pct_above_mean'],
            status, existing.get('signal_type', 'z_score'),
            self._strip_tz(existing['fired_at']),
            self._strip_tz(existing.get('acknowledged_at')),
            now_utc, now_utc,
        ]], column_names=COLS)

    def _update_open_alert(self, existing: dict, new: dict, now_utc):
        self.ch.client.insert('cost.alert_events', [[
            existing['alert_id'], existing['account_id'], existing['account_name'],
            existing['service'], str(new['severity']),
            float(new['cost_today']), float(new['mean_cost']), float(new['std_dev']),
            float(new['upper_threshold']), float(new['z_score']), float(new['pct_above_mean']),
            'OPEN', str(new.get('signal_type', existing.get('signal_type', 'z_score'))),
            self._strip_tz(existing['fired_at']),
            self._strip_tz(existing.get('acknowledged_at')),
            None, now_utc,
        ]], column_names=COLS)

    def _send_notifications(self, new_alerts):
        """Placeholder for Slack/Teams/PagerDuty webhook integrations."""
        pass
