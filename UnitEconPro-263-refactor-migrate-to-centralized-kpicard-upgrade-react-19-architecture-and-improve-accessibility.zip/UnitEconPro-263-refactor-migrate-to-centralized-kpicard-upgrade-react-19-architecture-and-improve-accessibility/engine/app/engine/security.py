import os
from cryptography.fernet import Fernet
import logging

logger = logging.getLogger(__name__)

def _get_fernet() -> Fernet:
    key = os.getenv("ENCRYPTION_MASTER_KEY", "").strip().strip('"').strip("'")
    if not key:
        raise ValueError("ENCRYPTION_MASTER_KEY environment variable is not set.")
    return Fernet(key.encode('utf-8'))

def encrypt_string(plain_text: str) -> str:
    """Encrypts a plain string using the master key from environment."""
    f = _get_fernet()
    return f.encrypt(plain_text.encode('utf-8')).decode('utf-8')

def decrypt_string(encrypted_text: str) -> str:
    """Decrypts an encrypted string using the master key from environment."""
    if not encrypted_text:
        return ""
    f = _get_fernet()
    return f.decrypt(encrypted_text.encode('utf-8')).decode('utf-8')

