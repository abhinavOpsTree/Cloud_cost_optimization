from abc import ABC, abstractmethod
from typing import Dict, Any

class Transformer(ABC):
    def __init__(self, mapping: Dict[str, str]):
        self.mapping = mapping

    @abstractmethod
    def transform(self, row: Dict[str, Any]) -> Dict[str, Any]:
        pass
