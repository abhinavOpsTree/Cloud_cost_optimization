from abc import ABC, abstractmethod


class BaseEngine(ABC):
    """
    Abstract base class for all data engines.
    Any subclass must implement the core methods: connection, fetch, ingest, and save.
    """

    @abstractmethod
    def connection(self):
        """Establish connection to the data source or destination."""
        pass

    @abstractmethod
    def fetch(self, query: str):
        """
        Fetch data from the source using a query.
        Returns: data in Python-native format (e.g., list of dicts).
        """
        pass

    @abstractmethod
    def ingest(self, data: list[dict]):
        """
        Transform and ingest data into the destination (e.g., ClickHouse).
        """
        pass

    @abstractmethod
    def save(self, data: list[dict], table: str):
        """
        Persist data to the destination.
        Could involve bulk insert or streaming, depending on subclass.
        """
        pass


