from clickhouse_connect import get_client  # type: ignore
from typing import List, Dict, Optional
from datetime import datetime
import os
import logging
import uuid

#from engine.engine import BaseEngine
from .engine import BaseEngine


logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

class ClickHouseEngine(BaseEngine):
    def __init__(self, service_mapping: Dict[str, str] = None):
        self.client = None
        self.table_name = os.getenv("CLICKHOUSE_TABLE")
        if not self.table_name:
            raise ValueError("CLICKHOUSE_TABLE not found in environment variables.")
        self.service_mapping = service_mapping or {}

    def ensure_connection(self):
        if not self.client:
            self.connection()

    def connection(self):
        try:
            host = os.getenv("CLICKHOUSE_HOST", "clickhouse")
            # Auto-detect: if 'clickhouse' hostname fails to resolve, use 'localhost'
            if host == "clickhouse":
                import socket
                try:
                    socket.gethostbyname(host)
                except socket.gaierror:
                    host = "localhost"
                    logger.info("'clickhouse' hostname not resolvable, using 'localhost'")
            
            self.client = get_client(
                host=host,
                port=os.getenv("CLICKHOUSE_PORT"),
                username=os.getenv("CLICKHOUSE_USER"),
                password=os.getenv("CLICKHOUSE_PASSWORD"),
                database=os.getenv("CLICKHOUSE_DATABASE"),
                # Avoid long-lived shared HTTP sessions causing SESSION_IS_LOCKED
                # cascades after slow/time-out mutations.
                session_id=str(uuid.uuid4()),
                
            )
            logger.info("Connected to ClickHouse.")
        except Exception as e:
            logger.critical(f" Failed to connect to ClickHouse: {e}")
            raise

    def ingest(self, data: List[Dict], table: str = None, batch_size: int = 10_000, min_batch_size: int = 50):
        """
        Insert data into ClickHouse in batches to prevent MEMORY_LIMIT_EXCEEDED errors
        when dealing with large datasets (e.g. CloudWatch, ECR).
        """
        self.ensure_connection()

        if not data:
            logger.warning(" No data to insert.")
            return

        target_table = table or self.table_name
        columns = list(data[0].keys())
        rows = [list(d.values()) for d in data]
        total = len(rows)

        current_batch_size = max(1, batch_size)
        offset = 0
        while offset < total:
            batch = rows[offset: offset + current_batch_size]
            batch_num = (offset // current_batch_size) + 1
            total_batches = (total + current_batch_size - 1) // current_batch_size
            try:
                self.client.insert(table=target_table, data=batch, column_names=columns)
                logger.info(
                    f" Inserted batch {batch_num}/{total_batches} "
                    f"({len(batch)} rows) into '{target_table}'."
                )
                offset += len(batch)
            except Exception as e:
                err_str = str(e)
                is_memory_error = "MEMORY_LIMIT_EXCEEDED" in err_str or "Code: 241" in err_str
                logger.error(
                    f" Batch {batch_num}/{total_batches} insert failed "
                    f"(rows {offset}–{offset + len(batch)}): {e}"
                )
                if is_memory_error and current_batch_size > max(1, min_batch_size):
                    next_batch_size = max(min_batch_size, current_batch_size // 2)
                    if next_batch_size == current_batch_size:
                        next_batch_size = max(1, current_batch_size - 1)
                    logger.warning(
                        f"Insert memory pressure detected. Reducing batch size from "
                        f"{current_batch_size} to {next_batch_size} and retrying."
                    )
                    current_batch_size = next_batch_size
                    continue
                raise

        logger.info(f" Inserted {total} rows into ClickHouse table '{target_table}'.")

    def fetch(self, query: str) -> List[Dict]:
        self.ensure_connection()

        try:
            result = self.client.query(query)
            return [dict(zip(result.column_names, row)) for row in result.result_rows]
        except Exception as e:
            logger.error(f" Failed to execute ClickHouse query: {e}")
            raise

    def save(self, data: List[Dict], table: str = None):
        self.ingest(data, table or self.table_name)

    def create_ingestion_log_table(self):
        """Table should already exist in database - this method is deprecated"""
        logger.warning("create_ingestion_log_table() called but tables should already exist")
        return

    # tracks status of every run: started/success/failed
    def log_ingestion_status(
        self,
        cloud: str,
        service: str,
        date: str,
        status: str,
        error_message: Optional[str] = None
    ):
        self.ensure_connection()
        db = os.getenv("CLICKHOUSE_DATABASE", "cost")

        now = datetime.utcnow()
        run_date = datetime.strptime(date, "%Y-%m-%d").date()
        started_at = now
        finished_at = now if status in ["success", "failed"] else None
        version = int(started_at.timestamp())

        try:
            self.client.insert(
                table=f"{db}.ingestion_log",
                data=[[
                    cloud,
                    service,
                    run_date,
                    status,
                    started_at,
                    finished_at,
                    error_message or "",
                    version
                ]],
                column_names=[
                    "cloud",
                    "service",
                    "run_date",
                    "status",
                    "started_at",
                    "finished_at",
                    "error_message",
                    "version"
                ]
            )
            logger.info(f"Logged ingestion status: {cloud}, {service}, {date}, {status}")
        except Exception as e:
            logger.error(f" Failed to log ingestion status for {cloud}-{service}-{date}: {e}")
            raise

    #it returns only those dates we need to retry or run for the first time
    def get_pending_ingestion_dates(
        self,
        cloud: str,
        service: str,
        expected_dates: List[str]
    ) -> List[str]:
        self.ensure_connection()

        if not expected_dates:
            return []

        db = os.getenv("CLICKHOUSE_DATABASE", "cost")
        date_list = ",".join([f"toDate('{d}')" for d in expected_dates])
        query = f"""
        SELECT run_date, status FROM {db}.ingestion_log
        WHERE cloud = %(cloud)s AND service = %(service)s
        AND run_date IN ({date_list})
        """

        try:
            result = self.client.query(query, parameters={"cloud": cloud, "service": service})
            rows = [dict(zip(result.column_names, row)) for row in result.result_rows]
            status_map = {str(row["run_date"]): row["status"] for row in rows}

            pending = [
                d for d in expected_dates
                if d not in status_map or status_map[d] in ("started", "failed")
            ]

            logger.info(f" Pending ingestion dates for {cloud}:{service}: {pending}")
            return pending
        except Exception as e:
            logger.error(f" Failed to fetch ingestion logs for {cloud}-{service}: {e}")
            raise

    # specifically filters out only the dates marked failed from the ingestion log - retry logic 
    def get_failed_ingestion_dates(
        self,
        cloud: str,
        service: str,
        retry_dates: List[str]
    ) -> List[str]:
        self.ensure_connection()

        if not retry_dates:
            return []

        db = os.getenv("CLICKHOUSE_DATABASE", "cost")
        date_list = ",".join([f"toDate('{d}')" for d in retry_dates])
        query = f"""
        SELECT run_date FROM {db}.ingestion_log
        WHERE cloud = %(cloud)s AND service = %(service)s
        AND run_date IN ({date_list})
        AND status = 'failed'
        """

        try:
            result = self.client.query(query, parameters={"cloud": cloud, "service": service})
            failed_dates = [str(row[0]) for row in result.result_rows]
            logger.info(f" Failed ingestion dates for {cloud}:{service}: {failed_dates}")
            return failed_dates
        except Exception as e:
            logger.error(f" Failed to get failed ingestion dates: {e}")
            raise
    
    def drop_partition(self, partition_date: datetime.date, account_id: Optional[int] = None):
        """
        Drop ClickHouse partition for a specific account_id and week start (Sunday),
        or for all account_ids for that week if account_id is None.
        """
        self.ensure_connection()

        if account_id is not None:
            # drop single (account_id, week)
            partition_tuple = f"({account_id}, toDateTime('{partition_date.strftime('%Y-%m-%d')}'))"
            query = f"ALTER TABLE {self.table_name} DROP PARTITION {partition_tuple}"
            self._run_partition_drop(query, account_id, partition_date)
        else:
            # fetch all account_ids for that week
            week_dt = partition_date.strftime('%Y-%m-%d')
            fetch_query = f"""
                SELECT DISTINCT account_id
                FROM {self.table_name}
                WHERE toStartOfWeek(usage_start_ts) = toDateTime('{week_dt}')
            """
            try:
                rows = self.client.query(fetch_query)
                account_ids = [row[0] for row in rows.result_rows]  

            except Exception as e:
                logger.error(f"Failed to fetch account_ids for week {partition_date}: {e}")
                return

            if not account_ids:
                logger.warning(f"No account_ids found for week {partition_date}, skipping partition drop.")
                return

            for acc_id in account_ids:
                partition_tuple = f"({acc_id}, toDateTime('{week_dt}'))"
                query = f"ALTER TABLE {self.table_name} DROP PARTITION {partition_tuple}"
                self._run_partition_drop(query, acc_id, partition_date)
    
    def count_records_by_date(self, target_date: datetime.date, service: Optional[str] = None, account_id: Optional[str] = None) -> int:
        """
        Count records for a specific date, optionally scoped to a specific account.
        """
        self.ensure_connection()
        
        from datetime import time, timedelta
        start_dt = datetime.combine(target_date, time.min)
        end_dt = datetime.combine(target_date + timedelta(days=1), time.min)
        
        query = f"""
            SELECT COUNT(*) FROM {self.table_name}
            WHERE usage_start_ts >= %(start_dt)s
            AND usage_start_ts < %(end_dt)s
        """
        params = {
            "start_dt": start_dt.strftime('%Y-%m-%d %H:%M:%S'),
            "end_dt": end_dt.strftime('%Y-%m-%d %H:%M:%S'),
        }

        if account_id:
            query += " AND account_id = %(account_id)s"
            params["account_id"] = account_id

        if service:
            service_config = self.service_mapping.get(service.lower())
            if isinstance(service_config, dict):
                product_code = service_config.get('product_code')
                operation_filter = service_config.get('operation_filter')
            else:
                product_code = service_config
                operation_filter = None

            query += " AND product_code = %(product_code)s"
            params["product_code"] = product_code
            if operation_filter:
                query += " AND operation LIKE %(operation_filter)s"
                params["operation_filter"] = operation_filter
        
        try:
            result = self.client.query(query, parameters=params)
            count = result.result_rows[0][0] if result.result_rows else 0
            return count
        except Exception as e:
            logger.error(f"Failed to count records for {target_date}: {e}")
            raise
    
    def delete_by_timestamp_range(
        self,
        min_ts: datetime,
        max_ts: datetime,
        service: Optional[str] = None,
    ) -> int:
        """
        Delete data by exact timestamp range.
        Returns approximate count of records deleted.
        """
        self.ensure_connection()

        ts_start = min_ts.strftime('%Y-%m-%d %H:%M:%S')
        ts_end = max_ts.strftime('%Y-%m-%d %H:%M:%S')

        product_filter = ""
        operation_filter = ""
        params = {
            "ts_start": ts_start,
            "ts_end": ts_end,
        }
        if service:
            service_config = self.service_mapping.get(service.lower())
            if isinstance(service_config, dict):
                product_code = service_config.get("product_code")
                op_filter_value = service_config.get("operation_filter")
            else:
                product_code = service_config
                op_filter_value = None

            if product_code:
                product_filter = " AND product_code = %(product_code)s"
                params["product_code"] = product_code
            if op_filter_value:
                operation_filter = " AND operation LIKE %(operation_filter)s"
                params["operation_filter"] = op_filter_value

        count_query = f"""
            SELECT COUNT(*) FROM {self.table_name}
                        WHERE usage_start_ts >= %(ts_start)s
                            AND usage_start_ts <= %(ts_end)s
              {product_filter}
              {operation_filter}
        """

        delete_query = f"""
            DELETE FROM {self.table_name}
                        WHERE usage_start_ts >= %(ts_start)s
                            AND usage_start_ts <= %(ts_end)s
              {product_filter}
              {operation_filter}
            SETTINGS
                mutations_sync = 0,
                lightweight_deletes_sync = 1
        """

        try:
            result = self.client.query(count_query, parameters=params)
            count = result.result_rows[0][0] if result.result_rows else 0

            self.client.command(delete_query, parameters=params)
            logger.info(f"Deleted ~{count} records in range [{ts_start} - {ts_end}]")
            return count
        except Exception as e:
            logger.error(f"Failed to delete by timestamp range: {e}")
            raise
    
    def delete_by_date(
        self,
        target_date: datetime.date,
        service: Optional[str] = None,
        account_id: Optional[str] = None,
        chunk_hours: int = 4,
        max_retries: int = 3,
        chunk_threshold: int = 1000,
    ):
        """
        Delete data for a specific date, chunked by hour to reduce memory pressure.
        """
        self.ensure_connection()

        if chunk_hours <= 0:
            raise ValueError(f"chunk_hours must be > 0, got {chunk_hours}")
        if chunk_threshold < 0:
            raise ValueError(f"chunk_threshold must be >= 0, got {chunk_threshold}")

        record_count = self.count_records_by_date(target_date, service, account_id=account_id)
        delete_mode = "single-shot" if record_count <= chunk_threshold else f"{chunk_hours}h chunks"
        logger.info(f"Found {record_count} existing records for {target_date} — deleting via {delete_mode}")

        if record_count == 0:
            logger.info(f"No records found for {target_date}, skipping delete.")
            return

        # --- Build the static filter parts ---
        acc_filter = ""

        product_filter = ""
        operation_filter = ""
        static_params = {}
        if account_id:
            acc_filter = " AND account_id = %(account_id)s"
            static_params["account_id"] = account_id

        if service:
            service_config = self.service_mapping.get(service.lower())
            if isinstance(service_config, dict):
                product_code = service_config.get("product_code")
                op_filter_value = service_config.get("operation_filter")
            else:
                product_code = service_config
                op_filter_value = None

            if not product_code:
                raise ValueError(f"No product_code found for service '{service}'")

            product_filter = " AND product_code = %(product_code)s"
            static_params["product_code"] = product_code
            if op_filter_value:
                operation_filter = " AND operation LIKE %(operation_filter)s"
                static_params["operation_filter"] = op_filter_value

        from datetime import time, timedelta
        import time as time_module

        # Fast path for small deletes: one query is usually faster than six chunk mutations.
        if record_count <= chunk_threshold:
            day_start = datetime.combine(target_date, time.min)
            day_end = day_start + timedelta(days=1)
            single_params = dict(static_params)
            single_params.update({
                "chunk_start": day_start.strftime('%Y-%m-%d %H:%M:%S'),
                "chunk_end": day_end.strftime('%Y-%m-%d %H:%M:%S'),
            })

            single_query = f"""
                DELETE FROM {self.table_name}
                WHERE usage_start_ts >= %(chunk_start)s
                AND usage_start_ts <  %(chunk_end)s
                {product_filter}
                {operation_filter}
                {acc_filter}
                SETTINGS
                    mutations_sync = 0,
                    lightweight_deletes_sync = 1
            """

            self._execute_with_retry(
                query=single_query,
                label=f"{target_date} full-day delete",
                max_retries=max_retries,
                params=single_params,
            )
            logger.info(
                f"Completed delete for {target_date} | service={service or 'ALL'} | "
                f"account={account_id or 'ALL'} | ~{record_count} records removed"
            )
            return

        current_chunk_hours = chunk_hours
        hour = 0
        while hour < 24:
            window_hours = min(current_chunk_hours, 24 - hour)
            if window_hours <= 0:
                logger.error(f"window_hours reached 0 at hour={hour}, aborting delete loop for {target_date}")
                break

            chunk_start = datetime.combine(target_date, time(hour, 0, 0))
            chunk_end = chunk_start + timedelta(hours=window_hours)

            chunk_params = dict(static_params)
            chunk_params.update({
                "chunk_start": chunk_start.strftime('%Y-%m-%d %H:%M:%S'),
                "chunk_end": chunk_end.strftime('%Y-%m-%d %H:%M:%S'),
            })

            query = f"""
                DELETE FROM {self.table_name}
                WHERE usage_start_ts >= %(chunk_start)s
                AND usage_start_ts <  %(chunk_end)s
                {product_filter}
                {operation_filter}
                {acc_filter}
                SETTINGS
                    mutations_sync = 0,
                    lightweight_deletes_sync = 1
            """

            try:
                self._execute_with_retry(
                    query=query,
                    label=f"{target_date} hours [{hour}-{hour + window_hours})",
                    max_retries=max_retries,
                    params=chunk_params,
                )
                hour += window_hours
                time_module.sleep(0.5)
            except Exception as e:
                err_str = str(e)
                is_memory_error = "MEMORY_LIMIT_EXCEEDED" in err_str
                if is_memory_error and current_chunk_hours > 1:
                    next_chunk = max(1, current_chunk_hours // 2)
                    logger.warning(
                        f"Memory pressure detected for {target_date} around hour {hour}. "
                        f"Reducing delete chunk size from {current_chunk_hours}h to {next_chunk}h and retrying."
                    )
                    current_chunk_hours = next_chunk
                    continue
                raise

        logger.info(f"Completed delete for {target_date} | service={service or 'ALL'} | account={account_id or 'ALL'} | ~{record_count} records removed")

    def _execute_with_retry(self, query: str, label: str, max_retries: int = 3, params: Optional[Dict] = None):
        """
        Execute a ClickHouse command with exponential backoff retry.
        Kills stuck mutations before retrying on memory errors.
        """
        import time as time_module

        for attempt in range(1, max_retries + 1):
            try:
                logger.debug(f"[Attempt {attempt}/{max_retries}] Executing delete chunk: {label}")
                self.client.command(query, parameters=params or {})
                logger.info(f"Deleted chunk: {label}")
                return
            except Exception as e:
                err_str = str(e)
                is_memory_error = "MEMORY_LIMIT_EXCEEDED" in err_str
                is_session_locked = "SESSION_IS_LOCKED" in err_str or "Code: 373" in err_str
                is_last_attempt = attempt == max_retries

                logger.warning(f"[Attempt {attempt}] Failed for chunk '{label}': {err_str[:300]}")

                if is_memory_error:
                    logger.warning("Memory limit hit — killing stuck mutations before retry...")
                    self._kill_stuck_mutations()

                if is_session_locked:
                    logger.warning("ClickHouse session is locked — resetting client session before retry...")
                    self._reset_connection()

                if is_last_attempt:
                    logger.error(f"All {max_retries} attempts failed for chunk: {label}")
                    raise

                backoff = 2 ** attempt
                logger.info(f"Retrying in {backoff}s...")
                time_module.sleep(backoff)

    def _reset_connection(self):
        """Recreate the ClickHouse client to get a fresh session_id."""
        try:
            old_client = self.client
            self.client = None
            if old_client and hasattr(old_client, "close"):
                old_client.close()
        except Exception:
            # Non-fatal: we still attempt to create a fresh client below.
            pass
        self.connection()

    def _kill_stuck_mutations(self):
        """Kill any unfinished mutations on the target table to free memory."""
        try:
            db = os.getenv("CLICKHOUSE_DATABASE", "cost")
            bare_table = self.table_name.split(".")[-1]
            kill_query = f"""
                KILL MUTATION WHERE 
                    database = '{db}'
                    AND
                    table = '{bare_table}' 
                    AND is_done = 0
            """
            self.client.command(kill_query)
            logger.info(f"Killed stuck mutations on {bare_table}")
        except Exception as e:
            logger.warning(f"Could not kill mutations (non-fatal): {e}")

    def _run_partition_drop(self, query: str, account_id: int, partition_date: datetime.date):
        try:
            self.client.command(query)
            logger.info(f"Dropped partition for account_id={account_id} and week={partition_date}")
        except Exception as e:
            logger.error(f"Failed to drop partition ({account_id}, {partition_date}): {e}")










