import logging
from datetime import datetime, date
from typing import List, Dict
from engine.victoria_metrics import VictoriaMetricsEngine
from engine.clickhouse import ClickHouseEngine

logger = logging.getLogger(__name__)

class VMUtilizationAnalyzer:
    """
    Analyze VM utilization and identify underutilized VMs.
    Bridges VictoriaMetrics → ClickHouse.
    """
    
    # Configurable thresholds
    THRESHOLDS = {
        'cpu_underutilized': 2.0,      # CPU < 2% = underutilized
        'mem_underutilized': 10.0,     # Memory < 10% = underutilized
        'cpu_weight': 0.6,      # 60% weight for CPU in score
        'mem_weight': 0.3,      # 30% weight for memory
        'network_weight': 0.1   # 10% weight for network
    }
    
    def __init__(self, vm_engine: VictoriaMetricsEngine, ch_engine: ClickHouseEngine):
        self.vm_engine = vm_engine
        self.ch_engine = ch_engine
        self.table_name = 'vm_utilization_summary'
    
    def create_table(self):
        """Create ClickHouse table if not exists."""
        schema = """
        CREATE TABLE IF NOT EXISTS vm_utilization_summary (
            provider String,
            account_id String,
            resource_id String,
            instance_type String,
            region String,
            availability_zone String,
            event_date Date,
            period_start DateTime,
            period_end DateTime,
            avg_cpu_percent Float64,
            max_cpu_percent Float64,
            avg_mem_percent Float64,
            max_mem_percent Float64,
            avg_network_in_mbps Float64 DEFAULT 0,
            avg_network_out_mbps Float64 DEFAULT 0,
            avg_disk_read_mbps Float64 DEFAULT 0,
            avg_disk_write_mbps Float64 DEFAULT 0,
            utilization_score Float64,
            is_underutilized UInt8,
            underutilization_reason String DEFAULT '',
            created_at DateTime DEFAULT now(),
            updated_at DateTime DEFAULT now()
        ) ENGINE = ReplacingMergeTree(updated_at)
        ORDER BY (provider, account_id, resource_id, event_date)
        PARTITION BY toYYYYMM(event_date)
        """
        
        try:
            self.ch_engine.client.command(schema)
            logger.info(f"✅ Table {self.table_name} ready")
        except Exception as e:
            logger.error(f"Failed to create table: {e}")
            raise
    
    def calculate_utilization_score(self, cpu_pct: float, mem_pct: float, 
                                    network_mbps: float = 0) -> float:
        """
        Calculate utilization score (0-100).
        Higher score = better utilized.
        """
        cpu_score = min(cpu_pct, 100)
        mem_score = min(mem_pct, 100)
        network_score = min(network_mbps / 10, 100)  # Assume 10 Mbps = 100%
        
        score = (
            cpu_score * self.THRESHOLDS['cpu_weight'] +
            mem_score * self.THRESHOLDS['mem_weight'] +
            network_score * self.THRESHOLDS['network_weight']
        )
        
        return round(score, 2)
    
    def is_underutilized(self, cpu_pct: float, mem_pct: float) -> tuple:
        """
        Determine if VM is underutilized.
        
        Returns:
            (is_underutilized: bool, reason: str)
        """
        reasons = []
        
        if cpu_pct < self.THRESHOLDS['cpu_underutilized']:
            reasons.append(f"CPU {cpu_pct:.1f}% < {self.THRESHOLDS['cpu_underutilized']}%")
        
        if mem_pct < self.THRESHOLDS['mem_underutilized']:
            reasons.append(f"Memory {mem_pct:.1f}% < {self.THRESHOLDS['mem_underutilized']}%")
        
        is_underutilized_vm = len(reasons) >= 2  # Both CPU AND memory must be low
        reason = "; ".join(reasons) if reasons else ""
        
        return is_underutilized_vm, reason
    
    def ingest_daily_metrics(self, provider: str = 'aws', lookback_hours: int = 24):
        """
        Query VictoriaMetrics and ingest into ClickHouse.
        
        Args:
            provider: Cloud provider ('aws', 'gcp', 'azure')
            lookback_hours: Hours to analyze (default: 24)
        """
        logger.info(f"═══════════════════════════════════════════════")
        logger.info(f"  VM UTILIZATION ANALYSIS - Daily Ingestion")
        logger.info(f"  Provider: {provider.upper()}")
        logger.info(f"  Lookback: {lookback_hours} hours")
        logger.info(f"═══════════════════════════════════════════════")
        
        # Query VictoriaMetrics
        vm_metrics = self.vm_engine.get_vm_utilization(lookback_hours=lookback_hours)
        
        if not vm_metrics:
            logger.warning("No metrics retrieved from VictoriaMetrics")
            return
        
        # Enrich and analyze
        records = []
        underutilized_count = 0
        
        for vm in vm_metrics:
            # Calculate score
            score = self.calculate_utilization_score(
                vm['avg_cpu_percent'],
                vm['avg_mem_percent']
            )
            
            # Check if underutilized
            is_underutilized_vm, reason = self.is_underutilized(
                vm['avg_cpu_percent'],
                vm['avg_mem_percent']
            )
            
            if is_underutilized_vm:
                underutilized_count += 1
            
            # Prepare record
            record = {
                'provider': provider,
                'account_id': '',  # Will be enriched from EC2 metadata or tags
                'resource_id': vm['instance_id'],
                'instance_type': '',  # Will be enriched
                'region': '',  # Will be enriched
                'availability_zone': '',
                'event_date': date.today(),
                'period_start': vm['period_start'],
                'period_end': vm['period_end'],
                'avg_cpu_percent': vm['avg_cpu_percent'],
                'max_cpu_percent': vm['avg_cpu_percent'],  # TODO: Get actual max
                'avg_mem_percent': vm['avg_mem_percent'],
                'max_mem_percent': vm['avg_mem_percent'],  # TODO: Get actual max
                'utilization_score': score,
                'is_underutilized': 1 if is_underutilized_vm else 0,
                'underutilization_reason': reason
            }
            
            records.append(record)
        
        # Bulk insert to ClickHouse
        try:
            self.ch_engine.client.insert(self.table_name, records)
            logger.info(f"✅ Ingested {len(records)} VM metrics")
            logger.info(f"⚠️ Found {underutilized_count} underutilized VMs ({underutilized_count/len(records)*100:.1f}%)")
        except Exception as e:
            logger.error(f"Failed to insert records: {e}")
            raise
    
    def get_underutilized_report(self, days: int = 7) -> Dict:
        """
        Generate underutilized VM report with cost correlation.
        
        Args:
            days: Number of days to analyze
        
        Returns:
            Report dict with underutilized VMs and cost data
        """
        query = f"""
        SELECT 
            u.provider,
            u.account_id,
            u.resource_id,
            u.instance_type,
            u.region,
            u.avg_cpu_percent,
            u.avg_mem_percent,
            u.utilization_score,
            u.underutilization_reason,
            COUNT(DISTINCT c.resource_id) as has_cost_data,
            SUM(c.cost_unblended) as total_cost_{days}d,
            AVG(c.cost_unblended) as avg_daily_cost
        FROM {self.table_name} u
        LEFT JOIN service_costs c 
            ON u.resource_id = c.resource_id
            AND c.product_code = 'AmazonEC2'
            AND c.usage_start_ts >= u.period_start
            AND c.usage_start_ts <= u.period_end
        WHERE u.is_underutilized = 1
            AND u.event_date >= today() - {days}
        GROUP BY 
            u.provider, u.account_id, u.resource_id, u.instance_type,
            u.region, u.avg_cpu_percent, u.avg_mem_percent,
            u.utilization_score, u.underutilization_reason
        ORDER BY total_cost_{days}d DESC
        """
        
        try:
            result = self.ch_engine.client.query(query)
            
            underutilized_vms = []
            total_waste = 0
            
            for row in result.result_rows:
                cost = row[10] if row[10] else 0
                total_waste += cost
                
                underutilized_vms.append({
                    'provider': row[0],
                    'account_id': row[1],
                    'resource_id': row[2],
                    'instance_type': row[3],
                    'region': row[4],
                    'avg_cpu_percent': round(row[5], 2),
                    'avg_mem_percent': round(row[6], 2),
                    'utilization_score': row[7],
                    'underutilization_reason': row[8],
                    'has_cost_data': row[9] > 0,
                    f'total_cost_{days}d': round(cost, 2),
                    'avg_daily_cost': round(row[11], 2) if row[11] else 0,
                    'potential_savings': round(cost * 0.7, 2)  # 70% savings
                })
            
            report = {
                'report_date': datetime.now().isoformat(),
                'period_days': days,
                'total_underutilized': len(underutilized_vms),
                'total_wasted_cost': round(total_waste, 2),
                'potential_monthly_savings': round(total_waste * 4.3 * 0.7, 2),
                'underutilized_vms': underutilized_vms
            }
            
            logger.info(f"📊 Report: {len(underutilized_vms)} underutilized VMs, ${total_waste:.2f} wasted")
            return report
        
        except Exception as e:
            logger.error(f"Failed to generate report: {e}")
            return {'error': str(e)}
