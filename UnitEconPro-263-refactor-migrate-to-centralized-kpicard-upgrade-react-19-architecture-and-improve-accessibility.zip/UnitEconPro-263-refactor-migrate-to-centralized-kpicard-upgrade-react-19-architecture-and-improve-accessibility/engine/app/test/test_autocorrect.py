import logging
import sys
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from engine.data_manager import CloudToClickHouseIngestor
from engine.clickhouse import ClickHouseEngine
from utils import load_config
from datetime import datetime

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def test_autocorrect():
    """Test autocorrect mode (drop and refresh weekly partitions)"""
    logging.info("🧪 Testing autocorrect mode for AWS")
    
    try:
        config = load_config('aws')
        service_mapping = config.get('aws', {}).get('service_mapping', {})
        ch_engine = ClickHouseEngine(service_mapping=service_mapping)
        ch_engine.connection()
        
        pipeline = CloudToClickHouseIngestor(cloud='aws', config=config, ch_engine=ch_engine)
        
        # Run autocorrect for EC2 service
        pipeline.autocorrect(current_date=datetime.today(), service='ec2', account_ids=None)
        
        logging.info("✅ Autocorrect test completed successfully")
    except Exception as e:
        logging.error(f"❌ Autocorrect test failed: {e}", exc_info=True)

if __name__ == "__main__":
    test_autocorrect()




