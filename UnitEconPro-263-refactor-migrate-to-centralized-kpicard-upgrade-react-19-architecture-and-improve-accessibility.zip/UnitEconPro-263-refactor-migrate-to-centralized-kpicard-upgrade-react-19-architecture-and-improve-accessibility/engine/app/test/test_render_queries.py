# from utils.utils import query_factory

# if __name__ == "__main__":
    
#     service = 'ec2'
#     start_date = '2023-01-01'
#     end_date = '2023-01-31'

#     query = query_factory(service, start_date, end_date)
#     print("Generated Query:\n", query)


import unittest
import yaml
from jinja2 import Template
import datetime

class TestQueryRendering(unittest.TestCase):
    def setUp(self):
        with open("config.yml") as f:
            self.config = yaml.safe_load(f)

    def test_queries_render(self):
        queries = self.config["athena"]["queries"]
        columns = self.config["athena"]["columns"]
        database = self.config["athena"]["database"]
        table = self.config["athena"]["table"]

        # Example date range for rendering
        start_date_str = (datetime.datetime.now() - datetime.timedelta(days=7)).strftime("%Y-%m-%d %H:%M:%S")
        end_date_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        for query in queries:
            if not query.get("enabled", False):
                continue

            service = query["service"]
            template_str = query["sql"]

            try:
                template = Template(template_str)
                rendered_query = template.render(
                    columns=columns,
                    database=database,
                    table=table,
                    start_date_str=start_date_str,
                    end_date_str=end_date_str,
                )
                self.assertIn("SELECT", rendered_query)  # basic check
            except Exception as e:
                self.fail(f"Failed to render query for service: {service} — {str(e)}")

if __name__ == "__main__":
    unittest.main()




