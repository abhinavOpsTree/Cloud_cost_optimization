-- Grafana Dashboard Queries for Underutilized VMs

-- Query 1: Top Underutilized VMs by Cost
SELECT 
    u.resource_id,
    u.instance_type,
    u.region,
    u.avg_cpu_percent,
    u.avg_mem_percent,
    u.utilization_score,
    SUM(c.cost_unblended) as total_cost_7d,
    SUM(c.cost_unblended) * 0.7 as potential_savings
FROM vm_utilization_summary u
LEFT JOIN service_costs c 
    ON u.resource_id = c.resource_id
    AND c.product_code = 'AmazonEC2'
WHERE u.is_underutilized = 1
    AND u.event_date >= today() - 7
GROUP BY u.resource_id, u.instance_type, u.region, 
         u.avg_cpu_percent, u.avg_mem_percent, u.utilization_score
ORDER BY total_cost_7d DESC
LIMIT 50;

-- Query 2: Total Wasted Cost
SELECT 
    SUM(c.cost_unblended) as total_waste
FROM vm_utilization_summary u
LEFT JOIN service_costs c 
    ON u.resource_id = c.resource_id
WHERE u.is_underutilized = 1
    AND u.event_date >= today() - 7;

-- Query 3: Underutilized VMs by Account
SELECT 
    u.account_id,
    COUNT(DISTINCT u.resource_id) as underutilized_count,
    SUM(c.cost_unblended) as wasted_cost
FROM vm_utilization_summary u
LEFT JOIN service_costs c ON u.resource_id = c.resource_id
WHERE u.is_underutilized = 1
    AND u.event_date >= today() - 7
GROUP BY u.account_id
ORDER BY wasted_cost DESC;

-- Query 4: Utilization Distribution
SELECT 
    utilization_score,
    COUNT(*) as vm_count
FROM vm_utilization_summary
WHERE event_date >= today() - 7
GROUP BY utilization_score
ORDER BY utilization_score;
