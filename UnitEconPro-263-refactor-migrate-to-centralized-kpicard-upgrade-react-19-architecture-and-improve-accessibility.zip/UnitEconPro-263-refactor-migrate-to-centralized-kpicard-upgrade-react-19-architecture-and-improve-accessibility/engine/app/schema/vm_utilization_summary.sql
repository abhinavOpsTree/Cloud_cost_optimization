-- VM Utilization Summary Table
-- Stores daily aggregated metrics from VictoriaMetrics/Prometheus

CREATE TABLE IF NOT EXISTS vm_utilization_summary (
    provider String,                    -- 'aws', 'gcp', 'azure'
    account_id String,                  -- Cloud account ID
    resource_id String,                 -- Instance ID (e.g., i-0abc123)
    instance_type String,               -- m5.xlarge, t3.medium, etc.
    region String,                      -- us-east-1, ap-south-1, etc.
    availability_zone String,           -- us-east-1a, etc.
    
    -- Time period
    event_date Date,                    -- Date of measurement
    period_start DateTime,              -- Start of measurement period
    period_end DateTime,                -- End of measurement period
    
    -- CPU metrics
    avg_cpu_percent Float64,            -- Average CPU usage (0-100)
    max_cpu_percent Float64,            -- Peak CPU usage (0-100)
    
    -- Memory metrics
    avg_mem_percent Float64,            -- Average memory usage (0-100)
    max_mem_percent Float64,            -- Peak memory usage (0-100)
    
    -- Network metrics (optional)
    avg_network_in_mbps Float64 DEFAULT 0,
    avg_network_out_mbps Float64 DEFAULT 0,
    
    -- Disk metrics (optional)
    avg_disk_read_mbps Float64 DEFAULT 0,
    avg_disk_write_mbps Float64 DEFAULT 0,
    
    -- Analysis
    utilization_score Float64,          -- Weighted score (0-100)
    is_underutilized UInt8,             -- 1 if underutilized, 0 if not
    underutilization_reason String DEFAULT '',  -- Why flagged as underutilized
    
    -- Metadata
    created_at DateTime DEFAULT now(),
    updated_at DateTime DEFAULT now()
    
) ENGINE = ReplacingMergeTree(updated_at)
ORDER BY (provider, account_id, resource_id, event_date)
PARTITION BY toYYYYMM(event_date);
