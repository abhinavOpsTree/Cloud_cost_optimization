# Cloud-Agnostic Tag Migration

## What Changed

Renamed tag columns from AWS-specific to cloud-agnostic names:

| Old Name | New Name | Why |
|----------|----------|-----|
| `tag_environment` | `tag_env` | Shorter, works for all clouds |
| `tag_application` | `tag_app` | Shorter, works for all clouds |
| `tags_extra` | `tags_map` | More descriptive |

## Migration Steps

### 1. Run Migration SQL
```bash
docker exec -it clickhouse clickhouse-client --user dba --password secretPassword < migrations/003_cloud_agnostic_tags.sql
```

### 2. Verify Migration
```bash
docker exec -it clickhouse clickhouse-client --user dba --password secretPassword --query "SELECT tag_env, tag_team, tag_app, COUNT(*) FROM cost.service_costs GROUP BY tag_env, tag_team, tag_app LIMIT 10"
```

### 3. Re-run Ingestion (Optional)
```bash
python3 app/app.py --mode refresh_days --days 1 --service all --cloud aws
```

## Benefits

✅ **Cloud-agnostic**: Same schema works for AWS, GCP, Azure  
✅ **Future-proof**: Add new clouds without schema changes  
✅ **Cleaner**: Shorter column names  
✅ **Maintainable**: Config-driven mapping  

## Backward Compatibility

Old columns are kept by default. To remove them, uncomment Step 3 in the migration SQL.
