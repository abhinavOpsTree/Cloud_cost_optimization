-- Migration: Add cloud-agnostic tag columns
-- Run this ONCE on existing ClickHouse database

-- Step 1: Add new cloud-agnostic columns
ALTER TABLE cost.service_costs 
ADD COLUMN IF NOT EXISTS tag_env LowCardinality(String) DEFAULT '';

ALTER TABLE cost.service_costs 
ADD COLUMN IF NOT EXISTS tag_app LowCardinality(String) DEFAULT '';

ALTER TABLE cost.service_costs 
ADD COLUMN IF NOT EXISTS tags_map Map(String, String) DEFAULT map();

-- Step 2: Copy data from old columns to new columns
ALTER TABLE cost.service_costs 
UPDATE tag_env = tag_environment WHERE tag_environment != '';

ALTER TABLE cost.service_costs 
UPDATE tag_app = tag_application WHERE tag_application != '';

-- Step 3: Verify migration
SELECT 
    'Migration Complete' as status,
    COUNT(*) as total_records,
    COUNT(tag_env) as with_env,
    COUNT(tag_app) as with_app
FROM cost.service_costs;
