import clickhouse_connect
import os
from datetime import datetime, timedelta
import random

# Connect to ClickHouse
client = clickhouse_connect.get_client(
    host=os.environ.get('CLICKHOUSE_HOST', 'localhost'),
    port=int(os.environ.get('CLICKHOUSE_PORT', 8123)),
    username=os.environ.get('CLICKHOUSE_USER', 'dba'),
    password=os.environ.get('CLICKHOUSE_PASSWORD', ''),
    database=os.environ.get('CLICKHOUSE_DB', 'cost')
)

# Generate sample data (e.g., last 3 weeks)
now = datetime.now()
data = []

for i in range(100):
    delta_days = random.randint(0, 20)  # Events in the last 3 weeks
    event_date = now - timedelta(days=delta_days)
    event_time = event_date.replace(hour=random.randint(0, 23), minute=random.randint(0, 59))
    user_id = random.randint(1000, 2000)
    amount = round(random.uniform(10, 100), 2)
    data.append([event_date.date(), event_time, user_id, amount])

# Insert data into ClickHouse
client.insert(
    table='weekly_metrics',
    data=data,
    column_names=['event_date', 'event_time', 'user_id', 'amount']
)

print("✅ Sample data inserted successfully!")

# View partitions with metadata
print("\n📦 Weekly Partitions Overview:")
result = client.query('''
    SELECT
        toStartOfWeek(event_date) AS week_start_date,
        count(*) AS row_count,
        min(event_date) AS from_date,
        max(event_date) AS to_date
    FROM cost.weekly_metrics
    GROUP BY week_start_date
    ORDER BY week_start_date
''')

# Print partition info
for row in result.result_rows:
    print(f"Partition (Week Start): {row[0]}, Rows: {row[1]}, From: {row[2]}, To: {row[3]}")

# SELECT toStartOfWeek(event_date) AS week_start_date, count(*) AS row_count, min(event_date) AS from_date, max(event_date) AS to_date FROM cost.weekly_metrics GROUP BY week_start_date ORDER BY week_start_date

# CREATE TABLE cost.weekly_metrics
#  (
#      `event_date` Date,
#      `event_time` DateTime,
#      `user_id` UInt32,
#      `amount` Float64
# )
# ENGINE = MergeTree
# PARTITION BY toStartOfWeek(event_date)
# ORDER BY (event_date, user_id)
# SETTINGS index_granularity = 8192

