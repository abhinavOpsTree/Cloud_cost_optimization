#!/bin/bash
set -euxo pipefail

# Set variables
NETWORK_NAME="clickhouse_net"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG_DIR="$SCRIPT_DIR/../logs"
MODES=("ingest" "retry" "autocorrect")

# Ensure log dir exists
mkdir -p "$LOG_DIR"

echo "[STARTING at $(date)]"

# Check if Docker network exists
if ! docker network ls | grep -q "$NETWORK_NAME"; then
  echo " Network '$NETWORK_NAME' not found. Please start Docker Compose first using:"
  echo "   docker-compose up -d"
  exit 1
fi

# Loop through modes and run the commands
for MODE in "${MODES[@]}"; do
  echo "  Running mode: $MODE"

  if [[ "$MODE" == "retry" ]]; then
    docker-compose run --rm scheduled-ingest \
      --mode ingest_daily \
      --cloud aws \
      --service all \
      --retry >> "$LOG_DIR/${MODE}.log" 2>&1

  elif [[ "$MODE" == "autocorrect" ]]; then
    docker-compose run --rm scheduled-ingest \
      --mode autocorrect \
      --cloud aws \
      --service all >> "$LOG_DIR/${MODE}.log" 2>&1

  else
    docker-compose run --rm scheduled-ingest \
      --mode ingest_daily \
      --cloud aws \
      --service all >> "$LOG_DIR/${MODE}.log" 2>&1
  fi
done


echo "[ All tasks completed at $(date)]"

docker system prune -f --volumes








