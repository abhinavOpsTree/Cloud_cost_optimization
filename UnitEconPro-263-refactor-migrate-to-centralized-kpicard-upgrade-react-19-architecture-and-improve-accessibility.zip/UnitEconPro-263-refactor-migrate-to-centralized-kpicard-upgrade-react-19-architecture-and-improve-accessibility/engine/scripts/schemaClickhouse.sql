CREATE DATABASE IF NOT EXISTS cost;

CREATE TABLE IF NOT EXISTS cost.weekly_athena_metrics (
    account_id String,
    usage_start_ts DateTime,
    usage_end_ts DateTime,
    product_code String,
    operation String,
    resource_id String,
    usage_qty Float64,
    cost_unblended Float64,
    cost_blended Float64,
    product_family String,
    region String,
    usage_type String
)
ENGINE = MergeTree
PARTITION BY toStartOfWeek(toDate(usage_start_ts))
ORDER BY (usage_start_ts, account_id)
SETTINGS index_granularity = 8192;