#!/bin/bash

# Script to manage AWS account ID to account name mappings in ClickHouse

CLICKHOUSE_HOST="${CLICKHOUSE_HOST:-localhost}"
CLICKHOUSE_PORT="${CLICKHOUSE_PORT:-8123}"
CLICKHOUSE_USER="${CLICKHOUSE_USER:-dba}"
CLICKHOUSE_PASSWORD="${CLICKHOUSE_PASSWORD:-secretPassword}"
CLICKHOUSE_DATABASE="${CLICKHOUSE_DATABASE:-cost}"
USE_DOCKER="${USE_DOCKER:-true}"

# Function to execute ClickHouse query
execute_query() {
    local query="$1"
    
    if [ "$USE_DOCKER" = "true" ]; then
        # Docker mode (local development)
        docker exec clickhouse clickhouse-client \
            --user "$CLICKHOUSE_USER" \
            --password "$CLICKHOUSE_PASSWORD" \
            -q "$query"
    else
        # Direct connection mode (production/K8s)
        clickhouse-client \
            --host "$CLICKHOUSE_HOST" \
            --port "$CLICKHOUSE_PORT" \
            --user "$CLICKHOUSE_USER" \
            --password "$CLICKHOUSE_PASSWORD" \
            -q "$query"
    fi
}

# Function to add an account mapping
add_account() {
    local account_id=$1
    local account_name=$2
    
    if [ -z "$account_id" ] || [ -z "$account_name" ]; then
        echo "Usage: $0 add <account_id> <account_name>"
        exit 1
    fi
    
    echo "Adding account mapping: $account_id -> $account_name"
    execute_query "INSERT INTO ${CLICKHOUSE_DATABASE}.account_map (account_id, account_name) VALUES ($account_id, '$account_name')"
    
    echo "✅ Account mapping added successfully"
}

# Function to list all account mappings
list_accounts() {
    echo "Current account mappings:"
    execute_query "SELECT account_id, account_name FROM ${CLICKHOUSE_DATABASE}.account_map ORDER BY account_id"
}

# Function to update an account mapping
update_account() {
    local account_id=$1
    local account_name=$2
    
    if [ -z "$account_id" ] || [ -z "$account_name" ]; then
        echo "Usage: $0 update <account_id> <account_name>"
        exit 1
    fi
    
    echo "Updating account mapping: $account_id -> $account_name"
    execute_query "ALTER TABLE ${CLICKHOUSE_DATABASE}.account_map DELETE WHERE account_id = $account_id"
    execute_query "INSERT INTO ${CLICKHOUSE_DATABASE}.account_map (account_id, account_name) VALUES ($account_id, '$account_name')"
    
    echo "✅ Account mapping updated successfully"
}

# Function to delete an account mapping
delete_account() {
    local account_id=$1
    
    if [ -z "$account_id" ]; then
        echo "Usage: $0 delete <account_id>"
        exit 1
    fi
    
    echo "Deleting account mapping for: $account_id"
    execute_query "ALTER TABLE ${CLICKHOUSE_DATABASE}.account_map DELETE WHERE account_id = $account_id"
    
    echo "✅ Account mapping deleted successfully"
}

# Main script logic
case "$1" in
    add)
        add_account "$2" "$3"
        ;;
    list)
        list_accounts
        ;;
    update)
        update_account "$2" "$3"
        ;;
    delete)
        delete_account "$2"
        ;;
    *)
        echo "Usage: $0 {add|list|update|delete} [arguments]"
        echo ""
        echo "Commands:"
        echo "  add <account_id> <account_name>    - Add a new account mapping"
        echo "  list                                - List all account mappings"
        echo "  update <account_id> <account_name> - Update an existing account mapping"
        echo "  delete <account_id>                 - Delete an account mapping"
        echo ""
        echo "Examples:"
        echo "  $0 add 123456789012 'Production Account'"
        echo "  $0 list"
        echo "  $0 update 123456789012 'Prod Account'"
        echo "  $0 delete 123456789012"
        exit 1
        ;;
esac
