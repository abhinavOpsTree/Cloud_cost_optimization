output "bucket_name" {
  value = aws_s3_bucket.cur_bucket.id
}

output "report_name" {
  value = aws_cur_report_definition.cur_report.report_name
}
