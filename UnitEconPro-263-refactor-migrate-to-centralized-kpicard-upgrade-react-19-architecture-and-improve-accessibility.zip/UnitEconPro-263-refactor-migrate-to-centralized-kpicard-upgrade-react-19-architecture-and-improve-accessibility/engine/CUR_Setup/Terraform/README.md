# AWS Cost and Usage Report (CUR) Setup using Terraform

This repository contains a Terraform configuration to set up **AWS Cost and Usage Reports (CUR)** and deliver them to an S3 bucket in **Parquet** format. The setup also enables Athena integration for querying usage reports.

---

##  Features

- Creates an **S3 bucket** to store CUR data
- Sets up **bucket policy** for AWS Billing service access
- Generates **CUR report definition**:
  - Daily frequency
  - Parquet format
  - Athena integration enabled
  - Includes resources and cost allocation data

---

##  Getting Started

### Prerequisites

- Terraform >= 1.0
- AWS CLI with configured credentials
- S3 bucket name and CUR report name (must be unique in your account)
- An **IAM user or role** with the **least privilege policy** defined in `least_privilege_policy.json`.



### 1. Configure Variables
Update the var.tf file or provide values via a terraform.tfvars file:

bucket_name = "your-unique-s3-bucket"
report_name = "your-cur-report"
region      = "your-region"

### 2. Terraform Commands

Below are the steps to run this Terraform project safely and effectively:

```bash
# Step 1: Initialize the Terraform working directory
terraform init

# Step 2: Format Terraform configuration files consistently
terraform fmt

# Step 3: Validate the Terraform code syntax and configurations
terraform validate

# Step 4: Preview the changes Terraform will apply
terraform plan 

# Step 5: Apply the planned infrastructure changes
terraform apply 
```

### Note: 
AWS may take up to 24 hours to generate the first CUR report.




