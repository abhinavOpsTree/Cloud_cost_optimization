variable "bucket_name" {
  description = "The name of the S3 bucket to store CUR report"
  type        = string
  default     = "tf-cur-bucket-poc978885735"
}

variable "report_name" {
  description = "The name of the CUR report"
  type        = string
  default     = "CUR-Report"
}

variable "region" {
  description = "This is aws region"
  type        = string
  default     = "us-east-1"
}