# Create S3 bucket
resource "aws_s3_bucket" "cur_bucket" {
  bucket        = var.bucket_name
  force_destroy = true

  tags = {
    Name = "cur-bucket"
  }
}

# Bucket policy to allow AWS Billing service to put reports
resource "aws_s3_bucket_policy" "cur_bucket_policy" {
  bucket = aws_s3_bucket.cur_bucket.id
  policy = data.aws_iam_policy_document.cur_bucket_policy.json
}

# Policy document for CUR access
data "aws_iam_policy_document" "cur_bucket_policy" {
  statement {
    sid    = "AWSBillingPolicy"
    effect = "Allow"

    principals {
      type        = "Service"
      identifiers = ["billingreports.amazonaws.com"]
    }

    actions = ["s3:GetBucketAcl", "s3:PutObject"]

    resources = [
      aws_s3_bucket.cur_bucket.arn,
      "${aws_s3_bucket.cur_bucket.arn}/*"
    ]
  }
}

# CUR report definition
resource "aws_cur_report_definition" "cur_report" {
  report_name                = var.report_name
  time_unit                  = "DAILY"
  format                     = "Parquet"
  compression                = "Parquet"
  additional_schema_elements = ["RESOURCES", "SPLIT_COST_ALLOCATION_DATA"]
  s3_bucket                  = aws_s3_bucket.cur_bucket.id
  s3_region                  = var.region
  s3_prefix                  = "billing"
  report_versioning    = "OVERWRITE_REPORT"
  additional_artifacts = ["ATHENA"]

}

