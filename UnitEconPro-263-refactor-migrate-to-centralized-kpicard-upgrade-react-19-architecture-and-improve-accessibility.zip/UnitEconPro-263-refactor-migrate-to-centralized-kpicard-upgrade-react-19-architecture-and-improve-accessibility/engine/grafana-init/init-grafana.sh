#!/bin/sh
set -e

echo "Waiting for Grafana to be ready..."
until curl -s http://grafana:3000/api/health > /dev/null 2>&1; do
  echo "Grafana is not ready yet, waiting..."
  sleep 2
done

echo "Grafana is ready!"
exit 0
