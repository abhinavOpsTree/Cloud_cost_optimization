# Architecture for Cost Visualization

![alt text](image.png)


# Explaination

## Step 1: Data Extraction 

Querying Data: We begin by extracting cost and usage data directly from AWS Athena, which queries the AWS Cost and Usage Report (CUR) stored in S3.

## Step 2: Data Transformation

Mapping and Normalization: Map Athena’s raw columns (including tags) to a clean ClickHouse schema, normalizing dates, types, and costs.

## Step 3: Data Ingestion

ClickHouse Integration: Insert transformed records into ClickHouse service_costs table in bulk, and log the ingestion status with timestamps and errors (if any).

## Step 4: Data Autocorrection

Weekly Partition Refresh: Detect stale weekly partitions (e.g., due to AWS CUR backfill), drop them, and re-ingest them in the correct order for consistency.

## Step 5: Data Visualization

Grafana Dashboard: Connect ClickHouse to Grafana to create interactive dashboards for analyzing cost, usage patterns, and tag-based splits over time.

## Clickhouse Login
```
docker exec -it clickhouse clickhouse-client --user dba --password secretPassword
```

## Show databases

```
curl "http://localhost:8123?user=dba&password=secretPassword" --data "SHOW DATABASES"
```

# Install Clickhouse client
```
pip install clickhouse-connect
```

# Datatypes of columns on  Athena
- line_item_usage_account_id ------> String
- line_item_usage_start_date ------> DateTime (timestamp)
- line_item_usage_end_date ------> DateTime (timestamp)
- line_item_product_code ------> String
- line_item_operation ------> String
- line_item_resource_id ------> String
- line_item_usage_amount ------> Double
- line_item_unblended_cost ------> Double
- line_item_blended_cost ------> Double
- product_product_family ------> String
- product_region ------> String
- product_usagetype ------> String


# To view partitions

```
SELECT
    partition_id,
    partition AS week_start_date,
    count() AS part_count,
    sum(rows) AS total_rows,
    formatReadableSize(sum(bytes_on_disk)) AS size,
    min(min_date) AS first_date_in_partition,
    max(max_date) AS last_date_in_partition
FROM (
    SELECT
        partition_id,
        partition,
        rows,
        bytes_on_disk,
        toDate(min_time) AS min_date,
        toDate(max_time) AS max_date
    FROM system.parts
    WHERE table = 'weekly_metrics'
      AND database = 'cost'
      AND active = 1
)
GROUP BY partition_id, partition
ORDER BY week_start_date;
```

## To view name of partition 

```
SELECT 
    partition, 
    name, 
    active, 
    rows, 
    bytes 
FROM system.parts 
WHERE table = 'service_costs' AND database = 'cost'
ORDER BY partition;

```

# Drop partitions 

```
ALTER TABLE cost.weekly_metrics 
DROP PARTITION '2025-05-11',
DROP PARTITION '2025-05-18'

```

```
SELECT DISTINCT partition
FROM system.parts
WHERE database = 'cost' AND table = 'service_costs'
ORDER BY partition DESC;

```


```
SELECT partition, active 
FROM system.parts 
WHERE database = 'cost' AND table = 'service_costs' 
GROUP BY partition, active;

```

## Daily Ingestion

```
python3 app.py --mode ingest_daily --cloud aws --service all
```

## Autocorrection Task

```
python3 app.py --mode autocorrect --cloud aws

```

## Force autocorrect by accountId

```
python3 app.py --mode autocorrect --account-id 702037529261 --force-autocorrect --service ec2  --cloud aws
```

## Retry Task

```
python3 app.py --mode ingest_daily --retry --cloud aws --service all
```

## Refresh Days (New Feature)

Ingest fresh 24-hour data + refresh historical data for past N days with delete and re-insert.

### Usage

```bash
# Refresh last 3 days for EC2
python3 app.py --mode refresh_days --days 3 --service ec2 --cloud aws

# Refresh last 7 days for all services (default)
python3 app.py --mode refresh_days --days 7 --service all --cloud aws

# Refresh last 14 days for S3
python3 app.py --mode refresh_days --days 14 --service s3 --cloud aws
```

### Behavior

**Example: Running on Jan 29 with `--days 2`**

1. **Fresh Ingestion**: Ingest Jan 28-29 (yesterday's 24 hours)
2. **Refresh Day 1**: Delete + Re-ingest Jan 27-28
3. **Refresh Day 2**: Delete + Re-ingest Jan 26-27

### Parameters

- `--days`: Number of past days to refresh (default: 7)
- `--service`: Service name or "all" for all enabled services
- `--cloud`: Cloud provider (aws/gcp/azure)

### Use Cases

- Fix AWS CUR backfill/corrections for past days
- Refresh data after AWS billing adjustments
- Re-ingest specific date ranges without affecting entire weeks
- Update cost data when AWS applies credits or refunds

```
## Docker execution

```bash
docker run -it --rm my-python-app python app.py --mode ingest_daily --cloud aws --service all

# Run refresh_days in Docker
docker run -it --rm my-python-app python app.py --mode refresh_days --days 3 --service ec2 --cloud aws
```


## Generate docker-secret

```
kubectl create secret docker-registry docker-secret \
  --docker-server=https://index.docker.io/v1/ \
  --docker-username=<username> \
  --docker-password=<password>\
  --docker-email=<email> \
  --namespace <namespace>  --dry-run=client -o yaml > docker-secret.yaml
```

## Describe cronjob logs
```
kubectl describe cronjob daily-ingestion -n uniteconpro

kubectl get events -n uniteconpro --watch
```

# Helm uninstall release
## Repository Setup

### Push to Private GitHub (Windows)
```powershell
git init
git checkout -b unified-ingestion
git add .
git commit -m "Initial commit: UnitEconPro production-ready"

git remote add origin https://github.com/<your-org>/<your-repo>.git
git push -u origin unified-ingestion
```

### Deploy on Ubuntu

#### Prerequisites
```bash
sudo apt update
sudo apt install -y git docker.io docker-compose-plugin python3-venv
sudo usermod -aG docker $USER
newgrp docker
```

#### Clone and Setup
```bash
git clone https://github.com/<your-org>/<your-repo>.git
cd <your-repo>

# Configure environment
cp .env.example .env
nano .env  # Fill in real credentials

# Start services
docker compose up -d

# Verify ClickHouse
docker exec clickhouse clickhouse-client --user dba --password secretPassword -q "SHOW DATABASES"
```

#### Run Application
```bash
python3 -m venv venv
source venv/bin/activate
pip install -r app/requirements.txt

# Test with refresh mode (recommended for production)
python app/app.py --mode refresh_days --cloud aws --service ec2 --days 3
```

## Production Notes
- **MergeTree engine** enabled for DELETE operations (requires Linux)
- `.env` excluded from git - never commit secrets
- `DEVELOPMENT_NOTES.md` has detailed implementation notes

```
helm uninstall uniteconpro --namespace uniteconpro-sandbox

helm list --namespace uniteconpro-sandbox
```