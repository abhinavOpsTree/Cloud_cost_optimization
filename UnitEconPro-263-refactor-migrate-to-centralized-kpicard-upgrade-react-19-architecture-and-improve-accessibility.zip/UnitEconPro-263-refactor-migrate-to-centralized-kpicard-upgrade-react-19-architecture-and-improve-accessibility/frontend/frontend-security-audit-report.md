# Frontend Security & Optimization Audit Report

**Project:** SpendSmart (UnitEconPro Frontend)  
**Date:** 2026-07-21  
**Scope:** Frontend-only analysis (React + Vite + Tailwind)

---

## Table of Contents
1. [Executive Summary](#executive-summary)
2. [Security Vulnerabilities](#security-vulnerabilities)
3. [Performance Optimizations](#performance-optimizations)
4. [Code Quality Issues](#code-quality-issues)
5. [Positive Findings](#positive-findings)

---

## Executive Summary

| Category | Critical | High | Medium | Low |
|----------|----------|------|--------|-----|
| Security | 0 | 2 | 5 | 6 |
| Performance | 0 | 2 | 5 | 3 |
| Code Quality | 0 | 0 | 3 | 2 |

**Key Risks:**
- Missing security headers (CSP, HSTS, X-Frame-Options) in both `index.html` and `nginx.conf`
- Three charting libraries (`chart.js`, `recharts`, `highcharts`) loaded simultaneously -- massive bundle bloat
- Critical React Context memoization bugs in `FiltersProvider`, `ThemeProvider`, and `SettingsProvider` causing unnecessary re-renders across the entire app
- No CSRF protection on API requests
- No Error Boundaries -- a single component crash can white-screen the entire app

---

## Security Vulnerabilities

### HIGH

#### 1. Missing HTTPS & Security Headers in Nginx (`nginx.conf`)
**Location:** `nginx.conf`  
**Risk:** Man-in-the-middle attacks, clickjacking, MIME-sniffing, XSS  
**Details:**
- Only listens on port 80 (HTTP) -- no HTTPS redirect
- No `X-Frame-Options` (vulnerable to clickjacking)
- No `X-Content-Type-Options: nosniff`
- No `Strict-Transport-Security` (HSTS)
- No `Referrer-Policy`
- No `Content-Security-Policy`

**Fix:**
```nginx
server {
    listen 80;
    server_name _;
    return 301 https://$host$request_uri;  # Redirect HTTP to HTTPS
}

server {
    listen 443 ssl http2;
    server_name _;
    root /usr/share/nginx/html;
    index index.html;

    # Security Headers
    add_header X-Frame-Options "SAMEORIGIN" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header X-XSS-Protection "1; mode=block" always;
    add_header Referrer-Policy "strict-origin-when-cross-origin" always;
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
    add_header Content-Security-Policy "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: https:; connect-src 'self' %VITE_API_BASE_URL%;" always;

    location / {
        try_files $uri /index.html;
    }
    location /static/ {
        expires 1y;
        add_header Cache-Control "public";
    }
}
```

#### 2. Missing Content Security Policy in `index.html`
**Location:** `index.html`  
**Risk:** XSS injection via inline scripts, style injection, unauthorized API calls  
**Details:** No `<meta http-equiv="Content-Security-Policy">` tag exists. The app loads an external env-config.js and uses inline styles from Tailwind.

**Fix:** Add a CSP meta tag (or better, serve it via nginx header above).

---

### MEDIUM

#### 3. No CSRF Protection on API Requests
**Location:** `src/APIs/ApiClient.jsx`, `src/Pages/Cloud-Sentry/lib/ApiClient.js`  
**Risk:** Cross-Site Request Forgery -- malicious sites could trigger state-changing API calls if the user has an active session  
**Details:** The `fetch`-based API client never attaches CSRF tokens or uses custom headers that would trigger CORS preflight for simple requests. All POST/PUT/DELETE requests lack CSRF protection.

**Fix:** Add a CSRF token header to all mutating requests, or ensure the backend uses SameSite=Lax/Strict cookies.

#### 4. AWS Secret Access Keys in React State (Potential Leak)
**Location:** `src/Pages/Settings/Onboarding/OnboardAccount.jsx`, `MultiStepModule.jsx`, `StepAWSDetails.jsx`  
**Risk:** Secret keys visible in React DevTools memory, potentially logged to console or error trackers  
**Details:** AWS Secret Access Keys are stored in component state and passed through forms. While not persisted to localStorage, they exist in memory and React DevTools can expose them. Console errors may capture state snapshots.

**Fix:** Consider using a backend-mediated onboarding flow where the frontend never touches the secret key directly. If unavoidable, clear the value from state immediately after submission.

#### 5. No React Error Boundaries
**Location:** App-wide (`src/main.jsx`, `src/App.jsx`)  
**Risk:** Complete UI crash (white screen) from a single component error  
**Details:** Zero Error Boundaries exist. Any unhandled exception in any component tree will unmount the entire React tree.

**Fix:** Add an Error Boundary at the app root and per-route level:
```jsx
// src/components/ErrorBoundary.jsx
class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }
  static getDerivedStateFromError() {
    return { hasError: true };
  }
  componentDidCatch(error, info) {
    // Send to logging service, NOT console in prod
    logErrorToService(error, info);
  }
  render() {
    if (this.state.hasError) {
      return <FallbackUI />;
    }
    return this.props.children;
  }
}
```

#### 6. Chat Messages Rendered Without Sanitization
**Location:** `src/Pages/Cloud-Sentry/subpages/Chatbot.jsx:167`  
**Risk:** XSS if the AI backend returns malicious HTML/JS  
**Details:** Chat messages are rendered via JSX interpolation `{msg.content}`. React escapes by default, BUT the component uses `whitespace-pre-wrap` which preserves formatting. If the backend ever sends HTML responses or if `dangerouslySetInnerHTML` is added later, this becomes an immediate XSS vector. The chat history is also persisted to localStorage without validation.

**Fix:** Sanitize message content before rendering (e.g., with DOMPurify) if HTML rendering is ever needed. For now, plain text is safe but add a comment/warning.

#### 7. Vite Dev Proxy Bypass Can Expose Source Files
**Location:** `vite.config.js:32-37`  
**Risk:** In development, `.js` and `.jsx` files bypass the proxy and are served directly  
**Details:**
```js
bypass: function (req, res, proxyOptions) {
  const pathname = req.url.split('?')[0];
  if (pathname.endsWith('.js') || pathname.endsWith('.jsx')) {
    return req.url;  // Serves source files directly!
  }
}
```
This is only a dev concern but should be documented/restricted.

---

### LOW

#### 8. Environment Variables Exposed Globally
**Location:** `dist/env-config.js`, `config.js`  
**Risk:** Any third-party script can read API endpoints and Keycloak config  
**Details:** `window._env_` exposes `VITE_API_BASE_URL`, `VITE_KEYCLOAK_URL`, `VITE_KEYCLOAK_REALM`, and `VITE_KEYCLOAK_CLIENT_ID`. This is an SPA necessity but should be acknowledged.

#### 9. Console Statements in Production Code
**Location:** ~35+ files  
**Risk:** Information leakage via browser console  
**Details:** Extensive use of `console.log`, `console.error`, `console.warn` across the codebase. In production, these can leak internal state, API errors, and user data.

**Fix:** Configure Vite to strip console statements in production builds:
```js
// vite.config.js
build: {
  minify: 'terser',
  terserOptions: {
    compress: {
      drop_console: true,
      drop_debugger: true,
    },
  },
}
```

#### 10. Keycloak Token Accessible via Context
**Location:** `src/providers/AuthContext.js`, `src/providers/AuthProvider.jsx`  
**Risk:** Any component can access the full Keycloak instance and parsed token  
**Details:** The entire `keycloak` object is exposed through context. While tokens are stored in memory (not localStorage -- good!), any malicious or compromised component can read `keycloak.token` and `keycloak.tokenParsed`.

**Fix:** Only expose what components need -- `authenticated`, `login`, `logout`, `userEmail`, `userName` -- not the entire keycloak instance.

#### 11. localStorage Used for Sensitive-ish Data
**Location:** `Chatbot.jsx`, `Dashboard.jsx` (Cloud Sentry)  
**Risk:** Chat session IDs and message history persisted unencrypted to localStorage  
**Details:** `cs_chat_session`, `cs_chat_messages`, `cloudSentryTimeFilter` stored in localStorage without encryption or expiration. On shared computers, this data persists across sessions.

#### 12. No Subresource Integrity (SRI)
**Location:** `index.html`  
**Risk:** If CDN or server is compromised, malicious scripts could be injected  
**Details:** The `<script src="/env-config.js">` tag has no `integrity` attribute. While this is self-hosted, SRI is still a defense-in-depth measure.

#### 13. `window.__CLOUD_SENTRY_USER_EMAIL__` Global Pollution
**Location:** `src/Pages/Cloud-Sentry/subpages/SkillContribution.jsx:208`  
**Risk:** Global window pollution with user identity data  
**Details:** Code explicitly sets a global window variable with user email. This is marked as a TODO in `ApiClient.js` but is still active.

---

## Performance Optimizations

### HIGH

#### 1. Three Charting Libraries Bundled Simultaneously
**Location:** `package.json`, `src/common/Charts/`  
**Impact:** Massive bundle size increase (~500-800KB+ gzipped overhead)  
**Details:**
- `chart.js` (^4.5.1) -- used in Barchart, Linechart, Piechart
- `recharts` (^3.8.0) -- used in CartesianChart, AreaChart  
- `highcharts` (^12.5.0) + `highcharts-react-official` -- used in various charts

All three are loaded into the app. This is the single biggest bundle bloat issue.

**Fix:** Standardize on ONE charting library. Recommendation:
- If you need simple charts + MUI integration: keep `recharts` (works well with React)
- If you need complex interactive charts: keep `highcharts` only
- Remove the other two and migrate all chart components

#### 2. Critical Context Memoization Bugs (3 Providers)
**Location:** `src/providers/Filtercontext.jsx:30`, `src/lib/ThemeProvider.jsx:28`, `src/providers/SettingsProvider.jsx:45`  
**Impact:** Entire app re-renders on every state change in these providers  
**Details:** All three providers create a `contextValue` with `useMemo` but then pass a **brand new inline object** to the context provider instead of the memoized value. This completely defeats the optimization.

Example from `FiltersProvider.jsx`:
```jsx
// BUG: contextValue is computed with useMemo...
const contextValue = useMemo(() => ({ filters, setFilters }), [filters])
// ...but a NEW object is passed to the provider!
<FiltersContext value={{ filters, setFilters }}>  {/* BUG! */}
```

Same bug exists in `ThemeProvider.jsx` and `SettingsProvider.jsx`.

**Fix:** Use the memoized value:
```jsx
<FiltersContext value={contextValue}>
```

---

### MEDIUM

#### 3. Table Component `columns` / `data` Array Recreation
**Location:** `src/common/Table.jsx`  
**Impact:** Table re-renders unnecessarily even with `React.memo`  
**Details:** `Table` is wrapped in `React.memo`, but parent components typically recreate the `columns` array and `data` array on every render, causing `Table` to re-render constantly.

**Fix:** Memoize columns in parent components:
```jsx
const columns = useMemo(() => [
  { key: 'name', label: 'Name' },
  // ...
], []);
```

#### 4. Missing List Virtualization
**Location:** `src/common/Table.jsx`, various list views  
**Impact:** DOM thrashing with large datasets (1000+ rows)  
**Details:** The Table component renders ALL rows into the DOM. For large AWS resource lists (EC2 instances, S3 buckets, etc.), this causes severe performance degradation.

**Fix:** Implement virtualization using `react-window` or `@tanstack/react-virtual` for tables with potentially large datasets.

#### 5. `alert()` Blocks Main Thread During Analysis
**Location:** `src/Pages/Cloud-Sentry/subpages/Dashboard.jsx:99-100`  
**Impact:** UI freezes, poor user experience  
**Details:**
```js
alert('Analysis completed successfully!');
window.location.reload();
```
`alert()` blocks the entire main thread. On slower devices, this is jarring.

**Fix:** Replace with a non-blocking toast notification from `react-toastify` (already installed!):
```js
toast.success('Analysis completed successfully!');
// Use React Router navigate or state update instead of reload
```

#### 6. MUI + Tailwind CSS Style Duplication
**Location:** App-wide  
**Impact:** Two complete CSS frameworks loaded, CSS bloat  
**Details:** The app uses both `@mui/material` AND `tailwindcss`. MUI comes with its own styling engine (Emotion). This results in duplicate utility classes, conflicting resets, and larger CSS bundles.

**Fix:** Gradually migrate fully to Tailwind (already the majority) and remove MUI, or use MUI's Tailwind-compatible configuration. The MUI chunk alone is 376KB.

#### 7. `useAccessibleAccounts` Runs on Every Render Trigger
**Location:** `src/hooks/useAccessibleAccounts.jsx`  
**Impact:** Potential unnecessary re-fetches  
**Details:** Query key includes `email` which comes from `keycloak?.tokenParsed?.email`. If keycloak object reference changes (even with same email), the query re-fetches.

**Fix:** Use `email` string directly, not `keycloak.tokenParsed`:
```jsx
const email = useMemo(() => keycloak?.tokenParsed?.email || "", [keycloak?.tokenParsed?.email]);
```

---

### LOW

#### 8. Dashboard `console.log` in Render Path
**Location:** `src/Pages/Dashboard/index.jsx:24`  
**Impact:** Minor render slowdown, dev-only concern  
**Details:** `console.log(budgetForecast)` runs on every render of the Dashboard page.

**Fix:** Remove the debug log.

#### 9. Image Loaded Without Dimensions or Lazy Loading
**Location:** `src/sidebar/Sidebar.jsx:28`  
**Impact:** Layout shift (CLS), unnecessary initial load  
**Details:** `<img src="./bg_svg.svg" alt="logo" className="size-4 shrink-0" />` has no `width`/`height` attributes and no `loading="lazy"`.

**Fix:** Add explicit dimensions and consider lazy loading below-the-fold images.

#### 10. `framer-motion` Used for Simple Sidebar Animation
**Location:** `src/sidebar/Sidebar.jsx`  
**Impact:** 136KB bundle for simple width transitions  
**Details:** `framer-motion` is 136KB in the bundle. The sidebar animation is a simple width transition that could be done with CSS transitions.

**Fix:** Replace `motion.aside` and `AnimatePresence` with CSS `transition: width 0.3s ease` for a significant bundle reduction.

---

## Code Quality Issues

### MEDIUM

#### 1. Missing Dependency in `useEffect` (Navbar)
**Location:** `src/Navbar/Navbar.jsx:36-47`  
**Details:** The `useEffect` that syncs accounts uses `filters.account` inside but does not list it in dependencies. With React 19's stricter linting, this could cause stale closure bugs.

#### 2. `JSON.parse` Without Try/Catch in Cloud Sentry Chatbot
**Location:** `src/Pages/Cloud-Sentry/subpages/Chatbot.jsx:24`  
**Details:**
```js
const history = JSON.parse(localStorage.getItem('cs_chat_messages') || '[]');
```
If localStorage data is corrupted, this will crash the component.

**Fix:** Wrap in try/catch (already done in SettingsProvider -- follow that pattern).

#### 3. Unused Variable in `FiltersProvider`
**Location:** `src/providers/Filtercontext.jsx:25`  
**Details:** `contextValue` is computed but never used because of the inline object bug mentioned above.

---

### LOW

#### 4. Inconsistent API Client Patterns
**Location:** `src/APIs/ApiClient.jsx` vs `src/Pages/Cloud-Sentry/lib/ApiClient.js`  
**Details:** Two completely different `apiRequest` implementations exist. The Cloud Sentry one is a positional-argument function, the main one is an options object. This inconsistency increases cognitive load and maintenance burden.

#### 5. `radix-ui` Package Imported Incorrectly
**Location:** `package.json:30`  
**Details:** `radix-ui` is installed as a dependency, but Radix primitives should be installed individually (`@radix-ui/react-dialog`, etc.). The umbrella package `radix-ui` may not tree-shake properly.

---

## Positive Findings

| Finding | Location | Benefit |
|---------|----------|---------|
| Route-based code splitting | `src/routes/*.routes.jsx` | Lazy-loaded routes reduce initial bundle |
| Manual chunk splitting | `vite.config.js:11-16` | Good separation of vendor/framework code |
| React.memo on Table | `src/common/Table.jsx:8` | Prevents unnecessary re-renders (when parents are fixed) |
| useMemo in hooks | `src/hooks/useDashboard.jsx` | Good query memoization with TanStack Query |
| Keycloak PKCE | `src/providers/AuthProvider.jsx:19` | `pkceMethod: "S256"` is the secure modern flow |
| Token refresh handling | `src/providers/AuthProvider.jsx:29-34` | Proper `onTokenExpired` callback |
| No source maps in dist | `dist/` | Production builds don't leak source code |
| TanStack Query for caching | `src/providers/QueryProvider.jsx` | Proper data fetching with stale-while-revalidate |
| useRef for mount guards | `src/providers/AuthProvider.jsx:7` | Prevents double `keycloak.init()` in StrictMode |
| Functional setState patterns | `src/lib/ThemeProvider.jsx:16` | Stable callback identities for performance |

---

## Prioritized Action Items

### Immediate (This Sprint)
1. **Fix the 3 Context memoization bugs** -- one-line fixes with massive performance gains
2. **Remove duplicate charting libraries** -- decide on one library, remove the other two from package.json
3. **Add Error Boundaries** -- wrap the app root and major route sections
4. **Strip console statements from production builds** -- add terser config to vite.config.js
5. **Fix Cloud Sentry Dashboard `alert()` calls** -- use `react-toastify` instead

### Short Term (Next 2 Sprints)
6. Add security headers to `nginx.conf` (CSP, HSTS, X-Frame-Options)
7. Add CSRF token handling to API client
8. Implement table virtualization for large datasets
9. Sanitize chatbot message rendering with DOMPurify
10. Replace `framer-motion` sidebar with CSS transitions

### Medium Term (Next Quarter)
11. Migrate fully from MUI to Tailwind (remove 376KB MUI chunk)
12. Refactor AWS secret key handling to avoid frontend exposure
13. Add SRI hashes to script tags
14. Encrypt sensitive localStorage data
15. Consolidate the two `apiRequest` implementations into one

---

*Report generated by automated frontend audit. Backend was not analyzed per request.*
