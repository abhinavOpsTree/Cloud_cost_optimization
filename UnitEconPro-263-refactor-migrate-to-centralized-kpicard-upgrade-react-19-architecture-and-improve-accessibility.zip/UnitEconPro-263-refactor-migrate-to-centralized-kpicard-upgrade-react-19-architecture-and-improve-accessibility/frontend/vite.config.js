import { defineConfig, loadEnv } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from "@tailwindcss/vite"

// https://vite.dev/config/
export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '');
  const rawTarget = env.VITE_API_TARGET || env.API_TARGET || env.VITE_API_BASE_URL || process.env.VITE_API_TARGET || process.env.API_TARGET || process.env.VITE_API_BASE_URL;
  const apiTarget = (rawTarget && rawTarget.startsWith('http')) ? rawTarget : 'http://localhost:8000';
  const proxyTimeout = parseInt(env.VITE_PROXY_TIMEOUT || process.env.VITE_PROXY_TIMEOUT || '600000', 10);

  return {
    plugins: [react(), tailwindcss()],
    build: {
      rollupOptions: {
        output: {
          manualChunks: {
            vendor: ['react', 'react-dom', 'react-router-dom'],
            mui: ['@mui/material', '@mui/x-date-pickers', '@emotion/react', '@emotion/styled'],
            highcharts: ['highcharts', 'highcharts-react-official'],
            recharts: ['recharts'],
            ui: ['framer-motion', 'lucide-react']
          }
        }
      },
      chunkSizeWarningLimit: 1000 // Optionally bump the warning limit just in case
    },
    server: {
      port: 5173,
      fs: {
        allow: ['..']
      },
      proxy: {
        '/api': {
          target: apiTarget,
          changeOrigin: true,
          timeout: proxyTimeout,
          proxyTimeout: proxyTimeout,
          bypass: function (req) {
            const pathname = req.url.split('?')[0];
            if (pathname.endsWith('.js') || pathname.endsWith('.jsx')) {
              return req.url;
            }
          },
          configure: (proxy, _options) => {
            proxy.on('error', (err, req, res) => {
              console.error(`[Vite Proxy Error] ${req.method || 'WS'} ${req.url || ''} -> ${apiTarget}:`, err.message);
              if (res && typeof res.writeHead === 'function') {
                if (!res.headersSent) {
                  const status = (err.code === 'ETIMEDOUT' || err.code === 'ESOCKETTIMEDOUT' || err.code === 'ECONNRESET') ? 504 : 502;
                  res.writeHead(status, {
                    'Content-Type': 'application/json',
                  });
                }
                res.end(JSON.stringify({
                  error: 'Proxy Error',
                  message: err.message || 'Failed to proxy request to target server',
                  code: err.code || 'PROXY_ERROR',
                  target: apiTarget
                }));
              } else if (res && typeof res.end === 'function') {
                res.end();
              }
            });
          }
        }
      }
    }
  };
})
