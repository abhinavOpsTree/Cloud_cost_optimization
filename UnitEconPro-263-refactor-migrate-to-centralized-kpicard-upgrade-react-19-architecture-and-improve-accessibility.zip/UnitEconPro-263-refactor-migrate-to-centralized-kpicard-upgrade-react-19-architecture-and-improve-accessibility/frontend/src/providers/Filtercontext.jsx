import { useState, useEffect, useMemo } from 'react'
import { FiltersContext, getDefaultStartDate, getDefaultEndDate } from '../context/FiltersContext'

export const FiltersProvider = ({ children }) => {
    const [filters, setFilters] = useState({
        start_date: getDefaultStartDate(),
        end_date: getDefaultEndDate(),
        compare_date_a: getDefaultStartDate(),
        compare_date_b: getDefaultEndDate(),
        account: localStorage.getItem('selected_account') || '',
    })

    useEffect(() => {
        if (filters.account) {
            localStorage.setItem('selected_account', filters.account);
        } else {
            localStorage.removeItem('selected_account');
        }
    }, [filters.account]);

    // Perf: without useMemo this object literal is recreated every render, forcing
    // every useFilters/useContext(FiltersContext) consumer to re-render even when
    // filters didn't change. setFilters needs no useCallback — React guarantees
    // state setters have a stable identity across renders.
    const contextValue = useMemo(() => ({ filters, setFilters }), [filters])

    return (
        // React 19 migration: context objects are directly renderable as providers.
        // <FiltersContext value={...}> replaces the legacy <FiltersContext.Provider value={...}>,
        <FiltersContext value={contextValue}>
            {children}
        </FiltersContext>
    )
}
