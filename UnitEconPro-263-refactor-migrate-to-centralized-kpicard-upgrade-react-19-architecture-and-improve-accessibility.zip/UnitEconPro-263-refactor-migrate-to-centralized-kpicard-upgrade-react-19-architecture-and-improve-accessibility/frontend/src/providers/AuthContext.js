import Keycloak from 'keycloak-js';
import { createContext, useContext } from 'react';

const getEnv = (key) => {
    if (typeof window !== "undefined" && window._env_ && window._env_[key]) {
      if (window._env_[key].startsWith("%") && window._env_[key].endsWith("%")) {
        return import.meta.env[key];
      }
      return window._env_[key];
    }
    return import.meta.env[key];
  };

export const AuthContext = createContext({
    keycloak: null,
    authenticated: false,
    login: () => { },
    logout: () => { },
    isLoading: true,
});

const VITE_KEYCLOAK_URL = getEnv("VITE_KEYCLOAK_URL");
const VITE_KEYCLOAK_REALM = getEnv("VITE_KEYCLOAK_REALM");
const VITE_KEYCLOAK_CLIENT_ID = getEnv("VITE_KEYCLOAK_CLIENT_ID");

export const keycloakConfig = {
    url: VITE_KEYCLOAK_URL || '',
    realm: VITE_KEYCLOAK_REALM || '',
    clientId: VITE_KEYCLOAK_CLIENT_ID || '',
};

export const keycloak = new Keycloak(keycloakConfig);

export const useAuth = () => useContext(AuthContext);
