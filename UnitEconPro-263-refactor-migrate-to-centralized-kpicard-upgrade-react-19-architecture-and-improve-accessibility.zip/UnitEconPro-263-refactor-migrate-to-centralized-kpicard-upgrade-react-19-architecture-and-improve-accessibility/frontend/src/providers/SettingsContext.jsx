import { createContext, useContext } from "react";
import { navigationItems } from "../sidebar/sidebarConfig";


export const defaultVisibility = navigationItems.reduce((acc, item) => {
    acc[item.name] = item.defaultVisible ?? true;
    return acc;
}, {});

export const SettingsContext = createContext({
    visibleNavItems: defaultVisibility,
    toggleNavItem: () => { },
});

export const useSettings = () => useContext(SettingsContext);
