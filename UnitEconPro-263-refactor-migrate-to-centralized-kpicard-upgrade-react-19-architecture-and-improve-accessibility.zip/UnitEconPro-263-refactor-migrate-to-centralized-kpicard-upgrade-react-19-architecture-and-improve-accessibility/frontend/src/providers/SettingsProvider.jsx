import { useCallback, useEffect, useMemo, useState } from 'react';
import { SettingsContext, defaultVisibility } from './SettingsContext';

export const SettingsProvider = ({ children }) => {
    const [visibleNavItems, setVisibleNavItems] = useState(() => {
        const initial = { ...defaultVisibility };
        try {
            const saved = localStorage.getItem('spendSmart_sidebar_v1');
            if (saved) {
                const parsed = JSON.parse(saved);
                // Merge carefully: only reuse saved values for keys that still exist in current navigationItems
                Object.keys(parsed).forEach(key => {
                    if (key in initial) {
                        initial[key] = parsed[key];
                    }
                });
            }
        } catch (e) {
            console.error("Failed to parse sidebar settings", e);
        }
        return initial;
    });

    useEffect(() => {
        localStorage.setItem('spendSmart_sidebar_v1', JSON.stringify(visibleNavItems));
    }, [visibleNavItems]);

    // Perf: stable identity — uses the functional setState form, so it never
    // needs to close over current state and can safely have empty deps.
    const toggleNavItem = useCallback((name) => {
        setVisibleNavItems(prev => ({ ...prev, [name]: !prev[name] }));
    }, []);

    // Perf: without useMemo this object literal is recreated every render, forcing
    // every useContext(SettingsContext) consumer (sidebar, settings page) to
    // re-render even when visibility didn't change.
    const contextValue = useMemo(
        () => ({ visibleNavItems, toggleNavItem }),
        [visibleNavItems, toggleNavItem]
    );

    return (
        // React 19 migration: context objects are directly renderable as providers.
        // <SettingsContext value={...}> replaces the legacy <SettingsContext.Provider value={...}>,
        <SettingsContext value={contextValue}>
            {children}
        </SettingsContext>
    );
};
