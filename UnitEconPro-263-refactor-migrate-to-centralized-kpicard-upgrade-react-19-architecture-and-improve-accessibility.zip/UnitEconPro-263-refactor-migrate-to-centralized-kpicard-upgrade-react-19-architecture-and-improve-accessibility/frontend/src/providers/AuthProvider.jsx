import { useCallback, useEffect, useMemo, useState, use } from 'react';
import { AuthContext, keycloak, keycloakConfig } from './AuthContext';
import { toast } from 'react-toastify';

let initPromise = null;
const initKeycloak = () => {
    if (!initPromise) {
        if (!keycloakConfig.url || !keycloakConfig.realm || !keycloakConfig.clientId) {
            toast.error("Keycloak configuration is missing! Please set env variables.");
            initPromise = Promise.resolve(false);
        } else {
            initPromise = keycloak.init({ onLoad: 'check-sso', pkceMethod: "S256" })
                .catch((err) => {
                    toast.error("Authentication Failed");
                    return false;
                });
        }
    }
    return initPromise;
};

export const AuthProvider = ({ children }) => {
    // React 19: suspends rendering until Keycloak initialization resolves.
    const initialAuth = use(initKeycloak());
    const [authenticated, setAuthenticated] = useState(initialAuth);

    useEffect(() => {
        keycloak.onTokenExpired = () => {
            keycloak.updateToken(60).catch(() => {
                toast.error('Failed to refresh token');
                setAuthenticated(false);
            });
        };
    }, []);

    // Perf: stable function identities so the memoized context value below only
    // changes when auth state actually changes (keycloak is a module-level singleton).
    const login = useCallback(() => {
        keycloak.login();
    }, []);

    const logout = useCallback(() => {
        keycloak.logout();
    }, []);

    // Perf: without useMemo this object literal is recreated every render, making
    // every useContext(AuthContext) consumer re-render even when nothing changed.
    const contextValue = useMemo(
        () => ({ keycloak, authenticated, login, logout }),
        [authenticated, login, logout]
    );

    return (
        // React 19 migration: context objects are directly renderable as providers.
        // <AuthContext value={...}> replaces the legacy <AuthContext.Provider value={...}>.
        // The value MUST be the memoized contextValue — an inline object literal here
        // would recreate it every render and defeat the useMemo above.
        <AuthContext value={contextValue}>
            {children}
        </AuthContext>
    );
};
