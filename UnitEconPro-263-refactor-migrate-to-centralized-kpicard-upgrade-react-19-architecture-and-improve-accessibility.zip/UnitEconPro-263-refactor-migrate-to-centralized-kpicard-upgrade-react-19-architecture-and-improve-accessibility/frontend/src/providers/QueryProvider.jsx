import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { toast } from "react-toastify";

const queryClient = new QueryClient({
    defaultOptions: {
        queries: {
            staleTime: 5 * 60 * 1000, // 5 minutes
            refetchInterval: 5 * 60 * 1000, // 5 minutes
            refetchOnWindowFocus: false,
            retry: 1,
        },
    },
});

queryClient.getQueryCache().subscribe((event) => {
    if (
        event.type === "updated" &&
        event.action?.type === "error" &&
        event.query.state.fetchFailureCount >= (event.query.options.retry ?? 1)
    ) {
        const err = event.query.state.error;
        toast.error(err?.message ?? "Something went wrong. Please try again.");
    }
});

export const QueryProvider = ({ children }) => (
    <QueryClientProvider client={queryClient}>
        {children}
    </QueryClientProvider>
);
