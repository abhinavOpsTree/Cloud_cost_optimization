const ensureProtocol = (url) => {
  if (!url) return url;
  if (!url.startsWith("http://") && !url.startsWith("https://")) {
    return `${window.location.protocol}//${url}`;
  }
  return url;
};

const getViteEnv = (key) => {
  switch (key) {
    case 'VITE_API_BASE_URL': return import.meta.env.VITE_API_BASE_URL;
    case 'VITE_KEYCLOAK_URL': return import.meta.env.VITE_KEYCLOAK_URL;
    case 'VITE_KEYCLOAK_REALM': return import.meta.env.VITE_KEYCLOAK_REALM;
    case 'VITE_KEYCLOAK_CLIENT_ID': return import.meta.env.VITE_KEYCLOAK_CLIENT_ID;
    case 'VITE_CLOUD_SENTRY_API_BASE_URL': return import.meta.env.VITE_CLOUD_SENTRY_API_BASE_URL;
    default: return undefined;
  }
};

export const getEnv = (key) => {
  console.log(key)
  let val;
  if (typeof window !== "undefined" && window._env_ && typeof window._env_[key] !== "undefined") {
    const rawVal = window._env_[key];
    if (typeof rawVal === "string" && rawVal.startsWith("%") && rawVal.endsWith("%")) {
      val = getViteEnv(key);
    } else {
      val = rawVal;
    }
  } else {
    val = getViteEnv(key);
  }

  const isUrlKey = key === "VITE_API_BASE_URL" || key === "VITE_CLOUD_SENTRY_API_BASE_URL" || key === "VITE_KEYCLOAK_URL";

  if (!val) {
    if (isUrlKey) {
      console.error(`[env] ${key} is not set — requests will fall back to a relative URL and hit the wrong host`);
    } else {
      console.error(`[env] ${key} is not set`);
    }
  } else if (isUrlKey) {
    val = ensureProtocol(val);
  }

  return val;
};

const rawBaseUrl = getEnv("VITE_API_BASE_URL");
export const API_BASE_URL = ensureProtocol(rawBaseUrl) || "";


export const API_ENDPOINTS = {

  // analytics
  analyticsAnnotations: `/api/v1/analytics/annotations`,
  getAnnotations: (account_name, service, date) => `/api/v1/analytics/annotations?account_name=${account_name}&service=${service}&date=${date}`,
  getAnnotationDates: (account_name, service, start_date, end_date) => `/api/v1/analytics/annotation-dates?account_name=${account_name}&service=${service}&start_date=${start_date}&end_date=${end_date}`,
  deleteAnnotation: (annotation_id) => `/api/v1/analytics/annotations/${annotation_id}`,
  updateAnnotation: (annotation_id) => `/api/v1/analytics/annotations/${annotation_id}`,

  // comparsion - summary
  comparsionSummary: `/api/v1/comparison/summary`,
  comparsionDetails: `/api/v1/comparison/detail`,
  comparsiondates: `/api/v1/comparison/dates?account=All`,

  // dashboard
  dashboardSummary: `/api/v1/dashboard/summary`,
  dashboardTrend: `/api/v1/dashboard/trend`,
  dashboardBreakdownService: `/api/v1/dashboard/breakdown/service`,
  dashboardBreakdownAccount: `/api/v1/dashboard/breakdown/account`,
  dashboardComparison: `/api/v1/dashboard/comparison`,
  dashboardForecast: `/api/v1/dashboard/forecast`,

  //EC2
  computeEC2Summary: `/api/v1/compute/ec2/summary`,
  computeEC2Instances: `/api/v1/compute/ec2/instances`,
  computeEC2Amis: `/api/v1/compute/ec2/amis`,
  computeEC2Lifecycle: (account, instance_id) => `/api/v1/compute/ec2/lifecycle?account=${account}&instance_id=${instance_id}&include_gaps=true&lookback_days=90&limit=100`,
  computeEC2Metadata: (instance_id) => `/api/v1/compute/ec2/instances/${instance_id}/metadata`,

  //EKS
  computeEKSSummary: `/api/v1/compute/eks/summary`,
  computeEKSClusters: `/api/v1/compute/eks/clusters`,
  computeEKSMetadata: (cluster_name) => `/api/v1/compute/eks/clusters/${cluster_name}/metadata`,

  //ECR
  computeECRSummary: `/api/v1/compute/ecr/summary`,
  computeECRRepositories: `/api/v1/compute/ecr/repositories`,
  computeECRMetadata: (repository) => `/api/v1/compute/ecr/repositories/${repository}/metadata`,


  //ECS
  computeECSSummary: `/api/v1/compute/ecs/summary`,
  computeECSCluster: `/api/v1/compute/ecs/clusters`,
  computeECSMetadata: (cluster_name) => `/api/v1/compute/ecs/clusters/${cluster_name}/metadata`,

  //S3
  storageS3Summary: `/api/v1/storage/s3/summary`,
  storageS3Buckets: `/api/v1/storage/s3/buckets`,
  storageS3Metadata: (bucket_name) => `/api/v1/storage/s3/buckets/${bucket_name}/metadata`,

  //RDS
  databaseRDSSummary: `/api/v1/databases/rds/summary`,
  databaseRDSInstances: `/api/v1/databases/rds/instances`,
  databaseRDSMetadata: (instance_id) => `/api/v1/databases/rds/instances/${instance_id}/metadata`,

  //ELB
  networkingELBSummary: `/api/v1/networking/elb/summary`,
  networkingELBLoadBalancers: `/api/v1/networking/elb/lbs`,
  networkingELBMetadata: (lb_arn) => `/api/v1/networking/elb/lbs/${lb_arn}/metadata`,

  //Monitoring
  monitoringCloudWatchSummary: `/api/v1/monitoring/cloudwatch/summary`,
  monitoringCloudWatchEKSClusters: `/api/v1/monitoring/cloudwatch/eks-clusters`,
  monitoringCloudWatchLogGroups: `/api/v1/monitoring/cloudwatch/log-groups`,

  //VPC
  networkingVPCSummary: `/api/v1/networking/vpc/summary`,
  networkingVPCBreakdownPublicIP: `/api/v1/networking/vpc/breakdown/public-ip`,
  networkingVPCResources: `/api/v1/networking/vpc/vpcs`,
  networkingVPCMetadata: (vpc_id) => `/api/v1/networking/vpc/${vpc_id}/metadata`,

  // Data Transfer
  dataTransferSummary: `/api/v1/networking/datatransfer/summary`,
  dataTransferResources: `/api/v1/networking/datatransfer/resources`,

  //EBS
  storageEBSSummary: `/api/v1/storage/ebs/summary`,
  storageEBSVolumes: `/api/v1/storage/ebs/volumes`,
  storageEBSSnapshots: `/api/v1/storage/ebs/snapshots`,
  storageEBSMetadata: (volume_id) => `/api/v1/storage/ebs/volumes/${volume_id}/metadata`,

  // unified
  unifiedtrend: (service, start_date, end_date, account) => `/api/v1/analytics/trend?service=${service}&start_date=${start_date}&end_date=${end_date}&account=${account}`,
  unifiedbreakdown: (service, start_date, end_date, dimension, account) => `/api/v1/analytics/breakdown?service=${service}&dimension=${dimension}&start_date=${start_date}&end_date=${end_date}&account=${account}`,
  analyticsTagBreakdown: (dimension, service, limit, skip, start_date, end_date, account) => `/api/v1/analytics/tag-breakdown?dimension=${dimension}&service=${service}&limit=${limit}&skip=${skip}&start_date=${start_date}&end_date=${end_date}&account=${account}`,
  analyticsFinancials: (service, account) => `/api/v1/analytics/financials?service=${service}&account=${account}`,

  // budget
  createBudget: `/api/v1/budget`,
  // getForecastbudget: (account_name) => `/api/v1/budget/${encodeURIComponent(account_name)}/forecast`,
  getBudgetStatus: (account_name) => `/api/v1/budget/${encodeURIComponent(account_name)}/list`,
  deleteBudget: (account_name) => `/api/v1/budget/${encodeURIComponent(account_name)}`,


  // suggestions 
  getlistsuggestions: `/api/v1/suggestions`,
  postcreatesuggestions: `/api/v1/suggestions`,
  updatesuggestions: (suggestion_id) => `/api/v1/suggestions/${suggestion_id}`,
  deletesuggestionid: (suggestion_id) => `/api/v1/suggestions/${suggestion_id}`,


  //accounts
  listaccounts: (email) => email ? `/api/v1/accounts/?email=${encodeURIComponent(email)}` : `/api/v1/accounts/`,
  createaccount: `/api/v1/accounts/`,
  deleteaccount: (account_id) => `/api/v1/accounts/${account_id}`,
  validateaccount: (account_id) => `/api/v1/accounts/${account_id}/validate`,

  //permissions
  getPermissions: (account_id) => `/api/v1/permissions/${account_id}`,
  upsertPermission: `/api/v1/permissions/`,

  // System Health
  systemHealth: `/api/v1/healthz`,
  systemReady: `/api/v1/readyz`,

  // Reporting
  reportSummary: (account, scope, period, persona) => `/api/v1/report/summary?account=${encodeURIComponent(account)}&scope=${encodeURIComponent(scope)}&period=${encodeURIComponent(period)}&persona=${encodeURIComponent(persona)}`,
  reportTrend: (account, scope, period, persona, lookback) => `/api/v1/report/trend?lookback=${lookback}&account=${encodeURIComponent(account)}&scope=${encodeURIComponent(scope)}&period=${encodeURIComponent(period)}&persona=${encodeURIComponent(persona)}`,
};
