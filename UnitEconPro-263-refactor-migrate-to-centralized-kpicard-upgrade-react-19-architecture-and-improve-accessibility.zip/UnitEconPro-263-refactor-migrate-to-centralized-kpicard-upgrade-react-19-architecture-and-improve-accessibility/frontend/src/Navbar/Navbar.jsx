import { ChevronRight } from "lucide-react";
import { Fragment, useMemo, useEffect, useState } from "react";
import { Link, useMatches, useLocation } from "react-router-dom";
import AccountFilter from "../common/AccountFilter";
import Datefilter from "../common/Datefilter";
import dayjs from "dayjs";
import { cn } from "../lib/cn";
import { useFilters } from "../hooks/useFilters";
import { useAccessibleAccounts } from "../hooks/useAccessibleAccounts";
import { getDefaultStartDate, getDefaultEndDate } from "../context/FiltersContext";

const Navbar = () => {
    const { filters, setFilters } = useFilters();
    const matches = useMatches();
    const location = useLocation();

    const isDateFilterDisabled = location.pathname.includes('cost-comparison') || location.pathname.includes('reporting');

    const [selectedAccount, setSelectedAccount] = useState();
    const { data: accountsData } = useAccessibleAccounts();
    const accounts = useMemo(
        () => (Array.isArray(accountsData)
            ? accountsData.map(acc => ({ label: acc.account_name, value: acc.account_name }))
            : []),
        [accountsData]
    );

    const [selectedDateRange, setSelectedDateRange] = useState({
        startDate: getDefaultStartDate(),
        endDate: getDefaultEndDate()
    });

    // Sync selection with the user's accessible accounts:
    // - none → clear selection and the persisted account so no stale data is fetched
    // - stale/none selected → default to the persisted account if still accessible, else the first
    useEffect(() => {
        if (!accountsData) return;
        if (accounts.length === 0) {
            setSelectedAccount(null);
            setFilters(prev => (prev.account ? { ...prev, account: "" } : prev));
            return;
        }
        setSelectedAccount(prev => {
            if (prev && accounts.some(acc => acc.value === prev.value)) return prev;
            return accounts.find(acc => acc.value === filters.account) || accounts[0];
        });
    }, [accountsData, accounts]);


    useEffect(() => {
        if (!selectedAccount?.value) return;

        setFilters(prev => ({
            ...prev,
            start_date: selectedDateRange.startDate,
            end_date: selectedDateRange.endDate,
            account: selectedAccount.value,
        }));
    }, [selectedAccount, selectedDateRange, setFilters]);

    const handleChangeAccount = (accounts) => {
        setSelectedAccount(accounts);
    }
    const handleDateChange = (range) => {
        setSelectedDateRange(range);
    };


    const handleResetDate = () => {
        setSelectedDateRange({
            startDate: getDefaultStartDate(),
            endDate: getDefaultEndDate(),
        });
    };


    const getBreadcrumbs = () => {
        return matches
            .filter((match) => Boolean(match.handle && match.handle.crumb))
            .map((match) => ({
                label: match.handle.crumb(match.data),
                path: match.pathname,
            }));
    };

    const breadcrumbs = getBreadcrumbs();

    return (
        <nav className="flex items-center justify-between px-6 sticky top-0 z-[9999] py-1.5">
            <div className="flex items-center gap-4">
                <div className="flex items-center text-sm font-medium">
                    <Link
                        to="/dashboard"
                        className="text-neutral-400 hover:text-neutral-900 transition-colors"
                    >
                        SpendSmart
                    </Link>
                    {breadcrumbs.map((crumb, index) => (
                        <Fragment key={crumb.path}>
                            <ChevronRight size={14} className="mx-2 text-neutral-300" />
                            <Link
                                to={crumb.path}
                                className={cn(
                                    "transition-colors",
                                    index === breadcrumbs.length - 1
                                        ? "text-neutral-900 cursor-default"
                                        : "text-neutral-400 hover:text-neutral-900"
                                )}
                                onClick={(e) => {
                                    if (index === breadcrumbs.length - 1) e.preventDefault();
                                }}
                            >
                                {crumb.label}
                            </Link>
                        </Fragment>
                    ))}
                </div>
            </div>

            <div className="flex items-center gap-6">
                <div className="flex items-center gap-3">
                    <Datefilter
                        disabled={isDateFilterDisabled}
                        filterSelector={
                            selectedDateRange.startDate &&
                                selectedDateRange.endDate
                                ? `${dayjs(
                                    selectedDateRange.startDate
                                ).format("DD MMM YYYY")} - ${dayjs(
                                    selectedDateRange.endDate
                                ).format("DD MMM YYYY")}`
                                : "Select Date Range"
                        }
                        onFilterChange={handleDateChange}
                        onReset={handleResetDate}
                    />
                    <AccountFilter
                        selectedAccount={selectedAccount}
                        onAccountSelect={handleChangeAccount}
                        accounts={accounts}
                    />
                </div>
            </div>
        </nav>
    );
};

export default Navbar;