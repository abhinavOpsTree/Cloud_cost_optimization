import { preconnect } from "react-dom";
import Routes from "./routes/Routes";
import { API_BASE_URL } from "./APIs/ApiEndPoint";
import { keycloakConfig } from "./providers/AuthContext";

const App = () => {
  if (API_BASE_URL) {
    preconnect(API_BASE_URL);
  }
  if (keycloakConfig?.url) {
    preconnect(keycloakConfig.url);
  }
  
  return (
    <main className="w-screen h-screen overflow-x-hidden bg-neutral-100">
      <Routes />
    </main >
  )
}

export default App