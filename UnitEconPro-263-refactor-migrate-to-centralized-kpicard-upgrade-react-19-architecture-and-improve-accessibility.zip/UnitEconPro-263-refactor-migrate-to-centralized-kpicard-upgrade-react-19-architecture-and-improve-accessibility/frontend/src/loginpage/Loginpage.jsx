import { Navigate } from "react-router-dom";
import { useAuth } from "../providers/AuthContext";

const Loginform = () => {
    const { login, authenticated } = useAuth();



    if (authenticated) {
        return <Navigate to="/" />;
    }

    return (
        <div className="w-screen h-screen p-[1rem]">
            <div className="h-[100%] mx-auto relative p-[1rem] flex rounded-lg">
                <div className='md:block md:w-1/2 hidden sm:hidden relative text-zinc-700 h-[100%] bg-white bg-[url("https://images.unsplash.com/photo-1722603264833-fde4f1f8a7ec?w=1000&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHx0b3BpYy1mZWVkfDh8Ym84alFLVGFFMFl8fGVufDB8fHx8fA%3D%3D")] bg-center rounded-md object-cover'>
                    <div className=" flex items-center w-[100%] justify-between px-10 py-5 h-20">
                        <h1 className="text-2xl capitalize font-bold text-white">SpendSmart</h1>
                    </div>
                    <div className="absolute bottom-[3.5vw] lg:left-[10vw] md:left-[5vw] ">
                        <div className="flex gap-10 justify-center">
                            <div className="w-16 rounded-md h-[5px] bg-white"></div>
                            <div className="w-16 rounded-md h-[5px] bg-white"></div>
                            <div className="w-16 rounded-md h-[5px] bg-white"></div>
                        </div>
                    </div>
                </div>
                <div className="w-full max-w-xl mx-auto flex flex-col justify-center items-center" >
                    <div className="text-center mb-8">
                        <div className="w-12 h-12 bg-indigo-600 rounded-xl mx-auto mb-6 flex items-center justify-center shadow-indigo-200 shadow-lg" >
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="lucide lucide-shield-check text-white w-6 h-6" aria-hidden="true">
                                <path d="M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1-1z"></path>
                                <path d="m9 12 2 2 4-4"></path>
                            </svg>
                        </div>
                        <h1 className="text-2xl font-bold text-slate-900 mb-2 tracking-tight">Welcome Back</h1>
                        <p className="text-slate-500 text-sm">Sign in with your corporate account to access SpendSmart.</p>
                    </div>
                    <div className="space-y-4">
                        <button
                            onClick={login}
                            className="w-full bg-slate-800 text-white font-medium py-3.5 px-6 rounded-xl flex items-center justify-center gap-3 transition-all shadow-lg shadow-slate-200" style={{ transform: "none" }}>
                            <div className="grid grid-cols-2 gap-0.5 w-4 h-4">
                                <div className="bg-[#f25022] w-full h-full"></div>
                                <div className="bg-[#7fba00] w-full h-full"></div>
                                <div className="bg-[#00a4ef] w-full h-full"></div>
                                <div className="bg-[#ffb900] w-full h-full"></div>
                            </div>
                            <span>Enterprise Login</span>
                        </button>
                    </div>
                    <div className="mt-12 text-center">
                        <p className="text-[10px] text-slate-400 font-medium tracking-wide uppercase">Secured by OpsTree</p>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Loginform;
