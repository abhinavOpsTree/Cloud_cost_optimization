import { Outlet, useLocation } from 'react-router-dom';
import { ShieldAlert } from 'lucide-react';
import Navbar from '../Navbar/Navbar';
import SideBar from '../sidebar/Sidebar';
import { SidebarProvider } from '../sidebar/SidebarContext';
import { Suspense, useEffect, useRef } from 'react';
import PageLoader from '../common/PageLoader';
import ErrorBoundary from '../common/ErrorBoundary';
import { useAccessibleAccounts } from '../hooks/useAccessibleAccounts';
import { useAuth } from '../providers/AuthContext';

const NoAccessScreen = ({ email }) => {
    const { logout } = useAuth();
    return (
        <div className="h-screen w-full flex flex-col items-center justify-center bg-[#f9fafb] text-center px-6">
            <div className="w-14 h-14 rounded-2xl bg-red-50 border border-red-100 flex items-center justify-center mb-4">
                <ShieldAlert size={26} className="text-red-500" />
            </div>
            <h1 className="text-lg font-bold text-gray-900 mb-1.5">No Access</h1>
            <p className="text-sm text-gray-500 max-w-md leading-relaxed">
                {email ? <span className="font-semibold text-gray-700">{email}</span> : "Your account"} has no cloud accounts assigned.
                Please contact your administrator to request access.
            </p>
            <button
                onClick={logout}
                className="mt-5 px-4 py-2 rounded-lg bg-[var(--button-bg)] text-white text-xs font-bold uppercase tracking-wider hover:bg-[var(--button-bg)]/90 transition-all cursor-pointer"
            >
                Sign out
            </button>
        </div>
    );
};

const Layout = () => {
    const { data: accountsData, isFetched, email } = useAccessibleAccounts();
    const noAccess = isFetched && Array.isArray(accountsData) && accountsData.length === 0;
    const slug = useLocation().pathname;
    useEffect(() => {
        if (contentRef.current) {
            contentRef.current.scrollTo(0, 0)
        }
    }, [slug])
    const contentRef = useRef(null);

    if (noAccess) return <NoAccessScreen email={email} />;

    return (
        <SidebarProvider>
            <div className="flex h-screen">
                <div className="h-full shrink-0 mr-1">
                    <SideBar />
                </div>
                <div className="flex-1 min-w-0 h-full relative flex flex-col pt-2">
                    <div className='bg-white w-full rounded-tl-xl border border-black/10 overflow-hidden flex flex-col h-full min-w-0'>
                        <div className='sticky top-0 z-40 bg-white'>
                            <Navbar />
                            <div className='h-[0.2px] w-full bg-black/10'></div>
                        </div>
                        <div ref={contentRef} className='flex-1 overflow-y-auto overflow-x-hidden'>
                            <section className="w-full h-full min-w-0">
                                <Suspense fallback={<PageLoader />}>
                                    <ErrorBoundary key={slug}>
                                        <Outlet />
                                    </ErrorBoundary>
                                </Suspense>
                            </section>
                        </div>
                    </div>
                </div>
            </div>
        </SidebarProvider>

    );
};

export default Layout;
