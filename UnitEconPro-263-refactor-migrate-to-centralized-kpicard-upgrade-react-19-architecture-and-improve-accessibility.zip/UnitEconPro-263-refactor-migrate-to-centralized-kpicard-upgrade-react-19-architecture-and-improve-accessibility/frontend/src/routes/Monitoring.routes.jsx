import { lazy } from "react";
import { Navigate } from "react-router-dom";

import CloudWatch from "../Pages/Monitoring/subpage/CloudWatch";

const Monitoring = lazy(() => import("../Pages/Monitoring/Index"));

export const monitoringRoutes = {
    path: "/monitoring",
    element: <Monitoring />,
    handle: {
        crumb: () => "Monitoring"
    },
    children: [
        {
            index: true,
            element: <Navigate to="/monitoring/cloudwatch" replace />
        },
        {
            path: "cloudwatch",
            element: <CloudWatch />
        }
    ]
};
