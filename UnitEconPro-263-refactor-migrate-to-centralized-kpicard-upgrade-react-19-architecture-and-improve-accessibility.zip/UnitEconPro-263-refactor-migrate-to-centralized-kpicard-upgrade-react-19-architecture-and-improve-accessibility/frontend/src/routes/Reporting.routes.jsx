import { lazy } from "react";
import { Navigate } from "react-router-dom";

const Reporting = lazy(() => import("../Pages/Reporting/index"));

export const reportingRoutes = {
    path: "/reporting",
    children: [
        { index: true, element: <Navigate to="cfo" replace /> },
        { 
            path: ":role", 
            element: <Reporting />, 
            handle: { crumb: () => "Reporting Module" } 
        }
    ]
};
