import { Navigate, Outlet } from 'react-router-dom';
import { useAuth } from '../providers/AuthContext';

const PrivateRoutes = () => {
    const { authenticated } = useAuth();



    return (
        authenticated ? <Outlet /> : <Navigate to="/login" />
    )
}

export default PrivateRoutes
