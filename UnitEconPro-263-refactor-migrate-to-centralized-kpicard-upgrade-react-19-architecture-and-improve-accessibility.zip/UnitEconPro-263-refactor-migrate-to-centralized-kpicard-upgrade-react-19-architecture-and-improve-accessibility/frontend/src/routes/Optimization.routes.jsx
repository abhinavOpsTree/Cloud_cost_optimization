import { lazy } from "react";

const Optimization = lazy(() => import("../Pages/Optimization/Index"));

export const optimizationRoutes = {
    path: "/optimization",
    element: <Optimization />,
    handle: {
        crumb: () => "Optimization"
    }
};
