import { lazy } from "react";
const CostComparison = lazy(() => import("../Pages/CostComparison/index"));

export const costComparisonRoutes = {
    path: "/cost-comparison",
    element: <CostComparison />,
    handle: { crumb: () => "Cost Comparison" },
};
