import { computeRoutes } from "./Compute.routes";
import { dashboardRoutes } from "./Dashboard.routes";
import { databasesRoutes } from "./Databases.routes";
import { governanceRoutes } from "./Governance.routes";
import { MyaccountRoute } from "./Myaccount";
import { networkingRoutes } from "./Networking.routes";
import { monitoringRoutes } from "./Monitoring.routes";
import { optimizationRoutes } from "./Optimization.routes";
import { settingsRoutes } from "./Settings.routes";
import { systemHealthRoutes } from "./SystemHealth.routes";
import { storageRoutes } from "./Storage.routes";
import { analyticsRoutes } from "./Analytics.routes";
import { costComparisonRoutes } from "./CostComparison";
import { accountRoutes } from "./Account.routes";
import { recommendationRoutes } from "./Recommendations";
import { reportingRoutes } from "./Reporting.routes";

export const appRoutes = [
    dashboardRoutes,
    analyticsRoutes,
    computeRoutes,
    storageRoutes,
    databasesRoutes,
    networkingRoutes,
    monitoringRoutes,
    optimizationRoutes,
    governanceRoutes,
    MyaccountRoute,
    settingsRoutes,
    systemHealthRoutes,
    costComparisonRoutes,
    reportingRoutes,
    recommendationRoutes,
    accountRoutes
];
