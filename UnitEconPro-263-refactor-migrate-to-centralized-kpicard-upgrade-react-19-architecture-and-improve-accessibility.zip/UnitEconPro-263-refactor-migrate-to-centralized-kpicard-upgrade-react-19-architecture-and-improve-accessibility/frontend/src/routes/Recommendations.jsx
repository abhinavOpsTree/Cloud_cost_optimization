import { lazy } from "react";
import { Outlet, Navigate } from "react-router-dom";

const RecommendationPage = lazy(() => import("../Pages/Recommendation/index"));
const SystemRecommendationPage = lazy(() => import("../Pages/Recommendation/System/index"));

// Cloud Sentry lazy imports
const CloudSentryLayout = lazy(() => import("../Pages/Cloud-Sentry/Index.jsx"));
const CloudSentryDashboard = lazy(() => import("../Pages/Cloud-Sentry/subpages/Dashboard.jsx"));
const CloudSentryRecommendations = lazy(() => import("../Pages/Cloud-Sentry/subpages/Recommendations.jsx"));
const CloudSentryInstances = lazy(() => import("../Pages/Cloud-Sentry/subpages/Instances.jsx"));
const CloudSentryTagAudit = lazy(() => import("../Pages/Cloud-Sentry/subpages/TagAudit.jsx"));
const CloudSentryChatbot = lazy(() => import("../Pages/Cloud-Sentry/subpages/Chatbot.jsx"));
const CloudSentryAuditLog = lazy(() => import("../Pages/Cloud-Sentry/subpages/AuditLog.jsx"));
const CloudSentrySkillContribution = lazy(() => import("../Pages/Cloud-Sentry/subpages/SkillContribution.jsx"));

export const recommendationRoutes = {
    path: "/recommendation",
    element: <Outlet />,
    children: [
        {
            index: true,
            element: <RecommendationPage />,
            handle: {
                crumb: () => "Recommendation",
            },
        },
        {
            path: "system",
            element: <SystemRecommendationPage />,
            handle: {
                crumb: () => "System Recommendations",
            },
        },
        {
            path: "cloud-sentry",
            element: <CloudSentryLayout />,
            children: [
                { index: true, element: <Navigate to="dashboard" replace /> },
                { path: "dashboard", element: <CloudSentryDashboard /> },
                { path: "recommendations", element: <CloudSentryRecommendations /> },
                { path: "instances", element: <CloudSentryInstances /> },
                { path: "tag-audit", element: <CloudSentryTagAudit /> },
                { path: "chatbot", element: <CloudSentryChatbot /> },
                { path: "audit-log", element: <CloudSentryAuditLog /> },
                { path: "skill-contribution", element: <CloudSentrySkillContribution /> }
            ]
        }
    ]
};
