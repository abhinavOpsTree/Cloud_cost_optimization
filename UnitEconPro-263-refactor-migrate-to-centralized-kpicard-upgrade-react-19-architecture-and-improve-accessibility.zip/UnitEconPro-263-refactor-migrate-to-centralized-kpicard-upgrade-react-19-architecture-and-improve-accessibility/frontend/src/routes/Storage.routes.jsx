import { lazy } from "react";
import { Navigate } from "react-router-dom";

// import Storage from "../Pages/Storage/Index"
// import S3 from "../Pages/Storage/subpage/S3"
// import EBS from "../Pages/Storage/subpage/EBS"

const Storage = lazy(() => import("../Pages/Storage/Index"));
const S3 = lazy(() => import("../Pages/Storage/subpage/S3"));
const EBS = lazy(() => import("../Pages/Storage/subpage/EBS"));

export const storageRoutes = {
    path: "/storage",
    element: <Storage />,
    handle: {
        crumb: () => "Storage"
    },
    children: [
        {
            index: true,
            element: <Navigate to="s3" replace />
        },
        { path: "s3", element: <S3 />, handle: { crumb: () => "S3" } },
        { path: "ebs", element: <EBS />, handle: { crumb: () => "EBS" } },
    ]
};
