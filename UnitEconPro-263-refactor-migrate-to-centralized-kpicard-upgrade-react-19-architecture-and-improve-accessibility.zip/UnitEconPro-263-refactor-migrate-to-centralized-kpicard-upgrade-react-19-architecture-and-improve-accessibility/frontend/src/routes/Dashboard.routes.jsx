import { lazy } from "react";

const Dashboard = lazy(() => import("../Pages/Dashboard/index"));

export const dashboardRoutes = {
    path: "/dashboard",
    element: <Dashboard />,
    handle: {
        crumb: () => "Dashboard"
    }
};
