import ProfileMenu from "../sidebar/ProfileMenu";

export const MyaccountRoute = {
    path: "/myaccount",
    element: <ProfileMenu />
};
