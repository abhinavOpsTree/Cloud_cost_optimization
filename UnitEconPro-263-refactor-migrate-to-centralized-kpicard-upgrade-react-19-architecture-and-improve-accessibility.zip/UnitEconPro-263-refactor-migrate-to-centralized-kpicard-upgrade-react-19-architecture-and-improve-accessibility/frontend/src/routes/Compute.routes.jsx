import { lazy } from "react";
import { Navigate } from "react-router-dom";

const ComputeLayout = lazy(() => import("../Pages/Compute/Index"));
const EKS = lazy(() => import("../Pages/Compute/subpages/EKS"));
const EC2 = lazy(() => import("../Pages/Compute/subpages/EC2"));
const ECR = lazy(() => import("../Pages/Compute/subpages/ECR"));
const ECS = lazy(() => import("../Pages/Compute/subpages/ECS"));

export const computeRoutes = {
    path: "/compute",
    element: <ComputeLayout />,
    handle: { crumb: () => "Compute" },
    children: [
        {
            index: true,
            element: <Navigate to="eks" replace />
        },
        {
            path: "eks",
            element: <EKS />,
            handle: { crumb: () => "EKS" },
        },
        {
            path: "ec2",
            element: <EC2 />,
            handle: { crumb: () => "EC2" }
        },
        {
            path: "ecr",
            element: <ECR />,
            handle: { crumb: () => "ECR" }
        },
        {
            path: "ecs",
            element: <ECS />,
            handle: { crumb: () => "ECS" }
        }
    ]
};
