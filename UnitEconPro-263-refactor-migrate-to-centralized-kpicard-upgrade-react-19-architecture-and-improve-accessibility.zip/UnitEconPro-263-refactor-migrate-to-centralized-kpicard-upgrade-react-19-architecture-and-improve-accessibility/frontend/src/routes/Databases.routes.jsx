import { lazy } from "react";
import RDS from "../Pages/Databases/subpage/RDS";
import { Navigate } from "react-router-dom";

const Databases = lazy(() => import("../Pages/Databases/Index"));

export const databasesRoutes = {
    path: "/databases",
    element: <Databases />,
    handle: {
        crumb: () => "Databases"
    },
    children: [
        {
            index: true,
            element: <Navigate to="/databases/rds" replace />
        },
        {
            path: "rds",
            element: <RDS/>
        }
    ]
};
