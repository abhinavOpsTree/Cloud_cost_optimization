import { lazy } from "react";

const Account = lazy(() => import("../Pages/Account/index"));

export const accountRoutes = {
    path: "/accounts",
    element: <Account />,
    handle: {
        crumb: () => "Accounts"
    }
};
