import { lazy } from "react";

const Analytics = lazy(() => import("../Pages/analytics/Index"));

export const analyticsRoutes = {
    path: "/analytics",
    element: <Analytics />,
    handle: {
        crumb: () => "Analytics"
    }
};
