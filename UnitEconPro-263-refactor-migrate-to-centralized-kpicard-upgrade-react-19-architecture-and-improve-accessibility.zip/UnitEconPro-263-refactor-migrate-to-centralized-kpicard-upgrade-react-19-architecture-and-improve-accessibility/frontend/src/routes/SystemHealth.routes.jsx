import { lazy } from "react";

const SystemHealth = lazy(() => import("../Pages/SystemHealth/index"));

export const systemHealthRoutes = {
    path: "/system-health",
    handle: {
        crumb: () => "System Health"
    },
    element: <SystemHealth />
};
