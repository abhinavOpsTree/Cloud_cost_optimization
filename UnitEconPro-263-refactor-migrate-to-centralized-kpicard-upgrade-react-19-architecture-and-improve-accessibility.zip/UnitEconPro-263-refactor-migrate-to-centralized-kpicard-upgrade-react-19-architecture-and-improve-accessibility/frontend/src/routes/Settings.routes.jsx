import Settings from "../Pages/Settings/Index";

export const settingsRoutes = {
    path: "/settings",
    handle: {
        crumb: () => "Settings"
    },
    element: <Settings />
};
