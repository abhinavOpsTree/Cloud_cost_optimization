import MainLayout from "../layout/Index";
import { createBrowserRouter, RouterProvider, Navigate, useRouteError } from "react-router-dom";
import { ErrorFallbackUI } from "../common/ErrorFallbackUI";
import PrivateRoutes from "./Protectedroutes";
import Loginform from "../loginpage/Loginpage";
import { appRoutes } from "./Index";

const GlobalRouteError = () => {
    const error = useRouteError();
    return (
        <ErrorFallbackUI 
            error={error} 
            onReset={() => window.location.reload()} 
            fullScreen={true} 
        />
    );
};

const router = createBrowserRouter([
    {
        path: "/login",
        element: <Loginform />
    },
    {
        element: <PrivateRoutes />,
        errorElement: <GlobalRouteError />,
        children: [
            {
                path: "/",
                element: <MainLayout />,
                children: [
                    {
                        index: true,
                        element: <Navigate to="/dashboard" replace />
                    },
                    ...appRoutes
                ]
            }
        ]
    },
    {
        path: "*",
        element: <Navigate to="/login" replace />
    }
]);

const Routes = () => {
    return (
        <RouterProvider router={router} />
    );
};

export default Routes;
