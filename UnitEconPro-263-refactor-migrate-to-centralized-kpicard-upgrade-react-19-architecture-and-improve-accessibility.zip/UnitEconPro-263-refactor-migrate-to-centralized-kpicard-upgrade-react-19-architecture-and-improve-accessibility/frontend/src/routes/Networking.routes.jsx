import { lazy } from "react";
import { Navigate } from "react-router-dom";

import VPC from "../Pages/Networking/subpage/VPC";
import ELB from "../Pages/Networking/subpage/ELB";
import DataTransfer from "../Pages/Networking/subpage/DataTransfer";

const Networking = lazy(() => import("../Pages/Networking/Index"));

export const networkingRoutes = {
    path: "/networking",
    element: <Networking />,
    handle: {
        crumb: () => "Networking"
    },
    children: [
        {
            index: true,
            element: <Navigate to="/networking/vpc" replace />
        },
        {
            path: "vpc",
            element: <VPC />
        },
        {
            path: "elb",
            element: <ELB />
        },
        {
            path: "datatransfer",
            element: <DataTransfer />
        }
    ]
};
