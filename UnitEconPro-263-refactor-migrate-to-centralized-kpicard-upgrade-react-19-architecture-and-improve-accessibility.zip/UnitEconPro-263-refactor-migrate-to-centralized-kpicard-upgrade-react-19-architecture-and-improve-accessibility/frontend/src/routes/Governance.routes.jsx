import { lazy } from "react";

const Governance = lazy(() => import("../Pages/Governance/Index"));

export const governanceRoutes = {
    path: "/governance",
    element: <Governance />,
    handle: {
        crumb: () => "Governance"
    }
};
