import { useState, useEffect, useActionState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Lightbulb } from "lucide-react";
import { useSuggestions } from "../hooks/useSuggestions";
import { useAuth } from "../providers/AuthContext";
import SubmitButton from "./SubmitButton";

export const AddSuggestionModal = ({
  isOpen,
  onClose,
  service = "",
  scope = "page",
  resourceId = "",
  resourceName = "",
  initialText = "",
}) => {
  const { keycloak } = useAuth();
  const keycloakName =
    keycloak?.tokenParsed?.name ||
    keycloak?.tokenParsed?.preferred_username ||
    "";

  const [text, setText] = useState("");
  const [context, setContext] = useState("");
  const [createdBy, setCreatedBy] = useState(keycloakName || "User");

  const { createSuggestion } = useSuggestions();

  useEffect(() => {
    const name = keycloak?.tokenParsed?.name || keycloak?.tokenParsed?.preferred_username;
    // eslint-disable-next-line react-hooks/set-state-in-effect
    if (name) setCreatedBy(name);
  }, [keycloak?.tokenParsed]);

  useEffect(() => {
    if (isOpen) {
      // eslint-disable-next-line react-hooks/set-state-in-effect
      setText(initialText || "");
      setContext("");
      setCreatedBy(keycloakName || "User");
    }
  }, [isOpen, keycloakName, initialText]);

  // Handle escape key to close modal
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === "Escape" && isOpen) {
        onClose();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isOpen, onClose]);

  const [state, formAction] = useActionState(async () => {
    if (!text.trim()) return { error: "Suggestion cannot be empty" };

    const payload = {
      service: String(service).toLowerCase(),
      scope,
      resource_id: scope === "page" ? "" : String(resourceId),
      resource_name: scope === "page" ? "" : String(resourceName || resourceId),
      text: text.trim() + (context.trim() ? " | " + context.trim() : ""),
      created_by: createdBy.trim() || "User",
    };

    try {
      await createSuggestion(payload);
      onClose();
      return { success: true };
    } catch (error) {
      console.error("Failed to create page suggestion:", error);
      return { error: error?.message || "Failed to create page suggestion" };
    }
  }, null);

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-[99999] flex items-center justify-center p-4">
          {/* Backdrop */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/45 backdrop-blur-[2px]"
          />

          {/* Modal Container */}
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 10 }}
            transition={{ type: "spring", duration: 0.4 }}
            className="relative w-full max-w-[500px] bg-white rounded-xl shadow-xl border border-black/10 overflow-hidden text-[var(--text-primary-color)] font-sans z-10"
          >
            {/* Header */}
            <div className="p-5 pb-3 flex items-start justify-between border-b border-black/5 bg-gray-50/50">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-lg bg-indigo-50 border border-indigo-100 flex items-center justify-center shrink-0">
                  <Lightbulb size={16} className="text-indigo-600" />
                </div>
                <div>
                  <h2 className="text-base font-bold tracking-tight text-gray-900">
                    Add Suggestion
                  </h2>
                  <p className="text-[11px] text-gray-500 font-medium">
                    {scope === "page"
                      ? `Page-level recommendation for ${service.toUpperCase()}`
                      : `Resource recommendation for ${resourceId}`}
                  </p>
                </div>
              </div>
              <button
                onClick={onClose}
                className="p-1 rounded hover:bg-gray-100 text-gray-400 hover:text-gray-600 transition-colors cursor-pointer"
                aria-label="Close modal"
              >
                <X size={16} />
              </button>
            </div>

            {/* Form */}
            <form action={formAction} className="p-5 space-y-4">
              {state?.error && (
                <div className="p-3 bg-red-50 border border-red-200 text-red-600 text-sm rounded-md font-medium">
                  {state.error}
                </div>
              )}
              <div>
                <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1.5">
                  What's the suggestion?
                </label>
                <input
                  type="text"
                  required
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                  placeholder={
                    scope === "page"
                      ? `e.g. Rightsizing standard family or lifecycle optimizations on ${service.toUpperCase()}`
                      : `e.g. Schedule stop window for instance ${resourceId} during weekends`
                  }
                  className="w-full px-3 py-2 bg-white border border-gray-200 rounded-lg text-xs text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all font-medium"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1.5">
                  More context <span className="text-gray-400 normal-case font-medium">(optional)</span>
                </label>
                <textarea
                  value={context}
                  onChange={(e) => setContext(e.target.value)}
                  placeholder="Why this matters, any specific resources in scope..."
                  rows={4}
                  className="w-full px-3 py-2 bg-white border border-gray-200 rounded-lg text-xs text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all resize-none font-medium leading-relaxed"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1.5">
                  Created By
                  {keycloakName && (
                    <span className="ml-2 text-[10px] font-normal text-emerald-600 normal-case">
                      · auto-filled from account
                    </span>
                  )}
                </label>
                <input
                  type="text"
                  required
                  value={createdBy}
                  onChange={(e) => setCreatedBy(e.target.value)}
                  placeholder="e.g. Rahul K"
                  className="w-full px-3 py-2 bg-white border border-gray-200 rounded-lg text-xs text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 transition-all font-medium"
                />
              </div>

              {/* Actions */}
              <div className="flex items-center justify-end gap-2.5 pt-2 border-t border-black/5">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-4 py-2 rounded-lg border border-gray-200 text-xs font-bold text-gray-500 hover:text-gray-700 hover:bg-gray-50 transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <SubmitButton
                  disabled={!text.trim()}
                  pendingText="Adding..."
                  defaultText="Add Suggestion"
                  className="px-4 py-2 rounded-lg text-xs shadow-sm hover:bg-[var(--button-bg)]/90 hover:scale-[1.01] active:scale-[0.98]"
                />
              </div>
            </form>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

export default AddSuggestionModal;
