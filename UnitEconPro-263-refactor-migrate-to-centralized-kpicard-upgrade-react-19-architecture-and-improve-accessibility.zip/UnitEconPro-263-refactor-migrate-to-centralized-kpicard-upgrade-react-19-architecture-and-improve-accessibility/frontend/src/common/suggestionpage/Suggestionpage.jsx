import { splitSuggestionText } from "../../lib/suggestionText";

export const SuggestionPage = () => {
    return (
        <div className="w-full h-50">
            {
                suggestions.length > 0 && (
                    <div className="py-1">
                        <div className="flex justify-between items-center mb-2.5">
                            <p className="text-sm font-bold uppercase text-[var(--text-primary-color)]">Suggestions</p>
                            <Link to="/recommendation">
                                <button className="text-xs font-bold text-indigo-600 hover:text-indigo-800 transition-colors cursor-pointer">View all</button>
                            </Link>
                        </div>
                        <div className="space-y-2.5">
                            {suggestions.slice(0, 1).map((item) => {
                                const { title, desc } = splitSuggestionText(item.text);
                                return (
                                    <div key={item.id} className="bg-white ring-1 ring-black/10 rounded-lg p-3">
                                        <p className="text-xs font-bold text-gray-900 leading-snug">{title}</p>
                                        {desc && <p className="text-[11px] text-gray-500 mt-1 leading-relaxed whitespace-pre-line">{desc}</p>}
                                        <div className="flex items-center gap-1.5 mt-2 text-[10px] text-gray-400 font-medium">
                                            <span>By {item.created_by || "User"}</span>
                                            <span>·</span>
                                            <span>{new Date(item.created_at).toLocaleDateString()}</span>
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                    </div>
                )
            }
        </div>
    )
}