import { ArrowDown, ArrowUp, ArrowUpFromLine, ChevronDown, ChevronRight } from "lucide-react";
import {memo, useMemo,Fragment, useState} from "react";
import { NavLink } from "react-router-dom";
import { cn } from "../lib/cn";
import Skeleton from "./Skeleton";
import { motion, AnimatePresence } from "framer-motion";
import ErrorBoundary from "./ErrorBoundary";

const TableInner = memo(function TableInner({
    columns = [],
    data = [],
    isFiltered = false,
    isLoading = false,
    actions = [],
    sortConfig = { key: null, direction: null },
    onSort,
    emptyState,
    onRowClick,
    expandable = false,
    singleExpand = false,
    expandIcon: ExpandIcon = ChevronRight,
    collapseIcon: CollapseIcon = ChevronDown,
    expandTooltip = "Expand",
    renderExpandedContent,
    rowsPerPage = 10,
    currentPage = null,
    rowKey = (row, index) => String(row.id || index),
    onRowHover,
    ref
}) {
    const [expandedRows, setExpandedRows] = useState(new Set());
    const [internalSortConfig, setInternalSortConfig] = useState({ key: null, direction: null });

    const activeSortConfig = onSort ? sortConfig : internalSortConfig;

    const toggleRow = (key, e) => {
        e.stopPropagation();
        let newExpandedRows;
        if (singleExpand) {
            newExpandedRows = new Set();
            if (!expandedRows.has(key)) {
                newExpandedRows.add(key);
            }
        } else {
            newExpandedRows = new Set(expandedRows);
            if (newExpandedRows.has(key)) {
                newExpandedRows.delete(key);
            } else {
                newExpandedRows.add(key);
            }
        }
        setExpandedRows(newExpandedRows);
    };

    const handleSort = (key) => {
        if (onSort) {
            onSort(key);
        } else {
            let direction = "asc";
            if (activeSortConfig.key === key && activeSortConfig.direction === "asc") {
                direction = "desc";
            } else if (activeSortConfig.key === key && activeSortConfig.direction === "desc") {
                direction = null;
                key = null;
            }
            setInternalSortConfig({ key, direction });
        }
    };

    const sortedData = useMemo(() => {
        if (onSort || !activeSortConfig.key || !activeSortConfig.direction) {
            return data;
        }

        const sorted = [...data];
        const { key, direction } = activeSortConfig;

        sorted.sort((a, b) => {
            let valA = a[key];
            let valB = b[key];

            if (valA === undefined || valA === null) valA = "";
            if (valB === undefined || valB === null) valB = "";

            const cleanNum = (val) => {
                if (typeof val === "number") return val;
                if (typeof val === "boolean") return val ? 1 : 0;
                const str = String(val).trim();
                const match = str.replace(/,/g, "").match(/^-?\$?\s*([0-9]+(?:\.[0-9]+)?)\s*(?:GB|MB|TB|KB|B|%)?$/i);
                if (match) {
                    return parseFloat(match[1]) * (str.startsWith("-") ? -1 : 1);
                }
                const parsed = parseFloat(str);
                return !isNaN(parsed) && isFinite(parsed) ? parsed : null;
            };

            const numA = cleanNum(valA);
            const numB = cleanNum(valB);

            if (numA !== null && numB !== null) {
                return direction === "asc" ? numA - numB : numB - numA;
            }

            const strA = String(valA).toLowerCase();
            const strB = String(valB).toLowerCase();

            if (strA < strB) return direction === "asc" ? -1 : 1;
            if (strA > strB) return direction === "asc" ? 1 : -1;
            return 0;
        });

        return sorted;
    }, [data, activeSortConfig, onSort]);

    const displayData = useMemo(() => {
        if (currentPage) {
            const start = (currentPage - 1) * rowsPerPage;
            return sortedData.slice(start, start + rowsPerPage);
        }
        return sortedData;
    }, [sortedData, currentPage, rowsPerPage]);

    const columnTotals = useMemo(() => {
        const totals = {};
        columns.forEach(col => {
            if (col.showTotal && isFiltered) {
                totals[col.key] = data.reduce((acc, row) => acc + (Number(row[col.key]) || 0), 0);
            }
        });
        return totals;
    }, [data, columns, isFiltered]);

    const renderEmptyRows = (count) => (
        [...Array(count)].map((_, index) => (
            <tr key={`empty-${index}`} className="transition-colors duration-150 odd:bg-white even:bg-slate-50 h-[45px]">
                {expandable && <td className="px-4 py-3" />}
                {columns.map((col) => (
                    <td key={`empty-col-${String(col.key)}`} className="px-4 py-3" />
                ))}
                {actions.length > 0 && <td className="px-4 py-2" />}
            </tr>
        ))
    );

    const isGhost = isLoading || displayData.length === 0;

    // RESPONSIVENESS: overflow-x-auto wrapper allows horizontal scrolling on mobile viewports
    return (
        <div ref={ref} className="w-full overflow-x-auto rounded-xl bg-white border border-slate-200 transition-all duration-300 shadow-sm min-h-[300px] relative">
            {/* RESPONSIVENESS: min-w-[800px] ensures column widths are preserved and do not collapse on small screens */}
            <div className="w-full min-w-[800px] relative">
                <table className="w-full text-left border-collapse table-fixed">
                    <thead>
                        <tr className="bg-[#626262] border-b border-slate-200">
                            {expandable && (
                                <th className="px-4 py-3 w-8" />
                            )}
                            {columns.map((col) => {
                                const isSortable = col.sortable === true;
                                return (
                                    <th
                                        key={String(col.key)}
                                        className={cn(
                                            "px-4 py-4 text-xs font-semibold text-white uppercase tracking-wider select-none text-center truncate",
                                            col.className
                                        )}
                                    >
                                        <button
                                            type="button"
                                            className={cn(
                                                "flex items-center gap-1 w-full justify-center bg-transparent border-none p-0 text-inherit font-inherit focus:outline-none",
                                                isSortable && "cursor-pointer hover:text-geist-foreground transition-colors"
                                            )}
                                            onClick={() => isSortable && handleSort(String(col.key))}
                                        >
                                            <span>
                                                {col.label}
                                                {col.showTotal && isFiltered && (
                                                    <span className="ml-1 whitespace-nowrap">
                                                        (${columnTotals[col.key].toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })})
                                                    </span>
                                                )}
                                            </span>
                                            {isSortable && (
                                                <span className="flex items-center opacity-70">
                                                    {activeSortConfig.key === col.key ? (
                                                        activeSortConfig.direction === "asc" ? (
                                                            <ArrowUp size={12} className="text-geist-foreground ml-1" />
                                                        ) : (
                                                            <ArrowDown size={12} className="text-geist-foreground ml-1" />
                                                        )
                                                    ) : (
                                                        <div className="w-3 h-3 ml-1" />
                                                    )}
                                                </span>
                                            )}
                                        </button>
                                    </th>
                                );
                            })}
                            {actions.length > 0 && (
                                <th className="px-4 py-4 text-xs font-semibold text-white uppercase tracking-wider text-center w-[8%] whitespace-nowrap">
                                    Actions
                                </th>
                            )}
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-200 bg-white">
                        {isLoading && (
                            [...Array(rowsPerPage)].map((_, index) => (
                                <tr key={`skeleton-${index}`} className="border-b border-black/5 last:border-0 h-[45px]">
                                    {expandable && (
                                        <td className="px-4 py-3 w-8">
                                            <Skeleton variant="rectangular" width={20} height={20} className="rounded" />
                                        </td>
                                    )}
                                    {columns.map((col, colIndex) => (
                                        <td key={colIndex} className="px-4 py-4" align={col.align || "left"}>
                                            <div className={cn("flex items-center", col.align === 'right' && "justify-end", col.align === 'center' && "justify-center")}>
                                                <Skeleton
                                                    variant="text"
                                                    width={col.key === 'instance_name' || col.key === 'account' ? '70%' : '40%'}
                                                    height={14}
                                                />
                                            </div>
                                        </td>
                                    ))}
                                    {actions.length > 0 && (
                                        <td className="px-4 py-4">
                                            <div className="flex items-center justify-end gap-2">
                                                {actions.map((_, i) => (
                                                    <Skeleton key={i} variant="circular" width={24} height={24} />
                                                ))}
                                            </div>
                                        </td>
                                    )}
                                </tr>
                            ))
                        )}
                        {!isLoading && displayData.length > 0 && (
                            <>
                                {displayData.map((row, rowIndex) => {
                                    const key = rowKey(row, rowIndex);
                                    const isExpanded = expandedRows.has(key);

                                    return (
                                        <Fragment key={key}>
                                            <tr
                                                onClick={() => onRowClick && onRowClick(row)}
                                                onMouseEnter={() => onRowHover && onRowHover(row)}
                                                className={cn(
                                                    "transition-colors duration-150 group odd:bg-white even:bg-slate-50 ",
                                                    onRowClick && "cursor-pointer",
                                                    isExpanded && "bg-slate-100"
                                                )}
                                            >
                                                {expandable && (
                                                    <td className="px-4 py-3 w-8">
                                                        <div className="relative flex items-center justify-center group/tooltip">
                                                            <button
                                                                onClick={(e) => toggleRow(key, e)}
                                                                className="p-1 hover:bg-white/50 rounded-md transition-colors"
                                                            >
                                                                {isExpanded ? (
                                                                    <CollapseIcon size={16} className="text-slate-600" />
                                                                ) : (
                                                                    <ExpandIcon size={16} className="text-slate-600" />
                                                                )}
                                                            </button>
                                                            {expandTooltip && (
                                                                <div className="absolute left-full ml-2 px-2 py-1 bg-white text-black text-[10px] font-semibold rounded shadow-md opacity-0 invisible group-hover/tooltip:opacity-100 group-hover/tooltip:visible transition-all duration-200 z-50 whitespace-nowrap border border-gray-200 pointer-events-none">
                                                                    {expandTooltip}
                                                                </div>
                                                            )}
                                                        </div>
                                                    </td>
                                                )}
                                                {columns.map((col) => {
                                                    const cellValue = row[col.key];
                                                    let displayValue = cellValue;

                                                    if (col.render) {
                                                        displayValue = col.render(cellValue, row);
                                                    }

                                                    if (displayValue === undefined || displayValue === null || displayValue === "") {
                                                        displayValue = "-";
                                                    }

                                                    return (
                                                        <td
                                                            key={String(col.key)}
                                                            className={cn(
                                                                "px-4 py-3 text-sm text-slate-900 font-medium text-center truncate max-w-[0px] cursor-pointer",
                                                                col.cellClassName
                                                            )}
                                                            onMouseEnter={(e) => {
                                                                e.currentTarget.classList.remove('truncate');
                                                                e.currentTarget.classList.add('whitespace-normal', 'break-all');
                                                            }}
                                                            onMouseLeave={(e) => {
                                                                e.currentTarget.classList.add('truncate');
                                                                e.currentTarget.classList.remove('whitespace-normal', 'break-all');
                                                            }}
                                                        >
                                                            {displayValue}
                                                        </td>
                                                    );
                                                })}
                                                {actions.length > 0 && (
                                                    <td className="px-4 py-2 text-center w-[8%] whitespace-nowrap">
                                                        <div className="flex items-center justify-center gap-1 opacity-80 group-hover:opacity-100 transition-opacity">
                                                            {actions.map((action, actionIndex) => {
                                                                const isDisabled = action.disabled ? action.disabled(row) : false;
                                                                const linkPath = typeof action.link === 'function' ? action.link(row) : action.link;
                                                                const tooltipTitle = typeof action.tooltip === 'function' ? action.tooltip(row) : (action.tooltip || action.label || '');

                                                                const ButtonContent = (
                                                                    <button
                                                                        title={tooltipTitle}
                                                                        onClick={(e) => {
                                                                            e.stopPropagation();
                                                                            action.onClick?.(row);
                                                                        }}
                                                                        onMouseEnter={() => {
                                                                            action.onHover?.(row);
                                                                        }}
                                                                        disabled={isDisabled}
                                                                        className={cn(
                                                                            "p-1.5 transition-all duration-200 rounded-md",
                                                                            isDisabled && "opacity-40 cursor-not-allowed",
                                                                            action.color === "error" && !isDisabled && "text-red-500 bg-red-50 hover:bg-red-100 hover:text-red-600",
                                                                            action.color === "success" && !isDisabled && "text-emerald-500 bg-emerald-50 hover:bg-emerald-100 hover:text-emerald-600",
                                                                            (!action.color || action.color === "default") && !isDisabled && "text-slate-600 bg-slate-100 hover:bg-slate-200 hover:text-slate-900"
                                                                        )}
                                                                    >
                                                                        {typeof action.icon === 'function' ? (
                                                                            <action.icon row={row} size={16} />
                                                                        ) : action.icon ? (
                                                                            <action.icon size={16} />
                                                                        ) : (
                                                                            <ArrowUpFromLine size={16} />
                                                                        )}
                                                                    </button>
                                                                );
                                                                return (
                                                                    <Fragment key={actionIndex}>
                                                                        {linkPath ? (
                                                                            <NavLink to={linkPath} onClick={(e) => e.stopPropagation()}>
                                                                                {ButtonContent}
                                                                            </NavLink>
                                                                        ) : (
                                                                            ButtonContent
                                                                        )}
                                                                    </Fragment>
                                                                );
                                                            })}
                                                        </div>
                                                    </td>
                                                )}
                                            </tr>
                                            <AnimatePresence initial={false}>
                                                {isExpanded && renderExpandedContent && (
                                                    <motion.tr
                                                        key={`expanded-${key}`}
                                                        initial={{ opacity: 0 }}
                                                        animate={{ opacity: 1 }}
                                                        exit={{ opacity: 0 }}
                                                        transition={{ duration: 0.2 }}
                                                    >
                                                        <td
                                                            colSpan={columns.length + (actions.length > 0 ? 1 : 0) + (expandable ? 1 : 0)}
                                                            className="p-0 border-y border-slate-100"
                                                        >
                                                            <motion.div
                                                                initial={{ height: 0, opacity: 0 }}
                                                                animate={{ height: "auto", opacity: 1 }}
                                                                exit={{ height: 0, opacity: 0 }}
                                                                transition={{ duration: 0.3, ease: "easeInOut" }}
                                                                className="overflow-hidden"
                                                            >
                                                                <div className="px-8 py-4 bg-slate-50/50">
                                                                    {renderExpandedContent(row)}
                                                                </div>
                                                            </motion.div>
                                                        </td>
                                                    </motion.tr>
                                                )}
                                            </AnimatePresence>
                                        </Fragment>
                                    );
                                })}
                            </>
                        )}
                        {!isLoading && renderEmptyRows(displayData.length === 0 ? rowsPerPage : (displayData.length < rowsPerPage ? rowsPerPage - displayData.length : 0))}
                    </tbody>
                </table>
            </div>

            {isGhost && (
                <div className="absolute inset-0 top-[49px] z-10 flex flex-col items-center justify-center bg-white/20 backdrop-blur-[1.5px] pointer-events-none rounded-b-xl">
                    {isLoading ? (
                        <div className="flex flex-col items-center gap-2 text-slate-500 bg-white/80 px-4 py-2 rounded-lg shadow-sm">
                            <div className="w-6 h-6 border-[3px] border-teal-200 border-t-teal-500 rounded-full animate-spin" />
                            <span className="text-xs font-semibold">Loading data...</span>
                        </div>
                    ) : (
                        <span className="text-sm font-semibold text-gray-500 px-4 py-2 rounded-lg">
                            {emptyState || "No Data Available"}
                        </span>
                    )}
                </div>
            )}
        </div>
    );
});

const Table = ({ ref, ...props }) => (
  <ErrorBoundary>
    <TableInner {...props} ref={ref} />
  </ErrorBoundary>
);

export default Table;