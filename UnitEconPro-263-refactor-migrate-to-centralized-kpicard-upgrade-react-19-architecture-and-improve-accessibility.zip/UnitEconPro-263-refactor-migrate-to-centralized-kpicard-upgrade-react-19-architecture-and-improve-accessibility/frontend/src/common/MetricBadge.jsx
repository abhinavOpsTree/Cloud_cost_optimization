import { memo } from "react";

/**
 * Reusable UI component for rendering standardized delta/variance metric badges.
 * Eliminates repeated background, ring border, and text color class calculations across tables.
 * 
 * @param {number|null|undefined} value - Numerical metric value to evaluate.
 * @param {boolean} [isTotal=false] - Whether this is a summary/total row (uses heavier font-weight).
 * @param {boolean} [zeroIsNeutral=false] - If true, 0 is styled as neutral gray/slate instead of green.
 * @param {string} [className=""] - Additional custom classes.
 */
const MetricBadge = memo(({ value, children, isTotal = false, zeroIsNeutral = false, className = "" }) => {
    const isNullOrZero = value == null || (zeroIsNeutral && value === 0);
    const isPositive = value > 0;

    const bgClass = isNullOrZero
        ? "bg-slate-100 ring-1 ring-inset ring-slate-200"
        : isPositive
            ? "bg-[var(--red-bg)] ring-1 ring-inset ring-[var(--red-ring)]"
            : "bg-[var(--green-bg)] ring-1 ring-inset ring-[var(--green-ring)]";

    const textClass = isNullOrZero
        ? "text-slate-500"
        : isPositive
            ? "text-red-600"
            : "text-emerald-600";

    const fontClass = isTotal ? "font-black" : "font-bold";

    return (
        <span className={`inline-flex items-center px-2.5 py-1 rounded-md text-xs ${fontClass} ${textClass} ${bgClass} ${className}`.trim()}>
            {children}
        </span>
    );
});

export default MetricBadge;
