import { useState} from "react";
import Select from "./Select";

export const CardSkeleton = ({ ref }) => (
    <div ref={ref} className="flex flex-col justify-between h-full p-4 animate-pulse bg-white ring-[.5px] ring-black/10 rounded-md">
        <div className="flex items-center justify-between mb-4">
            <div className="w-24 h-4 bg-black/10 dark:bg-white/10 rounded" />
            <div className="w-8 h-8 rounded-full bg-black/10 dark:bg-white/10" />
        </div>
        <div className="mb-2">
            <div className="w-32 h-8 bg-black/10 dark:bg-white/10 rounded" />
        </div>
        <div className="flex items-center gap-2 pt-3 border-t border-black/5 dark:border-white/5">
            <div className="w-16 h-3 bg-black/10 dark:bg-white/10 rounded" />
        </div>
    </div>
);

export { KpiCard } from "../components/common/KpiCard";
export const KpiDropdownCard = ({ kpi, ref }) => {
    const [selectedIdx, setSelectedIdx] = useState(0);
    const activeChild = kpi.children && kpi.children[selectedIdx] ? kpi.children[selectedIdx] : null;

    const displayTitle = activeChild
        ? activeChild.title?.replace(/_/g, " ")
        : kpi.title?.replace(/_/g, " ");

    const displayValue = activeChild?.value ?? kpi.value ?? 0;
    const displayValueIcon = activeChild?.icon ?? kpi.icon;

    // Cleanup not needed anymore as Select handles its own state

    return (
        <div ref={ref} className="flex flex-col shadow-[var(--shadow)] justify-between h-full p-5 min-h-[140px] bg-white rounded-md ring-[.5px] ring-black/10 hover:-translate-y-[2px] hover:shadow-sm transition-all duration-200">
            {/* Header: Title and custom dropdown */}
            <div className="flex items-start justify-between gap-2 mb-3">
                <span className="text-sm font-bold text-neutral-600 capitalize leading-tight pt-1">
                    {displayTitle}
                </span>
                {kpi.children && kpi.children.length > 0 && (
                        <Select
                            value={selectedIdx}
                            options={kpi.children.map((sub, i) => ({ label: sub.title.replace(/_/g, " "), value: i }))}
                            onChange={(val) => setSelectedIdx(val)}
                            className="text-[10px] bg-neutral-50 hover:bg-neutral-100/80 border border-neutral-200/80 shadow-sm py-1 px-2.5 min-w-[90px] max-w-[150px]"
                        />
                )}
            </div>

            {/* Value + icon */}
            <div className="flex items-center gap-1 mb-2">
                {displayValueIcon}
                <span className="text-2xl font-semibold text-geist-foreground">
                    {displayValue}
                </span>
            </div>
        </div>
    );
};

