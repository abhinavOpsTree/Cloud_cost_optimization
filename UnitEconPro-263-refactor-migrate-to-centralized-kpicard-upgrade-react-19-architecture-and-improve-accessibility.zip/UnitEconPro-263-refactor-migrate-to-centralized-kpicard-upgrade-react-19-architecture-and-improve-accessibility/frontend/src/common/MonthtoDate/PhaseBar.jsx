
import { useState } from "react";
import { COLORS, formatCurrency } from "./types";


const PhaseBar = ({ v, maxBarVal }) => {
    const [hovered, setHovered] = useState(false);
    return (
        <div
            onMouseEnter={() => setHovered(true)}
            onMouseLeave={() => setHovered(false)}
            className="flex flex-col items-center gap-[3px] relative"
        >
            {/* Tooltip */}
            <div className="absolute -top-6 px-[5px] py-[2px] rounded text-[8px] font-bold text-white whitespace-nowrap z-10 pointer-events-none transition-all duration-200"
                style={{
                    backgroundColor: COLORS.mutedDark,
                    opacity: hovered ? 1 : 0,
                    left: "50%",
                    transform: `translateX(-50%) translateY(${hovered ? 0 : 5}px)`
                }}
            >
                ${formatCurrency(v.val)}
                <div className="absolute -bottom-[3px] left-1/2 -translate-x-1/2 border-l-[3px] border-l-transparent border-r-[3px] border-r-transparent"
                    style={{
                        borderTop: `3px solid ${COLORS.mutedDark}`
                    }} 
                />
            </div>
            <div className="w-8 rounded-[3px_3px_2px_2px] cursor-pointer transition-transform duration-150 origin-bottom"
                style={{
                    height: Math.max((v.val / maxBarVal) * 40, 2),
                    background: v.forecast
                        ? `repeating-linear-gradient(135deg, ${COLORS.primaryBgAlt} 0px, ${COLORS.primaryBgAlt} 3px, ${COLORS.primaryBg} 3px, ${COLORS.primaryBg} 6px)`
                        : `linear-gradient(180deg, ${COLORS.primaryLighter}, ${COLORS.primary})`,
                    border: v.forecast ? `1.5px dashed ${COLORS.primary}` : "none",
                    opacity: v.forecast ? 0.9 : 1,
                    transform: hovered ? "scaleY(1.05)" : "none",
                }} 
            />
            <div className="text-[9px] font-bold" style={{ color: COLORS.muted }}>
                {v.label}
            </div>
        </div>
    );
};
export default PhaseBar;