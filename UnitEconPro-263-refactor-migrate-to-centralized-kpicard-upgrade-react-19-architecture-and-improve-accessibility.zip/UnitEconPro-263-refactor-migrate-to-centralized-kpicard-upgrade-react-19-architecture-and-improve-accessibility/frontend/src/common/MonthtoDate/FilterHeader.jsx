import { ChevronDown, RefreshCcw } from "lucide-react";

const Datefilter = ({
    filterSelector,
    // onFilterChange,
    onReset,
    // defaultLabel = "Select Month & Year"
}) => {

    return (
        <div className="mb-6 flex gap-3 items-center justify-start md:justify-end flex-wrap">
            <div className="relative rounded-lg p-3 w-fit flex items-center gap-3">
                <div className="relative">
                    <button
                        className="flex items-center justify-between px-2 py-2 text-sm bg-white/50 backdrop-blur-sm border border-white/40 rounded-lg shadow-sm outline-none cursor-pointer text-slate-700 transition-all hover:bg-white/70 min-w-[160px]"
                    >
                        <span className="text-xs font-medium">{filterSelector}</span>
                        <ChevronDown size={16} className={`transition-transform`} />
                    </button>

                </div>

                <button
                    className="flex items-center gap-1 px-4 py-1.5 bg-white/50 hover:bg-white/80 backdrop-blur-sm text-slate-600 rounded-lg text-sm font-medium transition-all shadow-sm border border-white/40 cursor-pointer"
                    onClick={onReset}
                >
                    <RefreshCcw size={14} />
                    Reset
                </button>
            </div>
        </div>
    );
};

export default Datefilter;
