import { useState } from "react";

const CostBar = ({ mtd, budget }) => {
    const [isHovered, setIsHovered] = useState(false);
    const isOver = mtd > budget;
    const maxVal = Math.max(mtd, budget) * 1.05;
    const progress = (mtd / maxVal) * 100;
    const budgetMark = (budget / maxVal) * 100;

    return (
        <div
            style={{ width: "100%", marginTop: "35px" }}
            onMouseEnter={() => setIsHovered(true)}
            onMouseLeave={() => setIsHovered(false)}
        >
            <div style={{
                width: "100%",
                height: "8px",
                backgroundColor: "#f3f4f6",
                borderRadius: "3px",
                position: "relative",
                marginBottom: "10px",
                cursor: "pointer"
            }}>
                <div style={{
                    position: "absolute",
                    left: `${budgetMark}%`,
                    top: "-26px",
                    transform: `translateX(-60%) translateY(${isHovered ? '0' : '10px'})`,
                    opacity: isHovered ? 1 : 0,
                    backgroundColor: "green",
                    color: "white",
                    padding: "2px 6px",
                    borderRadius: "2px",
                    fontSize: "10px",
                    fontWeight: "700",
                    whiteSpace: "nowrap",
                    zIndex: 20,
                    transition: "all 0.3s cubic-bezier(0.4, 0, 0.2, 1)",
                    pointerEvents: "none"
                }}>
                    Budget ${budget?.toLocaleString()}
                    <div style={{
                        position: "absolute",
                        bottom: "-4px",
                        left: "50%",
                        transform: "translateX(-50%)",
                        borderLeft: "4px solid transparent",
                        borderRight: "4px solid transparent",
                        borderTop: "4px solid green"
                    }} />
                </div>
                <div className={isOver ? "bg-[#fef0f0] ring-1 ring-[#fee2e2]" : "bg-[#ecfdf5] ring-1 ring-[#d1fae5]"} style={{
                    position: "absolute",
                    left: `${progress}%`,
                    top: "-26px",
                    transform: `translateX(-50%) translateY(${isHovered ? '0' : '10px'})`,
                    opacity: isHovered ? 1 : 0,
                    color: isOver ? "red" : "#0a7e57ff",
                    padding: "2px 6px",
                    borderRadius: "2px",
                    fontSize: "10px",
                    fontWeight: "700",
                    whiteSpace: "nowrap",
                    zIndex: 21,
                    transition: "all 0.3s cubic-bezier(0.4, 0, 0.2, 1)",
                    pointerEvents: "none"
                }}>
                    ${mtd?.toLocaleString()}
                    <div style={{
                        position: "absolute",
                        bottom: "-4px",
                        left: "50%",
                        transform: "translateX(-50%)",
                        borderLeft: "4px solid transparent",
                        borderRight: "4px solid transparent",
                        borderTop: `4px solid ${isOver ? '#fee2e2' : '#18c56bff'}`
                    }} />
                </div>
                <div style={{
                    width: `${progress}%`,
                    height: "100%",
                    borderRadius: "14px",
                    display: "flex",
                    overflow: "hidden",
                    transition: "width 0.5s ease-out"
                }}>
                    {isOver ? (
                        <>
                            <div style={{ width: `${(budget / mtd) * 100}%`, height: "100%", backgroundColor: "#10b981" }} />
                            <div style={{ flex: 1, height: "100%" }} className="bg-red-500" />
                        </>
                    ) : (
                        <div style={{ width: "100%", height: "100%", backgroundColor: "#10b981" }} />
                    )}
                </div>
                <div style={{
                    position: "absolute",
                    left: `${budgetMark}%`,
                    top: "-2px",
                    bottom: "-2px",
                    width: "2px",
                    backgroundColor: "#1f2937",
                    zIndex: 10,
                    transition: "left 0.5s ease-out"
                }} />
            </div>
            <div style={{ display: "flex", justifyContent: "space-between", marginTop: "4px", fontSize: "10px" }} className="text-neutral-500">
                <span>Budget: ${budget?.toLocaleString()} / month</span>
                {isOver ? (
                    <span style={{
                        backgroundColor: "#fef2f2",
                        color: "#ef4444",
                        padding: "2px 6px",
                        borderRadius: "2px",
                        fontWeight: "700",
                        border: "0.5px solid #fee2e2"
                    }}>
                        Extra: ${(mtd - budget).toLocaleString()}
                    </span>
                ) : (
                    <span style={{ color: "#10b981", fontWeight: "700" }}>Within Budget</span>
                )}
            </div>
        </div>
    );
};

export default CostBar;