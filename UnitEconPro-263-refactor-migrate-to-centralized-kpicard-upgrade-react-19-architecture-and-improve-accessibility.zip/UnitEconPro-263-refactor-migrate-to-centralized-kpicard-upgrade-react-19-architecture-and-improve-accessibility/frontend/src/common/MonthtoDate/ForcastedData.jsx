import React, { useEffect, useMemo, useState } from "react";
import dayjs from "dayjs";
import isBetween from "dayjs/plugin/isBetween";
import isoWeek from "dayjs/plugin/isoWeek";
// import { Calendar, TrendingUp, TrendingDown } from "lucide-react";
import CostBar from "./CostBar";
import { COLORS, formatCurrency } from "./types";
// import PhaseBar from "./PhaseBar";
import Highcharts from "highcharts";
import HighchartsReact from "highcharts-react-official";

dayjs.extend(isBetween);
dayjs.extend(isoWeek);

const calculateBuckets = (
    trend,
    start,
    end,
    granularity = "day"
) => {
    if (!trend?.length) return [];

    const now = dayjs();

    if (granularity === "month") {
        const months = {};
        trend.forEach(item => {
            const d = dayjs(item.date);
            if (d.isBefore(start, "day") || d.isAfter(end, "day")) return;
            const key = d.format("MMM YYYY");
            months[key] = (months[key] || 0) + item.cost;
        });

        return Object.entries(months).map(([label, val]) => ({
            label,
            val,
            forecast: dayjs(label, "MMM YYYY").isAfter(now, "month") || dayjs(label, "MMM YYYY").isSame(now, "month")
        }));
    }

    if (granularity === "phase") {
        const daysInMonth = start.daysInMonth();
        const startOfMonth = start.startOf("month");
        const periods = [
            { s: 1, e: 10, l: "1-10" },
            { s: 11, e: 20, l: "11-20" },
            { s: 21, e: daysInMonth, l: `21-${daysInMonth}` }
        ];

        return periods.map(p => {
            const pStart = startOfMonth.date(p.s).startOf("day");
            const pEnd = startOfMonth.date(p.e).endOf("day");

            const total = trend.reduce((sum, item) => {
                const d = dayjs(item.date);
                return d.isBetween(pStart, pEnd, "day", "[]") ? sum + item.cost : sum;
            }, 0);

            return {
                label: p.l,
                val: total,
                forecast: pEnd.isAfter(now, "day") || pEnd.isSame(now, "day")
            };
        });
    }

    const buckets = {};
    const divisor = granularity === "day" ? 1 : 7;

    const totalDays = end.diff(start, "day") + 1;
    const totalBuckets = Math.ceil(totalDays / divisor);

    trend.forEach(item => {
        const d = dayjs(item.date);
        if (!d.isBetween(start, end, "day", "[]")) return;

        const diff = d.diff(start, "day");
        const bucketIndex = Math.floor(diff / divisor);
        buckets[bucketIndex] = (buckets[bucketIndex] || 0) + item.cost;
    });

    return Array.from({ length: totalBuckets }).map((_, i) => {
        const bucketStart = start.add(i * divisor, "day");
        const bucketEnd = bucketStart.add(divisor - 1, "day");

        const isFuture = bucketEnd.isAfter(now, "day");

        return {
            label: granularity === "day"
                ? (totalBuckets > 10 ? bucketStart.format("D") : bucketStart.format("ddd"))
                : `W${i + 1}`,
            val: buckets[i] || 0,
            forecast: isFuture
        };
    });
};

const RangeSelector = ({ range, setRange }) => (
    <div style={{ display: "flex", background: COLORS.border, borderRadius: 8, padding: 3, gap: 2 }}>
        {["7D", "MONTH"].map(r => (
            <button
                key={r}
                onClick={() => setRange(r)}
                style={{
                    fontSize: 11,
                    fontWeight: 600,
                    padding: "4px 10px",
                    borderRadius: 6,
                    border: "none",
                    cursor: "pointer",
                    background: range === r ? COLORS.white : "transparent",
                    color: range === r ? COLORS.text : COLORS.muted,
                    boxShadow: range === r ? "0 1px 4px rgba(0,0,0,0.08)" : "none",
                    transition: "all 0.15s",
                }}
            >
                {r}
            </button>
        ))}
    </div>
);

const MonthProgress = ({ currentDay, daysInMonth, daysRemaining }) => {
    const progress = (currentDay / daysInMonth) || 0;
    return (
        <div className="flex flex-col gap-2 w-full">
            <div className="flex justify-between items-center">
                <span className="text-[10px] font-bold text-neutral-500 whitespace-nowrap uppercase tracking-wider">Month Progress</span>
                <span className="text-[10px] font-medium text-neutral-400 whitespace-nowrap">
                    {currentDay} of {daysInMonth} days · {daysRemaining} remaining
                </span>
            </div>
            <div className="h-1 w-full bg-gray-200 rounded-full overflow-hidden">
                <div
                    style={{ width: `${Math.min(100, progress * 100)}%` }}
                    className="h-full bg-emerald-500 rounded-full shadow-sm"
                />
            </div>
        </div>
    );
};

export const ForecastDashCard = ({ data, trend, comparison, isTrendLoading, budgetForecast }) => {
    const [chartRange, setChartRange] = useState("7D");
    const now = dayjs();
    const chartBars = useMemo(() => {
        if (!data || !trend) return [];
        let start, end, granularity;
        if (chartRange === "7D") {
            start = now.subtract(7, "day").startOf("day");
            end = now.subtract(1, "day").endOf("day");
            granularity = "day";
        } else {
            start = now.startOf("month");
            end = now.endOf("month");
            granularity = "phase";
        }
        return calculateBuckets(trend, start, end, granularity);
    }, [trend, now, data, chartRange]);

    const mtdCost = data?.mtd_cost || 0;
    const budget = budgetForecast?.budget_amount || data?.budget || 0;
    const predictedCost = budgetForecast?.forecast_month_cost || data?.predicted_month_cost || 0;
    const predicatedWeekCost = data?.predicted_week_cost || 0;

    const daysInMonth = now.daysInMonth();
    const currentDay = now.date();
    const daysRemaining = daysInMonth - currentDay;

    const displayBars = chartBars;
    const maxBarVal = Math.max(...displayBars.map(b => b.val), 1);

    return (
        <div className="bg-[var(--background-color)] rounded-xl ring-[.5px] ring-black/10 shadow-[var(--shadow)] p-4 space-y-6">
            {/* Header */}
            <div className="flex justify-between items-center gap-12">
                <div className="flex-1 w-full bg-">
                    <MonthProgress
                        currentDay={currentDay}
                        daysInMonth={daysInMonth}
                        daysRemaining={daysRemaining}
                    />
                </div>
                <div className="px-4 py-1 rounded-full border border-orange-200/70 bg-orange-50 text-orange-600 flex items-center gap-1 whitespace-nowrap shadow-sm">
                    <span className="text-[11px] font-bold">Daily Run Rate ${formatCurrency(data?.daily_run_rate)}/day</span>
                </div>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 items-stretch">
                <div className="col-span-12 md:col-span-6 lg:col-span-4 bg-[var(--background-color)] border border-black/10 rounded-xl p-4 flex flex-col justify-between">
                    <div>
                        <span className="text-[10px] font-bold text-[var(--text-color)] uppercase tracking-wider mb-2 block flex items-center  justify-between">
                            Month to Date
                            <div className="flex items-center gap-1">
                                {budgetForecast && budgetForecast.pct_used != null && (
                                    <>
                                        Budget Utilization :
                                        <span style={{
                                            fontSize: "10px",
                                            fontWeight: 700,
                                            padding: "2px 8px",
                                            borderRadius: "12px",
                                            backgroundColor: budgetForecast.pct_used < 0 ? "#ECFDF5" : "#FEF2F2",
                                            color: budgetForecast.pct_used < 0 ? "#10B981" : "#EF4444",
                                            border: `1px solid ${budgetForecast.pct_used < 0 ? "#D1FAE5" : "#FEE2E2"}`,
                                            marginTop: "2px",
                                        }}>
                                            {budgetForecast.pct_used > 0 ? `+${budgetForecast.pct_used}%` : `${budgetForecast.pct_used}%`}
                                        </span>
                                    </>
                                )}
                            </div>
                        </span>
                        <div className="text-4xl font-bold text-emerald-600 mb-4 tracking-tight">${formatCurrency(mtdCost)}</div>
                        <CostBar mtd={mtdCost} budget={budget} />
                    </div>
                    <div className="pt-4 border-t border-black/5 mt-4 flex flex-col gap-2">
                        <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block">Target vs Budget</span>
                        {budgetForecast ? (
                            <div className="flex items-center justify-between mt-1">
                            </div>
                        ) : (
                            <span className="text-xs font-medium text-neutral-400">No budget forecast integrated</span>
                        )}
                    </div>
                </div>
                <div className="col-span-12 md:col-span-6 lg:col-span-4 bg-[var(--background-color)] border border-black/10 rounded-xl p-4 flex flex-col justify-between">
                    <div className="flex items-stretch flex-1">
                        <div className="flex-1 flex flex-col justify-center">
                            <span className="text-[10px] font-bold text-[var(--text-color)] uppercase tracking-wider mb-1">Predicted Month Cost</span>
                            <div className="text-2xl font-bold text-neutral-900">${formatCurrency(predictedCost)}</div>
                        </div>
                        <div className="w-px bg-black/5 mx-4"></div>
                        <div className="flex-1 flex flex-col justify-center">
                            <span className="text-[10px] font-bold text-[var(--text-color)] uppercase tracking-wider mb-1">Predicted Week Cost</span>
                            <div className="text-2xl font-bold text-neutral-900">${formatCurrency(predicatedWeekCost)}</div>
                        </div>
                    </div>

                    <div className="h-px bg-black/5 my-3"></div>

                    <div className="flex items-stretch flex-1">
                        <div className="flex-1 flex flex-col justify-center">
                            <span className="text-[10px] font-bold text-[var(--text-primary-color)] uppercase tracking-wider mb-1">Last Week</span>
                            <div className="text-2xl font-semibold text-[var(--text-primary-color)]">${formatCurrency(comparison?.last_week_cost)}</div>
                        </div>
                        <div className="w-px bg-black/5 mx-4"></div>
                        <div className="flex-1 flex flex-col justify-center">
                            <div className="flex justify-between items-center mb-1">
                                <span className="text-[10px] font-bold text-[var(--text-primary-color)] uppercase tracking-wider">This Week</span>
                                {/* {comparison?.last_week_cost > 0 && (
                                    <div className={`text-[9px] font-bold px-1.5 py-0.5 rounded border flex items-center gap-0.5 ${comparison.this_week_cost > comparison.last_week_cost ? "bg-red-500/10 text-red-500 border-red-500/20" : "bg-emerald-500/10 text-emerald-500 border-emerald-500/20"}`}>
                                        {comparison.this_week_cost > comparison.last_week_cost ? <TrendingUp size={10} /> : <TrendingDown size={10} />}
                                        {Math.abs(((comparison.this_week_cost - comparison.last_week_cost) / comparison.last_week_cost) * 100).toFixed(1)}%
                                    </div>
                                )} */}
                            </div>
                            <div className="text-2xl font-bold text-[var(--text-primary-color)]">${formatCurrency(comparison?.this_week_cost)}</div>
                        </div>
                    </div>

                    <div className="h-px bg-black/5 my-3"></div>

                    <div className="flex items-stretch flex-1">
                        <div className="flex-1 flex flex-col justify-center">
                            <span className="text-[10px] font-bold text-[var(--text-primary-color)] uppercase tracking-wider mb-1">Last Month</span>
                            <div className="text-2xl font-semibold text-neutral-900">${formatCurrency(comparison?.last_month_cost)}</div>
                        </div>
                        <div className="w-px bg-black/5 mx-4"></div>
                        <div className="flex-1 flex flex-col justify-center">
                            <span className="text-[10px] font-bold text-[var(--text-primary-color)] uppercase tracking-wider mb-1">Yesterday</span>
                            <div className="text-2xl font-semibold text-[var(--text-primary-color)]">${formatCurrency(comparison?.yesterday_cost)}</div>
                        </div>
                    </div>
                </div>
                {/* Column 4: Chart */}
                <div className="col-span-12 md:col-span-12 lg:col-span-4 pb-4 lg:pb-0 flex items-stretch h-full mt-4 lg:mt-0 min-w-0">
                    <div className="flex-1 flex flex-col h-full bg-[var(--background-color)] border border-black/10 rounded-xl p-4 min-w-0">
                        <div className="flex justify-end mb-5">
                            <RangeSelector range={chartRange} setRange={setChartRange} />
                        </div>
                        <div className="flex-1 min-h-[160px] relative w-full min-w-0">
                            {isTrendLoading ? (
                                <div className="h-[180px] w-full px-2 pt-3 animate-pulse">
                                    <div className="relative flex h-[140px] items-end justify-between gap-3">
                                        {[40, 72, 55, 90, 65, 80, 50].map((height, i) => (
                                            <div
                                                key={i}
                                                className="flex flex-col items-center justify-end flex-1 h-full"
                                            >
                                                <div className="relative w-full max-w-[20px] h-full rounded-md bg-gray-100 overflow-hidden">
                                                    <div
                                                        className="absolute bottom-0 w-full rounded-md bg-gradient-to-t from-gray-200 via-gray-300 to-gray-200"
                                                        style={{ height: `${height}%` }}
                                                    />
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            ) : (
                                <HighchartsReact
                                    highcharts={Highcharts}
                                    containerProps={{ style: { height: '100%', width: '100%' } }}
                                    options={{
                                        chart: {
                                            type: 'column',
                                            backgroundColor: 'transparent',
                                            height: 180,
                                            spacing: [10, 0, 15, 0],
                                            animation: { duration: 800 }
                                        },

                                        title: { text: null },
                                        credits: { enabled: false },

                                        xAxis: {
                                            categories: displayBars.map(b => b.label),
                                            min: 0,
                                            max: displayBars.length - 1,
                                            tickPositions: displayBars.map((_, i) => i),
                                            labels: {
                                                allowOverlap: true,
                                                style: {
                                                    fontSize: '9px',
                                                    fontWeight: '900',
                                                    color: '#6b7280',
                                                    textTransform: 'uppercase'
                                                },
                                                autoRotation: false,
                                                distance: 10
                                            },
                                            lineWidth: 0,
                                            tickWidth: 0,
                                            gridLineWidth: 1,
                                            gridLineColor: 'rgba(0,0,0,0.05)',
                                            gridLineDashStyle: 'Dash',
                                        },

                                        yAxis: {
                                            title: { text: null },
                                            labels: { enabled: false },
                                            gridLineWidth: 1,
                                            gridLineColor: 'rgba(0,0,0,0.05)',
                                            gridLineDashStyle: 'Dash',
                                            min: 0,
                                            tickAmount: 5
                                        },

                                        legend: { enabled: false },

                                        tooltip: {
                                            headerFormat:
                                                '<span style="font-size: 10px; font-weight: bold; text-transform: uppercase; color: #9ca3af;">{point.key}</span><br/>',
                                            pointFormat:
                                                '<span style="color:#608B3A">●</span> <span style="color:white">Cost:</span> <b style="color:white">${point.y:,.2f}</b>',
                                            backgroundColor: '#121212',
                                            borderRadius: 8,
                                            borderWidth: 0,
                                            shadow: true,
                                            style: { color: 'white', fontSize: '11px' }
                                        },

                                        plotOptions: {
                                            column: {
                                                borderRadius: 6,
                                                borderWidth: 0,
                                                grouping: false,
                                                pointPadding: 0.25,
                                                groupPadding: 0.2,
                                                maxPointWidth: 35,
                                                states: {
                                                    inactive: {
                                                        opacity: 1
                                                    },
                                                    hover: {
                                                        brightness: 0.1
                                                    }
                                                }
                                            }
                                        },

                                        series: [
                                            {
                                                data: displayBars.map(() => maxBarVal),
                                                color: {
                                                    linearGradient: { x1: 0, x2: 0, y1: 0, y2: 1 },
                                                    stops: [
                                                        [0, '#e6e7e8'],
                                                        [0.5, '#f3f4f6'],
                                                        [1, '#f9fafb']
                                                    ]
                                                },
                                                enableMouseTracking: false,
                                                animation: false
                                            },
                                            {
                                                data: displayBars.map(b => b.val),
                                                color: {
                                                    linearGradient: { x1: 0, x2: 0, y1: 0, y2: 1.2 },
                                                    stops: [
                                                        [0, '#2d5e01ff'],
                                                        [0.5, '#7ab745ff'],
                                                        [1, '#ffffffff']
                                                    ]
                                                },
                                                animation: { duration: 2000 }
                                            }
                                        ]
                                    }}
                                />
                            )}
                        </div>
                    </div>
                </div>

            </div>
        </div>
    );
};
