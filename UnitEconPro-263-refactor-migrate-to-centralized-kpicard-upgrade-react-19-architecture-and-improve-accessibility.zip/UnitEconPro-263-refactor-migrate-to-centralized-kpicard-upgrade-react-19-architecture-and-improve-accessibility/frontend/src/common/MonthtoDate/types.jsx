export const COLORS = {
    primary: "#10b981",
    primaryLight: "#34d399",
    primaryLighter: "#6ee7b7",
    primaryBg: "#f0fdf4",
    primaryBgAlt: "#d1fae5",
    warning: "#ea580c",
    warningAlt: "#f97316",
    warningBg: "#fff7ed",
    text: "#000000",
    textSecondary: "#111827",
    muted: "#6b7280",
    mutedDark: "#374151",
    border: "#f3f4f6",
    white: "#fff",
    success: "#16a34a", 
};
export const formatCurrency = (val)=> {
    if (val === undefined || val === null || isNaN(val)) return "0.00";
    return val.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}; 
