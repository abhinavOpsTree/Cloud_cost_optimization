import React, { Suspense, lazy } from 'react';

const LazyComponent = lazy(() => import('./ForecastCardFinance').then(m => ({ default: m.ForecastCardFinance })));

export const ForecastCardFinance = (props) => (
    <Suspense fallback={<div className="h-[200px] w-full animate-pulse bg-neutral-100 rounded-xl"></div>}>
        <LazyComponent {...props} />
    </Suspense>
);
