import React, { useState } from 'react';
import { Copy, Check } from 'lucide-react';

const CopyableCell = ({ value }) => {
    const [copied, setCopied] = useState(false);

    const handleCopy = (e) => {
        e.stopPropagation();
        if (value) {
            navigator.clipboard.writeText(value.toString());
            setCopied(true);
            setTimeout(() => setCopied(false), 2000);
        }
    };

    if (!value) return <span>—</span>;

    return (
        <div className="grid grid-cols-[1fr_auto_1fr] items-center w-full group">
            <div />
            <span className="truncate min-w-0 text-center [.whitespace-normal_&]:whitespace-normal [.break-all_&]:break-all [.whitespace-normal_&]:overflow-visible" title={value}>{value}</span>
            <div className="flex justify-start items-center pl-1.5">
                <button
                    onClick={handleCopy}
                    className="opacity-0 group-hover:opacity-100 transition-opacity p-1 rounded hover:bg-gray-200 text-gray-500 shrink-0"
                    title="Copy to clipboard"
                >
                    {copied ? <Check size={14} className="text-green-500" /> : <Copy size={14} />}
                </button>
            </div>
        </div>
    );
};

export default CopyableCell;
