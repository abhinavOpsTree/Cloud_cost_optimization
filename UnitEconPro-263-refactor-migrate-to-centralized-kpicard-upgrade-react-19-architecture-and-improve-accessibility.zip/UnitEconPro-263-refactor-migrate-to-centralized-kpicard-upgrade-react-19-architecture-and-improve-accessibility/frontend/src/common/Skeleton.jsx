import React from "react"
const Skeleton = ({
  variant = "text",
  width = '100%',
  height = '16px',
  className = ''
}) => {
  const baseStyles = 'skeleton'

  const variantStyles = {
    text: 'rounded-micro',
    rectangular: 'rounded-standard',
    circular: 'rounded-pill',
  }


  const selectedVariant = variantStyles[variant] || variantStyles.text

  const circularHeight = variant === 'circular' ? width : height

  return (
    <div
      className={`${baseStyles} ${selectedVariant} ${className}`}
      style={{
        width: typeof width === 'number' ? `${width}px` : width,
        height: typeof circularHeight === 'number' ? `${circularHeight}px` : circularHeight,
      }}
    />
  )
}

export default Skeleton