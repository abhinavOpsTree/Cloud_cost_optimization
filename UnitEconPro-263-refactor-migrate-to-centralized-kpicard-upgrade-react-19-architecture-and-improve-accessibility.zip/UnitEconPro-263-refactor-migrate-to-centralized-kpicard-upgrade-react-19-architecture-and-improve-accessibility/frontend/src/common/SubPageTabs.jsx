import { motion } from 'framer-motion';
import { NavLink, useLocation, useNavigate } from 'react-router-dom';
import { cn } from '../lib/cn';
import { navigationItems } from '../sidebar/sidebarConfig';
import AddSuggestionModal from './AddSuggestionModal';
import { useState } from 'react';
import { Pencil } from 'lucide-react';
import Toggle from './Toggle';

const SubPageTabs = () => {
    const location = useLocation();
    const [isOpen, setisOpen] = useState(false);

    const activeParent = navigationItems.find(item =>
        item.subItems &&
        item.subItems.length > 0 &&
        (location.pathname === item.to || location.pathname.startsWith(item.to + '/'))
    );

    if (!activeParent || !activeParent.subItems) return null;

    const pathSegments = location.pathname.split("/").filter(Boolean);
    const service = pathSegments[pathSegments.length - 1] || "";

    const navigate = useNavigate();
    const activeItem = activeParent.subItems.find(item =>
        location.pathname === item.to || location.pathname.startsWith(item.to + '/')
    ) || activeParent.subItems[0];

    const options = activeParent.subItems.map(item => ({
        label: item.name,
        value: item.to
    }));

    return (
        <>
            <div className="sticky top-0 z-30 py-2 flex justify-between items-center w-full bg-[#f9fafb]/80 backdrop-blur-md">
                <Toggle
                    value={activeItem?.to}
                    onChange={(val) => navigate(val)}
                    options={options}
                />

                <motion.button
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => setisOpen(true)}
                    className="flex items-center justify-center gap-2 px-4 py-2 bg-[var(--button-bg)] text-white text-xs font-bold rounded-lg shadow-sm hover:bg-[var(--button-bg)]/90 transition-all cursor-pointer uppercase tracking-wider shrink-0"
                >
                    <Pencil size={14} />
                    Add Suggestion
                </motion.button>
            </div>

            <AddSuggestionModal
                isOpen={isOpen}
                onClose={() => setisOpen(false)}
                service={service}
                scope="page"
            />
        </>
    );
};

export default SubPageTabs;
