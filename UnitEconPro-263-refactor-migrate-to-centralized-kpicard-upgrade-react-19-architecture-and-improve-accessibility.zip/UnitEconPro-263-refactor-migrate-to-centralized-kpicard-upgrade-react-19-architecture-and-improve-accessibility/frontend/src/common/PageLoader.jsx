import Skeleton from "./Skeleton";

/**
 * PageLoader — Suspense fallback that mirrors the dashboard card layout.
 * Uses the existing `.skeleton` shine animation from index.css.
 */
const PageLoader = () => {
  return (
    <section className="min-h-screen w-full p-4 space-y-4 animate-pulse-subtle">

      {/* ── Row 1: Run-rate style stat cards ─────────────────────────── */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {Array.from({ length: 4 }).map((_, i) => (
          <div
            key={i}
            className="bg-[var(--card-bg)] border border-[var(--card-border-color)] rounded-[var(--card-border-radius)] p-[var(--card-padding)] space-y-3"
          >
            <div className="flex items-center justify-between">
              <Skeleton variant="text" width="55%" height="13px" />
              <Skeleton variant="circular" width="28px" height="28px" />
            </div>
            <Skeleton variant="text" width="70%" height="28px" />
            <Skeleton variant="text" width="40%" height="11px" />
          </div>
        ))}
      </div>

      {/* ── Row 2: Forecast / Month-to-date cards ─────────────────────── */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3">
        {/* Large chart card */}
        <div
          className="bg-[var(--card-bg)] border border-[var(--card-border-color)] rounded-[var(--card-border-radius)] p-[var(--card-padding)] lg:col-span-2 space-y-3"
        >
          <div className="flex items-center justify-between">
            <Skeleton variant="text" width="30%" height="14px" />
            <Skeleton variant="rectangular" width="80px" height="26px" />
          </div>
          {/* Fake bar chart */}
          <div className="flex items-end gap-2 h-36 pt-4">
            {[65, 80, 55, 90, 70, 85, 60, 75, 50, 88, 72, 95].map((h, i) => (
              <div
                key={i}
                className="skeleton flex-1 rounded-sm"
                style={{ height: `${h}%` }}
              />
            ))}
          </div>
          <div className="flex gap-4 pt-1">
            <Skeleton variant="text" width="20%" height="11px" />
            <Skeleton variant="text" width="20%" height="11px" />
          </div>
        </div>

        {/* Side metric card */}
        <div
          className="bg-[var(--card-bg)] border border-[var(--card-border-color)] rounded-[var(--card-border-radius)] p-[var(--card-padding)] space-y-4"
        >
          <Skeleton variant="text" width="50%" height="14px" />
          <Skeleton variant="text" width="60%" height="32px" />
          <div className="space-y-2 pt-2">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="flex items-center justify-between">
                <Skeleton variant="text" width="45%" height="11px" />
                <Skeleton variant="text" width="25%" height="11px" />
              </div>
            ))}
          </div>
          <Skeleton variant="rectangular" width="100%" height="6px" className="rounded-full mt-2" />
        </div>
      </div>

      {/* ── Row 3: Trend graph ─────────────────────────────────────────── */}
      <div
        className="bg-[var(--card-bg)] border border-[var(--card-border-color)] rounded-[var(--card-border-radius)] p-[var(--card-padding)] space-y-3"
      >
        <div className="flex items-center justify-between">
          <Skeleton variant="text" width="20%" height="14px" />
          <Skeleton variant="rectangular" width="100px" height="26px" />
        </div>
        {/* Fake line chart area */}
        <div className="relative h-40 overflow-hidden">
          <Skeleton variant="rectangular" width="100%" height="100%" className="rounded-md" />
        </div>
      </div>

      {/* ── Row 4: Cost categories table ─────────────────────────────── */}
      <div
        style={{
          background: "var(--card-bg)",
          border: "1px solid var(--card-border-color)",
          borderRadius: "var(--card-border-radius)",
          padding: "var(--card-padding)",
        }}
        className="space-y-3"
      >
        <Skeleton variant="text" width="25%" height="14px" />
        {/* Table rows */}
        {Array.from({ length: 5 }).map((_, i) => (
          <div key={i} className="flex items-center gap-3 py-1">
            <Skeleton variant="circular" width="24px" height="24px" />
            <Skeleton variant="text" width="30%" height="12px" />
            <Skeleton variant="text" width="15%" height="12px" className="ml-auto" />
            <Skeleton variant="rectangular" width="18%" height="8px" className="rounded-full" />
            <Skeleton variant="text" width="10%" height="12px" />
          </div>
        ))}
      </div>

    </section>
  );
};

export default PageLoader;
