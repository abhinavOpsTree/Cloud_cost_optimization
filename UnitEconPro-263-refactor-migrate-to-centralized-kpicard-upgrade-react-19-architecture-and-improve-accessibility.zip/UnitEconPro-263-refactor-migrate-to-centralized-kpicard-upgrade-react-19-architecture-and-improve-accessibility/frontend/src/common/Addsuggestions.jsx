import { useState, useEffect, useActionState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, ChevronDown } from "lucide-react";
import { useSuggestions } from "../hooks/useSuggestions";
import { useAuth } from "../providers/AuthContext";
import SubmitButton from "./SubmitButton";

// Category → services shown in the dependent Service dropdown
const CATEGORY_SERVICES = {
  Compute: [
    { value: "ec2", label: "EC2" },
    { value: "ecs", label: "ECS" },
    { value: "eks", label: "EKS" },
    { value: "ecr", label: "ECR" },
  ],
  Storage: [
    { value: "s3", label: "S3" },
    { value: "ebs", label: "EBS" },
  ],
  Networking: [
    { value: "vpc", label: "VPC" },
    { value: "datatransfer", label: "Data Transfer" },
    { value: "elb", label: "ELB" },
  ],
  Databases: [
    { value: "rds", label: "RDS" },
  ],
  Monitoring: [
    { value: "cloudwatch", label: "CloudWatch" },
  ],
  // No services — saved as "other"; stays on the hub, never routes anywhere
  Other: [],
};

export const Addsuggestions = ({ isOpen, onClose, onPost }) => {
  const { keycloak } = useAuth();
  const keycloakName =
    keycloak?.tokenParsed?.name ||
    keycloak?.tokenParsed?.preferred_username ||
    "";

  const [suggestion, setSuggestion] = useState("");
  const [context, setContext] = useState("");
  const [category, setCategory] = useState("Compute");
  const [service, setService] = useState(CATEGORY_SERVICES.Compute[0].value);
  const [createdBy, setCreatedBy] = useState(keycloakName || "User");

  const { createSuggestion } = useSuggestions();

  // Handle escape key to close modal
  useEffect(() => {
    const handleKeyDown = (e) => {
      if (e.key === "Escape" && isOpen) {
        onClose();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isOpen, onClose]);

  // Sync createdBy whenever keycloak token loads
  useEffect(() => {
    const name = keycloak?.tokenParsed?.name || keycloak?.tokenParsed?.preferred_username;
    // eslint-disable-next-line react-hooks/set-state-in-effect
    if (name) setCreatedBy(name);
  }, [keycloak?.tokenParsed]);

  const [state, formAction] = useActionState(async () => {
    if (!suggestion.trim()) return { error: "Suggestion cannot be empty" };

    const payload = {
      service,
      scope: "page",
      resource_id: "",
      resource_name: "",
      text: suggestion.trim() + (context.trim() ? " | " + context.trim() : ""),
      created_by: createdBy.trim() || keycloakName || "User",
    };

    try {
      await createSuggestion(payload);
      if (onPost) onPost(payload);
      setSuggestion("");
      setContext("");
      setCategory("Compute");
      setService(CATEGORY_SERVICES.Compute[0].value);
      setCreatedBy(keycloakName || "User");
      onClose();
      return { success: true };
    } catch (error) {
      console.error("Failed to save suggestion:", error);
      return { error: error?.message || "Failed to save suggestion" };
    }
  }, null);

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-black/50 backdrop-blur-sm"
          />

          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 10 }}
            transition={{ type: "spring", duration: 0.4 }}
            className="relative w-full max-w-[620px] bg-white rounded-2xl shadow-md border border-gray-100 overflow-hidden text-[var(--text-primary-color)]  z-10"
          >
            <div className="p-6 pb-4 flex items-start justify-between">
              <div>
                <h2 className="text-xl font-bold tracking-tight text-[var(--text-primary-color)]">
                  New suggestion
                </h2>
              </div>
              <button
                onClick={onClose}
                className="p-1.5 rounded-lg text-gray-400 hover:text-gray-600 bg-gray-100 transition-colors cursor-pointer"
                aria-label="Close modal"
              >
                <X size={18} />
              </button>
            </div>

            <form action={formAction} className="px-6 pb-6 space-y-5">
              {state?.error && (
                <div className="p-3 bg-red-50 border border-red-200 text-red-600 text-sm rounded-md font-medium">
                  {state.error}
                </div>
              )}

              <div>
                <label className="block text-xs font-bold text-[var(--text-secondary-color)] capitalize mb-2">
                  What's the suggestion?
                </label>
                <input
                  type="text"
                  required
                  value={suggestion}
                  onChange={(e) => setSuggestion(e.target.value)}
                  placeholder="e.g. Cut ap-south-1 compute by 20% this quarter"
                  className="w-full px-4 py-2.5 bg-white border border-gray-200 rounded-lg text-sm text-[var(--text-primary-color)] placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[var(--button-bg)]/20 focus:border-[var(--button-bg)] transition-all font-medium"
                />
              </div>

              {/* More context */}
              <div>
                <label className="block text-xs font-bold text-[var(--text-secondary-color)] capitalize mb-2">
                  More context <span className="text-gray-400 capitalize font-medium">(optional)</span>
                </label>
                <textarea
                  value={context}
                  onChange={(e) => setContext(e.target.value)}
                  placeholder="Why this matters, any specific resources in scope..."
                  rows={3}
                  className="w-full px-4 py-2.5 bg-white border border-gray-200 rounded-lg text-sm text-[var(--text-primary-color)] placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[var(--button-bg)]/20 focus:border-[var(--button-bg)] transition-all resize-none font-medium"
                />
              </div>

              {/* Category and Tags */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-[var(--text-secondary-color)] capitalize mb-2">
                    Category
                  </label>
                  <div className="relative">
                    <select
                      value={category}
                      onChange={(e) => {
                        const next = e.target.value;
                        setCategory(next);
                        setService(CATEGORY_SERVICES[next][0]?.value || "other");
                      }}
                      className="w-full px-4 py-2.5 bg-white border border-gray-200 rounded-lg text-sm text-[var(--text-primary-color)] focus:outline-none focus:ring-2 focus:ring-[var(--button-bg)]/20 focus:border-[var(--button-bg)] transition-all appearance-none cursor-pointer font-medium pr-10"
                    >
                      {Object.keys(CATEGORY_SERVICES).map((cat) => (
                        <option key={cat} value={cat}>{cat}</option>
                      ))}
                    </select>
                    <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none text-gray-400">
                      <ChevronDown size={16} />
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-[var(--text-secondary-color)] capitalize mb-2">
                    Service
                  </label>
                  <div className="relative">
                    <select
                      value={service}
                      onChange={(e) => setService(e.target.value)}
                      disabled={CATEGORY_SERVICES[category].length === 0}
                      className="w-full px-4 py-2.5 bg-white border border-gray-200 rounded-lg text-sm text-[var(--text-primary-color)] focus:outline-none focus:ring-2 focus:ring-[var(--button-bg)]/20 focus:border-[var(--button-bg)] transition-all appearance-none cursor-pointer font-medium pr-10 disabled:bg-gray-50 disabled:text-gray-400 disabled:cursor-not-allowed"
                    >
                      {CATEGORY_SERVICES[category].length === 0 ? (
                        <option value="other">Not applicable</option>
                      ) : (
                        CATEGORY_SERVICES[category].map((svc) => (
                          <option key={svc.value} value={svc.value}>{svc.label}</option>
                        ))
                      )}
                    </select>
                    <div className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none text-gray-400">
                      <ChevronDown size={16} />
                    </div>
                  </div>
                </div>
              </div>

              {/* Created By */}
              <div>
                <label className="block text-xs font-bold text-[var(--text-secondary-color)] capitalize mb-2">
                  Created By
                  {keycloakName && (
                    <span className="ml-2 text-[10px] font-normal text-emerald-600 normal-case">
                      · auto-filled from account
                    </span>
                  )}
                </label>
                <input
                  type="text"
                  required
                  value={createdBy}
                  onChange={(e) => setCreatedBy(e.target.value)}
                  placeholder="e.g. Rahul K"
                  className="w-full px-4 py-2.5 bg-white border border-gray-200 rounded-lg text-sm text-[var(--text-primary-color)] placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[var(--button-bg)]/20 focus:border-[var(--button-bg)] transition-all font-medium"
                />
              </div>

              {/* Actions Footer */}
              <div className="flex items-center justify-end gap-3 pt-3">
                <button
                  type="button"
                  onClick={onClose}
                  className="px-5 py-2.5 rounded-lg border border-gray-200 text-sm font-bold text-gray-500 hover:text-gray-700 hover:bg-gray-50 transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <SubmitButton
                  pendingText="Posting..."
                  defaultText="Post suggestion"
                  className="px-5 py-2.5 rounded-lg text-sm shadow-sm hover:bg-[var(--button-bg)]/90 hover:scale-[1.01] active:scale-[0.98]"
                />
              </div>
            </form>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
};

export default Addsuggestions;

