import React from "react";
import { motion } from "framer-motion";
import { cn } from "../lib/cn";

const IconDisplay = ({ className, icon, background }) => {
    if (!icon) return null;

    return (
        <motion.span
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.2 }}
            className={cn(
                "p-[3px] rounded-sm ring-[.5px] ring-black/20 flex items-center justify-center group-hover:scale-[1.1] group-hover:rotate-[8deg] shadow-[1px_1px_2px_0px_#F1F1F1]",
                background || "bg-neutral-300/20",
                className
            )}
        >
            {icon}
        </motion.span>
    );
};

export default IconDisplay;
