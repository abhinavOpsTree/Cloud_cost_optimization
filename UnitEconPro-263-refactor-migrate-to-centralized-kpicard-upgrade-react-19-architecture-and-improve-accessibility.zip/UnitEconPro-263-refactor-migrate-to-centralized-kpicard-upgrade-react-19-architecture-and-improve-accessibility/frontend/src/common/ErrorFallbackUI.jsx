import React from 'react';
import { AlertCircle, RefreshCw } from 'lucide-react';

export function ErrorFallbackUI({ error, onReset, fullScreen = false }) {
  return (
    <div className={`flex flex-col items-center justify-center p-6 bg-red-50/50 border border-red-100 rounded-xl w-full h-full gap-3 ${fullScreen ? 'min-h-[100vh]' : 'min-h-[150px]'}`}>
      <div className="flex items-center gap-2 text-red-600 font-semibold">
        <AlertCircle size={20} />
        <span>{fullScreen ? 'Something went wrong on this page' : 'Something went wrong'}</span>
      </div>
      <p className="text-sm text-red-500/80 text-center max-w-md">
        An unexpected error occurred while rendering this {fullScreen ? 'page' : 'component'}.
      </p>
      {error && (
        <div className="mt-2 w-full max-w-lg bg-red-100/50 p-3 rounded border border-red-200 overflow-x-auto">
          <code className="text-xs text-red-700 font-mono break-all whitespace-pre-wrap">
            {error.message || error.statusText || error.toString()}
          </code>
        </div>
      )}
      <button 
        onClick={onReset}
        className="mt-2 flex items-center gap-2 px-4 py-2 bg-white border border-red-200 text-red-600 rounded-md hover:bg-red-50 transition-colors text-sm font-medium shadow-sm"
      >
        <RefreshCw size={14} />
        Try Again
      </button>
    </div>
  );
}
