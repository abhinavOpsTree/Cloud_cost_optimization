
import { useFormStatus } from "react-dom";
import { motion } from "framer-motion";
import { RotateCcw } from "lucide-react";
import { cn } from "../lib/cn";

export default function SubmitButton({
    pendingText = "Submitting...",
    defaultText = "Submit",
    icon: Icon,
    className,
    disabled = false
}) {
    const { pending } = useFormStatus();
    
    return (
        <motion.button
            whileTap={{ scale: 0.98 }}
            type="submit"
            disabled={pending || disabled}
            className={cn(
                "flex items-center justify-center gap-2 bg-[var(--button-bg)] text-white font-bold cursor-pointer transition-all disabled:opacity-50 disabled:cursor-not-allowed",
                className
            )}
        >
            {pending ? (
                <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ repeat: Infinity, duration: 1, ease: "linear" }}
                >
                    <RotateCcw size={14} strokeWidth={3} />
                </motion.div>
            ) : Icon ? (
                <Icon size={16} strokeWidth={3} />
            ) : null}
            {pending ? pendingText : defaultText}
        </motion.button>
    );
}
