import { ChevronDown } from "lucide-react";
import { useEffect, useRef, useState, useMemo, useCallback, memo } from "react";
import { cn } from "../lib/cn";

const Select = memo(({ value, options = [], onChange, placeholder = "Select an option", className, menuClassName, iconClassName = "text-blue-600", disabled }) => {
    const [isOpen, setIsOpen] = useState(false);
    const dropdownRef = useRef(null);

    const selectedOption = useMemo(() => options.find(opt => opt.value === value), [options, value]);

    useEffect(() => {
        const handleClickOutside = (e) => {
            if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
                setIsOpen(false);
            }
        };

        document.addEventListener("mousedown", handleClickOutside);
        return () => document.removeEventListener("mousedown", handleClickOutside);
    }, []);

    const handleSelect = useCallback((val) => {
        onChange(val);
        setIsOpen(false);
    }, [onChange]);

    return (
        <div className="relative inline-block text-left" ref={dropdownRef}>
            <button
                type="button"
                disabled={disabled}
                onClick={() => !disabled && setIsOpen(!isOpen)}
                className={cn(
                    "flex items-center justify-between px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white ring-1 ring-black/10 rounded-lg cursor-pointer outline-none focus:ring-2 focus:ring-blue-500/30 transition-all shadow-sm w-full min-w-[120px] hover:bg-slate-50",
                    disabled && "opacity-60 cursor-not-allowed hover:bg-white pointer-events-none",
                    className
                )}
            >
                <span className="truncate mr-2 capitalize">{selectedOption?.label || placeholder}</span>
                <ChevronDown size={14} className={cn("transition-transform text-slate-400 shrink-0 ml-1", isOpen && "rotate-180")} />
            </button>

            <div
                style={{
                    transform: isOpen ? "translateY(0) scale(1)" : "translateY(-6px) scale(0.95)",
                    transitionProperty: "opacity, transform, visibility",
                }}
                className={cn(
                    "absolute right-0 top-full mt-1.5 min-w-full w-max bg-white border border-slate-100 rounded-lg shadow-lg py-1 overflow-hidden z-[9999] transition-all duration-200 origin-top",
                    isOpen ? "opacity-100 visible" : "opacity-0 invisible pointer-events-none",
                    menuClassName
                )}
            >
                {options.map((opt) => (
                    <button
                        key={opt.value}
                        type="button"
                        onClick={() => handleSelect(opt.value)}
                        className={cn(
                            "w-full text-left px-3 py-2 text-xs transition-colors flex items-center gap-2",
                            value === opt.value
                                ? "bg-slate-50 text-slate-900 font-bold"
                                : "text-slate-600 font-medium hover:bg-slate-50 hover:text-slate-900"
                        )}
                    >
                        <div className={cn("w-3.5 h-3.5 flex items-center justify-center shrink-0", value === opt.value ? "opacity-100" : "opacity-0")}>
                            <svg className={cn("w-3.5 h-3.5", iconClassName)} fill="none" stroke="currentColor" viewBox="0 0 24 24" strokeWidth="2.5">
                                <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                            </svg>
                        </div>
                        <span className="truncate capitalize">{opt.label}</span>
                    </button>
                ))}
            </div>
        </div>
    );
});

export default Select;
