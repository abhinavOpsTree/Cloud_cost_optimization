export function Header({ title, description, actions }) {
  return (
    <header className="flex items-center justify-between py-6 border-b border-accents-2 mb-8">
      <div className="flex flex-col gap-1">
        <h3 className="text-2xl font-semibold tracking-[-0.04em] text-geist-foreground">{title}</h3>
        <p className="text-sm text-accents-5 font-medium">{description}</p>
      </div>
      {actions && <div className="flex items-center gap-3">{actions}</div>}
    </header>

  )
}
