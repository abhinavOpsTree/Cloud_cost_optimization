import {  X } from "lucide-react";
import { useEffect, useState } from "react";

export const FullscreenChartModal = ({ title, subtitle, tooltip, children, onClose }) => {
    useEffect(() => {
        const handleKey = (e) => { if (e.key === "Escape") onClose(); };
        document.addEventListener("keydown", handleKey);
        return () => document.removeEventListener("keydown", handleKey);
    }, [onClose]);

    return (
        <div
            style={{
                position: "fixed", inset: 0, zIndex: 2000,
                background: "rgba(0,0,0,0.45)",
                display: "flex", alignItems: "center", justifyContent: "center",
                padding: 24,
            }}
            onClick={onClose}
            onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') onClose(); }}
            role="presentation"
        >
            <div
                style={{
                    background: "#fff", borderRadius: 16, width: "90vw", maxWidth: 1200,
                    maxHeight: "90vh", display: "flex", flexDirection: "column",
                    boxShadow: "0 24px 64px rgba(0,0,0,0.18)", overflow: "hidden",
                }}
                role="dialog"
                aria-modal="true"
                onClick={(e) => e.stopPropagation()}
                onKeyDown={(e) => e.stopPropagation()}
            >
                <div style={{
                    display: "flex", alignItems: "center", justifyContent: "space-between",
                    padding: "16px 24px", borderBottom: "1px solid #F0F1F5",
                }}>
                    <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                        <div>
                            <p style={{ margin: 0, fontSize: 16, fontWeight: 700, color: "#1A1A2E" }}>{title}</p>
                            {subtitle && <p style={{ margin: 0, fontSize: 12, color: "#9098b1", marginTop: 2 }}>{subtitle}</p>}
                        </div>
                    </div>
                    <button
                        onClick={onClose}
                        style={{
                            width: 30, height: 30, borderRadius: 8, border: "1.5px solid #E5E7EB",
                            background: "#fff", cursor: "pointer", fontSize: 18, color: "#374151",
                            display: "flex", alignItems: "center", justifyContent: "center",
                        }}
                    >
                        <X size={16} />
                    </button>
                </div>
                <div style={{ flex: 1, overflowY: "auto", padding: "20px 24px" }}>
                    {children}
                </div>
            </div>
        </div>
    );
};

export const ExpandableChartCard = ({ title, subtitle, icon, tooltip, loading, children }) => {
    const [expanded, setExpanded] = useState(false);

    return (
        <>
            <ChartCard
                icon={icon}
                title={title}
                subtitle={subtitle}
                tooltip={tooltip}
                loading={loading}
            >
                <div style={{ position: "relative" }}>
                    {!loading && (
                        <button
                            onClick={() => setExpanded(true)}
                            title="Expand chart"
                            style={{
                                position: "absolute", top: -50, right: 0,
                                width: 30, height: 30, borderRadius: 6,
                                border: "1.5px solid #E0E4EF", background: "#fff",
                                cursor: "pointer", display: "flex",
                                alignItems: "center", justifyContent: "center",
                                color: "#6B7280", zIndex: 5,
                                boxShadow: "0 1px 4px rgba(0,0,0,0.06)",
                            }}
                            onMouseEnter={(e) => { e.currentTarget.style.borderColor = "#0086FF"; e.currentTarget.style.color = "#0086FF"; }}
                            onMouseLeave={(e) => { e.currentTarget.style.borderColor = "#E0E4EF"; e.currentTarget.style.color = "#6B7280"; }}
                        >
                            <span className="ri-fullscreen-line" style={{ fontSize: 14 }} />
                        </button>
                    )}
                    {children}
                </div>
            </ChartCard>

            {expanded && (
                <FullscreenChartModal
                    title={title}
                    subtitle={subtitle}
                    tooltip={tooltip}
                    onClose={() => setExpanded(false)}
                >
                    {children}
                </FullscreenChartModal>
            )}
        </>
    );
};