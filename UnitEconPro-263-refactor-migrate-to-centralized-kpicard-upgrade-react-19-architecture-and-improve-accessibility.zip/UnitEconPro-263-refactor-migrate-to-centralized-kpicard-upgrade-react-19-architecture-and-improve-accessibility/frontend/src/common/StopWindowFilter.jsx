import { useState, useMemo } from "react";
import { ArrowRight, Calendar, Clock, X, ChevronDown, StopCircle } from "lucide-react";

// ─── constants ───────────────────────────────────────────────────────────────

const PRESETS = [
    { label: "Last 7d", days: 7 },
    { label: "Last 30d", days: 30 },
    { label: "Last 90d", days: 90 },
];

const DURATIONS = [
    { label: "Any", minHours: 0 },
    { label: "> 1h", minHours: 1 },
    { label: "> 6h", minHours: 6 },
    { label: "> 1d", minHours: 24 },
    { label: "> 3d", minHours: 72 },
];

const MONTH = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

const fmtDay = (d) => {
    if (!d || isNaN(d)) return "—";
    return `${MONTH[d.getMonth()]} ${d.getDate()}, ${d.getFullYear()}`;
};

const fmtTime = (d) => {
    if (!d || isNaN(d)) return "—";
    return (
        `${String(d.getHours()).padStart(2, "0")}:` +
        `${String(d.getMinutes()).padStart(2, "0")}`
    );
};

/** Human-readable duration from hours — handles 0.5 → 30m, 12 → 12h, 36 → 1.5d */
const durLabel = (hours) => {
    if (hours == null) return "—";
    const totalMins = Math.round(hours * 60);
    if (totalMins < 60) return `${totalMins}m`;
    const h = hours % 24;
    const d = Math.floor(hours / 24);
    if (d === 0) return `${hours % 1 === 0 ? hours : hours.toFixed(1)}h`;
    if (h === 0) return `${d}d`;
    return `${d}d ${h.toFixed(0)}h`;
};

/** Normalise a raw API gap to { start: Date, end: Date, hours: number } */
const normalise = (gap) => ({
    ...gap,
    start: gap.start instanceof Date ? gap.start : new Date(gap.gap_start ?? gap.start),
    end: gap.end instanceof Date ? gap.end : new Date(gap.gap_end ?? gap.end),
    hours:
        gap.hours != null
            ? gap.hours
            : gap.duration_days != null
                ? gap.duration_days * 24
                : null,
});


const StopWindowFilter = ({ gaps = [], emptyMessage }) => {
    const [presetLabel, setPresetLabel] = useState("Last 30d");
    const [durIdx, setDurIdx] = useState(0);
    const [showCustom, setShowCustom] = useState(false);
    const [customStart, setCustomStart] = useState("");
    const [customEnd, setCustomEnd] = useState("");

    // normalise once
    const normGaps = useMemo(() => gaps.map(normalise), [gaps]);

    const filtered = useMemo(() => {
        const minHours = DURATIONS[durIdx].minHours;
        const now = new Date();

        let rangeStart = null;
        let rangeEnd = null;

        if (showCustom) {
            if (customStart) rangeStart = new Date(customStart);
            if (customEnd) rangeEnd = new Date(customEnd);
        } else {
            const preset = PRESETS.find((p) => p.label === presetLabel);
            if (preset?.days != null) {
                rangeStart = new Date(now.getTime() - preset.days * 86_400_000);
            }
        }

        return normGaps.filter((g) => {
            if (minHours > 0 && (g.hours == null || g.hours < minHours)) return false;
            if (rangeStart && g.start < rangeStart) return false;
            if (rangeEnd && g.end > rangeEnd) return false;
            return true;
        });
    }, [normGaps, presetLabel, durIdx, showCustom, customStart, customEnd]);

    const hasActiveFilters =
        durIdx !== 0 ||
        presetLabel !== "All time" ||
        showCustom;

    const clearAll = () => {
        setPresetLabel("All time");
        setDurIdx(0);
        setCustomStart("");
        setCustomEnd("");
        setShowCustom(false);
    };

    return (
        <div className="space-y-4">
            {/* ── Filter bar ── */}
            <div className="bg-gray-50 border border-gray-200 rounded-xl p-4 space-y-3">

                {/* Row 1 – Date range */}
                <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-3 flex-wrap">
                    <div className="flex items-center gap-1.5 shrink-0">
                        <Calendar size={13} className="text-[var(--text-primary-color)]" />
                        <span className="text-[11px] font-semibold text-[var(--text-primary-color)] uppercase tracking-wider">
                            Range
                        </span>
                    </div>

                    {/* Preset pills */}
                    <div className="flex flex-wrap gap-1">
                        {PRESETS.map((p) => (
                            <button
                                key={p.label}
                                onClick={() => {
                                    setPresetLabel(p.label);
                                    setShowCustom(false);
                                }}
                                className={`text-xs px-2.5 py-1 rounded-lg border font-medium transition-all cursor-pointer ${presetLabel === p.label && !showCustom
                                    ? "bg-blue-600 text-white border-blue-600 shadow-sm"
                                    : "bg-white text-gray-600 border-gray-200 hover:border-blue-300 hover:text-blue-600"
                                    }`}
                            >
                                {p.label}
                            </button>
                        ))}

                        {/* Custom toggle */}
                        <button
                            onClick={() => {
                                setShowCustom((v) => !v);
                                setPresetLabel("All time");
                            }}
                            className={`text-xs px-2.5 py-1 rounded-lg border font-medium transition-all flex items-center gap-1 cursor-pointer ${showCustom
                                ? "bg-blue-600 text-white border-blue-600"
                                : "bg-white text-gray-600 border-gray-200 hover:border-blue-300 hover:text-blue-600"
                                }`}
                        >
                            Custom
                            <ChevronDown
                                size={11}
                                className={`transition-transform ${showCustom ? "rotate-180" : ""}`}
                            />
                        </button>
                    </div>
                </div>

                {/* Custom date range inputs */}
                {showCustom && (
                    <div className="flex flex-col sm:flex-row sm:items-center gap-2 pl-0 sm:pl-5 flex-wrap">
                        <input
                            type="datetime-local"
                            value={customStart}
                            onChange={(e) => setCustomStart(e.target.value)}
                            className="text-xs border border-gray-200 rounded-lg px-2.5 py-1.5 text-gray-700 bg-white focus:outline-none focus:ring-1 focus:ring-blue-400 w-full sm:w-auto"
                        />
                        <ArrowRight size={13} className="text-[var(--text-primary-color)] shrink-0 hidden sm:block" />
                        <input
                            type="datetime-local"
                            value={customEnd}
                            onChange={(e) => setCustomEnd(e.target.value)}
                            className="text-xs border border-gray-200 rounded-lg px-2.5 py-1.5 text-gray-700 bg-white focus:outline-none focus:ring-1 focus:ring-blue-400 w-full sm:w-auto"
                        />
                    </div>
                )}

                {/* Row 2 – Duration */}
                <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-3 flex-wrap">
                    <div className="flex items-center gap-1.5 shrink-0">
                        <Clock size={13} className="text-[var(--text-primary-color)]" />
                        <span className="text-[11px] font-semibold text-[var(--text-primary-color)] uppercase tracking-wider">
                            Duration
                        </span>
                    </div>

                    <div className="flex flex-wrap gap-1">
                        {DURATIONS.map((d, i) => (
                            <button
                                key={d.label}
                                onClick={() => setDurIdx(i)}
                                className={`text-xs px-2.5 py-1 rounded-lg border font-medium transition-all cursor-pointer ${durIdx === i
                                    ? "bg-red-50 text-red-700 border-red-300"
                                    : "bg-white text-gray-600 border-gray-200 hover:border-red-200 hover:text-red-600"
                                    }`}
                            >
                                {d.label}
                            </button>
                        ))}
                    </div>
                </div>

                {/* Clear row */}
                {hasActiveFilters && (
                    <div className="flex justify-end pt-2 border-t border-gray-200">
                        <button
                            onClick={clearAll}
                            className="flex items-center gap-1 text-xs text-[var(--text-primary-color)] hover:text-red-600 transition-colors cursor-pointer"
                        >
                            <X size={12} /> Clear filters
                        </button>
                    </div>
                )}
            </div>

            {/* ── Header row – sticky ── */}
            <div className="sticky top-0 z-10 bg-white py-2 h-20  flex items-center justify-between border-b border-gray-100">
                <p className="text-[11px] font-bold text-[var(--text-primary-color)] uppercase tracking-widest">
                    Detected stop windows
                </p>
                <span
                    className={`text-xs font-semibold px-2.5 py-0.5 rounded-full border ${filtered.length > 0
                        ? "bg-red-50 text-red-600 border-red-200"
                        : "bg-gray-50 text-[var(--text-primary-color)] border-gray-200"
                        }`}
                >
                    {filtered.length} gap{filtered.length !== 1 ? "s" : ""}
                </span>
            </div>

            {/* ── Gap list ── */}
            {filtered.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 text-center">
                    <div className="w-12 h-12 bg-green-50 rounded-2xl flex items-center justify-center mb-3">
                        <StopCircle size={22} className="text-green-400" />
                    </div>
                    <p className="text-sm font-semibold text-gray-500">
                        {emptyMessage ?? "No stop windows match your filters."}
                    </p>
                    <p className="text-xs text-[var(--text-primary-color)] mt-1">
                        Try adjusting the date range or duration filter.
                    </p>
                </div>
            ) : (
                <div className="flex flex-col gap-2 overflow-y-auto max-h-[380px] pr-1 scrollbar-thin scrollbar-thumb-gray-200 scrollbar-track-transparent">
                    {filtered.map((g, i) => (
                        <div
                            key={i}
                            className="flex items-center gap-3 border border-gray-200 rounded-xl px-4 py-3.5 bg-white hover:border-gray-300 hover:shadow-sm transition-all"
                        >
                            {/* Index */}
                            <span className="text-xs font-bold bg-red-50 text-red-500 border border-red-200 w-8 h-8 rounded-full flex items-center justify-center shrink-0">
                                {i + 1}
                            </span>

                            {/* Start block */}
                            <div className="flex flex-col min-w-0">
                                <span className="text-[10px] font-semibold text-[var(--text-primary-color)] uppercase tracking-wider mb-0.5">Start</span>
                                <span className="text-sm font-semibold text-gray-800 leading-tight">{fmtDay(g.start)}</span>
                                <span className="text-xs font-mono text-gray-500 mt-0.5">{fmtTime(g.start)}</span>
                            </div>

                            {/* Arrow */}
                            <div className="flex flex-col items-center gap-0.5 shrink-0 px-1">
                                <div className="w-px h-3 bg-gray-200" />
                                <ArrowRight size={14} className="text-gray-300" />
                                <div className="w-px h-3 bg-gray-200" />
                            </div>

                            {/* End block */}
                            <div className="flex flex-col min-w-0 flex-1">
                                <span className="text-[10px] font-semibold text-[var(--text-primary-color)] uppercase tracking-wider mb-0.5">Stop</span>
                                <span className="text-sm font-semibold text-gray-800 leading-tight">{fmtDay(g.end)}</span>
                                <span className="text-xs font-mono text-gray-500 mt-0.5">{fmtTime(g.end)}</span>
                            </div>

                            {/* Duration badge */}
                            <span className="ml-auto text-sm font-bold text-orange-700 bg-orange-50 border border-orange-200 px-3 py-1.5 rounded-lg shrink-0">
                                {durLabel(g.hours)}
                            </span>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
};

export default StopWindowFilter;
