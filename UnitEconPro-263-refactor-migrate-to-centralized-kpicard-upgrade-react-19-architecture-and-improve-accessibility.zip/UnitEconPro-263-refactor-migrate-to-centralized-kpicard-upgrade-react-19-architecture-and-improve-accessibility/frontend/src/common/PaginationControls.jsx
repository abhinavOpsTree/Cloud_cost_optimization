import { ChevronLeft, ChevronRight } from "lucide-react";
import { cn } from "../lib/cn";

const PaginationControls = ({ currentPage, totalPages = 6, onPageChange }) => {
  if (!totalPages || totalPages <= 0) return null;

  return (
    <div className="flex items-center justify-center py-6 gap-3">
      <button
        className={cn(
          "inline-flex items-center gap-1 py-1.5 px-3 text-xs font-bold transation-shadow cursor-pointer transition-all rounded ring-1 ring-black/5  disabled:cursor-not-allowed",
          currentPage > 1 && totalPages > 1
            ? "bg-[var(--button-bg)] text-white hover:opacity-90 shadow-sm"
            : "bg-neutral-100 text-[var(--text-secondary-color)] shadow-inner/2"
        )}
        disabled={currentPage === 1 || totalPages <= 1}
        onClick={() => onPageChange(currentPage - 1)}
      >
        <ChevronLeft size={14} />
        Previous
      </button>

      <div className="flex items-center gap-2 px-2">
        <span className="text-xs font-bold text-[var(--text-primary-color)]">
          {currentPage}
        </span>
        <span className="text-[10px] text-neutral-400 font-medium uppercase tracking-wider">of</span>
        <span className="text-xs font-bold text-[var(--text-primary-color)]">
          {totalPages}
        </span>
      </div>

      <button
        className={cn(
          "inline-flex items-center gap-1 py-1.5 px-3 text-xs font-bold transition-all cursor-pointer rounded ring-1 ring-black/10 disabled:cursor-not-allowed",
          currentPage < totalPages && totalPages > 1
            ? "bg-[var(--button-bg)] text-white hover:opacity-90"
            : "bg-neutral-100 text-[var(--text-primary-color)] shadow-inner/2"
        )}
        disabled={currentPage === totalPages || totalPages <= 1}
        onClick={() => onPageChange(currentPage + 1)}
      >
        Next
        <ChevronRight size={14} />
      </button>
    </div>

  );
};

export default PaginationControls;
