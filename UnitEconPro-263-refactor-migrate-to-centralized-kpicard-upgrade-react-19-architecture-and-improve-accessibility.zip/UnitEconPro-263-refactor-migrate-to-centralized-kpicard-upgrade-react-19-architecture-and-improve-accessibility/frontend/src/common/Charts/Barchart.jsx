import { useMemo } from 'react';
import Highcharts from 'highcharts';
import HighchartsReact from 'highcharts-react-official';
import {  AlertCircle, Loader } from "lucide-react";
import { GlassCard } from "../../components/common/GlassCard";
import { useNavigate } from 'react-router-dom';
import ErrorBoundary from '../ErrorBoundary';

function BarchartInner({ data = [], isLoading, isFetching, isError }) {
  const navigate = useNavigate();
  
  const allZero = useMemo(() => {
    if (!data || data.length === 0) return true;
    return data.every(d => Number(d.cost || 0) < 0.01);
  }, [data]);

  const isGhost = isLoading || isError || allZero;

  const options = useMemo(() => {
    const dummyData = [
      { name: " ", y: 100 },
      { name: "  ", y: 80 },
      { name: "   ", y: 60 },
      { name: "    ", y: 40 },
      { name: "     ", y: 20 },
    ];

    const chartDataToRender = isGhost ? dummyData : data.map(d => ({ name: d.name, y: d.cost }));
    const categories = isGhost ? dummyData.map(d => d.name) : data.map(d => d.name);

    return {
      chart: {
        type: 'column',
        backgroundColor: 'transparent',
        spacingBottom: 25,
        animation: {
          duration: 1500
        }
      },
      colors: isGhost 
        ? [{ linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 }, stops: [[0, '#f3f4f6'], [1, '#f3f4f6']] }]
        : [
        { linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 }, stops: [[0, '#6366f1'], [1, '#c7d2fe']] }, // Soft Indigo
        { linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 }, stops: [[0, '#10b981'], [1, '#a7f3d0']] }, // Soft Emerald
        { linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 }, stops: [[0, '#f43f5e'], [1, '#fecdd3']] }, // Soft Rose
        { linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 }, stops: [[0, '#f59e0b'], [1, '#fde68a']] }, // Soft Amber
        { linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 }, stops: [[0, '#8b5cf6'], [1, '#ddd6fe']] }, // Soft Violet
        { linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 }, stops: [[0, '#0ea5e9'], [1, '#bae6fd']] }, // Soft Sky Blue
        { linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 }, stops: [[0, '#14b8a6'], [1, '#99f6e4']] }, // Soft Teal
        { linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 }, stops: [[0, '#ec4899'], [1, '#fbcfe8']] }, // Soft Pink
      ],
      title: { text: '' },
      credits: { enabled: false },
      xAxis: {
        categories: categories,
        labels: {
          style: { color: '#64748b', fontSize: '10px', fontWeight: '500' }
        },
        lineWidth: 0,
        tickWidth: 0,
      },
      yAxis: {
        visible: true,
        title: { text: '' },
        gridLineColor: 'rgba(226, 232, 240, 0.6)',
        gridLineDashStyle: 'Dash',
        labels: {
          style: { color: '#94a3b8', fontSize: '10px', fontWeight: '500' },
          formatter: function () {
            return '$' + this.value.toLocaleString(undefined, { maximumFractionDigits: 0 });
          }
        }
      },
      tooltip: {
        enabled: !isGhost,
        backgroundColor: 'transparent',
        borderColor: 'transparent',
        shadow: false,
        useHTML: true,
        style: { pointerEvents: 'none' },
        formatter: function () {
          return `<div style="background: rgba(255, 255, 255, 0.6); backdrop-filter: blur(8px); border: 1px solid rgba(255,255,255,0.4); border-radius: 8px; padding: 8px 12px; color: #1e293b; font-size: 12px; font-weight: 500; box-shadow: 0 4px 6px rgba(0,0,0,0.05);">
            <span style="font-weight: 700; font-size: 13px;">${this.point.name}</span><br/>
            $${this.y?.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>`;
        }
      },
      plotOptions: {
        series: {
          enableMouseTracking: !isGhost,
          animation: {
            duration: 1500
          },
          cursor: isGhost ? 'default' : 'pointer',
          point: {
            events: {
              click: function () {
                const serviceName = this.name.toLowerCase();
                
                // Compute
                if (serviceName.includes('ec2')) return navigate('/compute/ec2');
                if (serviceName.includes('eks')) return navigate('/compute/eks');
                if (serviceName.includes('ecs')) return navigate('/compute/ecs');
                if (serviceName.includes('ecr')) return navigate('/compute/ecr');
                
                // Storage
                if (serviceName.includes('s3')) return navigate('/storage/s3');
                if (serviceName.includes('ebs')) return navigate('/storage/ebs');
                
                // Networking
                if (serviceName.includes('vpc')) return navigate('/networking/vpc');
                if (serviceName.includes('elb') || serviceName.includes('elasticloadbalancing')) return navigate('/networking/elb');
                if (serviceName.includes('transfer')) return navigate('/networking/datatransfer');
                
                // Databases
                if (serviceName.includes('rds')) return navigate('/databases/rds');
                
                // Monitoring
                if (serviceName.includes('cloudwatch')) return navigate('/monitoring/cloudwatch');
                
                console.warn("No route mapped for service:", this.name);
              }
            }
          }
        },
        column: {
          colorByPoint: true,
          borderRadius: 6,
          pointPadding: 0.1,
          groupPadding: 0.05,
          borderWidth: 0,
        }
      },
      series: [{
        type: 'column',
        data: chartDataToRender,
        showInLegend: false,
      }],
      legend: { enabled: false }
    };
  }, [data, isGhost]);

  return (
    <GlassCard className="w-full h-full flex flex-col p-4 bg-transparent border-none shadow-none">
      <div className="flex flex-col pb-0 w-full">
        <div className="flex justify-between items-center mb-4 w-full">
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-semibold text-foreground tracking-tight">Service Breakdown By Cost</h3>
          </div>
        </div>
      </div>
      <div className="flex-1 pt-4">
        <div className="w-full h-[400px] relative bg-white/50 dark:bg-white/30 rounded-md shadow-sm border border-blue-200/50 dark:border-blue-900/30 p-2 flex items-center justify-center">

          <HighchartsReact
            highcharts={Highcharts}
            options={options}
            updateArgs={[true, true, true]}
            containerProps={{ style: { width: "100%", height: "100%" } }}
          />

          {isGhost && (
            <div className="absolute inset-0 z-10 flex flex-col items-center justify-center bg-white/20 backdrop-blur-[1.5px] rounded-md transition-opacity duration-300 pointer-events-none">
              {isLoading ? (
                <div className="flex flex-col items-center gap-2 text-slate-500 bg-white/80 px-4 py-2 rounded-lg shadow-sm">
                  <Loader size={24} className="animate-spin text-blue-500" />
                  <span className="text-xs font-semibold">Loading breakdown...</span>
                </div>
              ) : isError ? (
                <div className="flex items-center gap-2 text-red-500 font-medium bg-white/90 px-4 py-2 rounded-lg shadow-sm">
                  <AlertCircle size={20} />
                  <span>Failed to load data</span>
                </div>
              ) : (
                <span className="text-sm font-semibold text-gray-500 bg-white/90 px-4 py-2 rounded-lg shadow-sm ring-1 ring-black/5">
                  No Data Available
                </span>
              )}
            </div>
          )}
        </div>
      </div>
    </GlassCard>
  );
}

export function Barchart(props) {
  return (
    <ErrorBoundary>
      <BarchartInner {...props} />
    </ErrorBoundary>
  );
}
