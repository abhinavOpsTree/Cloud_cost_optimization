import React, { Suspense, lazy } from 'react';

const LazyComponent = lazy(() => import('./Linechart').then(m => ({ default: m.Linechart })));

export const Linechart = (props) => (
    <Suspense fallback={<div className="h-[300px] w-full animate-pulse bg-neutral-100 rounded-xl"></div>}>
        <LazyComponent {...props} />
    </Suspense>
);
