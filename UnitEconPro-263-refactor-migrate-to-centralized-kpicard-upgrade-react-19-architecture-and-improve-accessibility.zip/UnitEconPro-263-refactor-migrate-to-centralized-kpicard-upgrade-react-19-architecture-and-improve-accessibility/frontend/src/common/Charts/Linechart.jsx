import { useState, useMemo, useContext } from "react";
import { useAnnotationDates } from "../../hooks/useAnnotations";
import { FiltersContext } from "../../context/FiltersContext";
import {
    AreaChart,
    Area,
    XAxis,
    YAxis,
    CartesianGrid,
    Tooltip,
    ResponsiveContainer,
    ReferenceLine,
} from "recharts";
import { AnnotationModal } from "./AnnotationModal";
import ErrorBoundary from "../ErrorBoundary";

// RESPONSIVENESS: Custom tick component to align first label to the left ('start')
// and last label to the right ('end') to prevent truncation or overlap with the Y-axis.
const CustomXAxisTick = (props) => {
    const { x, y, payload, index, visibleTicksCount } = props;

    let textAnchor = "middle";
    if (index === 0) {
        textAnchor = "start";
    } else if (index === visibleTicksCount - 1) {
        textAnchor = "end";
    }

    return (
        <text x={x} y={y} dy={10} fontSize={10} fill="#9ca3af" textAnchor={textAnchor}>
            {payload.value}
        </text>
    );
};

export function LinechartInner({ chartdata = [], name, service, isLoading, isError, avgCost }) {
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [selectedDate, setSelectedDate] = useState(null);
    const [hiddenSeries, setHiddenSeries] = useState({ current: false, avg: false, annotations: false });

    const toggleSeries = (key) => {
        setHiddenSeries(prev => ({ ...prev, [key]: !prev[key] }));
    };

    const allZero = useMemo(() => {
        if (!chartdata || chartdata.length === 0) return true;
        return chartdata.every(d => Number(d.cost || 0) < 0.01);
    }, [chartdata]);

    const isGhost = isLoading || isError || allZero;

    const data = useMemo(() => {
        if (isGhost) {
            return [
                { date: 'Jan 1', cost: 30, avgCost: 50, originalDate: '2026-01-01' },
                { date: 'Jan 2', cost: 70, avgCost: 50, originalDate: '2026-01-02' },
                { date: 'Jan 3', cost: 45, avgCost: 50, originalDate: '2026-01-03' },
                { date: 'Jan 4', cost: 80, avgCost: 50, originalDate: '2026-01-04' },
                { date: 'Jan 5', cost: 65, avgCost: 50, originalDate: '2026-01-05' },
            ];
        }
        return chartdata.map(d => ({
            ...d,
            originalDate: d.date, // keep original date for API calls
            avgCost: avgCost,
            date: new Date(d.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
        }));
    }, [chartdata, avgCost, isGhost]);

    const intervalVal = Math.max(0, Math.ceil(data.length / 15) - 1);

    const dateRange = useMemo(() => {
        if (!chartdata || chartdata.length === 0) return { start: null, end: null };
        const dates = chartdata.map(d => new Date(d.date).getTime()).filter(t => !isNaN(t));
        if (dates.length === 0) return { start: null, end: null };
        return {
            start: new Date(Math.min(...dates)).toISOString().split('T')[0],
            end: new Date(Math.max(...dates)).toISOString().split('T')[0]
        };
    }, [chartdata]);

    const { filters } = useContext(FiltersContext);
    const activeAccount = filters?.account || 'All';

    const { annotationDates } = useAnnotationDates(activeAccount, service || 'All', dateRange.start, dateRange.end);

    const annotatedDatesSet = useMemo(() => {
        return new Set(annotationDates.map(a => a.event_date));
    }, [annotationDates]);

    const renderCustomDot = (props) => {
        const { cx, cy, payload } = props;
        if (!payload || !payload.originalDate || hiddenSeries.annotations) return null;

        try {
            const dateStr = new Date(payload.originalDate).toISOString().split('T')[0];
            if (annotatedDatesSet.has(dateStr)) {
                return (
                    <circle
                        cx={cx}
                        cy={cy}
                        r={4.5}
                        fill="#f97316"
                        stroke="#fff"
                        strokeWidth={1.5}
                        style={{ cursor: 'pointer', zIndex: 10, pointerEvents: 'auto' }}
                        onClick={(e) => {
                            e.stopPropagation();
                            setSelectedDate(dateStr);
                            setIsModalOpen(true);
                        }}
                    />
                );
            }
        } catch (_e) {
            return null;
        }
        return null;
    };

    const handleChartClick = (e) => {
        if (e && e.activePayload && e.activePayload.length > 0) {
            const clickedData = e.activePayload[0].payload;
            if (clickedData && clickedData.originalDate) {
                try {
                    const dateStr = new Date(clickedData.originalDate).toISOString().split('T')[0];
                    setSelectedDate(dateStr);
                    setIsModalOpen(true);
                } catch (err) {
                    console.error("Invalid date format clicked", err);
                }
            }
        }
    };

    const handleDotClick = (event, payload) => {
        if (payload && payload.payload && payload.payload.originalDate) {
            try {
                const dateStr = new Date(payload.payload.originalDate).toISOString().split('T')[0];
                setSelectedDate(dateStr);
                setIsModalOpen(true);
            } catch (err) {
                console.error("Invalid date format clicked", err);
            }
        }
    };

    return (
        <div className="w-full bg-white p-4 rounded-xl ring-[.5px] ring-black/10 shadow-[var(--shadow)] relative">
            <h3 className="text-md font-semibold mb-3">Cost Trend</h3>
            {/* RESPONSIVENESS: Wrapper to support horizontal scroll on mobile devices */}
            <div className="w-full overflow-x-auto pb-2">
                {/* RESPONSIVENESS: Establish min-width to ensure chart remains legible on smaller viewports */}
                <div className="w-full min-w-[600px] h-[300px] relative">
                    <ResponsiveContainer width="100%" height="100%">
                        <AreaChart
                            data={data}
                            margin={{ top: 10, right: 10, left: -20, bottom: 0 }}
                            onClick={handleChartClick}
                            style={{ cursor: 'pointer' }}
                        >
                            <defs>
                                <linearGradient id="colorCost" x1="0" y1="0" x2="0" y2="1">
                                    <stop offset="5%" stopColor={isGhost ? "#cbd5e1" : "#3b82f6"} stopOpacity={0.2} />
                                    <stop offset="95%" stopColor={isGhost ? "#cbd5e1" : "#3b82f6"} stopOpacity={0} />
                                </linearGradient>
                                <linearGradient id="colorPrevious" x1="0" y1="0" x2="0" y2="1">
                                    <stop offset="5%" stopColor="#94a3b8" stopOpacity={0.05} />
                                    <stop offset="95%" stopColor="#94a3b8" stopOpacity={0} />
                                </linearGradient>
                                <linearGradient id="colorAvgCost" x1="0" y1="0" x2="0" y2="1">
                                    <stop offset="5%" stopColor={isGhost ? "#e2e8f0" : "#ed80f5ff"} stopOpacity={0.2} />
                                    <stop offset="95%" stopColor={isGhost ? "#e2e8f0" : "#ed80f5ff"} stopOpacity={0} />
                                </linearGradient>
                            </defs>
                            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                            {/* RESPONSIVENESS: Zero padding extends line to Y-axis; CustomXAxisTick handles label alignment */}
                            <XAxis
                                dataKey="date"
                                axisLine={false}
                                tickLine={false}
                                tick={<CustomXAxisTick />}
                                interval={intervalVal}
                                padding={{ left: 0, right: 0 }}
                            />
                            <YAxis
                                axisLine={false}
                                tickLine={false}
                                tick={{ fontSize: 10, fill: "#9ca3af" }}
                                tickFormatter={(val) => `$${val}`}
                            />
                            {!isGhost && (
                                <Tooltip
                                    contentStyle={{
                                        fontSize: '12px',
                                        borderRadius: '8px',
                                        border: '1px solid rgba(0,0,0,0.1)',
                                        padding: '12px',
                                        backgroundColor: "rgba(209,213,219,0.15)",
                                    }}
                                    formatter={(value) => [`$${value.toLocaleString()}`, name]}
                                />
                            )}
                            {!hiddenSeries.avg && avgCost !== undefined && avgCost !== null && (
                                <>
                                    <ReferenceLine
                                        y={isGhost ? 50 : avgCost}
                                        stroke={isGhost ? "#cbd5e1" : "#ed80f5ff"}
                                        strokeDasharray="3 3"
                                    />
                                    <Area
                                        type="monotone"
                                        dataKey="avgCost"
                                        stroke="none"
                                        fillOpacity={1}
                                        fill="url(#colorAvgCost)"
                                        animationDuration={1500}
                                        activeDot={false}
                                        tooltipType="none"
                                    />
                                </>
                            )}
                            {!hiddenSeries.current && (
                                <Area
                                    type="monotone"
                                    dataKey="cost"
                                    name={name}
                                    stroke={isGhost ? "#94a3b8" : "#3b82f6"}
                                    strokeWidth={2}
                                    fillOpacity={1}
                                    fill="url(#colorCost)"
                                    animationDuration={1500}
                                    dot={isGhost ? false : renderCustomDot}
                                    activeDot={isGhost ? false : { r: 5, fill: "#3b82f6", onClick: handleDotClick, style: { cursor: 'pointer', pointerEvents: 'auto' } }}
                                />
                            )}
                        </AreaChart>
                    </ResponsiveContainer>

                    {isGhost && (
                        <div className="absolute inset-0 z-10 flex flex-col items-center justify-center bg-white/20 backdrop-blur-[1.5px] rounded-md transition-opacity duration-300 pointer-events-none">
                            {isLoading ? (
                                <div className="flex flex-col items-center gap-2 text-slate-500 bg-white/80 px-4 py-2 rounded-lg shadow-sm">
                                    <div className="w-6 h-6 border-[3px] border-teal-200 border-t-teal-500 rounded-full animate-spin" />
                                    <span className="text-xs font-semibold">Loading chart...</span>
                                </div>
                            ) : isError ? (
                                <div className="flex items-center gap-2 text-red-500 font-medium bg-white/90 px-4 py-2 rounded-lg shadow-sm">
                                    <span>Error loading data</span>
                                </div>
                            ) : (
                                <span className="text-sm font-semibold text-gray-500 px-4 py-2 rounded-lg">
                                    No Data Available
                                </span>
                            )}
                        </div>
                    )}
                </div>
            </div>
            <div className="flex items-center gap-6 mt-4 pt-4 border-t border-gray-50">
                <div className="flex items-center justify-between w-full">
                    <div className="flex items-center gap-6">
                        <button 
                            type="button"
                            className={`flex items-center gap-2 cursor-pointer transition-all hover:opacity-80 bg-transparent border-none p-0 ${hiddenSeries.current ? 'opacity-40 grayscale' : ''}`}
                            onClick={() => toggleSeries('current')}
                        >
                            <div className="w-2 h-2 rounded-full bg-blue-500"></div>
                            <span className="text-[11px] font-medium text-gray-400">Current Period</span>
                        </button>
                        <button 
                            type="button"
                            className={`flex items-center gap-2 cursor-pointer transition-all hover:opacity-80 bg-transparent border-none p-0 ${hiddenSeries.avg ? 'opacity-40 grayscale' : ''}`}
                            onClick={() => toggleSeries('avg')}
                        >
                            <div className="w-2 h-2 rounded-full bg-[#ed80f5ff]"></div>
                            <span className="text-[11px] font-medium text-gray-400">
                                Avg Cost {avgCost !== undefined && avgCost !== null ? `($${Number(avgCost).toLocaleString(undefined, { maximumFractionDigits: 2 })})` : ''}
                            </span>
                        </button>
                    </div>
                    <button 
                        type="button"
                        className={`flex items-center gap-2 cursor-pointer transition-all hover:opacity-80 bg-transparent border-none p-0 ${hiddenSeries.annotations ? 'opacity-40 grayscale' : ''}`}
                        onClick={() => toggleSeries('annotations')}
                    >
                        <div className="w-2 h-2 rounded-full bg-orange-500"></div>
                        <span className="text-[11px] font-medium text-gray-400">Annotations</span>
                    </button>
                </div>
            </div>

            <AnnotationModal
                isOpen={isModalOpen}
                onClose={() => setIsModalOpen(false)}
                date={selectedDate}
                account_name={activeAccount}
                service={service || 'All'}
            />
        </div>
    );
}

export function Linechart(props) {
    return (
        <ErrorBoundary>
            <LinechartInner {...props} />
        </ErrorBoundary>
    );
}
