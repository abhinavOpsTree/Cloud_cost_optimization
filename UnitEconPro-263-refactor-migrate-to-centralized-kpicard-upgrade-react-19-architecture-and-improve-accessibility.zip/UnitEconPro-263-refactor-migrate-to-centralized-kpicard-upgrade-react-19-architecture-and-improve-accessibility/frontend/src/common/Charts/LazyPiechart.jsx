import React, { Suspense, lazy } from 'react';

const LazyComponent = lazy(() => import('./Piechart').then(m => ({ default: m.RoundedPieChart })));

export const RoundedPieChart = (props) => (
    <Suspense fallback={<div className="h-[300px] w-full animate-pulse bg-neutral-100 rounded-xl"></div>}>
        <LazyComponent {...props} />
    </Suspense>
);
