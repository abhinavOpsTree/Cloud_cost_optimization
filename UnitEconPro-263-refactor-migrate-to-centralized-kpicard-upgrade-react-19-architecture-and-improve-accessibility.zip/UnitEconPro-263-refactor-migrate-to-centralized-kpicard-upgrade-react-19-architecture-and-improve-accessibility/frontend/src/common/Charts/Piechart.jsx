import Highcharts from "highcharts";
import { useEffect, useRef, useMemo } from "react";
import { Loader } from "lucide-react";
import ErrorBoundary from "../ErrorBoundary";

const COLORS = [
  "#3b82f6",
  "#2dd4bf",
  "#a855f7",
  "#f97316",
  "#06b6d4",
  "#ef4444",
  "#8b5cf6",
  "#ec4899",
  "#84cc16",
];

export function RoundedPieChartInner({
  chartData = [],
  isLoading,
  isError,
  title,
  dataKey = "cost",
  nameKey = "name",
}) {
  const chartRef = useRef(null);

  const normalizedData = useMemo(() => {
    if (!Array.isArray(chartData)) return [];
    return chartData
      .filter((item) => Number(item[dataKey] ?? 0) >= 0.01)
      .map((item, index) => ({
        name: item[nameKey] || `Item ${index + 1}`,
        y: Number(item[dataKey] ?? 0),
        unit: item.unit,
      }));
  }, [chartData, dataKey, nameKey]);

  useEffect(() => {
    if (
      !chartRef.current ||
      isLoading ||
      isError
    ) {
      return;
    }

    const isGhost = normalizedData.length === 0;
    const chartDataToRender = isGhost ? [{ name: "No Data", y: 1 }] : normalizedData;

    const chart = Highcharts.chart(chartRef.current, {
      chart: {
        type: "pie",
        backgroundColor: "transparent",
        spacing: [8, 8, 8, 8],
      },

      title: {
        text: "",
      },

      credits: {
        enabled: false,
      },

      tooltip: {
        useHTML: true,
        outside: true,
        zIndex: 999,
        enabled: !isGhost,
        backgroundColor: "rgba(255,255,255,0.95)",
        borderColor: "rgba(0,0,0,0.08)",
        borderRadius: 8,
        style: {
          color: "#111827",
          fontSize: "12px",
          zIndex: 9999,
        },
        headerFormat: "",
        pointFormat:
          '<span style="color:{point.color}">●</span> <b>{point.name}</b><br/>' +
          'Cost: <b>${point.y:.2f}</b><br/>' +
          'Share: <b>{point.percentage:.1f}%</b>',
      },
      plotOptions: {
        pie: {
          allowPointSelect: !isGhost,
          cursor: isGhost ? "default" : "pointer",

          dataLabels: {
            enabled: !isGhost,
            useHTML: true,
            distance: 18,

            formatter: function () {
              const cost = Highcharts.numberFormat(this.point.y, 2);
              const percentage = Highcharts.numberFormat(
                this.point.percentage,
                1
              );

              return `
                <div style="text-align:center; font-size:11px; line-height:14px;">
                  <div style="font-weight:600; color:#111827;">
                    ${this.point.name}
                  </div>
                  <div style="font-weight:500; color:#4B5563;">
                    $${cost}
                  </div>
                  <div style="font-weight:500; color:#6B7280;">
                    ${percentage}%
                  </div>
                </div>
              `;
            },

            style: {
              fontSize: "11px",
              fontWeight: "500",
              textOutline: "none",
            },
          },

          showInLegend: !isGhost,
          states: {
            hover: {
              enabled: !isGhost
            },
            inactive: {
              opacity: 1
            }
          }
        },
      },

      legend: {
        enabled: !isGhost,
        layout: "horizontal",
        align: "center",
        verticalAlign: "bottom",

        itemStyle: {
          fontSize: "11px",
          fontWeight: "500",
          color: "#6B7280",
        },
      },

      series: [
        {
          type: "pie",
          name: title,
          colorByPoint: true,
          colors: isGhost ? ["#f3f4f6"] : COLORS,
          borderRadius: 6,
          data: chartDataToRender,
        },
      ],
    });

    return () => {
      chart.destroy();
    };
  }, [normalizedData, title, isLoading, isError]);

  if (isLoading) {
    return (
      <div className="w-full bg-white p-4 rounded-xl ring-[.5px] ring-black/10 flex items-center justify-center h-[350px]">
        <Loader size={24} className="animate-spin text-blue-500" />
      </div>
    );
  }

  if (isError) {
    return (
      <div className="w-full bg-white p-4 rounded-xl ring-[.5px] ring-black/10 flex items-center justify-center h-[350px] text-red-500 font-medium">
        Error loading data
      </div>
    );
  }

  return (
    <div className="w-full bg-white p-4 rounded-xl ring-[.5px] ring-black/10 flex flex-col shadow-[var(--shadow)]">
      <div className="flex items-center justify-between mb-4 px-2">
        <h3 className="text-sm font-bold text-[var(--text-primary-color)] capitalize">
          {title}
        </h3>
      </div>

      <div className="w-full h-[300px] relative">
        <div ref={chartRef} className="w-full h-full" />
        {normalizedData.length === 0 && (
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-10">
            <span className="text-sm font-semibold text-gray-500  px-4 py-2 rounded-lg backdrop-blur-sm  ">
              No Data Available
            </span>
          </div>
        )}
      </div>
    </div>
  );
}

export function RoundedPieChart(props) {
  return (
    <ErrorBoundary>
      <RoundedPieChartInner {...props} />
    </ErrorBoundary>
  );
}