import React, { useState } from 'react';
import { X, Edit2, Trash2 } from 'lucide-react';
import { useAnnotations } from '../../hooks/useAnnotations';
import { useAuth } from '../../providers/AuthContext';export function AnnotationModal({ 
    isOpen, 
    onClose, 
    date, 
    account_name, 
    service 
}) {
    const [newText, setNewText] = useState('');
    const [editingId, setEditingId] = useState(null);
    const [editText, setEditText] = useState('');
    const { 
        annotations, 
        isLoading, 
        isError, 
        createAnnotation, 
        isCreating,
        deleteAnnotation,
        isDeleting,
        updateAnnotation,
        isUpdating
    } = useAnnotations(
        account_name || 'All', 
        service || 'All', 
        date
    );

    const { keycloak } = useAuth();
    const userName = keycloak?.tokenParsed?.preferred_username || keycloak?.tokenParsed?.name || 'Unknown User';

    if (!isOpen) return null;

    const handleAdd = async () => {
        if (!newText.trim()) return;
        
        try {
            await createAnnotation({
                account_name: account_name || 'All',
                service: service || 'All',
                event_date: date,
                annotation_text: newText,
                created_by: userName
            });
            setNewText('');
        } catch (error) {
            console.error("Failed to add annotation", error);
        }
    };

    const handleEdit = async (id) => {
        if (!editText.trim()) return;
        
        try {
            await updateAnnotation({
                id, 
                data: { annotation_text: editText }
            });
            setEditingId(null);
        } catch (error) {
            console.error("Failed to edit annotation", error);
        }
    };

    const handleDelete = async (id) => {
        try {
            await deleteAnnotation(id);
        } catch (error) {
            console.error("Failed to delete annotation", error);
        }
    };

    // Format date for display (e.g., Nov 29, 2024)
    const formattedDate = date ? new Date(date).toLocaleDateString('en-US', {
        month: 'short', day: 'numeric', year: 'numeric'
    }) : '';

    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm">
            <div className="bg-white rounded-xl shadow-xl w-full max-w-md overflow-hidden flex flex-col max-h-[90vh]">
                {/* Header */}
                <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
                    <div>
                        <h3 className="font-semibold text-gray-800">Annotations</h3>
                        <p className="text-xs text-gray-500 mt-1">{formattedDate}</p>
                    </div>
                    <button 
                        onClick={onClose}
                        className="p-1.5 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
                    >
                        <X size={18} />
                    </button>
                </div>

                {/* Body - List of annotations */}
                <div className="flex-1 overflow-y-auto p-5 space-y-4">
                    {isLoading ? (
                        <div className="text-center py-8 text-sm text-gray-400">Loading annotations...</div>
                    ) : isError ? (
                        <div className="text-center py-8 text-sm text-red-400">Failed to load annotations</div>
                    ) : annotations.length === 0 ? (
                        <div className="text-center py-8 text-sm text-gray-400">
                            No annotations for this date.
                        </div>
                    ) : (
                        annotations.map(ann => (
                            <div key={ann.id} className="bg-orange-50/50 border border-orange-100 rounded-lg p-3">
                                {editingId === ann.id ? (
                                    <div className="space-y-2">
                                        <textarea
                                            className="w-full text-sm border-gray-200 rounded-md focus:ring-orange-500 focus:border-orange-500 p-2"
                                            rows={2}
                                            value={editText}
                                            onChange={(e) => setEditText(e.target.value)}
                                        />
                                        <div className="flex justify-end gap-2">
                                            <button 
                                                className="text-xs px-3 py-1.5 text-gray-600 hover:bg-gray-100 rounded-md"
                                                onClick={() => setEditingId(null)}
                                            >
                                                Cancel
                                            </button>
                                            <button 
                                                className="text-xs px-3 py-1.5 bg-orange-500 text-white hover:bg-orange-600 rounded-md disabled:opacity-50"
                                                onClick={() => handleEdit(ann.id)}
                                                disabled={isUpdating || !editText.trim()}
                                            >
                                                {isUpdating ? 'Saving...' : 'Save'}
                                            </button>
                                        </div>
                                    </div>
                                ) : (
                                    <div>
                                        <div className="flex items-start justify-between gap-3">
                                            <div className="flex-1">
                                                <p className="text-sm text-gray-700 whitespace-pre-wrap break-words">{ann.annotation_text}</p>
                                                {ann.service && ann.service !== 'All' && (
                                                    <span className="inline-block mt-2 px-1.5 py-0.5 bg-blue-50 text-blue-600 rounded text-[10px] font-medium border border-blue-100">
                                                        {ann.service}
                                                    </span>
                                                )}
                                            </div>
                                            <div className="flex shrink-0 gap-1">
                                                {ann.created_by === userName && (
                                                    <>
                                                        <button 
                                                            className="p-1 text-gray-400 hover:text-blue-600 rounded"
                                                            onClick={() => {
                                                                setEditingId(ann.id);
                                                                setEditText(ann.annotation_text);
                                                            }}
                                                        >
                                                            <Edit2 size={14} />
                                                        </button>
                                                        <button 
                                                            className="p-1 text-gray-400 hover:text-red-600 rounded disabled:opacity-50"
                                                            onClick={() => handleDelete(ann.id)}
                                                            disabled={isDeleting}
                                                        >
                                                            <Trash2 size={14} />
                                                        </button>
                                                    </>
                                                )}
                                            </div>
                                        </div>
                                        <div className="mt-2 text-[10px] text-gray-400 flex items-center justify-between">
                                            <span>{ann.created_by}</span>
                                            <span>
                                                {new Date(ann.created_at.includes('Z') ? ann.created_at : ann.created_at.replace(' ', 'T') + 'Z').toLocaleString('en-IN', {
                                                    timeZone: 'Asia/Kolkata',
                                                    month: 'short', 
                                                    day: 'numeric', 
                                                    year: 'numeric', 
                                                    hour: '2-digit', 
                                                    minute:'2-digit'
                                                })}
                                            </span>
                                        </div>
                                    </div>
                                )}
                            </div>
                        ))
                    )}
                </div>

                {/* Footer - Add new annotation */}
                <div className="p-5 border-t border-gray-100 bg-gray-50/50">
                    <div className="space-y-3">
                        <textarea
                            placeholder="Add a new annotation..."
                            className="w-full text-sm border-gray-200 rounded-lg focus:ring-orange-500 focus:border-orange-500 p-3 shadow-sm resize-none"
                            rows={2}
                            value={newText}
                            onChange={(e) => setNewText(e.target.value)}
                        />
                        <button
                            className="w-full py-2 bg-gray-800 text-white text-sm font-medium rounded-lg hover:bg-gray-900 focus:ring-4 focus:ring-gray-200 transition-colors disabled:opacity-50"
                            onClick={handleAdd}
                            disabled={isCreating || !newText.trim()}
                        >
                            {isCreating ? 'Adding...' : 'Add Annotation'}
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
}
