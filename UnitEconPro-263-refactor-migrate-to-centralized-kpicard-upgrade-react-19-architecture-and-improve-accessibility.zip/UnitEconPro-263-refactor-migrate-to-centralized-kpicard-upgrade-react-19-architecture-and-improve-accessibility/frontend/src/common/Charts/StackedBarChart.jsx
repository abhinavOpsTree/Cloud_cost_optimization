import { useMemo } from 'react';
import Highcharts from 'highcharts';
import HighchartsReact from 'highcharts-react-official';
import { Loader, AlertCircle } from "lucide-react";
import ErrorBoundary from "../ErrorBoundary";

// --- Internal Helper Components ---



const HC_TOOLTIP = {
  borderWidth: 0,
  borderRadius: 2,
  useHTML: true,
  style: { padding: '10px', fontSize: '12px' },
};

// --- Main Component ---

export function StackedBarChartInner({
  chartData = [],
  isLoading,
  isError,
  title,
  subtitle = "Breakdown by category",
  dataKey = "cost",
  nameKey = "name",
  height = "300px"
}) {

  const categories = useMemo(() => chartData.map(d => d[nameKey]), [chartData, nameKey]);
  const series = useMemo(() => [
    {
      name: "Cost",
      data: chartData.map(d => d[dataKey])
    }
  ], [chartData, dataKey]);

  const isEmptyData = (series = []) => {
    if (!Array.isArray(series) || series.length === 0) return true;
    return series.every(s => {
      if (!Array.isArray(s?.data) || s.data.length === 0) return true;
      return s.data.every(v => Number(v || 0) < 0.01);
    });
  };

  const isEmpty = isEmptyData(series);
  const isGhost = isLoading || isError || isEmpty;

  const dummyCategories = [" ", "  ", "   ", "    ", "     "];
  const dummySeries = [{ name: "Cost", data: [100, 80, 60, 40, 20] }];

  const categoriesToRender = isGhost ? dummyCategories : categories;
  const seriesToRender = isGhost ? dummySeries : series;

  const options = useMemo(
    () => ({
      chart: {
        type: "column",
        backgroundColor: "transparent",
        height: parseInt(height),
        style: { fontFamily: "inherit" },
        animation: { duration: 600 },
        spacing: [10, 0, 10, 0],
      },
      title: { text: null },
      credits: { enabled: false },
      xAxis: {
        categories: categoriesToRender,
        gridLineWidth: 0,
        lineWidth: 0,
        labels: { style: { color: "#6B7280", fontSize: "11px" } },
        title: { text: null },
      },
      yAxis: {
        title: { text: null },
        gridLineWidth: 0,
        lineWidth: 0,
        labels: {
          style: { color: "#6B7280", fontSize: "12px" },
          formatter: function () { return '$' + this.value.toLocaleString(); }
        },
      },
      legend: { enabled: false },
      tooltip: {
        enabled: !isGhost,
        ...HC_TOOLTIP,
      },
      plotOptions: {
        column: {
          stacking: "normal",
          borderWidth: 0,
          pointWidth: categories.length > 10 ? undefined : 15,
          groupPadding: 0.1,
          pointPadding: 0.05,
          borderRadius: 10,
        },
        series: {
          enableMouseTracking: !isGhost,
          animation: { duration: 600 },
          states: { inactive: { opacity: 1 } },
        },
      },
      series: seriesToRender.map((s) => {
        if (isGhost) return { name: s.name, data: s.data, color: "#f3f4f6" };
        const n = s.name?.toLowerCase() ?? "";
        if (n.includes("fail")) return { name: s.name, data: s.data, color: "#C30000", index: 0 };
        if (n.includes("rollback") || n.includes("rolled")) return { name: s.name, data: s.data, color: "#FEA111", index: 1 };
        if (n.includes("pass") || n.includes("success")) {
          return {
            name: s.name, data: s.data, index: 2,
            color: {
              linearGradient: [0, 0, 0, 300],
              stops: [
                [0, "#35CC00"],
                [1, "#A2F983"],
              ],
            },
          };
        }
        return {
          name: s.name,
          data: s.data,
          color: {
            linearGradient: [0, 0, 0, 300],
            stops: [
              [0, "#0284C7"],
              [1, "#BAE6FD"],
            ],
          },
        };
      }),
    }),
    [categoriesToRender, seriesToRender, height, isGhost, categories.length],
  );

  return (
    <div className="w-full bg-white p-4 rounded-xl ring-[.5px] ring-black/10 flex flex-col transition-all relative">
      <div className="flex flex-col mb-4">
        <div className="flex items-center gap-2 mb-1">
          <h3 className="text-sm font-bold text-gray-800 tracking-tight capitalize">{title}</h3>
        </div>
        {subtitle && <p className="text-xs text-gray-500 font-medium">{subtitle}</p>}
      </div>

      <div className="w-full overflow-hidden relative">
        <HighchartsReact
          highcharts={Highcharts}
          options={options}
          containerProps={{ style: { width: "100%", overflow: "hidden" } }}
        />

        {isGhost && (
          <div className="absolute inset-0 z-10 flex flex-col items-center justify-center bg-white/20 backdrop-blur-[1.5px] rounded-md transition-opacity duration-300 pointer-events-none">
            {isLoading ? (
              <div className="flex flex-col items-center gap-2 text-slate-500 bg-white/80 px-4 py-2 rounded-lg shadow-sm">
                <Loader size={24} className="animate-spin text-blue-500" />
                <span className="text-xs font-semibold">Loading chart...</span>
              </div>
            ) : isError ? (
              <div className="flex items-center gap-2 text-red-500 font-medium bg-white/90 px-4 py-2 rounded-lg shadow-sm">
                <AlertCircle size={20} />
                <span>Error loading chart data</span>
              </div>
            ) : (
              <span className="text-sm font-semibold text-gray-500 bg-white/90 px-4 py-2 rounded-lg shadow-sm ring-1 ring-black/5">
                No Data Available
              </span>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

export function StackedBarChart(props) {
  return (
    <ErrorBoundary>
      <StackedBarChartInner {...props} />
    </ErrorBoundary>
  );
}
