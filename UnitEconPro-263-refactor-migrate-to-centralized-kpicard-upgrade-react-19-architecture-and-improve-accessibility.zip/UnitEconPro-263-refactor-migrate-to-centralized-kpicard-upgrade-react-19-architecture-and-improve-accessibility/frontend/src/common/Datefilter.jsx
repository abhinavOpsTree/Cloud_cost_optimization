import React, { useState } from 'react';
import {
    Box,
    Popover,
    TextField,
    InputAdornment,
    Button,
    Typography,
    styled,
    Divider
} from '@mui/material';
import { LocalizationProvider, DatePicker } from '@mui/x-date-pickers';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import dayjs from 'dayjs';
import { ChevronDown } from 'lucide-react';
import { cn } from '../lib/cn';

const StyledPopover = styled(Popover)(() => ({
    '& .MuiPaper-root': {
        borderRadius: '8px',
        boxShadow: 'var(--shadow-card)',
        border: 'var(--shadow-border)',
        minWidth: '600px',
        marginTop: '8px',
        backgroundColor: 'var(--geist-background)',
    }
}));

const QuickSelectButton = styled(Button)(({ selected }) => ({
    width: '100%',
    height: '36px',
    padding: '8px 12px',
    borderRadius: '6px',
    textTransform: 'none',
    fontFamily: 'var(--font-geist)',
    fontWeight: 500,
    fontSize: '13px',
    color: selected ? 'var(--geist-foreground)' : 'var(--accents-5)',
    backgroundColor: selected ? 'var(--accents-2)' : 'transparent',
    border: 'none',
    justifyContent: 'flex-start',
    '&:hover': {
        backgroundColor: 'var(--accents-1)',
        color: 'var(--geist-foreground)',
    }
}));

const SectionHeading = styled(Typography)({
    fontFamily: 'var(--font-geist)',
    fontWeight: 600,
    fontSize: '13px',
    color: 'var(--geist-foreground)',
    marginBottom: '16px'
});

const dateFieldSx = {
    '& .MuiOutlinedInput-root': {
        borderRadius: '6px',
        backgroundColor: 'var(--accents-1)',
        '& .MuiOutlinedInput-notchedOutline': {
            borderColor: 'var(--accents-2)',
        },
        '&:hover .MuiOutlinedInput-notchedOutline': {
            borderColor: 'var(--accents-3)',
        },
        '&.Mui-focused .MuiOutlinedInput-notchedOutline': {
            borderColor: 'var(--focus-color)',
            borderWidth: '1px',
        },
    },
    '& .MuiInputBase-root': {
        fontFamily: 'var(--font-geist)',
        fontSize: '13px'
    }
};

const CustomDateRangePopover = ({ anchorEl, open, onClose, onApply, onReset }) => {
    const [startDate, setStartDate] = useState(null);
    const [endDate, setEndDate] = useState(null);
    const [selectedQuickRange, setSelectedQuickRange] = useState(null);
    const [searchTerm, setSearchTerm] = useState('');

    const quickRanges = [
        { label: 'Last week', value: 'last_week' },
        { label: 'Last 30 days', value: 'last_30_days' },
        { label: 'Last 90 days', value: 'last_90_days' },
        { label: 'Last 6 months', value: 'last_6_months' },
        { label: 'Last 1 year', value: 'last_1_year' },
        { label: 'This month so far', value: 'this_month' }
    ];

    const getDateRangeFromQuickSelect = (value) => {
        const today = dayjs();
        let start, end;

        switch (value) {
            case 'last_week':
                start = today.subtract(7, 'day');
                end = today;
                break;
            case 'last_30_days':
                start = today.subtract(30, 'day');
                end = today;
                break;
            case 'last_90_days':
                start = today.subtract(90, 'day');
                end = today;
                break;
            case 'last_6_months':
                start = today.subtract(6, 'month');
                end = today;
                break;
            case 'last_1_year':
                start = today.subtract(1, 'year');
                end = today;
                break;
            case 'this_month':
                start = today.startOf('month');
                end = today;
                break;
            default:
                start = null;
                end = null;
        }

        return { start, end };
    };

    const applyAndClose = (start, end) => {
        if (start && end) {
            if (typeof onApply === 'function') {
                onApply({
                    startDate: start.format('YYYY-MM-DD'),
                    endDate: end.format('YYYY-MM-DD'),
                    displayStart: start.format('DD MMM YYYY'),
                    displayEnd: end.format('DD MMM YYYY'),
                    startDateObj: start,
                    endDateObj: end
                });
            }
            if (typeof onClose === 'function') {
                onClose();
            }
        }
    };

    const handleQuickRangeClick = (rangeValue) => {
        setSelectedQuickRange(rangeValue);
        const { start, end } = getDateRangeFromQuickSelect(rangeValue);
        setStartDate(start);
        setEndDate(end);
        applyAndClose(start, end);
    };

    const handleApply = () => {
        applyAndClose(startDate, endDate);
    };

    const handleCancel = () => {
        setStartDate(null);
        setEndDate(null);
        setSelectedQuickRange(null);
        setSearchTerm('');
        onClose();
    };

    const handleRemoveFilters = () => {
        setStartDate(null);
        setEndDate(null);
        setSelectedQuickRange(null);
        setSearchTerm('');
        onApply({
            startDate: '',
            endDate: '',
            startDateObj: '',
            endDateObj: ''
        });
        onClose();
    };

    const filteredRanges = quickRanges.filter(range =>
        range.label.toLowerCase().includes(searchTerm.toLowerCase())
    );

    return (
        <StyledPopover
            open={open}
            anchorEl={anchorEl}
            onClose={handleCancel}
            anchorOrigin={{
                vertical: 'bottom',
                horizontal: 'right',
            }}
            transformOrigin={{
                vertical: 'top',
                horizontal: 'right',
            }}
            className='backdrop-blur-[1px]'
        >
            <Box sx={{ display: 'flex' }} className='bg-[var(--sidebar-primary-bg)] border border-[var(--border-primary-color)]'>
                <Box sx={{ flex: 1, minWidth: '250px', padding: '12px 12px 16px' }}>
                    <SectionHeading>Absolute Time Range</SectionHeading>

                    <LocalizationProvider dateAdapter={AdapterDayjs}>
                        <Box sx={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                            <Box>
                                <Typography variant="caption" sx={{ fontWeight: 600, color: 'text.secondary', display: 'block', mb: 0.5 }}>From</Typography>
                                <DatePicker
                                    value={startDate}
                                    onChange={(newValue) => {
                                        setStartDate(newValue);
                                        setSelectedQuickRange(null);
                                    }}
                                    onAccept={(newValue) => {
                                        if (newValue && endDate) {
                                            applyAndClose(newValue, endDate);
                                        }
                                    }}
                                    maxDate={endDate ?? undefined}
                                    slotProps={{
                                        textField: {
                                            size: 'small',
                                            fullWidth: true,
                                            sx: dateFieldSx,
                                            placeholder: 'From'
                                        }
                                    }}
                                />
                            </Box>
                            <Box>
                                <Typography variant="caption" sx={{ fontWeight: 600, color: 'text.secondary', display: 'block', mb: 0.5 }}>To</Typography>
                                <DatePicker
                                    value={endDate}
                                    onChange={(newValue) => {
                                        setEndDate(newValue);
                                        setSelectedQuickRange(null);
                                    }}
                                    onAccept={(newValue) => {
                                        if (startDate && newValue) {
                                            applyAndClose(startDate, newValue);
                                        }
                                    }}
                                    minDate={startDate ?? undefined}
                                    maxDate={dayjs()}
                                    slotProps={{
                                        textField: {
                                            size: 'small',
                                            fullWidth: true,
                                            sx: dateFieldSx,
                                            placeholder: 'To'
                                        }
                                    }}
                                />
                            </Box>
                            <Button
                                variant="contained"
                                fullWidth
                                onClick={handleApply}
                                disabled={!startDate || !endDate}
                                sx={{ textTransform: 'none', mt: 1 }}
                            >
                                Apply time Range
                            </Button>
                        </Box>
                    </LocalizationProvider>
                </Box>
                <Divider orientation="vertical" flexItem sx={{ backgroundColor: '#E6E6E6' }} />
                <Box sx={{ flex: 1, minWidth: '250px', padding: '12px 8px 16px' }}>
                    <SectionHeading>Quick Ranges</SectionHeading>

                    <TextField
                        placeholder="Search ranges..."
                        size="small"
                        fullWidth
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        sx={{
                            marginBottom: '12px',
                            '& .MuiInputBase-root': {
                                fontFamily: 'Montserrat, sans-serif',
                                fontSize: '14px'
                            }
                        }}
                        InputProps={{
                            startAdornment: (
                                <InputAdornment position="start">
                                    <i className="ri-search-line" style={{ fontSize: '16px', color: '#666' }} />
                                </InputAdornment>
                            )
                        }}
                    />

                    <Box sx={{
                        display: 'flex',
                        flexDirection: 'column',
                        gap: '8px',
                        maxHeight: '280px',
                        overflowY: 'auto',
                        paddingRight: '4px',
                        '&::-webkit-scrollbar': { width: '6px' },
                        '&::-webkit-scrollbar-thumb': {
                            backgroundColor: '#D0D0D0',
                            borderRadius: '3px'
                        }
                    }}>
                        {filteredRanges.map((range) => (
                            <QuickSelectButton
                                key={range.value}
                                selected={selectedQuickRange === range.value}
                                onClick={() => handleQuickRangeClick(range.value)}
                            >
                                {range.label}
                            </QuickSelectButton>
                        ))}
                    </Box>
                </Box>
            </Box>

            <Box sx={{
                display: 'flex',
                justifyContent: 'flex-start',
                padding: '8px 12px',
            }} className='bg-[var(--sidebar-primary-bg)] border border-[var(--border-primary-color)]'>
                <button
                    onClick={onReset}
                    className="text-xs font-medium text-[#fff] rounded-md  transition-all bg-[var(--button-bg)] shadow-[var(--shadow-sm)] cursor-pointer px-4 py-1.5 rounded-standard"
                >
                    Reset
                </button>
            </Box>
        </StyledPopover>
    );
};

const Datefilter = ({
    filterSelector,
    onFilterChange,
    onReset,
    disabled = false
}) => {
    const [anchorEl, setAnchorEl] = useState(null);

    const handleClick = (event) => {
        setAnchorEl(event.currentTarget);
    };

    const handleClose = () => {
        setAnchorEl(null);
    };

    const open = Boolean(anchorEl);

    return (
        <div className="flex gap-2 items-center">
            <button
                onClick={handleClick}
                disabled={disabled}
                className={cn("flex items-center justify-between px-4 py-1.5 text-xs font-medium outline-none cursor-pointer text-accents-5 bg-neutral-100 rounded-md ring-1 ring-black/20 transition-all shadow-geist-border min-w-[200px]", disabled ? "opacity-50 cursor-not-allowed" : "hover:text-geist-foreground")}
            >
                <span>{filterSelector || "Select Date Range"}</span>
                <ChevronDown size={14} className={cn("transition-transform text-accents-3", open && "rotate-180")} />
            </button>

            <CustomDateRangePopover
                open={open}
                anchorEl={anchorEl}
                onClose={handleClose}
                onApply={onFilterChange}
                onReset={onReset}
            />
        </div>
    );

};

export default Datefilter;