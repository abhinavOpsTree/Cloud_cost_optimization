import { motion } from "framer-motion";
import { useId, useState, useEffect } from "react";
import { flushSync } from "react-dom";

export default function Toggle({ value, onChange, options, disabled }) {
  const id = useId();
  const [internalValue, setInternalValue] = useState(value);

  useEffect(() => {
    setInternalValue(value);
  }, [value]);

  const handleSelect = (val) => {
    if (disabled || val === internalValue) return;
    flushSync(() => {
      setInternalValue(val);
    });
    setTimeout(() => {
      onChange?.(val);
    }, 0);
  };

  if (options) {
    return (
      <div className={`bg-slate-100 p-1 rounded-xl inline-flex relative shadow-inner ${disabled ? 'opacity-60 cursor-not-allowed' : ''}`}>
        {options.map((opt) => {
          const isActive = internalValue === opt.value;
          return (
            <button
              key={opt.value}
              type="button"
              disabled={disabled}
              onClick={() => handleSelect(opt.value)}
              className={`relative px-5 py-1.5 rounded-lg text-sm font-medium transition-colors duration-150 ${
                isActive ? "text-slate-800" : "text-slate-500 hover:text-slate-700"
              } ${disabled ? 'cursor-not-allowed pointer-events-none' : ''}`}
            >
              {isActive && (
                <motion.div
                  layoutId={`toggle-active-${id}`}
                  className="absolute inset-0 bg-white rounded-lg shadow-sm border border-slate-200/50 z-0"
                  transition={{ type: "spring", bounce: 0.15, duration: 0.3 }}
                />
              )}
              <span className="relative z-10">{opt.label}</span>
            </button>
          );
        })}
      </div>
    );
  }

  const isRole = internalValue === "RoleARN";
  return (
    <div className={`bg-slate-100 p-1 rounded-xl inline-flex relative shadow-inner ${disabled ? 'opacity-60 cursor-not-allowed' : ''}`}>
      <motion.div
        layout
        transition={{ type: "spring", bounce: 0.15, duration: 0.3 }}
        className={`absolute top-1 bottom-1 ${isRole ? 'left-1 w-[100px]' : 'right-1 w-[220px]'} bg-white rounded-lg shadow-sm border border-slate-200/50 z-0`}
        style={{ left: isRole ? '4px' : 'auto', right: isRole ? 'auto' : '4px', width: isRole ? '100px' : '200px' }}
      />
      <button
        disabled={disabled}
        onClick={() => handleSelect("RoleARN")}
        className={`relative z-10 px-6 py-2 rounded-lg text-sm font-medium transition-colors w-[100px] ${isRole ? "text-slate-800" : "text-slate-500 hover:text-slate-700"
          } ${disabled ? 'cursor-not-allowed pointer-events-none' : ''}`}
      >
        Role ARN
      </button>
      <button
        disabled={disabled}
        onClick={() => handleSelect("AccessKey")}
        className={`relative z-10 px-6 py-2 rounded-lg text-sm font-medium transition-colors w-[200px] ${!isRole ? "text-slate-800" : "text-slate-500 hover:text-slate-700"
          } ${disabled ? 'cursor-not-allowed pointer-events-none' : ''}`}
      >
        Access Key ~ Secret Key
      </button>
    </div>
  );
}
