
import { AlertTriangle } from "lucide-react";
import FinOpsCard from "./FinOpsCard";
import { signalToText } from "../lib/suggestionPrefill";

const FinOpsFlagsContainer = ({ flags, items, onSuggest }) => {
    const list = flags || items || [];
    if (list.length === 0) return null;

    return (
        <div className="space-y-2">
            {list.map((item, idx) => (
                typeof item === "object"
                    ? <FinOpsCard key={item.id || item.recommendation_id || `${item.resource_id}-${idx}`} item={item} onSuggest={onSuggest} />
                    : (
                        <button
                            type="button"
                            key={item || idx}
                            onClick={() => onSuggest && onSuggest(signalToText(item))}
                            title="Click to add as suggestion"
                            className="w-full text-left flex items-start gap-2.5 bg-white dark:bg-slate-800 border border-gray-200 dark:border-slate-700 rounded-lg px-3.5 py-2.5 cursor-pointer hover:border-gray-300 dark:hover:border-slate-600 hover:bg-gray-50/50 dark:hover:bg-slate-700/50 transition-colors focus:outline-none">
                            <AlertTriangle size={15} className="text-amber-500 shrink-0 mt-0.5" />
                            <div>
                                <p className="text-xs font-semibold text-gray-800 dark:text-gray-100 capitalize">{String(item).replace(/_/g, " ")}</p>
                            </div>
                        </button>
                    )
            ))}
        </div>
    );
};

export default FinOpsFlagsContainer;
