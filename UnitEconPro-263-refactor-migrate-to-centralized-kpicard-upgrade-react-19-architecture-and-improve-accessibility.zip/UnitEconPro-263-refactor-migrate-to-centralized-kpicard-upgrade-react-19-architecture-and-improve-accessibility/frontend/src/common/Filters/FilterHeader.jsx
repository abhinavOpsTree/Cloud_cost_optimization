import { useState, useRef, useEffect } from "react";
import { ChevronDown, RotateCcw, Search, SearchIcon, X } from "lucide-react";
import { cn } from "../../lib/cn";

const FilterHeader = ({
    filterSelector,
    onFilterChange,
    onReset,
    filterOptions = [],
    onRefresh,
    defaultLabel = "All Status",
    searchTerm = "",
    onSearchChange
}) => {
    const [isOpen, setIsOpen] = useState(false);
    const dropdownRef = useRef(null);

    useEffect(() => {
        const handleClickOutside = (event) => {
            if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
                setIsOpen(false);
            }
        };
        document.addEventListener("mousedown", handleClickOutside);
        return () => document.removeEventListener("mousedown", handleClickOutside);
    }, []);

    const selectedOption = filterOptions.find(opt => opt.value === filterSelector);
    const displayLabel = selectedOption ? selectedOption.label : defaultLabel;

    return (
        <div className="flex gap-3 items-center justify-start md:justify-end flex-wrap">
            <div style={{
                display: "flex", alignItems: "center", gap: 8,
                background: "white",
                border: "0.5px solid var(--color-border-tertiary)",
                borderRadius: "var(--border-radius-md)",
                flex: 1, minWidth: 200, maxWidth: 300, marginLeft: "auto"
            }} className="p-2">
                <Search size={14} style={{ color: "var(--color-text-secondary)" }} />
                <input
                    type="text"
                    value={searchTerm}
                    onChange={(e) => onSearchChange(e.target.value)}
                    placeholder="Search..."
                    style={{
                        background: "none", border: "none", outline: "none",
                        fontSize: 12, color: "var(--color-text-primary)", width: "100%"
                    }}
                />
                {searchTerm.length > 0 && (
                    <button type="button" onClick={() => onSearchChange("")} className="bg-transparent border-none p-0 flex items-center justify-center cursor-pointer">
                        <X size={14} style={{ color: "var(--color-text-secondary)" }} />
                    </button>
                )}
            </div>
            <div className="relative" ref={dropdownRef}>
                <button
                    type="button"
                    onClick={() => setIsOpen(!isOpen)}
                    className="flex items-center justify-between pl-3 pr-8 py-2 text-sm bg-[#ffffff] border border-black/20 rounded-lg  outline-none cursor-pointer min-w-[150px] text-[#6b7280] transition-all font-semibold"
                >
                    <span className="text-[11px] uppercase tracking-wider">{displayLabel}</span>
                </button>
                <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-[#9ca3af]">
                    <ChevronDown size={14} className={cn("transition-transform duration-200", isOpen && "rotate-180")} />
                </div>
                {isOpen && (
                    <div className="absolute z-50 w-full mt-1 bg-white/90 backdrop-blur-md border border-black/20 rounded-lg  overflow-hidden animate-in fade-in zoom-in duration-200">
                        <div className="py-1">
                            <button
                                type="button"
                                onClick={() => {
                                    onFilterChange("");
                                    setIsOpen(false);
                                }}
                                className={cn(
                                    "w-full text-left bg-transparent border-none px-3 py-2 text-xs cursor-pointer transition-colors border-b border-neutral-200 ",
                                    !filterSelector ? "text-blue-600 font-bold" : "text-neutral-800"
                                )}
                            >
                                {defaultLabel}
                            </button>
                            {filterOptions.map((option) => (
                                <button
                                    key={option.value}
                                    type="button"
                                    onClick={() => {
                                        onFilterChange(option.value);
                                        setIsOpen(false);
                                    }}
                                    className={cn(
                                        "w-full text-left bg-transparent border-none px-3 py-2 text-xs cursor-pointer transition-colors border-b border-neutral-200 last:border-none",
                                        filterSelector === option.value ? "text-blue-600 font-bold" : "text-neutral-800"
                                    )}
                                >
                                    {option.label}
                                </button>
                            ))}
                        </div>
                    </div>
                )}
            </div>
            <button
                type = "button"
                className="flex items-center gap-1 px-4 py-2 bg-[#ffffff] border border-black/20 text-neutral-600 rounded-lg text-xs font-bold uppercase tracking-wider transition-all cursor-pointer"
                onClick={onReset}
            >
                <RotateCcw size={14} />
                Reset
            </button>
            <button
                onClick={onRefresh}
                className="flex items-center gap-1 px-4 py-2 bg-[#ffffff] border border-black/20 text-neutral-600 rounded-lg text-xs font-bold uppercase tracking-wider transition-all cursor-pointer">
                Refresh
            </button>

        </div >
    )
}

export default FilterHeader