import React, { useState, useEffect, useMemo, useRef } from "react";
import { Search, X, ChevronDown, Filter as FilterIcon, RotateCcw } from "lucide-react";

export const Filters = ({
    data = [],
    onFilter,
    searchKeys = ["instance_name", "instance_id"],
    filterConfigs = [
        { key: "account", label: "Account" },
        { key: "region", label: "Region" }
    ],
    placeholder = "Search by name, ID..."
}) => {
    const [searchQuery, setSearchQuery] = useState("");
    const [debouncedSearchQuery, setDebouncedSearchQuery] = useState("");
    const [selectedFilters, setSelectedFilters] = useState({});
    const [activeDropdown, setActiveDropdown] = useState(null);
    const dropdownRef = useRef(null);

    useEffect(() => {
        const handler = setTimeout(() => {
            setDebouncedSearchQuery(searchQuery);
        }, 300);
        return () => clearTimeout(handler);
    }, [searchQuery]);

    useEffect(() => {
        const handleClickOutside = (event) => {
            if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
                setActiveDropdown(null);
            }
        };
        document.addEventListener("mousedown", handleClickOutside);
        return () => document.removeEventListener("mousedown", handleClickOutside);
    }, []);

    // Serialize object/array props to string dependencies to prevent infinite re-renders from inline definitions in parents
    const searchKeysStr = JSON.stringify(searchKeys);
    const filterConfigsStr = JSON.stringify(filterConfigs);

    const filterOptions = useMemo(() => {
        const options = {};
        filterConfigs.forEach(({ key }) => {
            if (!Array.isArray(data)) return;
            const uniqueValues = [...new Set(data.map(item => item[key]).filter(Boolean))];
            options[key] = uniqueValues.sort();
        });
        return options;
    }, [data, filterConfigsStr]);

    // Handle filter selection
    const handleSelectFilter = (key, value) => {
        setSelectedFilters(prev => {
            const currentSelected = prev[key] || [];
            const isAlreadySelected = currentSelected.includes(value);

            const updated = isAlreadySelected
                ? currentSelected.filter(v => v !== value)
                : [...currentSelected, value];

            return {
                ...prev,
                [key]: updated
            };
        });
    };

    // Clear specific filter field or single value
    const handleClearFilterValue = (key, value) => {
        setSelectedFilters(prev => {
            const currentSelected = prev[key] || [];
            return {
                ...prev,
                [key]: currentSelected.filter(v => v !== value)
            };
        });
    };

    const handleResetAll = () => {
        setSearchQuery("");
        setSelectedFilters({});
        setActiveDropdown(null);
    };

    const onFilterRef = useRef(onFilter);
    useEffect(() => {
        onFilterRef.current = onFilter;
    }, [onFilter]);

    const prevResultRef = useRef([]);

    useEffect(() => {
        const hasSearch = !!debouncedSearchQuery.trim();
        const hasSelected = Object.values(selectedFilters).some(arr => arr && arr.length > 0);

        let result = null;

        if (hasSearch || hasSelected) {
            result = Array.isArray(data) ? [...data] : [];

            if (hasSearch) {
                const lowerQuery = debouncedSearchQuery.toLowerCase();
                result = result.filter(item => {
                    return searchKeys.some(key => {
                        const value = item[key];
                        return value && String(value).toLowerCase().includes(lowerQuery);
                    });
                });
            }
            
            Object.entries(selectedFilters).forEach(([key, selectedValues]) => {
                if (selectedValues && selectedValues.length > 0) {
                    result = result.filter(item => {
                        const itemValue = item[key];
                        return itemValue && selectedValues.includes(String(itemValue));
                    });
                }
            });
        }

        const isSameResult =
            prevResultRef.current === result ||
            (Array.isArray(prevResultRef.current) && Array.isArray(result) &&
             prevResultRef.current.length === result.length &&
             prevResultRef.current.every((item, index) => item === result[index]));

        if (!isSameResult) {
            prevResultRef.current = result;
            if (onFilterRef.current) {
                onFilterRef.current(result);
            }
        }
    }, [data, debouncedSearchQuery, selectedFilters, searchKeysStr]);

    const activeFilterCount = useMemo(() => {
        let count = searchQuery.trim() ? 1 : 0;
        Object.values(selectedFilters).forEach(arr => {
            if (arr && arr.length > 0) {
                count += arr.length;
            }
        });
        return count;
    }, [searchQuery, selectedFilters]);

    return (
        <div className="w-full space-y-3 bg-white p-4 rounded-xl border border-gray-200/80 shadow-sm" ref={dropdownRef}>
            <div className="flex flex-col md:flex-row md:items-center gap-3">
                <div className="relative flex-1 group">
                    <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-gray-400 group-focus-within:text-blue-500 transition-colors">
                        <Search size={18} />
                    </span>
                    <input
                        type="text"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        placeholder={placeholder}
                        className="w-full pl-10 pr-9 py-2 text-sm bg-gray-50 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500/10 focus:border-blue-500 focus:bg-white transition-all duration-200"
                    />
                    {searchQuery && (
                        <button
                            onClick={() => setSearchQuery("")}
                            className="absolute inset-y-0 right-0 flex items-center pr-2.5 text-gray-400 hover:text-gray-600 transition-colors"
                        >
                            <X size={16} />
                        </button>
                    )}
                </div>

                <div className="flex flex-wrap items-center gap-2">
                    {filterConfigs.map(({ key, label }) => {
                        const options = filterOptions[key] || [];
                        const selected = selectedFilters[key] || [];
                        const isOpen = activeDropdown === key;

                        return (
                            <div key={key} className="relative">
                                <button
                                    onClick={() => setActiveDropdown(isOpen ? null : key)}
                                    className={`flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg border transition-all duration-150 cursor-pointer ${selected.length > 0
                                        ? "border-blue-200 bg-blue-50/50 text-blue-700 hover:bg-blue-50"
                                        : "border-gray-200 bg-white text-gray-600 hover:bg-gray-50"
                                        }`}
                                >
                                    <FilterIcon size={12} className={selected.length > 0 ? "text-blue-500" : "text-gray-400"} />
                                    <span>{label}</span>
                                    {selected.length > 0 && (
                                        <span className="flex items-center justify-center bg-blue-600 text-white rounded-full w-4 h-4 text-[10px] font-bold">
                                            {selected.length}
                                        </span>
                                    )}
                                    <ChevronDown size={14} className={`text-gray-400 transition-transform duration-200 ${isOpen ? "rotate-180" : ""}`} />
                                </button>

                                {isOpen && (
                                    <div className="absolute right-0 mt-1.5 w-56 bg-white border border-gray-150 rounded-lg shadow-lg py-1.5 z-50 animate-in fade-in slide-in-from-top-1 duration-150 max-h-60 overflow-y-auto">
                                        <div className="px-3 py-1 border-b border-gray-50 flex items-center justify-between">
                                            <span className="text-[11px] font-bold uppercase tracking-wider text-gray-400">{label} Options</span>
                                            {selected.length > 0 && (
                                                <button
                                                    onClick={() => setSelectedFilters(prev => ({ ...prev, [key]: [] }))}
                                                    className="text-[10px] font-bold text-blue-600 hover:text-blue-800 transition-colors"
                                                >
                                                    Clear all
                                                </button>
                                            )}
                                        </div>
                                        {options.length === 0 ? (
                                            <p className="px-3 py-2 text-xs text-gray-400 italic">No options found</p>
                                        ) : (
                                            <div className="py-1">
                                                {options.map(option => {
                                                    const isChecked = selected.includes(String(option));
                                                    return (
                                                        <label
                                                            key={option}
                                                            className="flex items-center gap-2 px-3 py-1.5 text-xs text-gray-700 hover:bg-gray-50 cursor-pointer transition-colors"
                                                        >
                                                            <input
                                                                type="checkbox"
                                                                checked={isChecked}
                                                                onChange={() => handleSelectFilter(key, String(option))}
                                                                className="rounded text-blue-600 focus:ring-blue-500/20 border-gray-300 w-3.5 h-3.5"
                                                            />
                                                            <span className="truncate">{option}</span>
                                                        </label>
                                                    );
                                                })}
                                            </div>
                                        )}
                                    </div>
                                )}
                            </div>
                        );
                    })}

                    {activeFilterCount > 0 && (
                        <button
                            onClick={handleResetAll}
                            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg text-red-600 hover:bg-red-50 transition-colors cursor-pointer border border-transparent hover:border-red-100"
                            title="Reset all search and filters"
                        >
                            <RotateCcw size={13} />
                            <span>Reset</span>
                        </button>
                    )}
                </div>
            </div>

            {/* Bottom Row: Active filter chips */}
            {activeFilterCount > 0 && (
                <div className="flex flex-wrap items-center gap-1.5 pt-2.5 border-t border-gray-100 animate-in fade-in duration-200">
                    <span className="text-[10px] font-bold text-gray-400 uppercase tracking-wider mr-1">Active filters:</span>

                    {/* Search Chip */}
                    {searchQuery.trim() && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-medium bg-gray-100 hover:bg-gray-150 text-gray-700 rounded-full border border-gray-200/50 transition-colors">
                            <span className="text-gray-400">Search:</span>
                            <span className="font-semibold">"{searchQuery}"</span>
                            <button
                                onClick={() => setSearchQuery("")}
                                className="p-0.5 hover:bg-gray-200 rounded-full text-gray-400 hover:text-gray-600 transition-colors"
                            >
                                <X size={10} />
                            </button>
                        </span>
                    )}

                    {/* Dropdown filter Chips */}
                    {Object.entries(selectedFilters).map(([key, values]) => {
                        const config = filterConfigs.find(c => c.key === key);
                        if (!values || values.length === 0) return null;

                        return values.map(val => (
                            <span key={`${key}-${val}`} className="inline-flex items-center gap-1 px-2.5 py-1 text-[11px] font-medium bg-blue-50/60 hover:bg-blue-50 text-blue-700 rounded-full border border-blue-100 transition-colors">
                                <span className="text-blue-400 font-normal">{config?.label || key}:</span>
                                <span className="font-semibold">{val}</span>
                                <button
                                    onClick={() => handleClearFilterValue(key, val)}
                                    className="p-0.5 hover:bg-blue-100 rounded-full text-blue-400 hover:text-blue-600 transition-colors"
                                >
                                    <X size={10} />
                                </button>
                            </span>
                        ));
                    })}
                </div>
            )}
        </div>
    );
};