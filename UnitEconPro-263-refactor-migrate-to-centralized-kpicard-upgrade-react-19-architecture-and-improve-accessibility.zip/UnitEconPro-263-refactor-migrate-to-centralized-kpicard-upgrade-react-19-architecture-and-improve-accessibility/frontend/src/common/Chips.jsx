import { Chip } from "@mui/material";

export const Chips = ({ options, selected, onSelect }) => {
    return (
        <div className="w-full">
            {/* RESPONSIVENESS: Render a select dropdown on mobile screens (< 640px) to conserve vertical space. */}
            <div className="sm:hidden block w-full relative">
                <select
                    value={selected}
                    onChange={(e) => onSelect(e.target.value)}
                    className="w-full appearance-none bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 font-medium py-2.5 pl-4 pr-10 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all shadow-[0_2px_4px_rgba(0,0,0,0.02)] cursor-pointer"
                >
                    {options.map((option) => (
                        <option key={option.value} value={option.value}>
                            {option.label}
                        </option>
                    ))}
                </select>
                <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center pr-3 text-slate-500">
                    <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                    </svg>
                </div>
            </div>

            {/* RESPONSIVENESS: Render horizontal list of clickable Chips on desktop and tablet screens (>= 640px). */}
            <div className="hidden sm:flex flex-wrap gap-2">
                {options.map((option) => (
                    <Chip
                        key={option.value}
                        label={option.label}
                        variant={selected === option.value ? "filled" : "outlined"}
                        color="primary"
                        onClick={() => onSelect(option.value)}
                        className="w-fit hover:cursor-pointer transition-all active:scale-95 duration-100"
                    />
                ))}
            </div>
        </div>
    );
};