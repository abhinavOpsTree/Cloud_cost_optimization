import {  Loader2 } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import Select from "./Select";

const AccountFilter = ({ selectedAccount, onAccountSelect, isUpdating, accounts }) => {
    const [showAccountDropdown, setShowAccountDropdown] = useState(false);
    const dropdownRef = useRef(null);
    

    

    useEffect(() => {
        const handleClickOutside = (e) => {
            if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
                setShowAccountDropdown(false);
            }
        };

        document.addEventListener("mousedown", handleClickOutside);
        return () => document.removeEventListener("mousedown", handleClickOutside);
    }, []);

    return (
        <div className="flex items-center relative">
            <div className="relative mr-2">
                {isUpdating && (
                    <div className="flex items-center gap-2 px-2 py-1 bg-accents-1 rounded-standard shadow-geist-border">
                        <Loader2 className="h-3 w-3 animate-spin text-accents-3" />
                        <span className="text-[10px] text-accents-4 font-medium">Updating...</span>
                    </div>
                )}
            </div>

            <Select
                value={selectedAccount?.value}
                options={accounts}
                onChange={(val) => {
                    const acc = accounts.find(a => a.value === val);
                    onAccountSelect(acc);
                }}
                placeholder="Select Account"
                className="min-w-[200px]"
            />
        </div>
    );
};

export default AccountFilter;
