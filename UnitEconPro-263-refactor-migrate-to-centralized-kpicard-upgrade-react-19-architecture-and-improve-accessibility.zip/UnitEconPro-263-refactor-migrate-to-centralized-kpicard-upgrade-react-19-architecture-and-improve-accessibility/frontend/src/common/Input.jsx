import { useRef } from "react";
import { cn } from "../lib/cn";

const Input = ({ type, placeholder, value, onChange, className, icon }) => {
    const ref = useRef(null);
    const handleClick = () => {
        if (ref.current) {
            ref.current.focus();
        }
    }
    return (
        <div className={cn("relative flex items-center", className)}>
            <button type="button" onClick={handleClick} className="absolute left-2 cursor-pointer z-[50] text-black/50 bg-transparent border-none p-0 flex items-center justify-center pointer-events-none">
                {icon}
            </button>
            <input
                type={type}
                placeholder={placeholder}
                value={value}
                onChange={onChange}
                className={cn(
                    "w-full text-slate-700 bg-white/50  border border-white/40 placeholder:text-slate-400 rounded-lg px-7  py-1 outline-none focus:ring-2 focus:ring-blue-400/50 focus:border-transparent transition-all shadow-sm")}
            />
        </div>
    )
}

export default Input