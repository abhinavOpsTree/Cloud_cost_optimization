import { useState } from "react";
import { AlertTriangle, Pencil, ChevronDown, ChevronUp } from "lucide-react";
import { signalToText } from "../lib/suggestionPrefill";

// Shared expandable FinOps flag card used by the S3/EBS/RDS/VPC/ELB/EC2 metadata drawers.

const MONO = "font-mono";

const Pill = ({ children, color = "gray" }) => {
    const cls = {
        red: "bg-red-50 text-red-800 border-red-200 dark:bg-red-950/40 dark:text-red-300 dark:border-red-800/50",
        orange: "bg-orange-100 text-orange-900 border-orange-300 dark:bg-orange-950/60 dark:text-orange-400 dark:border-orange-800/70",
        yellow: "bg-yellow-50 text-yellow-800 border-yellow-200 dark:bg-yellow-950/40 dark:text-yellow-300 dark:border-yellow-800/50",
        amber: "bg-amber-50 text-amber-800 border-amber-200 dark:bg-amber-950/40 dark:text-amber-300 dark:border-amber-800/50",
        green: "bg-emerald-50 text-emerald-800 border-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-300 dark:border-emerald-800/50",
    }[color] || "bg-gray-100 text-gray-700 border-gray-200 dark:bg-slate-800 dark:text-gray-300 dark:border-slate-700";

    return (
        <span className={`inline-flex items-center text-[10px] font-bold px-2 py-0.5 rounded border ${cls}`}>
            {children}
        </span>
    );
};

const SeverityBadge = ({ severity }) => {
    const color = { CRITICAL: "red", HIGH: "orange", MEDIUM: "yellow", LOW: "green" }[severity?.toUpperCase()] || "gray";
    return <Pill color={color}>{severity}</Pill>;
};

const FinOpsCard = ({ item, onSuggest }) => {
    const [expanded, setExpanded] = useState(false);
    const flagLabel = (item.flag || item.signal_type || "").replace(/_/g, " ");
    const sev = (item.severity || "").toUpperCase();

    const severityBg = {
        CRITICAL: "bg-red-50/60 dark:bg-red-950/20 border-red-200/70 dark:border-red-800/40",
        HIGH: "bg-orange-100/60 dark:bg-orange-950/40 border-orange-300/70 dark:border-orange-700/50",
        MEDIUM: "bg-yellow-50/60 dark:bg-yellow-950/20 border-yellow-200/70 dark:border-yellow-800/40",
        LOW: "bg-emerald-50/60 dark:bg-emerald-950/20 border-emerald-200/70 dark:border-emerald-800/40",
    }[sev] || "bg-white dark:bg-slate-800 border-gray-200 dark:border-slate-700";

    const hoverBg = {
        CRITICAL: "hover:bg-red-100/50 dark:hover:bg-red-900/30",
        HIGH: "hover:bg-orange-200/50 dark:hover:bg-orange-900/40",
        MEDIUM: "hover:bg-yellow-100/50 dark:hover:bg-yellow-900/30",
        LOW: "hover:bg-emerald-100/50 dark:hover:bg-emerald-900/30",
    }[sev] || "hover:bg-gray-50/50 dark:hover:bg-slate-700/50";

    const reasonText = item.reason || item.description;

    return (
        <div className={`border rounded-xl overflow-hidden mb-2 transition-colors ${severityBg}`}>
            <button
                className={`w-full flex items-center gap-3 px-4 py-3 text-left transition-colors cursor-pointer ${hoverBg}`}
                onClick={() => setExpanded((p) => !p)}
            >
                <AlertTriangle size={14} className="text-amber-500 shrink-0" />
                <div className="flex-1 min-w-0">
                    <div className="text-xs font-bold text-gray-800 dark:text-gray-100 capitalize truncate">{flagLabel}</div>
                </div>
                {onSuggest && (
                    <span
                        role="button"
                        title="Add as suggestion"
                        onClick={(e) => { e.stopPropagation(); onSuggest(signalToText(item)); }}
                        className="p-1 rounded hover:bg-gray-100 dark:hover:bg-slate-700 text-gray-400 hover:text-gray-700 dark:hover:text-gray-200 transition-colors shrink-0"
                    >
                        <Pencil size={12} />
                    </span>
                )}
                {item.impact_usd != null && (
                    <span className="text-[10px] font-bold text-gray-700 dark:text-gray-300 bg-white/50 dark:bg-slate-800/50 px-1.5 py-0.5 rounded border border-gray-200/50 dark:border-slate-700/50 shrink-0">
                        ${Number(item.impact_usd).toFixed(2)}/mo
                    </span>
                )}
                <SeverityBadge severity={sev || "INFO"} />
                {expanded ? <ChevronUp size={14} className="text-gray-400 shrink-0" /> : <ChevronDown size={14} className="text-gray-400 shrink-0" />}
            </button>

            <div
                className={`grid transition-[grid-template-rows,opacity] duration-300 ease-in-out ${
                    expanded ? "grid-rows-[1fr] opacity-100" : "grid-rows-[0fr] opacity-0"
                }`}
            >
                <div className="overflow-hidden">
                    <div className="border-t border-gray-200/50 dark:border-slate-700/50 px-4 py-3 space-y-2.5 text-[11px] bg-white/60 dark:bg-slate-900/40">
                    {item.impact_type && (
                        <div className="flex items-center justify-between">
                            <div className="text-[9px] font-bold uppercase text-gray-400">Impact Type</div>
                            <div className="text-gray-700 dark:text-gray-200 capitalize font-medium text-right">{String(item.impact_type).replace(/_/g, " ")}</div>
                        </div>
                    )}
                    {item.evidence && (
                        <div>
                            <div className="text-[9px] font-bold uppercase text-gray-400 mb-1">Evidence</div>
                            <div className={`text-gray-600 ${MONO} bg-white px-2 py-1.5 rounded border border-gray-100`}>{item.evidence}</div>
                        </div>
                    )}
                    {reasonText && (
                        <div>
                            <div className="text-[9px] font-bold uppercase text-gray-400 mb-1">Why</div>
                            <div className="text-gray-700 leading-relaxed">{reasonText.trim()}</div>
                        </div>
                    )}
                    {item.action && (
                        <div>
                            <div className="text-[9px] font-bold uppercase text-gray-400 mb-1">Recommended Action</div>
                            <div className="text-blue-700 font-medium leading-relaxed">{item.action}</div>
                        </div>
                    )}
                    {item.confidence && (
                        <div className="flex items-center gap-2">
                            <div className="text-[9px] font-bold uppercase text-gray-400">Confidence</div>
                            <Pill color={item.confidence === "HIGH" ? "green" : "amber"}>
                                {item.confidence}
                            </Pill>
                        </div>
                    )}
                    </div>
                </div>
            </div>
        </div>
    );
};

export default FinOpsCard;
