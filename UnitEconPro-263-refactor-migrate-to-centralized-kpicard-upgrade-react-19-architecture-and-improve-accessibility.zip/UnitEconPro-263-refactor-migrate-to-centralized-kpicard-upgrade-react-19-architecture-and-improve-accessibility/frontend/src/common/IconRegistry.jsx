import React from "react";
import { Activity, Box, DollarSign, Globe, Users, Zap, Server, Database, Cloud } from "lucide-react";

export const IconRegistry = {
    "total_cost": { icon: <DollarSign size={16} className="text-green-500" /> },
    "avg_daily_cost": { icon: <Activity size={16} className="text-green-800" /> },
    "predicted_month_cost": { icon: <Box size={16} className="text-green-500" /> },
    "active_services": { icon: <Globe size={16} className="text-red-500" /> },
    "total_accounts": { icon: <Users size={16} className="text-purple-500" /> },
    "active_regions": { icon: <Zap size={16} className="text-yellow-500" /> },
    "total_resources": { icon: <Box size={16} className="text-green-800" /> },
    "predicted_week_cost": { icon: <DollarSign size={16} className="text-green-500" /> },
    "total_instances": { icon: <Server size={16} className="text-blue-500" /> },
    "total_usage_hours": { icon: <Activity size={16} className="text-orange-500" /> },
    "total_clusters": { icon: <Box size={16} className="text-indigo-500" /> },
    "total_repositories": { icon: <Server size={16} className="text-cyan-500" /> },
    "available_storage": { icon: <Database size={16} className="text-amber-500" /> },
    "total_snapshots": { icon: <Cloud size={16} className="text-sky-500" /> },
    "total_volumes": { icon: <Database size={16} className="text-blue-500" /> },
    "total_storage_gb": { icon: <Box size={16} className="text-indigo-500" /> },
    "total_snapshot_gb": { icon: <Cloud size={16} className="text-orange-500" /> },
    "total_lb_hours": { icon: <Activity size={16} className="text-blue-400" /> },
    "total_log_gb": { icon: <Database size={16} className="text-purple-400" /> },
    "total_alarms": { icon: <Zap size={16} className="text-red-400" /> },
    "total_api_calls": { icon: <Activity size={16} className="text-green-400" /> },
};
