import { Component } from 'react';
import { toast } from 'react-toastify';
import { ErrorFallbackUI } from './ErrorFallbackUI';

class ErrorBoundary extends Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    // Update state so the next render will show the fallback UI.
    return { hasError: true, error };
  }

  componentDidCatch(error, errorInfo) {
    // log the error to an error reporting service here
    console.error("ErrorBoundary caught an error:", error, errorInfo);
    toast.error(error.message ? `Component Error: ${error.message}` : 'A component error occurred');
  }

  handleReset = () => {
    this.setState({ hasError: false, error: null });
    // Optionally trigger a remount or data refetch if provided via props
    if (this.props.onReset) {
      this.props.onReset();
    }
  }

  render() {
    if (this.state.hasError) {
      return (
        <ErrorFallbackUI 
          error={this.state.error} 
          onReset={this.handleReset} 
        />
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;
