import { useQuery, useMutation, useQueryClient, keepPreviousData } from "@tanstack/react-query";
import { getlistsuggestions, postcreatesuggestions, updatesuggestions, deletesuggestions } from "../Pages/Recommendation/Recommendation.api";
import { queryKeys } from "../lib/queryKeys";
import { useFilters } from "./useFilters";

export const useSuggestions = () => {
  const queryClient = useQueryClient();
  const { filters } = useFilters();
  const accountName = filters?.account || filters?.account_name;

  const listQuery = useQuery({
    queryKey: queryKeys.suggestions.list({ account_name: accountName }),
    queryFn: () => getlistsuggestions({ account_name: accountName }),
    placeholderData: keepPreviousData,
    enabled: !!accountName,
    retry: 1,
  });

  const createMutation = useMutation({
    mutationFn: (payload) => postcreatesuggestions({ account_name: accountName, ...payload }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.suggestions.all });
    },
  });

  const updateMutation = useMutation({
    mutationFn: ({ suggestion_id, payload }) => updatesuggestions(suggestion_id, payload),
    onSuccess: () => {
      setTimeout(() => {
        queryClient.invalidateQueries({ queryKey: queryKeys.suggestions.all });
      }, 2000);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (suggestion_id) => deletesuggestions(suggestion_id),
    onMutate: async (suggestion_id) => {
      await queryClient.cancelQueries({ queryKey: queryKeys.suggestions.list({ account_name: accountName }) });
      const previousSuggestions = queryClient.getQueryData(queryKeys.suggestions.list({ account_name: accountName }));
      
      if (previousSuggestions) {
        queryClient.setQueryData(
          queryKeys.suggestions.list({ account_name: accountName }),
          (old) => Array.isArray(old) ? old.filter((s) => String(s.id || s.suggestion_id || s._id) !== String(suggestion_id)) : old
        );
      }
      return { previousSuggestions };
    },
    onError: (err, variables, context) => {
      if (context?.previousSuggestions) {
        queryClient.setQueryData(queryKeys.suggestions.list({ account_name: accountName }), context.previousSuggestions);
      }
    },
    onSettled: () => {
      setTimeout(() => {
        queryClient.invalidateQueries({ queryKey: queryKeys.suggestions.all });
      }, 2000);
    },
  });

  return {
    suggestions: listQuery.data ?? [],
    isLoading: listQuery.isLoading,
    isError: listQuery.isError,
    listQuery,

    createSuggestion: createMutation.mutateAsync,
    isCreating: createMutation.isPending,
    createError: createMutation.error,

    updateSuggestion: updateMutation.mutateAsync,
    isUpdating: updateMutation.isPending,
    updateError: updateMutation.error,

    deleteSuggestion: deleteMutation.mutateAsync,
    isDeleting: deleteMutation.isPending,
    deleteError: deleteMutation.error,
  };
};
