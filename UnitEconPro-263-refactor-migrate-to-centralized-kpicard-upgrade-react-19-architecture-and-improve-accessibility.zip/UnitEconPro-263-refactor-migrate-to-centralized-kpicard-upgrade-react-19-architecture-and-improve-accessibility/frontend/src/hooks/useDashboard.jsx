import { keepPreviousData, useQuery } from "@tanstack/react-query";
import { getDashboardSummary, getDashboardForecast, getDashboardTrend, getComparison, getForecastBudget, getBudgetBudget, getBreakdownService } from "../Pages/Dashboard/dashboard.api";
import { useFilters } from "./useFilters";
import { queryKeys } from "../lib/queryKeys";

export const useDashboard = () => {
    const { filters } = useFilters();
    const hasDateRange = !!filters.start_date && !!filters.end_date;
    const accountName = filters.account || filters.account_name;
    const hasAccount = !!accountName;
    const isQueryEnabled = hasDateRange && hasAccount;

    const summaryQuery = useQuery({
        queryKey: queryKeys.dashboard.summary(filters),
        queryFn: () => getDashboardSummary(filters),
        enabled: isQueryEnabled,
    });

    const comparisonQuery = useQuery({
        queryKey: queryKeys.dashboard.comparison(filters),
        queryFn: () => getComparison(filters),
        enabled: isQueryEnabled,
    });

    const forecastQuery = useQuery({
        queryKey: queryKeys.dashboard.forecast(filters),
        queryFn: () => getDashboardForecast(filters),
        enabled: isQueryEnabled,
    });

    const trendQuery = useQuery({
        queryKey: queryKeys.dashboard.trend(filters),
        queryFn: () => getDashboardTrend(filters),
        enabled: isQueryEnabled,
        placeholderData: keepPreviousData,
    });

    const breakdownServiceQuery = useQuery({
        queryKey: queryKeys.dashboard.breakdownService(filters),
        queryFn: () => getBreakdownService(filters),
        enabled: isQueryEnabled,
        placeholderData: keepPreviousData,
    });

    const budgetForecastQuery = useQuery({
        queryKey: queryKeys.budget.getBudgetBudget(accountName),
        queryFn: () => getBudgetBudget(accountName),
        enabled: hasAccount,
    });

    return {
        summary: summaryQuery.data,
        comparison: comparisonQuery.data,
        forecast: forecastQuery.data,
        budgetForecast: budgetForecastQuery.data,
        trend: trendQuery.data,
        breakdownService: breakdownServiceQuery.data,
        isLoading:
            summaryQuery.isLoading ||
            comparisonQuery.isLoading ||
            forecastQuery.isLoading ||
            budgetForecastQuery.isLoading ||
            trendQuery.isLoading ||
            breakdownServiceQuery.isLoading,
        isError:
            summaryQuery.isError ||
            comparisonQuery.isError ||
            forecastQuery.isError ||
            budgetForecastQuery.isError ||
            trendQuery.isError ||
            breakdownServiceQuery.isError,
        isSummaryLoading: summaryQuery.isLoading,
        isSummaryError: summaryQuery.isError,
        isComparisonLoading: comparisonQuery.isLoading,
        isComparisonError: comparisonQuery.isError,
        isTrendLoading: trendQuery.isLoading,
        isTrendError: trendQuery.isError,
        isForecastLoading: forecastQuery.isLoading,
        isForecastError: forecastQuery.isError,
        isBudgetForecastLoading: budgetForecastQuery.isLoading,
        isBudgetForecastError: budgetForecastQuery.isError,
        isBreakdownServiceLoading: breakdownServiceQuery.isLoading,
        isBreakdownServiceFetching: breakdownServiceQuery.isFetching,
        isBreakdownServiceError: breakdownServiceQuery.isError,
    };
};
