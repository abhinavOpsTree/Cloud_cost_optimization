import { useQuery, keepPreviousData } from "@tanstack/react-query";
import { getRDSSummary, getRDSInstances, getRDSMetadata } from "../Pages/Databases/database.api";
import { useFilters } from "./useFilters";
import { queryKeys } from "../lib/queryKeys";

export const useDatabase = (instanceId) => {
    const { filters } = useFilters();
    const hasDateRange = !!filters.start_date && !!filters.end_date;
    const hasAccount = !!(filters.account || filters.account_name);
    const isQueryEnabled = hasDateRange && hasAccount;

    const summaryQuery = useQuery({
        queryKey: queryKeys.database.summary(filters),
        queryFn: () => getRDSSummary(filters),
        enabled: isQueryEnabled,
        placeholderData: keepPreviousData,
        retry: 1,
    });

    const instancesQuery = useQuery({
        queryKey: queryKeys.database.instances(filters),
        queryFn: () => getRDSInstances(filters),
        enabled: isQueryEnabled,
        placeholderData: keepPreviousData,
        retry: 1,
    });

    const metadataQuery = useQuery({
        queryKey: queryKeys.database.metadata(instanceId, filters),
        queryFn: () => getRDSMetadata(instanceId),
        enabled: isQueryEnabled && !!instanceId,
        placeholderData: keepPreviousData,
        retry: 1,
    });

    return {
        rdsSummary: summaryQuery.data ?? null,
        rdsInstances: instancesQuery.data ?? [],
        metadata: metadataQuery.data ?? null,
        isLoading: summaryQuery.isLoading || instancesQuery.isLoading,
        isError: summaryQuery.isError || instancesQuery.isError,
        isMetadataLoading: metadataQuery.isLoading,
        isMetadataError: metadataQuery.isError,
        summaryQuery,
        instancesQuery,
        metadataQuery,
    };
};
