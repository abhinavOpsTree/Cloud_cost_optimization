import { useQuery } from "@tanstack/react-query";
import { fetchReports, fetchReportTrend } from "../Pages/Reporting/Reporting.api";

export const useReports = (filters = {}) => {
    const { account = "All", scope = "month", period = "current", persona = "cfo" } = filters;
    return useQuery({
        queryKey: ['reports', 'summary', account, scope, period, persona],
        queryFn: () => fetchReports({ account, scope, period, persona }),
        staleTime: 5 * 60 * 1000,
    });
};

export const useReportTrend = (filters = {}) => {
    const { account = "All", scope = "month", period = "current", persona = "cfo", lookback = 6 } = filters;
    return useQuery({
        queryKey: ['reports', 'trend', account, scope, period, persona, lookback],
        queryFn: () => fetchReportTrend({ account, scope, period, persona, lookback }),
        staleTime: 5 * 60 * 1000,
    });
};
