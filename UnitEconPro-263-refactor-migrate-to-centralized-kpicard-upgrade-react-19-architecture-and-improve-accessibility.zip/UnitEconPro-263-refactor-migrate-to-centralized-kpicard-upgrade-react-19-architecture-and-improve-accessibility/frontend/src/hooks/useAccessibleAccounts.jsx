import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "../lib/apiClient";
import { API_ENDPOINTS } from "../APIs/ApiEndPoint";
import { useAuth } from "../providers/AuthContext";

// Accounts the logged-in user can access (backend filters by email).
// Shared query key so Navbar and Layout reuse a single request/cache entry.
export const useAccessibleAccounts = () => {
    const { keycloak, isLoading: isAuthLoading } = useAuth();
    const email = keycloak?.tokenParsed?.email || "";

    const query = useQuery({
        queryKey: ["accessible-accounts", email],
        queryFn: () => apiRequest({ endpoint: API_ENDPOINTS.listaccounts(email) }),
        enabled: !isAuthLoading,
    });

    return { ...query, email };
};

