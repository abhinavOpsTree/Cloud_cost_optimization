import { useQuery } from "@tanstack/react-query";
import {
    getComputeECSSummary,
    getComputeECSClusters,
    getComputeECSMetadata,
} from "../../Pages/Compute/Compute.api";
import { useFilters } from "../useFilters";

export const useECS = (clusterName) => {
    const { filters } = useFilters();
    const hasDateRange = !!filters.start_date && !!filters.end_date;
    const hasAccount = !!(filters.account || filters.account_name);
    const isQueryEnabled = hasDateRange && hasAccount;

    // ── Summary cards ───────────────────────────────────────────────────────
    const summaryQuery = useQuery({
        queryKey: ["ECS", "summary", filters.start_date, filters.end_date, filters.account],
        queryFn: () => getComputeECSSummary(filters),
        enabled: isQueryEnabled,
    });

    // ── Repository list ─────────────────────────────────────────────────────
    const repositoriesQuery = useQuery({
        queryKey: ["ECS", "repositories", filters.start_date, filters.end_date, filters.account],
        queryFn: () => getComputeECSClusters(filters),
        enabled: isQueryEnabled,
    });

    // ── Per-repo metadata (only when clusterName is provided) ────────────
    const metadataQuery = useQuery({
        queryKey: ["ECS", "metadata", clusterName, filters.start_date, filters.end_date, filters.account],
        queryFn: () => getComputeECSMetadata({
            cluster_name: clusterName,
            start_date: filters.start_date,
            end_date: filters.end_date,
            account: filters.account,
        }),
        enabled: isQueryEnabled && !!clusterName,
    });

    return {
        summary: summaryQuery.data ?? null,
        repositories: repositoriesQuery.data ?? [],
        metadata: metadataQuery.data?.data ?? metadataQuery.data ?? null,
        isLoading: summaryQuery.isLoading || repositoriesQuery.isLoading,
        isMetadataLoading: metadataQuery.isLoading,
        isError: summaryQuery.isError || repositoriesQuery.isError,
        isMetadataError: metadataQuery.isError,
        summaryQuery,
        repositoriesQuery,
        metadataQuery,
    };
};
