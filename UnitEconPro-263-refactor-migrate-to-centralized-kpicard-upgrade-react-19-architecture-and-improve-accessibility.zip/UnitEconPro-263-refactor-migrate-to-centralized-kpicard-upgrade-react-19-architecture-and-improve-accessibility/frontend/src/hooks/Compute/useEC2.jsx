import { useQuery, keepPreviousData } from "@tanstack/react-query";
import {
    getComputeEC2Summary,
    getComputeEC2Instances,
    getComputeEC2Metadata,
} from "../../Pages/Compute/Compute.api";
import { useFilters } from "../useFilters";
import { queryKeys } from "../../lib/queryKeys";

/**
 * Hook for EC2 summary and instances list.
 */
export const useEC2 = (pagination = {}) => {
    const { filters } = useFilters();
    const hasDateRange = !!filters.start_date && !!filters.end_date;
    const hasAccount = !!(filters.account || filters.account_name);
    const isQueryEnabled = hasDateRange && hasAccount;

    // ── Summary cards ──────────────────────────────────────────────────────
    const summaryQuery = useQuery({
        queryKey: queryKeys.ec2.summary(filters),
        queryFn: () => getComputeEC2Summary(filters),
        enabled: isQueryEnabled,
        placeholderData: keepPreviousData,
    });

    // ── Instance list ───────────────────────────────────────────────────────
    const instancesQuery = useQuery({
        queryKey: queryKeys.ec2.instances({ ...filters, ...pagination }),
        queryFn: () => getComputeEC2Instances({ ...filters, ...pagination }),
        enabled: isQueryEnabled,
        placeholderData: keepPreviousData,
    });


    return {
        summary: summaryQuery.data ?? null,
        instances: instancesQuery.data ?? [],
        isLoading: summaryQuery.isLoading || instancesQuery.isLoading,
        isError: summaryQuery.isError || instancesQuery.isError,
        summaryQuery,
        instancesQuery,
    };
};

/**
 * Hook for EC2 instance-specific metadata.
 */
export const useEC2Metadata = (instanceId) => {
    const { filters } = useFilters();
    const hasDateRange = !!filters.start_date && !!filters.end_date;
    const hasAccount = !!(filters.account || filters.account_name);
    const isQueryEnabled = hasDateRange && hasAccount;

    const metadataQuery = useQuery({
        queryKey: queryKeys.ec2.metadata(instanceId, filters),
        queryFn: () => getComputeEC2Metadata({
            instance_id: instanceId,
            start_date: filters.start_date,
            end_date: filters.end_date,
            account: filters.account,
        }),
        enabled: isQueryEnabled && !!instanceId,
        placeholderData: keepPreviousData,
    });

    return {
        metadata: metadataQuery.data ?? null,
        isMetadataLoading: metadataQuery.isLoading,
        isMetadataError: metadataQuery.isError,
        metadataQuery,
    };
};
