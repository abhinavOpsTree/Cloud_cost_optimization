import { useQuery } from "@tanstack/react-query";
import {
    getComputeEKSSummary,
    getComputeEKSClusters,
    getComputeEKSMetadata,
} from "../../Pages/Compute/Compute.api";
import { useFilters } from "../useFilters";

export const useEKS = (clusterName) => {
    const { filters } = useFilters();
    const hasDateRange = !!filters.start_date && !!filters.end_date;
    const hasAccount = !!(filters.account || filters.account_name);
    const isQueryEnabled = hasDateRange && hasAccount;

    const summaryQuery = useQuery({
        queryKey: ["eks", "summary", filters.start_date, filters.end_date, filters.account],
        queryFn: () => getComputeEKSSummary(filters),
        enabled: isQueryEnabled,
    });

    // ── Cluster list ────────────────────────────────────────────────────────
    const clustersQuery = useQuery({
        queryKey: ["eks", "clusters", filters.start_date, filters.end_date, filters.account],
        queryFn: () => getComputeEKSClusters(filters),
        enabled: isQueryEnabled,
    });

    const metadataQuery = useQuery({
        queryKey: ["eks", "metadata", clusterName || filters.cluster_name, filters.start_date, filters.end_date, filters.account],
        queryFn: () => getComputeEKSMetadata({
            cluster_name: clusterName || filters.cluster_name,
            start_date: filters.start_date,
            end_date: filters.end_date,
            account: filters.account,
        }),
        enabled: isQueryEnabled && !!(clusterName || filters.cluster_name),
    });

    return {
        // data
        summary: summaryQuery.data ?? null,
        clusters: clustersQuery.data ?? [],
        metadata: metadataQuery.data ?? null,
        // loading / error
        isLoading: summaryQuery.isLoading || clustersQuery.isLoading || (!!clusterName && metadataQuery.isLoading),
        isError: summaryQuery.isError || clustersQuery.isError || (!!clusterName && metadataQuery.isError),
        isMetadataLoading: metadataQuery.isLoading,
        isMetadataError: metadataQuery.isError,
        // raw query refs
        summaryQuery,
        clustersQuery,
        metadataQuery,
    };
};
