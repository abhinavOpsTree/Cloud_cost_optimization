import { useQuery } from "@tanstack/react-query";
import {
    getComputeECRSummary,
    getComputeECRRepositories,
    getComputeECRMetadata,
} from "../../Pages/Compute/Compute.api";
import { useFilters } from "../useFilters";

export const useECR = (repositoryName) => {
    const { filters } = useFilters();
    const hasDateRange = !!filters.start_date && !!filters.end_date;
    const hasAccount = !!(filters.account || filters.account_name);
    const isQueryEnabled = hasDateRange && hasAccount;

    // ── Summary cards ───────────────────────────────────────────────────────
    const summaryQuery = useQuery({
        queryKey: ["ecr", "summary", filters.start_date, filters.end_date, filters.account],
        queryFn: () => getComputeECRSummary(filters),
        enabled: isQueryEnabled,
    });

    // ── Repository list ─────────────────────────────────────────────────────
    const repositoriesQuery = useQuery({
        queryKey: ["ecr", "repositories", filters.start_date, filters.end_date, filters.account],
        queryFn: () => getComputeECRRepositories(filters),
        enabled: isQueryEnabled,
    });

    // ── Per-repo metadata (only when repositoryName is provided) ────────────
    const metadataQuery = useQuery({
        queryKey: ["ecr", "metadata", repositoryName, filters.start_date, filters.end_date, filters.account],
        queryFn: () => getComputeECRMetadata({
            repository_name: repositoryName,
            start_date: filters.start_date,
            end_date: filters.end_date,
            account: filters.account,
        }),
        enabled: isQueryEnabled && !!repositoryName,
    });

    return {
        summary: summaryQuery.data ?? null,
        repositories: repositoriesQuery.data ?? [],
        metadata: metadataQuery.data?.data ?? metadataQuery.data ?? null,
        isLoading: summaryQuery.isLoading || repositoriesQuery.isLoading,
        isMetadataLoading: metadataQuery.isLoading,
        isError: summaryQuery.isError || repositoriesQuery.isError,
        isMetadataError: metadataQuery.isError,
        summaryQuery,
        repositoriesQuery,
        metadataQuery,
    };
};
