import { useMutation, useQueryClient } from "@tanstack/react-query";
import { createBudget } from "../Pages/Account/Account.api";
import { queryKeys } from "../lib/queryKeys";
import { apiRequest } from "../lib/apiClient";
import { API_ENDPOINTS } from "../APIs/ApiEndPoint";

// Fetches the account's fresh budget once and patches it into the cached accounts list.
// Must be called AFTER all budget saves for the account have completed — refreshing
// per-mutation races concurrent saves and can leave stale data in the cache.
export const refreshAccountBudget = async (queryClient, accountName) => {
  try {
    const freshBudgetData = await apiRequest({
      endpoint: API_ENDPOINTS.getBudgetStatus(accountName),
      method: "GET",
    });

    queryClient.setQueriesData({ queryKey: queryKeys.accounts.all }, (oldData) => {
      if (!oldData) return oldData;
      return oldData.map(account => {
        if (account.account_name === accountName) {
          const accountData = freshBudgetData?.account || freshBudgetData;
          const servicesData = freshBudgetData?.services || freshBudgetData?.service_budgets || [];
          return {
            ...account,
            budget: {
              ...accountData,
              services: servicesData
            }
          };
        }
        return account;
      });
    });
  } catch (err) {
    console.error("Failed to refresh budget data for account", err);
    queryClient.invalidateQueries({ queryKey: queryKeys.accounts.all });
  }
};

export const useCreateBudget = () => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({ account_name, budget_amount, service_code }) => {
      if (!account_name?.trim()) {
        return Promise.reject(new Error("An account name is required to set a budget"));
      }
      return createBudget(budget_amount, account_name.trim(), service_code);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: queryKeys.budget.all });
    },
  });
};

