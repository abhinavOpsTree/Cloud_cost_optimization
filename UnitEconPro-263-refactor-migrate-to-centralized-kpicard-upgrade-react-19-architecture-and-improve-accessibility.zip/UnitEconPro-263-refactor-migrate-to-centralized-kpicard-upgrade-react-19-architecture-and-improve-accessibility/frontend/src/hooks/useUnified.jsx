import { useQuery, keepPreviousData } from "@tanstack/react-query";
import { useLocation } from "react-router-dom";
import { useFilters } from "./useFilters";
import { getUnifiedBreakdown, getUnifiedTrend } from "../lib/types/Unified";
import { queryKeys } from "../lib/queryKeys";

const ROUTE_TO_SERVICE = {
    ec2: "ec2",
    ecr: "ecr",
    eks: "eks",
    ecs: "ecs",
    s3: "s3",
    ebs: "ebs",
    rds: "rds",
    vpc: "vpc",
    elb: "elb",
    cloudwatch: "cloudwatch",
    datatransfer :"data-transfer"
};

const getServiceFromPathname = (pathname) => {
    const segments = pathname.split("/").filter(Boolean);
    const last = segments[segments.length - 1]?.toLowerCase();
    return ROUTE_TO_SERVICE[last] ?? null;
};

export const useUnified = (
    dimension = "region",
    serviceOverride,
    options = { trend: true, breakdown: true }
) => {
    const { pathname } = useLocation();
    const { filters } = useFilters();

    const service = serviceOverride?.toLowerCase() || getServiceFromPathname(pathname);
    const hasDateRange = !!filters.start_date && !!filters.end_date;
    const hasAccount = !!(filters.account || filters.account_name);
    const isQueryEnabled = hasDateRange && hasAccount;

    const trendQuery = useQuery({
        queryKey: queryKeys.unified.trend(service || "unknown", filters),
        queryFn: () => getUnifiedTrend(filters, service),
        enabled: !!service && isQueryEnabled && options.trend !== false,
        placeholderData: keepPreviousData,
        staleTime: 60000,
        retry: false,
        refetchOnWindowFocus: false,
        refetchOnReconnect: false,
    });

    const breakdownQuery = useQuery({
        queryKey: queryKeys.unified.breakdown(service || "unknown", dimension, filters),
        queryFn: () => getUnifiedBreakdown(filters, service, dimension),
        enabled: !!service && isQueryEnabled && options.breakdown !== false,
        // OPTIMIZATION: Removed `placeholderData: keepPreviousData` to prevent PieChart double-animation glitches.
        // Keeping previous data caused the chart to instantly start animating old slice data with a new title, 
        // only to abruptly halt and restart when the new data arrived 200ms later.
        staleTime: 60000,
        retry: false,
        refetchOnWindowFocus: false,
        refetchOnReconnect: false,
    });

    const isServiceValid = !!service;

    return {
        service,
        trend: trendQuery.data ?? [],
        breakdown: breakdownQuery.data ?? [],
        isTrendLoading: isServiceValid && trendQuery.isLoading,
        isBreakdownLoading: isServiceValid && breakdownQuery.isLoading,
        isTrendError: trendQuery.isError,
        isBreakdownError: breakdownQuery.isError,
        isLoading: isServiceValid && (trendQuery.isLoading || breakdownQuery.isLoading),
        isError: trendQuery.isError || breakdownQuery.isError,
    };
};
