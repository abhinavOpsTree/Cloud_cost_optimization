import { useState, useEffect, useCallback, useMemo } from 'react';
import { cloudSentryApi } from '../../Pages/Cloud-Sentry/cloudSentry.api.js';

export function useCloudSentry() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const executeApiCall = useCallback(async (apiFunction, ...args) => {
    setLoading(true);
    setError(null);
    try {
      const result = await apiFunction(...args);
      return result;
    } catch (err) {
      setError(err.message || 'An error occurred');
      throw err;
    } finally {
      setLoading(false);
    }
  }, []);

  const apiMethods = useMemo(() => ({
    postIngest: (days, startDate, endDate) => executeApiCall(cloudSentryApi.postIngest, days, startDate, endDate),
    postAnalyse: () => executeApiCall(cloudSentryApi.postAnalyse),
    getAnalyseProgress: () => executeApiCall(cloudSentryApi.getAnalyseProgress),
    getRecommendations: (params) => executeApiCall(cloudSentryApi.getRecommendations, params),
    getScriptPreview: (recId) => executeApiCall(cloudSentryApi.getRecommendationScriptPreview, recId),
    updateRecommendationStatus: (recId, status) => executeApiCall(cloudSentryApi.updateRecommendationStatus, recId, status),
    getInstances: (params) => executeApiCall(cloudSentryApi.getInstances, params),
    getHealth: () => executeApiCall(cloudSentryApi.getHealth),
    getFleetSummary: () => executeApiCall(cloudSentryApi.getFleetSummary),
    getTimeSeriesStats: (days, startDate, endDate) => executeApiCall(cloudSentryApi.getTimeSeriesStats, days, startDate, endDate),
    getSavings: () => executeApiCall(cloudSentryApi.getSavings),
    getTagAudit: () => executeApiCall(cloudSentryApi.getTagAudit),
    postChat: (body) => executeApiCall(cloudSentryApi.postChat, body),
    getChatHistory: (sessionId) => executeApiCall(cloudSentryApi.getChatHistory, sessionId),
    getWhatIf: (resourceId) => executeApiCall(cloudSentryApi.getWhatIf, resourceId),
    getSpotSimulator: (searchTerm) => executeApiCall(cloudSentryApi.getSpotSimulator, searchTerm),
    getExportAuditSummary: () => executeApiCall(cloudSentryApi.getExportAuditSummary),
    getCompleteness: () => executeApiCall(cloudSentryApi.getCompleteness),
    submitSkill: (body) => executeApiCall(cloudSentryApi.submitSkill, body),
    getSkillSubmissions: (status) => executeApiCall(cloudSentryApi.getSkillSubmissions, status),
    approveSkillSubmission: (id, userEmail, reviewNotes) => executeApiCall(cloudSentryApi.approveSkillSubmission, id, userEmail, reviewNotes),
    rejectSkillSubmission: (id, userEmail, reviewNotes) => executeApiCall(cloudSentryApi.rejectSkillSubmission, id, userEmail, reviewNotes),
    getSkillAdmins: () => executeApiCall(cloudSentryApi.getSkillAdmins),
    addSkillAdmin: (email, userEmail) => executeApiCall(cloudSentryApi.addSkillAdmin, email, userEmail),
    removeSkillAdmin: (email, userEmail) => executeApiCall(cloudSentryApi.removeSkillAdmin, email, userEmail),
  }), [executeApiCall]);

  return {
    loading,
    error,
    ...apiMethods
  };
}
