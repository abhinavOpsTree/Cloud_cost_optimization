import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { annotationsApi } from "../services/annotationsApi";
import { queryKeys } from "../lib/queryKeys";

export const useAnnotations = (account_name, service, date) => {
    const queryClient = useQueryClient();

    const listQuery = useQuery({
        queryKey: queryKeys.annotations.list({ account_name, service, date }),
        queryFn: () => annotationsApi.getAnnotations(account_name, service, date),
        enabled: !!account_name && !!service && !!date,
    });

    const createMutation = useMutation({
        mutationFn: (payload) => annotationsApi.createAnnotation(payload),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: queryKeys.annotations.all });
        },
    });

    const deleteMutation = useMutation({
        mutationFn: (annotation_id) => annotationsApi.deleteAnnotation(annotation_id),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: queryKeys.annotations.all });
        },
    });

    const updateMutation = useMutation({
        mutationFn: ({ id, data }) => annotationsApi.updateAnnotation(id, data),
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: queryKeys.annotations.all });
        },
    });

    return {
        annotations: listQuery.data ?? [],
        isLoading: listQuery.isLoading,
        isError: listQuery.isError,

        createAnnotation: createMutation.mutateAsync,
        isCreating: createMutation.isPending,
        createError: createMutation.error,

        deleteAnnotation: deleteMutation.mutateAsync,
        isDeleting: deleteMutation.isPending,
        deleteError: deleteMutation.error,

        updateAnnotation: updateMutation.mutateAsync,
        isUpdating: updateMutation.isPending,
        updateError: updateMutation.error,
    };
};

export const useAnnotationDates = (account_name, service, start_date, end_date) => {
    const listQuery = useQuery({
        queryKey: queryKeys.annotations.dates({ account_name, service, start_date, end_date }),
        queryFn: () => annotationsApi.getAnnotationDates(account_name, service, start_date, end_date),
        enabled: !!account_name && !!service && !!start_date && !!end_date,
    });

    return {
        annotationDates: listQuery.data ?? [],
        isLoading: listQuery.isLoading,
        isError: listQuery.isError,
    };
};
