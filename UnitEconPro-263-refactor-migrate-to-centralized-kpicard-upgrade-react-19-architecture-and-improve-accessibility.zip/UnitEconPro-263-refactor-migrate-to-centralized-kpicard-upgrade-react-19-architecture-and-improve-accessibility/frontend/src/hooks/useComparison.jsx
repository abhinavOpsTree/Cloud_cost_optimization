import { useQuery, keepPreviousData } from "@tanstack/react-query";
import {
    getCostComparisonDetails,
    getCostComparisonSummary,
} from "../Pages/CostComparison/CostComparison.api";
import { useFilters } from "./useFilters";
import { queryKeys } from "../lib/queryKeys";
import { useDashboard } from "./useDashboard";

export const useComparison = () => {
    const { filters } = useFilters();
    const hasDateRange = !!filters.compare_date_a && !!filters.compare_date_b;
    const hasAccount = !!(filters.account || filters.account_name);
    const isQueryEnabled = hasDateRange && hasAccount;

    const summaryQuery = useQuery({
        queryKey: queryKeys.comparison.summary(filters),
        queryFn: () => getCostComparisonSummary(filters),
        enabled: isQueryEnabled,
        placeholderData: keepPreviousData,
    });

    const detailsQuery = useQuery({
        queryKey: ["cost-comparison", "detail", filters.compare_date_a, filters.compare_date_b, filters.account, filters.service],
        queryFn: () => getCostComparisonDetails(filters),
        enabled: hasDateRange && !!filters.service,
    });
    const { summary } = useDashboard();

    return {
        summaryData: summaryQuery.data,
        detailsData: detailsQuery.data,
        isLoading: summaryQuery.isLoading,
        isError: summaryQuery.isError,
        
    };
};
