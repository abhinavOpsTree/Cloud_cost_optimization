import { useQuery, keepPreviousData } from "@tanstack/react-query";
import {
    getELBSummary,
    getELBLoadBalancers,
    getELBMetadata,
} from "../../Pages/Networking/networking.api";
import { useFilters } from "../useFilters";
import { queryKeys } from "../../lib/queryKeys";

export const useELB = (lbArn) => {
    const { filters } = useFilters();
    const hasDateRange = !!filters.start_date && !!filters.end_date;
    const hasAccount = !!(filters.account || filters.account_name);
    const isQueryEnabled = hasDateRange && hasAccount;

    const summaryQuery = useQuery({
        queryKey: queryKeys.elb.summary(filters),
        queryFn: () => getELBSummary(filters),
        enabled: isQueryEnabled,
        placeholderData: keepPreviousData,
        retry: 1,
    });

    const loadBalancersQuery = useQuery({
        queryKey: queryKeys.elb.loadBalancers(filters),
        queryFn: () => getELBLoadBalancers(filters),
        enabled: isQueryEnabled,
        placeholderData: keepPreviousData,
        retry: 1,
    });

    const metadataQuery = useQuery({
        queryKey: queryKeys.elb.metadata(lbArn, filters),
        queryFn: () => getELBMetadata(lbArn, filters),
        enabled: isQueryEnabled && !!lbArn,
        placeholderData: keepPreviousData,
        retry: 1,
    });

    return {
        elbSummary: summaryQuery.data ?? null,
        elbLoadBalancers: loadBalancersQuery.data ?? [],
        elbIdleLoadBalancers: [],
        metadata: metadataQuery.data ?? null,
        isLoading: summaryQuery.isLoading || loadBalancersQuery.isLoading,
        isError: summaryQuery.isError || loadBalancersQuery.isError,
        isMetadataLoading: metadataQuery.isLoading,
        isMetadataError: metadataQuery.isError,
        summaryQuery,
        loadBalancersQuery,
        metadataQuery,
    };
};
