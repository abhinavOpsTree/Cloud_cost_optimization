import { useQuery } from "@tanstack/react-query";
import { getDataTransferSummary, getDataTransferTopResources } from "../../Pages/Networking/networking.api";
import { useFilters } from "../useFilters";
import { queryKeys } from "../../lib/queryKeys";

export const useDataTransfer = () => {
    const { filters } = useFilters();
    const hasDateRange = !!filters.start_date && !!filters.end_date;
    const hasAccount = !!(filters.account || filters.account_name);
    const isQueryEnabled = hasDateRange && hasAccount;

    const summaryQuery = useQuery({
        queryKey: queryKeys.dataTransfer.summary(filters),
        queryFn: () => getDataTransferSummary(filters),
        enabled: isQueryEnabled,
        retry: 1,
        refetchOnWindowFocus: false,
        refetchOnReconnect: false,
    })

    const ResourcesQuery = useQuery({
        queryKey: queryKeys.dataTransfer.resources(filters),
        queryFn: () => getDataTransferTopResources(filters),
        enabled: isQueryEnabled,
        retry: 1,
        refetchOnWindowFocus: false,
        refetchOnReconnect: false,
    });

    return {
        summary: summaryQuery.data ?? null,
        topResources: ResourcesQuery.data ?? [],
        isLoading: summaryQuery.isLoading || ResourcesQuery.isLoading,
        isError: summaryQuery.isError || ResourcesQuery.isError,
        summaryQuery,
        ResourcesQuery,
    };
};
