import { useQuery, keepPreviousData } from "@tanstack/react-query";
import {
    getVPCSummary,
    getVPCPublicIPBreakdown,
    getVPCResources,
    getVPCMetadata,
} from "../../Pages/Networking/networking.api";
import { useFilters } from "../useFilters";
import { queryKeys } from "../../lib/queryKeys";

export const useVPC = (vpcId) => {
    const { filters } = useFilters();
    const hasDateRange = !!filters.start_date && !!filters.end_date;
    const hasAccount = !!(filters.account || filters.account_name);
    const isQueryEnabled = hasDateRange && hasAccount;

    const summaryQuery = useQuery({
        queryKey: queryKeys.vpc.summary(filters),
        queryFn: () => getVPCSummary(filters),
        enabled: isQueryEnabled,
        placeholderData: keepPreviousData,
    });

    const publicIpQuery = useQuery({
        queryKey: queryKeys.vpc.publicIp(filters),
        queryFn: () => getVPCPublicIPBreakdown(filters),
        enabled: isQueryEnabled,
        placeholderData: keepPreviousData,
    });

    const resourcesQuery = useQuery({
        queryKey: queryKeys.vpc.resources(filters),
        queryFn: () => getVPCResources(filters),
        enabled: isQueryEnabled,
        placeholderData: keepPreviousData,
    });

    const metadataQuery = useQuery({
        queryKey: queryKeys.vpc.metadata(vpcId, filters),
        queryFn: () => getVPCMetadata(vpcId, filters),
        enabled: isQueryEnabled && !!vpcId,
        placeholderData: keepPreviousData,
    });

    return {
        vpcSummary: summaryQuery.data ?? [],
        vpcPublicIP: publicIpQuery.data ?? [],
        vpcResources: resourcesQuery.data ?? [],
        metadata: metadataQuery.data ?? null,
        isLoading: summaryQuery.isLoading || publicIpQuery.isLoading || resourcesQuery.isLoading,
        isError: summaryQuery.isError || publicIpQuery.isError || resourcesQuery.isError,
        isMetadataLoading: metadataQuery.isLoading,
        isMetadataError: metadataQuery.isError,
        summaryQuery,
        publicIpQuery,
        resourcesQuery,
        metadataQuery,
    };
};
