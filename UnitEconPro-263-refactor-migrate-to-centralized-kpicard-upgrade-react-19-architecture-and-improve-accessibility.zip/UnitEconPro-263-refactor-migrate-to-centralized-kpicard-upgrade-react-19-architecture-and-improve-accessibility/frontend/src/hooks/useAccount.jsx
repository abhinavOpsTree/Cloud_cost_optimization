import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { fetchAccountsWithBudgets, deleteAccount } from "../Pages/Account/Account.api";
import { useAuth } from "../providers/AuthContext";

export const useAccounts = () => {
    const { keycloak, isLoading } = useAuth();
    const email = keycloak?.tokenParsed?.email || "";
    return useQuery({
        queryKey: ['accounts', email],
        queryFn: () => fetchAccountsWithBudgets(email),
        enabled: !isLoading,
    });
};

export const useDeleteAccount = () => {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: deleteAccount,
        onSuccess: () => {
            queryClient.invalidateQueries({ queryKey: ['accounts'] });
        },
    });
};
