import { useQuery, useMutation, useQueryClient, keepPreviousData } from "@tanstack/react-query";
import { getPermissions, updatePermission } from "../Pages/Permission/Permission.api";

const ACCOUNT_NAME_TO_ID = {
    "tripare-dev": "383114925628",
    "dealshare-infra": "432995435807",
    "opstree": "702037529261",
    "dealshare": "880042530053"
};

const resolveAccountId = (account) => {
    let accountId = account?.aws_account_id;
    if (!accountId && account?.account_name) {
        const name = account.account_name.toLowerCase();
        accountId = ACCOUNT_NAME_TO_ID[name] || account.account_name;
    }
    return accountId;
};

export const prefetchPermissions = (queryClient, account) => {
    const accountId = resolveAccountId(account);
    if (!accountId) return;
    
    queryClient.prefetchQuery({
        queryKey: ['permissions', accountId],
        queryFn: () => getPermissions(accountId),
        staleTime: 5 * 60 * 1000, // Keep fresh for 5 minutes
    });
};

export const usePermission = (account) => {
    const accountId = resolveAccountId(account);

    const permissionsQuery = useQuery({
        queryKey: ['permissions', accountId],
        queryFn: () => getPermissions(accountId),
        enabled: !!accountId,
        placeholderData: keepPreviousData,
        retry: 1,
    });

    return {
        permissions: permissionsQuery.data ?? [],
        isLoading: permissionsQuery.isLoading,
        isError: permissionsQuery.isError,
        permissionsQuery,
    };
};

export const useUpdatePermission = () => {
    const queryClient = useQueryClient();

    return useMutation({
        mutationFn: updatePermission,
        onMutate: async (newPermission) => {
            // Cancel any outgoing refetches (so they don't overwrite our optimistic update)
            await queryClient.cancelQueries({ queryKey: ['permissions', newPermission.account_id] });

            // Snapshot the previous value
            const previousPermissions = queryClient.getQueryData(['permissions', newPermission.account_id]);

            // Optimistically update to the new value
            queryClient.setQueryData(['permissions', newPermission.account_id], (old) => {
                if (!old) return old;
                return old.map(perm => 
                    perm.service === newPermission.service 
                        ? { ...perm, enabled: newPermission.enabled }
                        : perm
                );
            });

            // Return a context with the previous data so we can roll back if it fails
            return { previousPermissions };
        },
        onError: (err, newPermission, context) => {
            console.error("Failed to update permission:", err);
            // Roll back to the previous value if the API fails
            if (context?.previousPermissions) {
                queryClient.setQueryData(['permissions', newPermission.account_id], context.previousPermissions);
            }
        },
        onSettled: (data, error, variables) => {
            // Always refetch to ensure we're strictly synced with the backend
            queryClient.invalidateQueries({ queryKey: ['permissions', variables.account_id] });
        },
    });
};
