import { useQuery, keepPreviousData } from "@tanstack/react-query";
import { useFilters } from "../useFilters";
import { queryKeys } from "../../lib/queryKeys";
import {
    getStorageSummary,
    getStorageBuckets,
    getStorageS3Metadata,
} from "../../Pages/Storage/storage.api";

export const useS3 = (bucketName) => {
    const { filters } = useFilters();
    const hasDateRange = !!filters.start_date && !!filters.end_date;
    const hasAccount = !!(filters.account || filters.account_name);
    const isQueryEnabled = hasDateRange && hasAccount;

    const summaryQuery = useQuery({
        queryKey: queryKeys.s3.summary(filters),
        queryFn: () => getStorageSummary(filters),
        enabled: isQueryEnabled,
        placeholderData: keepPreviousData,
    });

    const bucketsQuery = useQuery({
        queryKey: queryKeys.s3.buckets(filters),
        queryFn: () => getStorageBuckets(filters),
        enabled: isQueryEnabled,
        placeholderData: keepPreviousData,
    });

    const metadataQuery = useQuery({
        queryKey: queryKeys.s3.metadata(bucketName, filters),
        queryFn: () => getStorageS3Metadata(bucketName, filters),
        enabled: isQueryEnabled && !!bucketName,
        placeholderData: keepPreviousData,
    });

    return {
        s3Summary: summaryQuery.data ?? null,
        s3Buckets: bucketsQuery.data ?? [],
        metadata: metadataQuery.data ?? null,
        isLoading: summaryQuery.isLoading || bucketsQuery.isLoading,
        isError: summaryQuery.isError || bucketsQuery.isError,
        isMetadataLoading: metadataQuery.isLoading,
        isMetadataError: metadataQuery.isError,
        summaryQuery,
        bucketsQuery,
        metadataQuery,
    };
};
