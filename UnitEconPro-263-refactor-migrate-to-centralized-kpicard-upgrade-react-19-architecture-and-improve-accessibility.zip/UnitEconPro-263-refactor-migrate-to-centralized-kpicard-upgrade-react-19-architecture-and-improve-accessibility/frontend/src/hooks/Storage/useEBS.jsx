import { useQuery, keepPreviousData } from "@tanstack/react-query";
import {
    getStorageEBSSummary,
    getStorageEBSVolumes,
    getStorageEBSSnapshots,
    getStorageEBSMetadata,
} from "../../Pages/Storage/storage.api";
import { useFilters } from "../useFilters";
import { queryKeys } from "../../lib/queryKeys";

export const useEBS = (volumeId) => {
    const { filters } = useFilters();
    const hasDateRange = !!filters.start_date && !!filters.end_date;
    const hasAccount = !!(filters.account || filters.account_name);
    const isQueryEnabled = hasDateRange && hasAccount;

    const summaryQuery = useQuery({
        queryKey: queryKeys.ebs.summary(filters),
        queryFn: () => getStorageEBSSummary(filters),
        enabled: isQueryEnabled,
        placeholderData: keepPreviousData,
        retry: 1,
    });

    const volumesQuery = useQuery({
        queryKey: queryKeys.ebs.volumes(filters),
        queryFn: () => getStorageEBSVolumes(filters),
        enabled: isQueryEnabled,
        placeholderData: keepPreviousData,
        retry: 1,
    });

    const snapshotsQuery = useQuery({
        queryKey: queryKeys.ebs.snapshots(filters),
        queryFn: () => getStorageEBSSnapshots(filters),
        enabled: isQueryEnabled,
        placeholderData: keepPreviousData,
        retry: 1,
    });

    const metadataQuery = useQuery({
        queryKey: queryKeys.ebs.metadata(volumeId, filters),
        queryFn: () => getStorageEBSMetadata(volumeId, filters),
        enabled: isQueryEnabled && !!volumeId,
        placeholderData: keepPreviousData,
        retry: 1,
    });

    return {
        ebsSummary: summaryQuery.data ?? null,
        ebsVolumes: volumesQuery.data ?? [],
        ebsSnapshots: snapshotsQuery.data ?? [],
        metadata: metadataQuery.data ?? null,
        isLoading: summaryQuery.isLoading || volumesQuery.isLoading || snapshotsQuery.isLoading,
        isError: summaryQuery.isError || volumesQuery.isError || snapshotsQuery.isError,
        isMetadataLoading: metadataQuery.isLoading,
        isMetadataError: metadataQuery.isError,
        summaryQuery,
        volumesQuery,
        snapshotsQuery,
        metadataQuery,
    };
};
