import { useQuery, keepPreviousData } from "@tanstack/react-query";
import { getSystemHealthz, getSystemReadyz } from "../../Pages/SystemHealth/systemHealth.api";
import { queryKeys } from "../../lib/queryKeys";

export const useSystemHealth = () => {
    const healthzQuery = useQuery({
        queryKey: queryKeys.systemHealth.healthz(),
        queryFn: () => getSystemHealthz(),
        retry: 1,
        staleTime: 5 * 60 * 1000,
        placeholderData: keepPreviousData,
    });

    const readyzQuery = useQuery({
        queryKey: queryKeys.systemHealth.readyz(),
        queryFn: () => getSystemReadyz(),
        retry: 1,
        staleTime: 5 * 60 * 1000,
        placeholderData: keepPreviousData,
    });

    return {
        healthz: healthzQuery.data ?? null,
        readyz: readyzQuery.data ?? null,
        isLoading: healthzQuery.isLoading || readyzQuery.isLoading,
        isError: healthzQuery.isError || readyzQuery.isError,
        healthzQuery,
        readyzQuery,
    };
};
