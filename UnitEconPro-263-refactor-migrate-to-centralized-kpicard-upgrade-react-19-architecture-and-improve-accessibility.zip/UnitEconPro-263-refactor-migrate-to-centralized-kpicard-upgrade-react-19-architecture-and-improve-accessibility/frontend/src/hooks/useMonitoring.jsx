import { useQuery, keepPreviousData } from "@tanstack/react-query";
import {
    getCloudWatchSummary,
    getCloudWatchEKSClusters,
    getCloudWatchLogGroups
} from "../Pages/Monitoring/monitoring.api";
import { useFilters } from "./useFilters";
import { queryKeys } from "../lib/queryKeys";

export const useMonitoring = () => {
    const { filters } = useFilters();
    const hasDateRange = !!filters.start_date && !!filters.end_date;
    const hasAccount = !!(filters.account || filters.account_name);
    const isQueryEnabled = hasDateRange && hasAccount;

    const summaryQuery = useQuery({
        queryKey: queryKeys.monitoring.summary(filters),
        queryFn: () => getCloudWatchSummary(filters),
        enabled: isQueryEnabled,
        placeholderData: keepPreviousData,
        retry: 1,
    });

    const eksClustersQuery = useQuery({
        queryKey: queryKeys.monitoring.eksClusters(filters),
        queryFn: () => getCloudWatchEKSClusters(filters),
        enabled: isQueryEnabled,
        placeholderData: keepPreviousData,
        retry: 1,
    });

    const logGroupsQuery = useQuery({
        queryKey: queryKeys.monitoring.logGroups(filters),
        queryFn: () => getCloudWatchLogGroups(filters),
        enabled: isQueryEnabled,
        retry: 1,
    });

    return {
        cloudWatchSummary: summaryQuery.data ?? null,
        eksClusters: eksClustersQuery.data ?? [],
        logGroups: logGroupsQuery.data ?? [],

        isLoading:
            summaryQuery.isLoading ||
            eksClustersQuery.isLoading ||
            logGroupsQuery.isLoading,
        isError:
            summaryQuery.isError ||
            eksClustersQuery.isError ||
            logGroupsQuery.isError,
        summaryQuery,
        eksClustersQuery,
        logGroupsQuery,
    };
};
