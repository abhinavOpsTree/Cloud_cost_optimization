import { memo, useEffect, useRef } from 'react';
import { NavLink } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { cn } from '../lib/cn';

const SidebarSubmenu = memo(({ subItems, parentTo, parentName, isExpanded, isSidebarOpen }) => {
    const submenuRef = useRef(null);

    useEffect(() => {
        const handleKeyDown = (e) => {
            if (!isExpanded || !submenuRef.current) return;

            const focusableElements = submenuRef.current.querySelectorAll('a');
            const focusedIndex = Array.from(focusableElements).indexOf(document.activeElement);

            if (e.key === 'ArrowDown') {
                e.preventDefault();
                const nextIndex = (focusedIndex + 1) % focusableElements.length;
                focusableElements[nextIndex]?.focus();
            } else if (e.key === 'ArrowUp') {
                e.preventDefault();
                const prevIndex = (focusedIndex - 1 + focusableElements.length) % focusableElements.length;
                focusableElements[prevIndex]?.focus();
            } else if (e.key === 'Escape') {
                e.preventDefault();
                // Focus back to parent button
                const parentButton = submenuRef.current.closest('.space-y-1')?.querySelector(`button[aria-controls="submenu-${parentName}"]`);
                parentButton?.focus();
            }
        };

        if (isExpanded) {
            document.addEventListener('keydown', handleKeyDown);
        }

        return () => {
            document.removeEventListener('keydown', handleKeyDown);
        };
    }, [isExpanded, parentName]);

    return (
        <AnimatePresence>
            {isExpanded && isSidebarOpen && (
                <motion.div
                    ref={submenuRef}
                    id={`submenu-${parentName}`}
                    role="menu"
                    aria-labelledby={`menuitem-${parentName}`}
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="overflow-hidden ml-4 pl-4 border-l border-[var(--border-color)] mt-1 space-y-1"
                >
                    {subItems.map(sub => (
                        <NavLink
                            key={sub.name}
                            to={sub.to}
                            end={sub.to === parentTo}
                            role="menuitem"
                            /* Display a tooltip if the submenu item is marked as disabled */
                            title={sub.disabled ? "Permission Denied" : undefined}
                            /* Prevent navigation if the submenu item is marked as disabled */
                            onClick={(e) => {
                                if (sub.disabled) e.preventDefault();
                            }}
                            className={({ isActive }) => cn(
                                "block px-3 py-1.5 rounded-md text-[13px] transition-all",
                                /* Apply disabled styling (grayed out, not-allowed cursor) or standard active/inactive styling */
                                sub.disabled
                                    ? "text-slate-400 bg-neutral-50/50 border border-transparent font-semibold cursor-not-allowed opacity-60"
                                    : isActive 
                                        ? "text-blue-600 bg-neutral-100/80 border border-black/10 font-semibold" 
                                        : "text-slate-500 bg-neutral-100/80 border border-black/10 font-semibold hover:text-slate-900 hover:bg-neutral-200/80"
                            )}
                        >
                            {sub.name}
                        </NavLink>
                    ))}
                </motion.div>
            )}
        </AnimatePresence>
    );
});

SidebarSubmenu.displayName = 'SidebarSubmenu';

export default SidebarSubmenu;
