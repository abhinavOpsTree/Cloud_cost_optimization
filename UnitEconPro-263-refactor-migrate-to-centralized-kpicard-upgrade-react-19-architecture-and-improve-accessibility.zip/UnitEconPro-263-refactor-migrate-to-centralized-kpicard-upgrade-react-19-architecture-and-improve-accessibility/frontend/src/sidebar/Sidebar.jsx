import { AnimatePresence, motion } from "framer-motion";
import { useSettings } from '../providers/SettingsContext';
import SidebarItem from './SidebarItem';
import { useSidebar } from './SidebarShared';
import { ChevronLeft, ChevronRight, PanelLeftClose, PanelRightClose } from "lucide-react";
import ProfileMenu from "./ProfileMenu";
import { cn } from "../lib/cn";
import { navigationItems, sidebarConfig } from "../sidebar/sidebarConfig";


const SideBar = () => {
    const { isSidebarOpen, setIsSidebarOpen } = useSidebar();
    const { visibleNavItems } = useSettings();

    return (
        <motion.aside
            initial={false}
            animate={{ width: isSidebarOpen ? sidebarConfig.widths.open : sidebarConfig.widths.closed }}
            transition={sidebarConfig.animation.spring}
            className="h-[calc(100vh)] sticky z-50 flex relative flex-col bg-[var(--sidebar-primary-bg)] text-[var(--text-primary-color)]"
        >
            <div className="flex items-center justify-between px-4 py-1 relative">
                <button type="button" className="flex items-center gap-2 bg-neutral-100 w-full px-1.5 rounded-lg h-14 relative group cursor-pointer border-none text-left" onClick={() => !isSidebarOpen && setIsSidebarOpen(true)}>
                    <div className={cn(
                        "flex items-center gap-2 transition-all duration-200",
                        !isSidebarOpen ? "mx-auto group-hover:opacity-0" : ""
                    )}>
                        <img src="./bg_svg.svg" alt="logo" className="size-4 shrink-0" />
                        <AnimatePresence mode="wait">
                            {isSidebarOpen && (
                                <motion.span
                                    key="logo-text"
                                    initial={{ opacity: 0, x: -10 }}
                                    animate={{ opacity: 0.9, x: 0 }}
                                    exit={{ opacity: 0, x: -10 }}
                                    transition={{ duration: 0.2 }}
                                    className="text-base font-semibold overflow-hidden whitespace-nowrap"
                                >
                                    <span className="text-geist-foreground">Spend</span><span className="text-develop">Smart</span>
                                </motion.span>
                            )}
                        </AnimatePresence>
                    </div>
                </button>

                <div className={cn(
                    "absolute right-6 flex items-center transition-all duration-200 pointer-events-none",
                    !isSidebarOpen
                        ? "opacity-0 group-hover:opacity-100"
                        : ""
                )}>
                    <button
                        type="button"
                        onClick={(e) => {
                            e.stopPropagation();
                            setIsSidebarOpen(!isSidebarOpen);
                        }}
                        className="p-1 rounded-md cursor-pointer bg-neutral-300 hover:bg-neutral-200 transition-colors duration-200 text-neutral-500 hover:text-neutral-900 pointer-events-auto"
                        title={isSidebarOpen ? "Collapse Menu" : "Open Menu"}
                    >
                        {isSidebarOpen ? <ChevronLeft size={16} className="text-black" /> : <ChevronRight size={16} className="text-black" />}
                    </button>
                </div>
            </div>

            <div className="flex-1 flex flex-col overflow-y-auto overflow-x-hidden no-scrollbar items-start justify-start px-[8px]  space-y-6">
                <nav className="space-y-1 w-full" role="navigation" aria-label="Main navigation">
                    {navigationItems.map((item) => {
                        if (item.type === "separator") {
                            // Use title as the unique key, avoiding array indices entirely
                            return (
                                <div key={`sep-${item.title || item.id}`} className={cn(
                                    "my-3 border-t border-neutral-200 dark:border-neutral-700/50",
                                    !isSidebarOpen ? "mx-2" : "mx-4"
                                )}>
                                    {isSidebarOpen && item.title && (
                                        <div className="mt-3 mb-1 text-[10px] font-bold text-neutral-400 dark:text-neutral-500 uppercase tracking-widest">
                                            {item.title}
                                        </div>
                                    )}
                                </div>
                            );
                        }

                        const isVisible = visibleNavItems[item.name] ?? true;
                        if (!isVisible) return null;
                        return (
                            <div key={item.name}>
                                <SidebarItem
                                    item={item}
                                    hasSubItems={false}
                                    isExpanded={false}
                                />
                            </div>
                        );
                    })}
                </nav>
            </div>
            <div className="sticky bottom-0 w-full h-[60px] flex gap-2 items-center sidebar-closed">
                <ProfileMenu />
            </div>
        </motion.aside>
    );
};

export default SideBar;
