import { useEffect, useState } from 'react';
import { SidebarContext } from './SidebarShared';
import { sidebarConfig } from '../sidebar/sidebarConfig';
export const SidebarProvider = ({ children }) => {
    // RESPONSIVENESS: Initialize sidebar state dynamically based on window width.
    // Starts collapsed (false) on mobile devices, and expanded (true) on desktop screens.
    const [isSidebarOpen, setIsSidebarOpen] = useState(() => {
        if (typeof window !== 'undefined') {
            return window.innerWidth >= sidebarConfig.mobileBreakpoint;
        }
        return true;
    });
    const [expandedMenus, setExpandedMenus] = useState([]);

    // Responsive behavior: auto-collapse on mobile
    useEffect(() => {
        const handleResize = () => {
            if (window.innerWidth < sidebarConfig.mobileBreakpoint) {
                setIsSidebarOpen(false);
            } else {
                setIsSidebarOpen(true);
            }
        };

        handleResize();
        window.addEventListener('resize', handleResize);
        return () => window.removeEventListener('resize', handleResize);
    }, []);

    const toggleMenu = (name) => {
        if (!isSidebarOpen) {
            setIsSidebarOpen(true);
            setExpandedMenus([name]);
            return;
        }
        setExpandedMenus(prev =>
            prev.includes(name) ? prev.filter(m => m !== name) : [...prev, name]
        );
    };

    return (
        <SidebarContext value={{ isSidebarOpen, setIsSidebarOpen, expandedMenus, toggleMenu }}>
            {children}
        </SidebarContext>
    );
};
