import { AnimatePresence, motion } from 'framer-motion';
import { memo, useState } from 'react';
import { NavLink, useLocation, useNavigate } from 'react-router-dom';
import { cn } from '../lib/cn';
import { useSidebar } from './SidebarShared';
import { ChevronDown, ChevronRight } from 'lucide-react';
import SidebarSubmenu from './SidebarSubmenu';

const SidebarItem = memo(({ item }) => {
    const { isSidebarOpen, setIsSidebarOpen } = useSidebar();
    const location = useLocation();
    
    // Automatically expand if a subItem is active
    const isActivePath = item.expandable && item.subItems?.some(sub => location.pathname === sub.to || location.pathname.startsWith(sub.to + "/"));
    const [isExpanded, setIsExpanded] = useState(isActivePath);
    const [prevActivePath, setPrevActivePath] = useState(isActivePath);

    if (isActivePath !== prevActivePath) {
        setPrevActivePath(isActivePath);
        if (isActivePath) {
            setIsExpanded(true);
        }
    }

    const handleExpandClick = (e, isActive) => {
        if (item.expandable) {
            // If it's already active, prevent navigation and just toggle expansion
            if (isActive) {
                e.preventDefault();
                setIsExpanded(!isExpanded);
            } else {
                // If it's not active, NavLink will navigate it to the first child. We just ensure it expands.
                setIsExpanded(true);
            }
            if (!isSidebarOpen && setIsSidebarOpen) {
                setIsSidebarOpen(true);
            }
        }
    };

    const ButtonContent = (isActive) => (
        <button
            onClick={(e) => handleExpandClick(e, isActive)}
            className={cn(
                "relative w-full flex items-center gap-3 px-3 py-4.5 rounded-standard text-sm transition-all duration-200 cursor-pointer group font-medium h-8",
                isActive
                    ? "text-white"
                    : "text-[var(--sidebar-secondary-text)] hover:bg-[var(--sidebar-primary-bg)]",
                !isSidebarOpen && "justify-center"
            )}
            aria-current={isActive ? "page" : undefined}
        >
            {isActive && (
                <motion.div
                    layoutId="sidebarActiveBackground"
                    className="absolute inset-0 bg-blue-500 rounded-md"
                    transition={{ type: "spring", bounce: 0.2, duration: 0.4 }}
                />
            )}
            <div className={cn("relative z-10 flex items-center gap-3 w-full", !isSidebarOpen && "justify-center")}>
                <div className={cn("transition-transform duration-200", isActive ? "scale-105" : "group-hover:scale-105")}>
                    <item.icon size={16} className="shrink-0" />
                </div>
                <AnimatePresence mode="wait">
                    {isSidebarOpen && (
                        <>
                            <motion.span
                                initial={{ opacity: 0, x: -5 }}
                                animate={{ opacity: 1, x: 0 }}
                                exit={{ opacity: 0, x: -5 }}
                                transition={{ duration: 0.15 }}
                                className="flex-1 text-left overflow-hidden whitespace-nowrap text-ellipsis text-xs"
                            >
                                {item.name}
                            </motion.span>
                            {item.expandable && (
                                <motion.div
                                    initial={{ opacity: 0 }}
                                    animate={{ opacity: 1 }}
                                    exit={{ opacity: 0 }}
                                    className={cn("shrink-0", isActive ? "text-white" : "text-[var(--sidebar-secondary-text)]")}
                                >
                                    {isExpanded ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
                                </motion.div>
                            )}
                        </>
                    )}
                </AnimatePresence>
            </div>
        </button>
    );

    return (
        <div className="w-full">
            <NavLink to={item.to} end={item.end}>
                {({ isActive }) => {
                    const finalIsActive = item.expandable ? (isActive || isActivePath) : isActive;
                    return ButtonContent(finalIsActive);
                }}
            </NavLink>
            {item.expandable && (
                <SidebarSubmenu
                    subItems={item.subItems}
                    parentTo={item.to}
                    parentName={item.name}
                    isExpanded={isExpanded}
                    isSidebarOpen={isSidebarOpen}
                />
            )}
        </div>
    );
});

SidebarItem.displayName = 'SidebarItem';

export default SidebarItem;
