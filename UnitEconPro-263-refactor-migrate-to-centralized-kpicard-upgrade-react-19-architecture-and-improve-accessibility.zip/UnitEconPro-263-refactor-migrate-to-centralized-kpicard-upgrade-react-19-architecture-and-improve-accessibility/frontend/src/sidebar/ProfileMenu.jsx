import { AnimatePresence, motion } from 'framer-motion';
import { LogOut } from 'lucide-react';
import { memo, useEffect, useRef, useState } from 'react';
import { useAuth } from '../providers/AuthContext';
import { useSidebar } from './SidebarShared';

const ProfileMenu = memo(() => {
    const { logout, keycloak } = useAuth();
    const { isSidebarOpen } = useSidebar();
    const [showProfile, setShowProfile] = useState(false);

    const name = keycloak?.tokenParsed?.name || keycloak?.tokenParsed?.preferred_username;
    const email = keycloak?.tokenParsed?.email;
    const dropdownRef = useRef(null);

    useEffect(() => {
        const handleClickOutside = (event) => {
            if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
                setShowProfile(false);
            }
        };

        const handleKeyDown = (e) => {
            if (e.key === 'Escape' && showProfile) {
                setShowProfile(false);
            }
        };

        if (showProfile) {
            document.addEventListener('mousedown', handleClickOutside);
            document.addEventListener('keydown', handleKeyDown);
        }

        return () => {
            document.removeEventListener('mousedown', handleClickOutside);
            document.removeEventListener('keydown', handleKeyDown);
        };
    }, [showProfile]);

    const handleLogout = () => {
        logout();
    };

    return (
        <div className="relative w-full" ref={dropdownRef}>
            <button
                onClick={() => setShowProfile(!showProfile)}
                className="flex items-center justify-between bg-white  size-10 p-3 md:px-3 md:py-4 md:w-full rounded-md overflow-hidden ring-1 ring-black/20 shadow-inner transition-all text-black active:scale-95 cursor-pointer"
                aria-expanded={showProfile}
                aria-haspopup="true"
                aria-label="User profile menu"
            >
                <img src="./bg_svg.svg" alt="opstree" className="size-6 lg:w-8 lg:h-8 rounded-full border border-slate-200 object-cover" />
                {isSidebarOpen && (
                    <div className="flex flex-col items-start overflow-hidden">
                        <span className="text-xs font-semibold text-black/70 uppercase">Powered by</span>
                        <span className="text-[10px] text-black/70 ">OpsTree Labs</span>
                    </div>
                )}
            </button>

            <AnimatePresence>
                {showProfile && (
                    <motion.div
                        initial={{ opacity: 0, y: 8, scale: 0.95 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: 8, scale: 0.95 }}
                        transition={{ duration: 0.15, ease: "easeOut" }}
                        className="absolute bottom-14 left-0 mt-2 w-64 bg-white rounded-md ring-1 ring-black/20 shadow-[var(--shadow-md)] overflow-hidden z-[100]"
                        role="menu"
                    >
                        <div className="px-4 py-3 flex flex-col border-b border-[var(--border-primary-color)]">
                            <span className="text-sm font-semibold text-neutral-900 truncate">
                                {name}
                            </span>
                            <span className="text-xs text-neutral-500 truncate mt-0.5">
                                {email}
                            </span>
                        </div>
                        <div className="p-1.5 border-t border-[var(--border-primary-color)]">
                            <button
                                onClick={handleLogout}
                                className="flex items-center cursor-pointer gap-2.5 w-full px-2.5 py-2 text-sm text-neutral-700 hover:bg-red-50 hover:text-red-600 rounded-md transition-colors group"
                                role="menuitem"
                            >
                                <LogOut size={16} className="text-neutral-400 group-hover:text-red-500" />
                                <span className="flex-1 text-left">Logout</span>
                            </button>
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
});

ProfileMenu.displayName = 'ProfileMenu';

export default ProfileMenu;
