import {
  Activity,
  HeartPulse,
  ChartLine,
  ChartNoAxesColumnDecreasing,
  Cloudy,
  Database,
  HardDrive,
  LayoutDashboard,
  Lightbulb,
  Network,
  Server,
  Settings,
  Lock,
  FileText,
} from "lucide-react";

export const navigationItems = [
  { type: "separator", title: "Overview" },
  { name: "Dashboard", to: "/dashboard", icon: LayoutDashboard, end: false, defaultVisible: true },
  // { name: "Analytics", to: "/analytics", icon: ChartLine, end: false, defaultVisible: true },
  { name: "Cost Comparison", to: "/cost-comparison", icon: ChartLine, end: false, defaultVisible: true },
  {
    name: "Reports",
    to: "/reporting",
    icon: FileText,
    defaultVisible: true,
    expandable: true,
    subItems: [
      { name: "CFO", to: "/reporting/cfo" },
      { name: "CTO", to: "#", disabled: true }
      
    ]
  },
  { type: "separator", title: "Services" },
  {
    name: "Compute",
    icon: Server,
    to: "/compute",
    defaultVisible: true,
    subItems: [
      // { name: "COMPUTE", to: "/compute" },
      { name: "EKS", to: "/compute/eks" },
      { name: "EC2", to: "/compute/ec2" },
      { name: "ECR", to: "/compute/ecr" },
      { name: "ECS", to: "/compute/ecs" },
    ]
  },
  {
    name: "Storage", to: "/storage", icon: HardDrive, defaultVisible: true,
    subItems: [
      { name: "S3", to: "/storage/s3" },
      { name: "EBS", to: "/storage/ebs" },
    ]
  },
  { name: "Databases", to: "/databases", icon: Database, defaultVisible: true, subItems: [{ name: "RDS", to: "/databases/rds" }] },
  {
    name: "Networking",
    to: "/networking",
    icon: Network,
    defaultVisible: true,
    subItems: [
      { name: "VPC", to: "/networking/vpc" },
      { name: "ELB", to: "/networking/elb" },
      { name: "Data Transfer", to: "/networking/datatransfer" }
    ]
  },
  {
    name: "Monitoring",
    to: "/monitoring",
    icon: Activity,
    defaultVisible: true,
    subItems: [
      { name: "CloudWatch", to: "/monitoring/cloudwatch" }
    ]
  },
  { type: "separator", title: "Savings"},
  { name: "Accounts", to: "/accounts", icon: Cloudy, defaultVisible: true, end: false },
  {
    name: "Recommendation",
    to: "/recommendation",
    icon: Lightbulb,
    defaultVisible: true,
    expandable: true,
    subItems: [
      { name: "Manual", to: "/recommendation" },
      // { name: "System", to: "/recommendation/system" }
      { name: "Cloud Sentry", to: "/recommendation/cloud-sentry/dashboard" }
    ]
  },

  { type: "separator", title: "Settings" },
  { name: "Settings", to: "/settings", icon: Settings, defaultVisible: true, subItems: [{ name: "Sidebar Modules", to: "/settings" }] },
  // { name: "System Health", to: "/system-health", icon: HeartPulse, defaultVisible: true, end: false },
];

export const sidebarConfig = {
  widths: {
    open: 195,
    closed: 60,
  },
  animation: {
    spring: {
      type: "spring",
      stiffness: 500,
      damping: 50,
      mass: 1,
    },
    duration: {
      fade: 0.2,
    },
  },
  mobileBreakpoint: 900,
};
