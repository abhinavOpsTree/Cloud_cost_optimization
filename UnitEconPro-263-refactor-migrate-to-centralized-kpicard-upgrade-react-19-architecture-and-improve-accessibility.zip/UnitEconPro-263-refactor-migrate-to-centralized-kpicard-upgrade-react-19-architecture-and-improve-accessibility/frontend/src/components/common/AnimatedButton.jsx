import { motion } from "framer-motion";
import { Loader2 } from "lucide-react";
import React from "react";
import { cn } from "../../lib/cn";


export const AnimatedButton = ({
    children,
    className,
    variant = "primary",
    size = "md",
    isLoading = false,
    disabled,
    ...props
}) => {
    const baseStyles =
        "inline-flex items-center justify-center rounded font-medium transition-colors focus:outline-none focus:ring-2 focus:ring-ring focus:ring-offset-2 disabled:opacity-50 disabled:pointer-events-none ring-offset-background active:scale-95";

    const variants = {
        primary:
            "bg-primary text-primary-foreground hover:bg-primary/90 shadow",
        secondary:
            "bg-secondary text-secondary-foreground hover:bg-secondary/80",
        outline:
            "border border-input hover:bg-accent hover:text-accent-foreground glass-effect",
        ghost: "hover:bg-accent hover:text-accent-foreground",
        danger:
            "bg-destructive text-destructive-foreground hover:bg-destructive/90 shadow-md",
    };

    const sizes = {
        sm: "h-9 px-3 text-xs",
        md: "h-10 py-2 px-4 text-sm",
        lg: "h-11 px-8 text-base",
        icon: "h-10 w-10",
    };

    return (
        <motion.button
            whileHover={{ scale: disabled || isLoading ? 1 : 1.02 }}
            whileTap={{ scale: disabled || isLoading ? 1 : 0.98 }}
            className={cn(baseStyles, variants[variant], sizes[size], className)}
            disabled={disabled || isLoading}
            {...props}
        >
            {isLoading ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
            {children}
        </motion.button>
    );
};
