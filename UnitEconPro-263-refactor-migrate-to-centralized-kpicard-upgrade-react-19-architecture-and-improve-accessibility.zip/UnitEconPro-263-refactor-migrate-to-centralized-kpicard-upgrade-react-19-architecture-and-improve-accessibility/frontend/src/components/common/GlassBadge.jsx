import React from "react";
import { cn } from "../../lib/cn";


export const GlassBadge = ({
    children,
    className,
    variant = "default",
    borderless = false,
    ...props
}) => {
    const variants = {
        default: "bg-white/60 text-foreground dark:bg-white/10",
        success: "bg-green-100/60 text-green-800 dark:bg-green-900/30 dark:text-green-300",
        warning: "bg-yellow-100/60 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300",
        destructive: "bg-red-100/60 text-red-800 dark:bg-red-900/30 dark:text-red-300",
        info: "bg-blue-100/60 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300",
    };

    return (
        <div
            className={cn(
                "inline-flexitems-center rounded-full px-2.5 py-0.5 text-xs font-semibold backdrop-blur-md transition-colors",
                !borderless && "border border-white/40 dark:border-white/10",
                variants[variant],
                className
            )}
            {...props}
        >
            {children}
        </div>
    );
};
