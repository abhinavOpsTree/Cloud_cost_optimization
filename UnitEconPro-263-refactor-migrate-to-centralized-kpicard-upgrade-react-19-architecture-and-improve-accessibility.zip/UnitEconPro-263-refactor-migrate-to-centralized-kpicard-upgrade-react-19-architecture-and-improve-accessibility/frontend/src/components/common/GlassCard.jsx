import { motion } from "framer-motion";
import React from "react";
import { cn } from "../../lib/cn";

export const GlassCard = ({
  children,
  className,
  hoverEffect = false,
  ...props
}) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
      className={cn(
        "relative overflow-hidden bg-background rounded-comfortable shadow-geist-card transition-all duration-300",
        hoverEffect && "hover:-translate-y-1 hover:shadow-subtle transition-transform",
        className
      )}
      {...props}
    >
      <div className="relative z-10 w-full h-full">{children}</div>
    </motion.div>

  );
};
