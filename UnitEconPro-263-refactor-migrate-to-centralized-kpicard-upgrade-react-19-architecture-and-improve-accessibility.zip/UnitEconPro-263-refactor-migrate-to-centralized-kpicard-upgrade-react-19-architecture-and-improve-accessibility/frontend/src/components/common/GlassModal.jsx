import { AnimatePresence, motion } from "framer-motion";
import { X } from "lucide-react";
import React, { useEffect } from "react";
import { cn } from "../../lib/cn";

export const GlassModal = ({
    isOpen,
    onClose,
    title,
    children,
    className,
    size = "md",
}) => {
    useEffect(() => {
        if (isOpen) {
            document.body.style.overflow = "hidden";
        } else {
            document.body.style.overflow = "unset";
        }
        return () => {
            document.body.style.overflow = "unset";
        };
    }, [isOpen]);

    const sizes = {
        sm: "max-w-md",
        md: "max-w-lg",
        lg: "max-w-3xl",
        xl: "max-w-5xl",
        full: "max-w-[95vw] h-[95vh]",
    };

    return (
        <AnimatePresence>
            {isOpen && (
                <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
                    <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        onClick={onClose}
                        className="absolute inset-0 bg-black/20 backdrop-blur-sm transition-opacity"
                    />
                    <motion.div
                        initial={{ opacity: 0, scale: 0.95, y: 10 }}
                        animate={{ opacity: 1, scale: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.95, y: 10 }}
                        transition={{ type: "spring", duration: 0.4, bounce: 0 }}
                        className={cn(
                            "relative z-50 w-full overflow-hidden rounded-2xl md:rounded-3xl border border-white/40 shadow-2xl",
                            "bg-white/70 backdrop-blur-2xl dark:bg-black/60 dark:border-white/10",
                            sizes[size],
                            className
                        )}
                        onClick={(e) => e.stopPropagation()}
                    >
                        <div className="absolute inset-0 " />

                        <div className="relative z-10 flex h-full flex-col">
                            {title && (
                                <div className="flex items-center justify-between border-b border-black/5 dark:border-white/10 px-6 py-4">
                                    <h2 className="text-lg font-semibold text-foreground">
                                        {title}
                                    </h2>
                                    <button
                                        onClick={onClose}
                                        className="rounded-full p-1.5 transition-colors hover:bg-black/5 dark:hover:bg-white/10"
                                    >
                                        <X className="h-5 w-5 opacity-70" />
                                    </button>
                                </div>
                            )}
                            {!title && (
                                <div className="absolute right-4 top-4 z-20">
                                    <button
                                        onClick={onClose}
                                        className="rounded-full p-1.5 transition-colors hover:bg-black/5 dark:hover:bg-white/10 bg-white/50 backdrop-blur-md shadow-sm"
                                    >
                                        <X className="h-5 w-5 opacity-70" />
                                    </button>
                                </div>
                            )}

                            <div className="flex-1 overflow-y-auto p-6">{children}</div>
                        </div>
                    </motion.div>
                </div>
            )}
        </AnimatePresence>
    );
};

