import { memo } from "react";
import { ArrowUpRight, ArrowDownRight, DollarSign } from "lucide-react";
import IconDisplay from "../../common/IconDisplay";

export const KpiCard = memo((props) => {
    // Merge kpi object with direct props if it exists
    const data = props.kpi ? { ...props.kpi, ...props } : props;
    
    // Normalization
    const title = data.label || data.title || (data.key ? data.key.replace(/_/g, " ") : "");
    const value = data.value ?? "—";
    const unit = data.unit || "";
    const sub = data.sub || "";
    const trend = data.trend || "";
    const positive = data.positive !== false; // defaults to true
    const warn = data.warn || false;
    const variant = props.variant || "overview"; 
    
    const isLoading = props.isLoading || false;
    const isError = props.isError || false;

    if (isLoading || isError) {
        // Skeleton logic based on variant
        if (variant === "compact") {
            return (
                <div className="flex flex-col shadow-[var(--shadow)] justify-between h-full px-4 py-3 bg-white rounded-md ring-[.5px] ring-black/10">
                    <div className="skeleton w-16 h-3 rounded mb-1" />
                    <div className="skeleton w-20 h-6 rounded mt-1" />
                </div>
            );
        }
        return (
            <div className={`flex flex-col justify-between h-full bg-white ring-[.5px] ring-black/10 rounded-md min-h-[140px] ${variant === "dashboard" ? "px-4 py-2" : "p-5"}`}>
                <div className="flex items-center justify-between mb-4">
                    <div className="skeleton w-24 h-4 rounded" />
                    <div className="skeleton w-8 h-8 rounded-full" />
                </div>
                <div className="mb-2">
                    <div className="skeleton w-32 h-8 rounded" />
                </div>
                <div className="flex items-center gap-2 pt-3 border-t border-black/5 mt-auto">
                    <div className="skeleton w-16 h-3 rounded" />
                </div>
            </div>
        );
    }

    if (variant === "compact") {
        return (
            <div className={`flex flex-col shadow-[var(--shadow)] justify-between h-full px-4 py-3 rounded-md ring-[.5px] ring-black/10 hover:shadow-sm hover:-translate-y-[2px] transition-all duration-200 ${warn ? "bg-amber-50" : "bg-white"}`}>
                <div>
                    <p className={`text-[10px] font-bold uppercase tracking-wider mb-1 ${warn ? "text-amber-700 opacity-75" : "text-[var(--text-secondary-color)]"}`}>
                        {title}
                    </p>
                    <p className={`text-2xl font-bold leading-tight ${warn ? "text-amber-700" : (data.valueColor || "text-[var(--text-primary-color)]")}`}>
                        {value}
                        <span className={`text-xs font-normal ml-1 ${warn ? "text-amber-600 opacity-60" : "text-gray-400"}`}>{unit}</span>
                    </p>
                </div>
                {sub && (
                    <div className={`flex items-center gap-1.5 pt-2.5 border-t ${warn ? 'border-amber-200/50' : 'border-black/5'} text-[11px] font-medium mt-2`}>
                        <span className={`${warn ? "text-amber-700/70" : "text-slate-500"}`}>{sub}</span>
                    </div>
                )}
            </div>
        );
    }

    if (variant === "dashboard") {
        return (
            <div className="flex shadow-[var(--shadow)] flex-col justify-between h-full px-4 py-2 min-h-[140px] bg-white rounded-md ring-[.5px] ring-black/10 hover:shadow-sm hover:-translate-y-[2px] transition-all duration-200">
                <div className="flex items-center justify-between gap-2 mb-3">
                    <span className="text-sm font-bold text-[var(--text-primary-color)] capitalize">
                        {title}
                    </span>
                    {(data.icon || data.background) && <IconDisplay icon={data.icon} background={data.background} />}
                </div>

                <div className="flex items-center gap-1 mb-2">
                    {(data.currency || (data.key && data.key.toLowerCase().includes("cost"))) && (
                        <DollarSign size={24} className="text-green-600" />
                    )}
                    <span className="text-4xl font-semibold tracking-[-0.04em] text-[var(--text-primary-color)]">
                        {value}
                    </span>
                </div>

                {trend && (
                    <div className="flex items-center gap-1.5 pt-3 border-t border-accents-2 text-xs font-medium mt-auto">
                        {positive ? (
                            <ArrowUpRight className="w-3.5 h-3.5 text-green-500" />
                        ) : (
                            <ArrowDownRight className="w-3.5 h-3.5 text-red-500" />
                        )}
                        <span className={positive ? "text-green-600" : "text-red-600"}>
                            {trend}
                        </span>
                    </div>
                )}
            </div>
        );
    }

    // Default: "overview" variant (for Cardoverview.jsx)
    return (
        <div ref={props.ref} className="flex flex-col shadow-[var(--shadow)] justify-between h-full p-5 min-h-[140px] bg-white rounded-md ring-[.5px] ring-black/10 hover:-translate-y-[2px] hover:shadow-sm transition-all duration-200">
            <div className="flex items-center justify-between gap-2 mb-3">
                <span className="text-sm font-bold text-neutral-600 capitalize leading-tight">
                    {title}
                </span>
                {data.icon && !data.icon2 && <IconDisplay icon={data.icon} background="bg-white" />}
                {data.icon && data.icon2 && <IconDisplay icon={data.icon} background="bg-white" />}
            </div>

            <div className="flex items-center gap-1 mb-2">
                {data.icon2 ? data.icon2 : null}
                <span className="text-2xl font-semibold text-geist-foreground">
                    {value}
                </span>
            </div>

            {trend && (
                <div className="flex items-center gap-1.5 pt-3 border-t border-accents-2 text-xs font-medium mt-auto">
                    {positive ? (
                        <ArrowUpRight className="w-3.5 h-3.5 text-green-500" />
                    ) : (
                        <ArrowDownRight className="w-3.5 h-3.5 text-red-500" />
                    )}
                    <span className={positive ? "text-green-600" : "text-red-600"}>
                        {trend}
                    </span>
                </div>
            )}
        </div>
    );
});
