import { AnimatePresence, motion } from "framer-motion";
import { ChevronDown } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { cn } from "../../lib/cn";


export const CustomDropdown = ({
    label,
    options,
    value,
    onChange,
    className,
}) => {
    const [isOpen, setIsOpen] = useState(false);
    const containerRef = useRef<HTMLDivElement>(null);

    const selectedOption = options?.find((opt) => opt.value === value);

    useEffect(() => {
        const handleClickOutside = (event) => {
            if (
                containerRef.current &&
                !containerRef.current.contains(event.target)
            ) {
                setIsOpen(false);
            }
        };
        document.addEventListener("mousedown", handleClickOutside);
        return () => document.removeEventListener("mousedown", handleClickOutside);
    }, []);

    return (
        <div ref={containerRef} className={cn("relative", className)}>
            {label && (
                <span className="block text-xs font-medium text-black mb-1">
                    {label}
                </span>
            )}
            <button
                type="button"
                className={cn(
                    "flex py-1 w-full min-w-[200px] items-center justify-between rounded",
                    "bg-white border border-[#3f3f3e] px-3 text-sm cursor-pointer",
                    "transition-all duration-200 hover:border-[#555] focus:outline-none",
                    isOpen && "ring-1 ring-neutral-500/40"
                )}
                onClick={() => setIsOpen(!isOpen)}
            >
                <span className="text-black font-medium">
                    {selectedOption?.label ?? "Select..."}
                </span>
                <motion.div
                    animate={{ rotate: isOpen ? 180 : 0 }}
                    transition={{ type: "spring", stiffness: 300, damping: 20 }}
                >
                    <ChevronDown className="h-4 w-4 text-slate-400" />
                </motion.div>
            </button>

            <AnimatePresence>
                {isOpen && (
                    <motion.div
                        initial={{ opacity: 0, y: -6, scale: 0.98 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: -6, scale: 0.98 }}
                        transition={{ duration: 0.15, ease: "easeOut" }}
                        className="absolute z-50 mt-1 w-full overflow-hidden rounded border border-black/10 text-black"
                    >
                        <div className="max-h-60 overflow-y-auto p-1 bg-white rounded-sm">
                            {options?.map((option) => (
                                <button
                                    type="button"
                                    key={option.value}
                                    className={cn(
                                        "w-full text-left bg-transparent border-none flex items-center gap-2 rounded-md px-3 py-2 text-sm cursor-pointer transition-colors focus:outline-none",
                                        "text-black",
                                        value === option.value &&
                                        "bg-white text-black font-medium"
                                    )}
                                    onClick={() => {
                                        onChange?.(option.value);
                                        setIsOpen(false);
                                    }}
                                >
                                    <span
                                        className={cn(
                                            "h-1.5 w-1.5 rounded-full transition-colors",
                                            value === option.value
                                                ? "bg-emerald-400"
                                                : "bg-transparent"
                                        )}
                                    />
                                    {option.label}
                                </button>
                            ))}
                        </div>
                    </motion.div>
                )}
            </AnimatePresence>
        </div>
    );
};