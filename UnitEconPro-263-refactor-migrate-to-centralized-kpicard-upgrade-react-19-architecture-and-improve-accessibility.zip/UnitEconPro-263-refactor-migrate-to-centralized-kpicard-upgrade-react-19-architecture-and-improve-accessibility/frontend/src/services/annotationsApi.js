import { apiRequest } from '../lib/apiClient';
import { API_ENDPOINTS } from '../APIs/ApiEndPoint';

export const annotationsApi = {
    createAnnotation: async (data) => {
        return apiRequest({
            endpoint: API_ENDPOINTS.analyticsAnnotations,
            method: 'POST',
            body: data
        });
    },
    getAnnotations: async (account_name, service, date) => {
        return apiRequest({
            endpoint: API_ENDPOINTS.getAnnotations(account_name, service, date),
            method: 'GET'
        });
    },
    getAnnotationDates: async (account_name, service, start_date, end_date) => {
        return apiRequest({
            endpoint: API_ENDPOINTS.getAnnotationDates(account_name, service, start_date, end_date),
            method: 'GET'
        });
    },
    deleteAnnotation: async (annotation_id) => {
        return apiRequest({
            endpoint: API_ENDPOINTS.deleteAnnotation(annotation_id),
            method: 'DELETE'
        });
    },
    updateAnnotation: async (annotation_id, data) => {
        return apiRequest({
            endpoint: API_ENDPOINTS.updateAnnotation(annotation_id),
            method: 'PUT',
            body: data
        });
    }
};

