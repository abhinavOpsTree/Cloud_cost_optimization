import { useState, useMemo, useCallback, memo } from "react";
import {
    Pencil, Server, Globe, Box, Database, HardDrive,
    Archive, Layers, Trash2, Edit3, Check, X as XIcon,
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useNavigate } from "react-router-dom";
import Addsuggestions from "../../common/Addsuggestions";
import { splitSuggestionText } from "../../lib/suggestionText";
import { useSuggestions } from "../../hooks/useSuggestions";

const SERVICE_META = {
    ec2:        { color: "bg-orange-50 text-orange-700 border-orange-200",  stripeColor: "bg-orange-400",  resourceLabel: "Instance",      ResourceIcon: Server,    route: "/compute/ec2" },
    eks:        { color: "bg-purple-50 text-purple-700 border-purple-200",  stripeColor: "bg-purple-400",  resourceLabel: "Cluster",       ResourceIcon: Layers,    route: "/compute/eks" },
    ecr:        { color: "bg-cyan-50 text-cyan-700 border-cyan-200",        stripeColor: "bg-cyan-400",    resourceLabel: "Repository",    ResourceIcon: Archive,   route: "/compute/ecr" },
    ecs:        { color: "bg-teal-50 text-teal-700 border-teal-200",        stripeColor: "bg-teal-400",    resourceLabel: "Cluster",       ResourceIcon: Layers,    route: "/compute/ecs" },
    s3:         { color: "bg-green-50 text-green-700 border-green-200",     stripeColor: "bg-green-400",   resourceLabel: "Bucket",        ResourceIcon: Box,       route: "/storage/s3" },
    ebs:        { color: "bg-lime-50 text-lime-700 border-lime-200",        stripeColor: "bg-lime-500",    resourceLabel: "Volume",        ResourceIcon: HardDrive, route: "/storage/ebs" },
    rds:        { color: "bg-blue-50 text-blue-700 border-blue-200",        stripeColor: "bg-blue-400",    resourceLabel: "DB Instance",   ResourceIcon: Database,  route: "/databases/rds" },
    vpc:        { color: "bg-indigo-50 text-indigo-700 border-indigo-200",  stripeColor: "bg-indigo-400",  resourceLabel: "VPC",           ResourceIcon: Globe,     route: "/networking/vpc" },
    elb:        { color: "bg-sky-50 text-sky-700 border-sky-200",           stripeColor: "bg-sky-400",     resourceLabel: "Load Balancer", ResourceIcon: Server,    route: "/networking/elb" },
    cloudwatch: { color: "bg-yellow-50 text-yellow-700 border-yellow-200",  stripeColor: "bg-yellow-400",  resourceLabel: "Log Group",     ResourceIcon: Layers,    route: "/monitoring/cloudwatch" },
    datatransfer: { color: "bg-sky-50 text-sky-700 border-sky-200",         stripeColor: "bg-sky-400",     resourceLabel: "Transfer",      ResourceIcon: Globe,     route: "/networking/datatransfer" },
    // Category-level services (hub "New suggestion" modal falls back to the category name) — route to the section landing page
    compute:    { color: "bg-orange-50 text-orange-700 border-orange-200",  stripeColor: "bg-orange-400",  resourceLabel: "Resource",      ResourceIcon: Server,    route: "/compute" },
    storage:    { color: "bg-green-50 text-green-700 border-green-200",     stripeColor: "bg-green-400",   resourceLabel: "Resource",      ResourceIcon: HardDrive, route: "/storage" },
    database:   { color: "bg-blue-50 text-blue-700 border-blue-200",        stripeColor: "bg-blue-400",    resourceLabel: "Resource",      ResourceIcon: Database,  route: "/databases" },
    networking: { color: "bg-indigo-50 text-indigo-700 border-indigo-200",  stripeColor: "bg-indigo-400",  resourceLabel: "Resource",      ResourceIcon: Globe,     route: "/networking" },
};
const DEFAULT_META = { color: "bg-gray-50 text-gray-600 border-gray-200", stripeColor: "bg-gray-400", resourceLabel: "Resource", ResourceIcon: Server, route: "" };
const getServiceMeta = (s) => SERVICE_META[String(s || "").toLowerCase()] || DEFAULT_META;

const inferCategory = (service) => {
    const v = String(service || "").toLowerCase();
    if (["ec2", "eks", "ecr", "ecs", "compute"].includes(v)) return "compute";
    if (["s3", "ebs", "storage"].includes(v)) return "storage";
    if (["rds", "database"].includes(v)) return "databases";
    if (["vpc", "elb", "datatransfer", "networking"].includes(v)) return "networking";
    if (["cloudwatch"].includes(v)) return "monitoring";
    return "compute";
};

const relativeTime = (isoStr) => {
    if (!isoStr) return "Just now";
    const date = new Date(isoStr);
    if (isNaN(date.getTime())) return isoStr;
    const ms = Date.now() - date.getTime();
    const m = Math.floor(ms / 60_000), h = Math.floor(ms / 3_600_000), d = Math.floor(ms / 86_400_000);
    if (m < 1) return "Just now";
    if (m < 60) return `${m}m ago`;
    if (h < 24) return `${h}h ago`;
    return d === 1 ? "1d ago" : `${d}d ago`;
};

const formatISTDate = (dateStr) => {
    if (!dateStr) return "";
    // Aggressively extract just the YYYY-MM-DDTHH:mm:ss part
    let cleanStr = dateStr.replace(" ", "T");
    if (cleanStr.length > 19) {
        cleanStr = cleanStr.substring(0, 19);
    }
    // Force UTC parsing by explicitly appending Z
    const utcDate = new Date(cleanStr + "Z");

    return utcDate.toLocaleString("en-US", {
        timeZone: "Asia/Kolkata",
        year: "numeric",
        month: "short",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit"
    });
};

const formatSuggestion = (s) => {
    const author = s.created_by || "User";
    const initials = author.split(" ").map((n) => n[0]).join("").toUpperCase().slice(0, 2);
    const { title, desc } = splitSuggestionText(s.text);
    const isEdited = s.updated_at && s.created_at && s.updated_at !== s.created_at;
    return {
        ...s,
        title, desc, author, initials,
        timeStr: relativeTime(s.created_at),
        isEdited,
        category: inferCategory(s.service),
        serviceMeta: getServiceMeta(s.service),
        isResourceScope: s.scope === "resource" && !!s.resource_id,
        shortId: (s.id || "").slice(-8),
    };
};

// Perf: fully static filter definitions, hoisted to module scope — one allocation
// for the app's lifetime. This also makes the selectedSvcMeta memo below honest:
// previously it closed over a SUBCATEGORIES object that was recreated on every
// render, so the memo's cached result silently referenced stale-but-identical data.
const CATEGORIES = [
    { label: "All Categories", value: "all" },
    { label: "Compute",        value: "compute"    },
    { label: "Storage",        value: "storage"     },
    { label: "Databases",      value: "databases"   },
    { label: "Networking",     value: "networking"  },
    { label: "Monitoring",     value: "monitoring"  },
];

const SUBCATEGORIES = {
    compute:    [{ label: "EC2", value: "ec2", resourceLabel: "Instance" }, { label: "EKS", value: "eks", resourceLabel: "Cluster" }, { label: "ECR", value: "ecr", resourceLabel: "Repository" }, { label: "ECS", value: "ecs", resourceLabel: "Cluster" }],
    storage:    [{ label: "S3", value: "s3", resourceLabel: "Bucket" }, { label: "EBS", value: "ebs", resourceLabel: "Volume" }],
    databases:  [{ label: "RDS", value: "rds", resourceLabel: "DB Instance" }],
    networking: [{ label: "VPC", value: "vpc", resourceLabel: "VPC" }, { label: "ELB", value: "elb", resourceLabel: "Load Balancer" }, { label: "Data Transfer", value: "datatransfer", resourceLabel: "Resource" }],
    monitoring: [{ label: "CloudWatch", value: "cloudwatch", resourceLabel: "Log Group" }],
};

export const Recommendation = () => {
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [selectedCategory, setSelectedCategory] = useState("all");
    const [selectedService, setSelectedService] = useState("all");
    const [scopeFilter, setScopeFilter] = useState("all");
    const { suggestions, isLoading, updateSuggestion, deleteSuggestion } = useSuggestions();

    const currentDateStr = useMemo(() =>
        new Date().toLocaleDateString("en-US", { weekday: "long", year: "numeric", month: "long", day: "numeric" }), []);

    // SUBCATEGORIES is now a module constant, so selectedService is the only real
    // input and this memo no longer recalculates for unrelated state changes.
    const selectedSvcMeta = useMemo(() => {
        if (selectedService === "all") return null;
        for (const subs of Object.values(SUBCATEGORIES)) {
            const found = subs.find((s) => s.value === selectedService);
            if (found) return found;
        }
        return null;
    }, [selectedService]);

    // Perf: stable handler identities (all use plain setters/stable mutations), so
    // the memo'd SuggestionCard below can skip re-rendering unchanged cards.
    const handleCategorySelect = useCallback((cat) => { setSelectedCategory(cat); setSelectedService("all"); setScopeFilter("all"); }, []);
    const handleServiceSelect  = useCallback((svc) => { setSelectedService(svc); setScopeFilter("all"); }, []);

    const formattedSuggestions = useMemo(() => (suggestions || []).map(formatSuggestion), [suggestions]);

    const filteredSuggestions = useMemo(() => formattedSuggestions.filter((item) => {
        if (selectedCategory !== "all" && item.category !== selectedCategory) return false;
        if (selectedService !== "all" && (item.service || "").toLowerCase() !== selectedService) return false;
        if (scopeFilter === "page" && item.isResourceScope) return false;
        if (scopeFilter === "resource" && !item.isResourceScope) return false;
        return true;
    }), [formattedSuggestions, selectedCategory, selectedService, scopeFilter]);

    const scopeCounts = useMemo(() => {
        const base = formattedSuggestions.filter((item) => {
            if (selectedCategory !== "all" && item.category !== selectedCategory) return false;
            if (selectedService !== "all" && (item.service || "").toLowerCase() !== selectedService) return false;
            return true;
        });
        return { all: base.length, page: base.filter((i) => !i.isResourceScope).length, resource: base.filter((i) => i.isResourceScope).length };
    }, [formattedSuggestions, selectedCategory, selectedService]);

    const resourceScopeLabel = selectedSvcMeta?.resourceLabel || "Resource";

    const handleTagClick = useCallback(({ service, scope }) => {
        const svc = (service || "").toLowerCase();
        setSelectedCategory(svc ? inferCategory(svc) : "all");
        setSelectedService(svc || "all");
        setScopeFilter(scope || "all");
    }, []);

    // Perf: previously inline arrows created per card per render, defeating the
    // card memo; react-query mutation fns are identity-stable.
    const handleUpdate = useCallback((suggestion_id, payload) => updateSuggestion({ suggestion_id, payload }), [updateSuggestion]);
    const handleDelete = useCallback((suggestion_id) => deleteSuggestion(suggestion_id), [deleteSuggestion]);

    return (
        <section className="w-full h-full min-h-screen bg-gray-50/50 p-6 mb-10">
            <title>Recommendations | SpendSmart</title>
            <meta name="description" content="View actionable recommendations to reduce cloud waste." />
            <div className="w-full flex items-center justify-between mb-8">
                <div>
                    <h1 className="text-2xl font-bold tracking-tight text-[var(--text-primary-color)]">Recommendation Hub</h1>
                    <p className="text-xs text-[var(--text-secondary-color)] font-medium mt-1">{currentDateStr}</p>
                </div>
                <motion.button
                    whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}
                    onClick={() => setIsModalOpen(true)} 
                    type="button"
                    className="flex items-center justify-center gap-2 px-5 py-2.5 bg-[var(--button-bg)] text-white text-xs font-bold rounded-lg shadow-sm hover:bg-[var(--button-bg)]/90 transition-all cursor-pointer uppercase tracking-wider shrink-0"
                >
                    <Pencil size={14} />
                    Add Suggestion
                </motion.button>
            </div>

            <div className="max-w-[720px] w-full mb-6 space-y-3">
                <div className="flex flex-wrap gap-2">
                    {CATEGORIES.map((cat) => {
                        const isActive = selectedCategory === cat.value;
                        return (
                            <button key={cat.value} onClick={() => handleCategorySelect(cat.value)}
                                className={`px-4 py-2 rounded-lg text-xs font-semibold border transition-all cursor-pointer shadow-sm ${isActive ? "bg-indigo-600 border-indigo-600 text-white shadow-indigo-100" : "bg-white border-gray-200 text-[var(--text-primary-color)] hover:border-indigo-300 hover:text-indigo-600"}`}>
                                {cat.label}
                            </button>
                        );
                    })}
                </div>

                {SUBCATEGORIES[selectedCategory] && (
                    <motion.div initial={{ opacity: 0, y: -6 }} animate={{ opacity: 1, y: 0 }}
                        className="flex flex-wrap gap-2 pl-3 py-2 border-l-2 border-indigo-200 bg-white/40 rounded-r-lg">
                        <button onClick={() => handleServiceSelect("all")}
                            className={`px-3 py-1.5 rounded-md text-[10px] font-bold border uppercase tracking-wider transition-all cursor-pointer ${selectedService === "all" ? "bg-indigo-50 border-indigo-200 text-indigo-700" : "bg-white border-gray-200 text-gray-500 hover:border-indigo-200 hover:text-indigo-600"}`}>
                            All
                        </button>
                        {SUBCATEGORIES[selectedCategory].map((svc) => {
                            const isActive = selectedService === svc.value;
                            const meta = getServiceMeta(svc.value);
                            return (
                                <button key={svc.value} onClick={() => handleServiceSelect(svc.value)}
                                    className={`px-3 py-1.5 rounded-md text-[10px] font-bold border uppercase tracking-wider transition-all cursor-pointer ${isActive ? meta.color : "bg-white border-gray-200 text-gray-500 hover:border-indigo-200 hover:text-indigo-600"}`}>
                                    {svc.label}
                                </button>
                            );
                        })}
                    </motion.div>
                )}

                {selectedService !== "all" && (
                    <motion.div key={selectedService} initial={{ opacity: 0, y: -4 }} animate={{ opacity: 1, y: 0 }}
                        className="flex items-center gap-2 pl-3 py-2 border-l-2 border-gray-200 bg-white/30 rounded-r-lg">
                        <span className="text-[9px] font-bold text-gray-400 uppercase tracking-widest mr-1">Scope</span>
                        {[
                            { value: "all",      label: "All",                                  count: scopeCounts.all      },
                            { value: "page",     label: `Overall ${selectedService.toUpperCase()}`, count: scopeCounts.page  },
                            { value: "resource", label: resourceScopeLabel,                     count: scopeCounts.resource  },
                        ].map((opt) => {
                            const isActive = scopeFilter === opt.value;
                            return (
                                <button key={opt.value} onClick={() => setScopeFilter(opt.value)}
                                    className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-bold border transition-all cursor-pointer ${isActive ? "bg-gray-800 border-gray-800 text-white" : "bg-white border-gray-200 text-gray-500 hover:border-gray-400 hover:text-gray-700"}`}>
                                    {opt.label}
                                    <span className={`text-[9px] font-bold px-1 rounded-full ${isActive ? "bg-white/20 text-white" : "bg-gray-100 text-gray-500"}`}>{opt.count}</span>
                                </button>
                            );
                        })}
                    </motion.div>
                )}
            </div>

            {/* List */}
            <div className="max-w-full w-full mb-4">
                <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-2">
                        <span className="text-[11px] font-bold text-[var(--text-primary-color)] uppercase tracking-widest">Manual Recommendations</span>
                        <span className="text-[10px] font-bold size-5 flex justify-center items-center rounded-full bg-gray-200 text-gray-600">{filteredSuggestions.length}</span>
                    </div>

                    {(selectedCategory !== "all" || scopeFilter !== "all") && (
                        <div className="flex items-center gap-1.5 flex-wrap">
                            {selectedService !== "all" && (
                                <span className={`inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded border uppercase tracking-wider ${getServiceMeta(selectedService).color}`}>
                                    {selectedService.toUpperCase()}
                                    <button onClick={() => { setSelectedService("all"); setScopeFilter("all"); }} className="ml-0.5 hover:opacity-60 cursor-pointer">×</button>
                                </span>
                            )}
                            {scopeFilter !== "all" && (
                                <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded border uppercase tracking-wider bg-gray-800 text-white border-gray-800">
                                    {scopeFilter === "resource" ? resourceScopeLabel : `Overall ${selectedService.toUpperCase()}`}
                                    <button onClick={() => setScopeFilter("all")} className="ml-0.5 hover:opacity-60 cursor-pointer">×</button>
                                </span>
                            )}
                            <button onClick={() => { setSelectedCategory("all"); setSelectedService("all"); setScopeFilter("all"); }}
                                className="text-[10px] text-gray-400 hover:text-gray-700 font-medium cursor-pointer underline underline-offset-2">
                                Clear all
                            </button>
                        </div>
                    )}
                </div>

                {isLoading ? (
                    <div className="space-y-3">
                        {[1, 2, 3].map((n) => <div key={n} className="h-36 bg-white ring-1 ring-zinc-950/50 rounded-xl animate-pulse" />)}
                    </div>
                ) : (
                    <div className="space-y-3 pb-4">
                        {filteredSuggestions.map((item) => (
                            <SuggestionCard
                                key={item.id}
                                item={item}
                                onTagClick={handleTagClick}
                                onUpdate={handleUpdate}
                                onDelete={handleDelete}
                            />
                        ))}

                        {filteredSuggestions.length === 0 && (
                            <div className="flex flex-col items-center justify-center py-12 text-center bg-white border border-dashed border-gray-200 rounded-xl">
                                <span className="text-xs text-[var(--text-secondary-color)] font-medium">No recommendations found matching the selected filters.</span>
                            </div>
                        )}
                    </div>
                )}
            </div>

            <Addsuggestions isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
        </section>
    );
};

// Perf: memo'd so only cards whose item (or the shared handlers) changed re-render;
// pairs with the useCallback handlers and memoized formattedSuggestions above.
const SuggestionCard = memo(({ item, onTagClick, onUpdate, onDelete }) => {
    const { serviceMeta, isResourceScope, service } = item;
    const { color, resourceLabel, ResourceIcon } = serviceMeta;
    const navigate = useNavigate();

    const [isEditing, setIsEditing] = useState(false);
    const [editTitle, setEditTitle] = useState(item.title || "");
    const [editDesc, setEditDesc]   = useState(item.desc  || "");
    const [isSaving, setIsSaving]   = useState(false);
    const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
    const [isDeleting, setIsDeleting] = useState(false);

    // const handleLike = () => {
    //     setLiked((p) => !p);
    //     setLikeCount((p) => p + (liked ? -1 : 1));
    // };

    const handleSave = async () => {
        if (!editTitle.trim()) return;
        setIsSaving(true);
        try {
            const newText = editDesc.trim() ? `${editTitle.trim()} | ${editDesc.trim()}` : editTitle.trim();
            await onUpdate(item.id, { text: newText });
            setIsEditing(false);
        } catch (e) {
            console.error("Update failed:", e);
        } finally {
            setIsSaving(false);
        }
    };

    const handleDelete = async () => {
        setIsDeleting(true);
        try {
            await onDelete(item.id);
        } catch (e) {
            console.error("Delete failed:", e);
            setIsDeleting(false);
            setShowDeleteConfirm(false);
        }
    };

    // Navigates to the target page — resource drawer if resource-scoped, service page if page-scoped
    const handleOpenTarget = () => {
        if (isEditing || showDeleteConfirm) return;
        const route = serviceMeta.route;
        if (!route) return;
        const url = isResourceScope && item.resource_id
            ? `${route}?resource=${encodeURIComponent(item.resource_id)}`
            : route;
        navigate(url);
    };

    const hasRoute = !!serviceMeta.route;

    return (
        <button
            type="button"
            onClick={handleOpenTarget}
            title={!hasRoute ? undefined : isResourceScope ? `Open ${item.resource_name || item.resource_id} metadata` : `Open ${(service || "").toUpperCase()} page`}
            className={`w-full text-left relative flex flex-col bg-white ring-1 ring-black/10 rounded-xl overflow-hidden hover:shadow-[0_4px_20px_rgba(0,0,0,0.07)] transition-all duration-200 focus:outline-none border-none p-0 m-0 ${hasRoute ? "cursor-pointer" : ""}`}>
            {/* ── Card header bar (white) */}
            <div className={`flex items-center justify-between px-4 py-2.5 bg-white border-b border-gray-100/80 ${isResourceScope ? "pl-5" : ""}`}>
                <div className="flex items-center gap-1.5 flex-wrap">
                    <button
                        type="button"
                        title={`Show all ${service?.toUpperCase()} recommendations`}
                        onClick={(e) => { e.stopPropagation(); onTagClick?.({ service, scope: "all" }); }}
                        className={`inline-flex items-center gap-1 font-bold px-2 py-0.5 rounded border text-[10px] uppercase tracking-wider cursor-pointer transition-all hover:opacity-80 active:scale-95 ${color}`}>
                        {(service || "unknown").toUpperCase()}
                    </button>

                    {isResourceScope ? (
                        <button type="button"
                            title={`Show only ${resourceLabel}-scoped ${service?.toUpperCase()}`}
                            onClick={(e) => { e.stopPropagation(); onTagClick?.({ service, scope: "resource" }); }}
                            className="inline-flex items-center gap-1 font-bold px-2 py-0.5 rounded border text-[10px] uppercase tracking-wider cursor-pointer hover:opacity-85 active:scale-95 bg-gray-50 text-gray-500 border-gray-200 hover:bg-gray-100 hover:text-gray-700">
                            <ResourceIcon size={9} />
                            {resourceLabel}
                        </button>
                    ) : (
                        <button type="button"
                            title={`Show overall ${service?.toUpperCase()}`}
                            onClick={(e) => { e.stopPropagation(); onTagClick?.({ service, scope: "page" }); }}
                            className="inline-flex items-center gap-1 font-bold px-2 py-0.5 rounded border text-[10px] uppercase tracking-wider cursor-pointer hover:opacity-85 active:scale-95 bg-gray-50 text-gray-500 border-gray-200 hover:bg-gray-100 hover:text-gray-700">
                            <Globe size={9} />
                            Overall
                        </button>
                    )}
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                    {/* Like */}
                    {/* <button
                        type="button"
                        onClick={handleLike}
                        className={`inline-flex items-center gap-1 px-2.5 py-1 rounded text-[11px] font-bold border transition-all cursor-pointer ${liked ? "bg-rose-500 border-rose-500 text-white" : "bg-gray-50 border-gray-200 text-gray-500 hover:bg-rose-500/10 hover:border-rose-400 hover:text-rose-400"}`}>
                        <ThumbsUp size={11} className={liked ? "fill-white" : ""} />
                        {likeCount > 0 && <span>{likeCount}</span>}
                    </button> */}

                    {/* Edit */}
                    {!isEditing && (
                        <button
                            type="button"
                            onClick={(e) => { e.stopPropagation(); setIsEditing(true); setEditTitle(item.title || ""); setEditDesc(item.desc || ""); }}
                            className="inline-flex items-center gap-1 px-2.5 py-1 rounded text-[11px] font-semibold border bg-white border-gray-200 text-gray-600 hover:bg-gray-50 hover:text-gray-900 hover:border-gray-300 transition-all cursor-pointer shadow-sm">
                            <Edit3 size={11} />
                            Edit
                        </button>
                    )}

                    {!showDeleteConfirm ? (
                        <button
                            type="button"
                            onClick={(e) => { e.stopPropagation(); setShowDeleteConfirm(true); }}
                            className="inline-flex items-center gap-1 px-2.5 py-1 rounded text-[11px] font-semibold border bg-white border-gray-200 text-gray-600 hover:bg-red-50 hover:border-red-200 hover:text-red-600 transition-all cursor-pointer shadow-sm">
                            <Trash2 size={11} />
                            Delete
                        </button>
                    ) : (
                        <div className="inline-flex items-center gap-1">
                            {/* <span className="text-[10px] text-red-500 font-semibold mr-1">Sure?</span> */}
                            <button onClick={handleDelete} disabled={isDeleting}
                                className="px-2 py-1 rounded text-[11px] font-bold bg-red-500 text-white border border-red-500 hover:bg-red-600 cursor-pointer transition-all disabled:opacity-50 shadow-sm">
                                {isDeleting ? "…" : "Yes"}
                            </button>
                            <button onClick={() => setShowDeleteConfirm(false)}
                                className="px-2 py-1 rounded text-[11px] font-bold bg-white text-gray-600 border border-gray-200 hover:bg-gray-50 hover:text-gray-900 hover:border-gray-300 cursor-pointer transition-all shadow-sm">
                                No
                            </button>
                        </div>
                    )}
                </div>
            </div>

            <div className={`flex-1 px-5 py-4 flex flex-col gap-2.5 ${isResourceScope ? "pl-6" : ""}`}>
                {isResourceScope && (
                    <div className="flex items-center gap-1.5">
                        <ResourceIcon size={12} className="text-gray-400 shrink-0" />
                        <span className="text-[11px] font-semibold text-[var(--text-secondary-color)] truncate">
                            {item.resource_name || item.resource_id}
                            {item.resource_id && item.resource_name && (
                                <span className="ml-1.5 text-[10px] text-gray-400">· {item.resource_id}</span>
                            )}
                        </span>
                    </div>
                )}

                {!isEditing ? (
                    <>
                        <p className="font-bold text-sm text-[var(--text-primary-color)] leading-snug">
                            {item.title || "(no title)"}
                        </p>
                        {item.desc && (
                            <div className="relative rounded-md ring-1 ring-black/10 p-2 h-60">
                                <span className="border-b border-black/10">Descriptions </span>
                                <div className="text-xs h-full text-[var(--text-secondary-color)] leading-relaxed min-h-[5rem] overflow-y-auto pr-1 whitespace-pre-line scrollbar-thin scrollbar-thumb-gray-200 scrollbar-track-transparent">
                                    {item.desc}
                                </div>
                                {/* <div className="absolute bottom-0 left-0 right-0 h-5 bg-gradient-to-t from-white to-transparent pointer-events-none" /> */}
                            </div>
                        )}
                    </>
                ) : (
                    <AnimatePresence mode="wait">
                        <motion.div key="edit-form" initial={{ opacity: 0, y: -4 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} className="space-y-2">
                            <input
                                autoFocus
                                value={editTitle}
                                onChange={(e) => setEditTitle(e.target.value)}
                                placeholder="Suggestion title"
                                className="w-full px-3 py-2 text-sm font-semibold border border-gray-200 rounded-lg bg-gray-50 text-[var(--text-primary-color)] focus:outline-none focus:ring-2 focus:ring-[var(--button-bg)]/20 focus:border-[var(--button-bg)] transition-all"
                            />
                            <textarea
                                value={editDesc}
                                onChange={(e) => setEditDesc(e.target.value)}
                                placeholder="More context (optional)"
                                rows={3}
                                className="w-full px-3 py-2 text-xs border border-gray-200 rounded-lg bg-gray-50 text-[var(--text-primary-color)] focus:outline-none focus:ring-2 focus:ring-[var(--button-bg)]/20 focus:border-[var(--button-bg)] transition-all resize-none"
                            />
                            <div className="flex items-center gap-2 justify-end">
                                <button onClick={() => setIsEditing(false)}
                                    className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold border border-gray-200 text-gray-500 hover:bg-gray-50 cursor-pointer transition-all">
                                    <XIcon size={12} /> Cancel
                                </button>
                                <button onClick={handleSave} disabled={isSaving || !editTitle.trim()}
                                    className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-bold bg-[var(--button-bg)] text-white hover:bg-[var(--button-bg)]/90 cursor-pointer transition-all disabled:opacity-50">
                                    <Check size={12} /> {isSaving ? "Saving…" : "Save"}
                                </button>
                            </div>
                        </motion.div>
                    </AnimatePresence>
                )}
            </div>

            {!isEditing && (
                <div className={`flex items-center justify-between px-5 pb-3 ${isResourceScope ? "pl-6" : ""}`}>
                    <div className="flex items-center gap-1.5 text-[11px] text-gray-400 font-medium">
                        <span className="w-5 h-5 rounded-full bg-gray-100 flex items-center justify-center text-[9px] font-bold text-gray-500">
                            {item.initials}
                        </span>
                        <span>{item.author}</span>
                        {item.isEdited && (
                            <>
                                <span>·</span>
                                <span className="text-[10px] px-1.5 py-0.5 rounded bg-gray-100 text-gray-400 font-semibold">edited</span>
                            </>
                        )}
                    </div>
                    <div className="text-[10px] text-gray-400 font-medium">
                        {item.created_at ? formatISTDate(item.created_at) : item.timeStr}
                    </div>
                </div>
            )}
        </button>
    );
});

export default Recommendation;