import { apiRequest } from "../../lib/apiClient";
import { API_ENDPOINTS } from "../../APIs/ApiEndPoint";

export const getlistsuggestions = async (params = {}) => {
  const qs = new URLSearchParams();
  if (params.account_name) qs.append("account_name", params.account_name);
  if (params.service) qs.append("service", params.service);
  if (params.scope) qs.append("scope", params.scope);
  if (params.resource_id) qs.append("resource_id", params.resource_id);
  const query = qs.toString();
  const endpoint = query
    ? `${API_ENDPOINTS.getlistsuggestions}?${query}`
    : API_ENDPOINTS.getlistsuggestions;
  return apiRequest({ endpoint, method: "GET" });
};

export const postcreatesuggestions = async (payload) => {
  return apiRequest({
    endpoint: API_ENDPOINTS.postcreatesuggestions,
    method: "POST",
    body: payload,
  });
};

export const updatesuggestions = async (suggestion_id, payload) => {
  const endpoint = typeof API_ENDPOINTS.updatesuggestions === "function"
    ? API_ENDPOINTS.updatesuggestions(suggestion_id)
    : API_ENDPOINTS.updatesuggestions;
  return apiRequest({
    endpoint,
    method: "PUT",
    body: payload,
  });
};

export const deletesuggestions = async (suggestion_id) => {
  const endpoint = typeof API_ENDPOINTS.deletesuggestionid === "function"
    ? API_ENDPOINTS.deletesuggestionid(suggestion_id)
    : `${API_ENDPOINTS.getlistsuggestions}/${suggestion_id}`;
  return apiRequest({ endpoint, method: "DELETE" });
};


