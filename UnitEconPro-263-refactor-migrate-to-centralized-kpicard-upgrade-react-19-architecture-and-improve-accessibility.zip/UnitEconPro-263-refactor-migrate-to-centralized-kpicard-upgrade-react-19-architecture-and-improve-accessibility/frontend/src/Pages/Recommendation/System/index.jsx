import React from "react";

const SystemRecommendation = () => {
    return (
        <div className="w-full min-h-screen p-6">
            <h1 className="text-2xl font-bold">System Recommendations</h1>
            <p className="mt-4 text-gray-600">Coming soon...</p>
        </div>
    );
};

export default SystemRecommendation;
