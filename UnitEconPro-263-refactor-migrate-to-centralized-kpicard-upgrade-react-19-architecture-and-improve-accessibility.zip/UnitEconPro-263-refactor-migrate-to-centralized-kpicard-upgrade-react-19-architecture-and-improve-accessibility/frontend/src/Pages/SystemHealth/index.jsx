import { Activity, Database, Server, RefreshCw } from "lucide-react";
import { useSystemHealth } from "../../hooks/SystemHealth/useSystemHealth";

const SystemHealth = () => {
    const { healthz, readyz, isLoading, isError, healthzQuery, readyzQuery } = useSystemHealth();

    const isRefetching = healthzQuery.isRefetching || readyzQuery.isRefetching;

    const handleRefresh = () => {
        healthzQuery.refetch();
        readyzQuery.refetch();
    };

    return (
        <div className="p-6 max-w-4xl mx-auto">
            <title>System Health | SpendSmart</title>
            <meta name="description" content="View system health, API status, and database metrics." />
            <div className="flex items-center justify-between mb-6">
                <h1 className="text-2xl font-bold text-[var(--text-primary-color)] flex items-center gap-2">
                    <Activity size={24} className="text-blue-500" />
                    System Health Overview
                </h1>
                <button 
                    onClick={handleRefresh}
                    disabled={isRefetching}
                    className="group flex items-center gap-2 px-4 py-2 bg-white border border-gray-200 text-gray-700 rounded-lg hover:text-blue-500 hover:border-blue-200 hover:bg-blue-50 cursor-pointer active:scale-95 transition-all shadow-sm text-sm font-medium disabled:opacity-50"
                >
                    <RefreshCw size={16} className={`${isRefetching ? "animate-spin text-blue-500" : "transition-transform duration-500 group-hover:rotate-180"}`} />
                    {isRefetching ? "Refresh" : "Refresh"}
                </button>
            </div>
            
            {isLoading && !isRefetching ? (
                <div className="flex items-center justify-center p-12">
                    <div className="w-8 h-8 border-4 border-blue-200 border-t-blue-500 rounded-full animate-spin"></div>
                </div>
            ) : isError ? (
                <div className="bg-red-50 text-red-500 p-4 rounded-xl border border-red-100 font-medium">
                    Error fetching system health data. Please check your connection to the API.
                </div>
            ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* API Status Card */}
                    <div className="bg-white p-6 rounded-xl shadow-[var(--shadow)] ring-[0.5px] ring-black/10">
                        <div className="flex items-center gap-3 mb-4 border-b border-gray-100 pb-4">
                            <div className="p-2 bg-blue-50 text-blue-600 rounded-lg">
                                <Server size={20} />
                            </div>
                            <div>
                                <h2 className="text-lg font-bold text-gray-800">API Server</h2>
                                <p className="text-xs text-gray-500">Liveness Probe (/healthz)</p>
                            </div>
                        </div>
                        <div className="flex items-center justify-between">
                            <span className="text-sm font-medium text-gray-600">Status</span>
                            <span className={`px-3 py-1 rounded-full text-xs font-bold ${healthz?.status === 'alive' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                                {healthz?.status ? healthz.status.toUpperCase() : 'UNKNOWN'}
                            </span>
                        </div>
                    </div>

                    {/* Database Status Card */}
                    <div className="bg-white p-6 rounded-xl shadow-[var(--shadow)] ring-[0.5px] ring-black/10">
                        <div className="flex items-center gap-3 mb-4 border-b border-gray-100 pb-4">
                            <div className="p-2 bg-purple-50 text-purple-600 rounded-lg">
                                <Database size={20} />
                            </div>
                            <div>
                                <h2 className="text-lg font-bold text-gray-800">Database</h2>
                                <p className="text-xs text-gray-500">Readiness Probe (/readyz)</p>
                            </div>
                        </div>
                        <div className="flex items-center justify-between mb-3">
                            <span className="text-sm font-medium text-gray-600">Status</span>
                            <span className={`px-3 py-1 rounded-full text-xs font-bold ${readyz?.status === 'ready' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                                {readyz?.status ? readyz.status.toUpperCase() : 'UNKNOWN'}
                            </span>
                        </div>
                        
                        {readyz?.database && (
                            <div className="bg-gray-50 p-4 rounded-lg mt-4 space-y-2">
                                <div className="flex justify-between text-xs">
                                    <span className="text-gray-500 font-medium">Name</span>
                                    <span className="text-gray-800 font-semibold">{readyz.database.name}</span>
                                </div>
                                <div className="flex justify-between text-xs">
                                    <span className="text-gray-500 font-medium">Host</span>
                                    <span className="text-gray-800 font-semibold">{readyz.database.host}</span>
                                </div>
                                <div className="flex justify-between text-xs">
                                    <span className="text-gray-500 font-medium">Port</span>
                                    <span className="text-gray-800 font-semibold">{readyz.database.port}</span>
                                </div>
                                <div className="flex justify-between text-xs">
                                    <span className="text-gray-500 font-medium">Response Time</span>
                                    <span className={`font-semibold ${readyz.database.response_time_ms < 50 ? 'text-green-600' : 'text-orange-500'}`}>
                                        {readyz.database.response_time_ms} ms
                                    </span>
                                </div>
                            </div>
                        )}
                    </div>
                </div>
            )}
        </div>
    );
};

export default SystemHealth;
