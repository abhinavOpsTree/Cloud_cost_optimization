import { apiRequest } from "../../lib/apiClient";
import { API_ENDPOINTS } from "../../APIs/ApiEndPoint";

export const getSystemHealthz = async () => {
    return await apiRequest({
        endpoint: API_ENDPOINTS.systemHealth,
        method: "GET",
    });
};

export const getSystemReadyz = async () => {
    return await apiRequest({
        endpoint: API_ENDPOINTS.systemReady,
        method: "GET",
    });
};

