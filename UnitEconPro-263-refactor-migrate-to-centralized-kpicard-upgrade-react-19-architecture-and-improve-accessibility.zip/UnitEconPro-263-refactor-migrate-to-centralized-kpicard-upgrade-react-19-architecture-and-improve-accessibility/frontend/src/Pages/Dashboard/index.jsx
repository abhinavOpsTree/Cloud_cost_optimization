import { lazy, Suspense } from "react";
import { useDashboard } from "../../hooks/useDashboard";
import RunRate from "./Components/RunRate";

const ForecastDashCard = lazy(() => import("../../common/MonthtoDate/ForcastedData").then(module => ({ default: module.ForecastDashCard })));
const Trendgraph = lazy(() => import("./Components/Trendgraph"));
const CostCategories = lazy(() => import("./Components/Costcategories").then(module => ({ default: module.CostCategories })));
const Barchart = lazy(() => import("../../common/Charts/Barchart").then(module => ({ default: module.Barchart })));

const Dashboard = () => {
    const { summary, forecast, trend, isTrendError, isTrendLoading, comparison, isComparisonError, isComparisonLoading, budgetForecast, breakdownService, isBreakdownServiceLoading, isBreakdownServiceFetching, isBreakdownServiceError } = useDashboard();
    return (
        <section className="min-h-screen w-full p-4 space-y-4">
            <title>Dashboard | SpendSmart</title>
            <meta name="description" content="View your high-level cloud spend and analytics on the SpendSmart dashboard." />
            <RunRate />
            <Suspense fallback={<div className="h-[200px] w-full animate-pulse bg-neutral-100 border border-black/10 rounded-xl mt-4"></div>}>
                <ForecastDashCard
                    comparison={comparison}
                    isComparisonError={isComparisonError}
                    isComparisonLoading={isComparisonLoading}
                    data={forecast}
                    trend={trend}
                    isTrendLoading={isTrendLoading}
                    budgetForecast={budgetForecast}
                />
            </Suspense>
            <Suspense fallback={<div className="h-[300px] w-full animate-pulse bg-neutral-100 border border-black/10 rounded-xl mt-4"></div>}>
                <Trendgraph data={trend} loading={isTrendLoading} error={isTrendError} budget={budgetForecast?.budget_amount ?? null} avgCost={summary?.avg_daily_cost} />
            </Suspense>
            <Suspense fallback={<div className="h-[300px] w-full animate-pulse bg-[var(--background-color)] border border-black/10 rounded-xl mt-4"></div>}>
                <Barchart data={breakdownService} isLoading={isBreakdownServiceLoading} isFetching={isBreakdownServiceFetching} isError={isBreakdownServiceError} />
            </Suspense>
            <Suspense fallback={<div className="h-[300px] w-full animate-pulse bg-neutral-100 border border-black/10 rounded-xl mt-4"></div>}>
                <CostCategories />
            </Suspense>
        </section>
    );
};

export default Dashboard;
