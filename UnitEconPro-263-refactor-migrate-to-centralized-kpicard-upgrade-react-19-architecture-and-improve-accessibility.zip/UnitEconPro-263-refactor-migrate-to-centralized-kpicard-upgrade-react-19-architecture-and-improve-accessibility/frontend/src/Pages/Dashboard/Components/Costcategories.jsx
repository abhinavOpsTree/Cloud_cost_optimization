import { ArrowRight, ChevronDown, Check, Maximize2 } from "lucide-react";
import { useState, useRef, useEffect, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { Area, AreaChart, ResponsiveContainer, Tooltip, XAxis, YAxis, CartesianGrid } from "recharts";
import { motion, AnimatePresence } from "framer-motion";
import { useFilters } from "../../../hooks/useFilters";
import { getUnifiedTrend } from "../../../lib/types/Unified";
import { queryKeys } from "../../../lib/queryKeys";
import Skeleton from "../../../common/Skeleton";
import { Link } from "react-router-dom";
import { FullscreenChartModal } from "../../../common/FullScreen";

const categories = [
    {
        title: "Compute",
        services: [
            { type: "EkS" },
            { type: "ECR" },
            { type: "ECS" },
            { type: "EC2" },
        ],
        driver: "Major driver",
        driverColor: "text-red-500",
        color: "#3b82f6",
        path: "/compute/EKS",
    },
    {
        title: "Storage",
        services: [
            { type: "S3" },
            { type: "EBS" },
        ],
        driver: "Unusual spike",
        driverColor: "text-orange-500",
        color: "#10b981",
        path: "/storage/s3",
    },
    {
        title: "Database",
        services: [
            { type: "RDS" },
        ],
        driver: "Minor change",
        driverColor: "text-emerald-500",
        color: "#f59e0b",
        path: "/databases/rds",
    },
    {
        title: "Network",
        services: [
            { type: "VPC" },
            { type: "ELB" },
            { type: "Data-Transfer" }
        ],
        driver: "Moderate increase",
        driverColor: "text-orange-400",
        color: "#8b5cf6",
        path: "/networking/vpc",
    },
    {
        title: "Monitoring",
        services: [
            { type: "Cloudwatch" },
        ],
        driver: "Moderate increase",
        driverColor: "text-orange-400",
        // Distinct from Network's #8b5cf6 (was accidentally duplicated); cyan is
        // already in COLOR_CLASSES so no map change is needed.
        color: "#06b6d4",
        path: "/monitoring/cloudwatch",
    },
];

// Tailwind generates CSS only for class literals it can see at build time, so the
// finite chart palette is mapped to prebuilt classes here instead of inline styles.
// IMPORTANT: if a color is ever added to `categories` above or to the serviceColors
// palette inside CategoryCard, it MUST be added to this map too — an unmapped color
// silently renders unstyled.
const COLOR_CLASSES = {
    "#3b82f6": { borderTop: "border-t-[#3b82f6]", bg: "bg-[#3b82f6]", tint: "bg-[#3b82f6]/[7.8%]" },
    "#10b981": { borderTop: "border-t-[#10b981]", bg: "bg-[#10b981]", tint: "bg-[#10b981]/[7.8%]" },
    "#f59e0b": { borderTop: "border-t-[#f59e0b]", bg: "bg-[#f59e0b]", tint: "bg-[#f59e0b]/[7.8%]" },
    "#8b5cf6": { borderTop: "border-t-[#8b5cf6]", bg: "bg-[#8b5cf6]", tint: "bg-[#8b5cf6]/[7.8%]" },
    "#ef4444": { borderTop: "border-t-[#ef4444]", bg: "bg-[#ef4444]", tint: "bg-[#ef4444]/[7.8%]" },
    "#06b6d4": { borderTop: "border-t-[#06b6d4]", bg: "bg-[#06b6d4]", tint: "bg-[#06b6d4]/[7.8%]" },
};

const CategoryCard = ({ cat }) => {

    const [activeService, setActiveService] = useState(cat.services[0].type);
    const [isOpen, setIsOpen] = useState(false);
    const [isFullscreen, setIsFullscreen] = useState(false);
    const dropdownRef = useRef(null);
    const { filters } = useFilters();
    const hasDateRange = !!filters.start_date && !!filters.end_date;
    const hasAccount = !!(filters.account || filters.account_name);
    const isQueryEnabled = hasDateRange && hasAccount;

    const activeQuery = useQuery({
        queryKey: queryKeys.unified.trend(activeService.toLowerCase(), filters),
        queryFn: () => getUnifiedTrend(filters, activeService.toLowerCase()),
        enabled: isQueryEnabled,
        staleTime: 60000,
        retry: false,
        refetchOnWindowFocus: false,
        refetchOnReconnect: false,
    });

    const trend = activeQuery?.data ?? [];
    const isTrendLoading = activeQuery?.isLoading ?? false;
    const isTrendError = activeQuery?.isError ?? false;

    const [fsActiveService, setFsActiveService] = useState(cat.services[0].type);
    const [isFsDropdownOpen, setIsFsDropdownOpen] = useState(false);
    const fsDropdownRef = useRef(null);

    const fsQuery = useQuery({
        queryKey: queryKeys.unified.trend(fsActiveService.toLowerCase(), filters),
        queryFn: () => getUnifiedTrend(filters, fsActiveService.toLowerCase()),
        enabled: isQueryEnabled && isFullscreen,
        staleTime: 60000,
        retry: false,
        refetchOnWindowFocus: false,
        refetchOnReconnect: false,
    });

    const fsTrend = fsQuery?.data ?? [];
    const isFsTrendLoading = fsQuery?.isLoading ?? false;
    const isFsTrendError = fsQuery?.isError ?? false;

    const serviceColors = useMemo(() => {
        const palette = ["#3b82f6", "#10b981", "#f59e0b", "#8b5cf6", "#ef4444", "#06b6d4"];
        return Object.fromEntries(cat.services.map((s, i) => [s.type, palette[i % palette.length]]));
    }, [cat.services]);

    const fsColor = serviceColors[fsActiveService] || cat.color;

    useEffect(() => {
        const available = cat.services.map((s) => s.type);
        if (available.length === 0) return;
        if (!available.includes(activeService)) {
            setActiveService(available[0]);
        }
    }, [cat.services, activeService]);

    useEffect(() => {
        const handleClickOutside = (event) => {
            if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
                setIsOpen(false);
            }
            if (fsDropdownRef.current && !fsDropdownRef.current.contains(event.target)) {
                setIsFsDropdownOpen(false);
            }
        };
        document.addEventListener("mousedown", handleClickOutside);
        return () => document.removeEventListener("mousedown", handleClickOutside);
    }, []);

    const miniChartJsx = (
        <div className="mt-auto h-16 w-full relative overflow-hidden">
            {isTrendLoading ? (
                <Skeleton height="100%" variant="rectangular" className="opacity-50" />
            ) : isTrendError ? (
                <div className="absolute inset-0 flex items-center justify-center bg-red-50/50 z-10 rounded">
                    <span className="text-[10px] font-bold text-red-500">Error loading trend</span>
                </div>
            ) : !Array.isArray(trend) || trend.length === 0 ? (
                <div className="absolute inset-0 flex items-center justify-center bg-gray-50/50 z-10 rounded">
                    <span className="text-[10px] font-bold text-gray-500 capitalize">No data available</span>
                </div>
            ) : (
                <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={trend} margin={{ top: 0, right: 0, left: 0, bottom: 0 }}>
                        <defs>
                            <linearGradient id={`mini-${cat.title}`} x1="0" y1="0" x2="0" y2="1">
                                <stop offset="5%" stopColor={cat.color} stopOpacity={0.15} />
                                <stop offset="95%" stopColor={cat.color} stopOpacity={0} />
                            </linearGradient>
                        </defs>
                        <Tooltip
                            formatter={(value) => [`$${Number(value).toFixed(2)}`, "Cost"]}
                            labelFormatter={(label, payload) => {
                                const point = payload?.[0]?.payload;
                                return point?.date || point?.month || point?.day || label || "Date";
                            }}
                            labelClassName="text-gray-900 text-[11px]"
                            wrapperClassName="rounded-lg border border-gray-200 text-[11px] px-2 py-1.5"
                            contentStyle={{}}
                            cursor={{ stroke: cat.color, strokeWidth: 1, strokeOpacity: 0.4 }}
                        />
                        {/* Dashed line to bridge missing data gaps */}
                        <Area
                            type="monotone"
                            dataKey="cost"
                            stroke={cat.color}
                            strokeWidth={1}
                            strokeDasharray="3 3"
                            connectNulls={true}
                            fill="none"
                            tooltipType="none"
                            activeDot={false}
                            isAnimationActive={true}
                            dot={false}
                        />
                        {/* Solid line for actual data */}
                        <Area
                            type="monotone"
                            dataKey="cost"
                            stroke={cat.color}
                            strokeWidth={1.2}
                            fillOpacity={1}
                            fill={`url(#mini-${cat.title})`}
                            connectNulls={false}
                            isAnimationActive={true}
                            dot={false}
                        />
                    </AreaChart>
                </ResponsiveContainer>
            )}
        </div>
    );
    const fullscreenChartJsx = (
        <div className="h-[280px] w-full">
            {isFsTrendLoading ? (
                <Skeleton height="100%" variant="rectangular" />
            ) : isFsTrendError ? (
                <div className="flex items-center justify-center h-full">
                    <span className="text-[13px] text-red-500 font-bold">Error loading trend</span>
                </div>
            ) : fsTrend.length === 0 ? (
                <div className="flex items-center justify-center h-full">
                    <span className="text-[13px] text-[#9098b1]">No data available</span>
                </div>
            ) : (
                <ResponsiveContainer width="100%" height="100%">
                    <AreaChart
                        data={fsTrend}
                        margin={{ top: 10, right: 24, left: -5, bottom: 0 }}
                    >
                        <defs>
                            <linearGradient id={`fs-grad-${fsActiveService}`} x1="0" y1="0" x2="0" y2="1">
                                <stop offset="0%" stopColor={fsColor} stopOpacity={0.18} />
                                <stop offset="70%" stopColor={fsColor} stopOpacity={0.05} />
                                <stop offset="100%" stopColor={fsColor} stopOpacity={0} />
                            </linearGradient>
                        </defs>

                        <CartesianGrid strokeDasharray="3 3" stroke="#F0F1F5" vertical={false} />

                        <XAxis
                            dataKey="date"
                            tick={{ fontSize: 11, fill: "#9098b1" }}
                            tickLine={false}
                            axisLine={false}
                            height={24}
                            tickMargin={6}
                            minTickGap={30}
                        />

                        <YAxis
                            tick={{ fontSize: 11, fill: "#9098b1" }}
                            tickLine={false}
                            axisLine={false}
                            tickFormatter={(v) => `$${v}`}
                            tickMargin={6}
                            width={55}
                        />

                        <Tooltip
                            formatter={(value) => [`$${Number(value).toFixed(2)}`, fsActiveService]}
                            labelClassName="text-gray-900 text-[11px]"
                            wrapperClassName="rounded-lg border border-gray-200 text-[11px] px-3 py-2 backdrop-blur-sm bg-white/90"
                            contentStyle={{}}
                            cursor={{ stroke: "#D1D5DB", strokeWidth: 1, strokeDasharray: "4 4" }}
                        />

                        {/* Dashed line to bridge missing data gaps */}
                        <Area
                            type="monotone"
                            dataKey="cost"
                            stroke={fsColor}
                            strokeWidth={1.2}
                            strokeDasharray="5 5"
                            connectNulls={true}
                            fill="none"
                            tooltipType="none"
                            activeDot={false}
                            isAnimationActive={false}
                            dot={false}
                        />

                        {/* Main solid line */}
                        <Area
                            type="monotone"
                            dataKey="cost"
                            name={fsActiveService}
                            stroke={fsColor}
                            strokeWidth={2.4}
                            fill={`url(#fs-grad-${fsActiveService})`}
                            fillOpacity={1}
                            connectNulls={false}
                            isAnimationActive={false}
                            dot={false}
                            activeDot={{
                                r: 4,
                                strokeWidth: 2,
                                fill: "#fff",
                                stroke: fsColor,
                            }}
                        />
                    </AreaChart>
                </ResponsiveContainer>
            )}
        </div>
    );

    return (
        <>
            <div
                className={`h-fit bg-white shadow-sm rounded-md overflow-hidden ring-1 ring-black/5 flex flex-col hover:shadow-md transition-shadow 3xl:min-w-80 3xl:w-80 3xl:w-full border-t ${COLOR_CLASSES[cat.color]?.borderTop ?? "border-t-transparent"}`}
            >
                <div className="p-4 flex-1 flex flex-col">
                    <div className="flex justify-between items-center mb-4 gap-4">
                        <span className="text-sm font-semibold text-gray-600 whitespace-nowrap">{cat.title}</span>
                        {/* {isTrendLoading ? (
                            <Skeleton width={64} height={24} variant="rectangular" />
                        ) :  */
                        cat.services.length > 0 && (
                            <div className="relative" ref={dropdownRef}>
                                {cat.services.length > 1 ? (
                                    <button
                                        onClick={(e) => {
                                            e.stopPropagation();
                                            setIsOpen(!isOpen);
                                        }}
                                        className="flex cursor-pointer items-center justify-between gap-2 px-3 py-1 min-w-10 max-w-34 bg-[var(--card-bg)] rounded ring-1 ring-black/10 hover:ring-black/20 transition-all duration-200"
                                    >
                                        <span className="text-[10px] font-bold text-gray-700">{activeService}</span>
                                        <ChevronDown
                                            size={12}
                                            className={`text-gray-400 transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`}
                                        />
                                    </button>
                                ) : (
                                    <span className="text-[10px] font-bold text-gray-700 px-3 py-1">{activeService}</span>
                                )}
                                <AnimatePresence>
                                    {isOpen && cat.services.length > 1 && (
                                        <motion.div
                                            initial={{ opacity: 0, y: -10, scale: 0.95 }}
                                            animate={{ opacity: 1, y: 4, scale: 1 }}
                                            exit={{ opacity: 0, y: -10, scale: 0.95 }}
                                            transition={{ duration: 0.15, ease: "easeOut" }}
                                            className="absolute right-0 top-full z-50 min-w-16 w-fit bg-white shadow-[0_10px_40px_-10px_rgba(0,0,0,0.15)] ring-1 ring-black/10 rounded overflow-hidden"
                                        >
                                            {cat.services.map((service) => (
                                                <button
                                                    type="button"
                                                    key={service.type}
                                                    onClick={(e) => {
                                                        e.stopPropagation();
                                                        setActiveService(service.type);
                                                        setIsOpen(false);
                                                    }}
                                                    className={`w-full text-left border-none flex items-center justify-between px-2 py-1 text-[10px] font-bold cursor-pointer transition-colors duration-200 focus:outline-none ${activeService === service.type
                                                        ? `text-white ${COLOR_CLASSES[cat.color]?.bg ?? ""}`
                                                        : `bg-transparent text-gray-600 hover:bg-gray-50/50`
                                                        }`}
                                                >
                                                    {service.type}
                                                    {activeService === service.type && (
                                                        <Check size={10} strokeWidth={3} />
                                                    )}
                                                </button>
                                            ))}
                                        </motion.div>
                                    )}
                                </AnimatePresence>
                            </div>
                        )}
                    </div>

                    <div className="mb-1">
                        {isTrendLoading ? (
                            <div className="space-y-1">
                                {/* <Skeleton width={100} height={28} variant="rectangular" /> */}
                                {/* <Skeleton width={80} height={12} variant="rectangular" /> */}
                            </div>
                        ) : (
                            <>
                                <div className="text-2xl font-bold text-gray-900"></div>
                            </>
                        )}
                    </div>
                    {miniChartJsx}
                </div>
                <div className="px-4 py-2 bg-gray-50/50 flex justify-between items-center border-t border-gray-100">
                    <button
                        onClick={() => setIsFullscreen(true)}
                        title="Open fullscreen"
                        className="flex items-center gap-1 text-gray-400 hover:text-[var(--button-bg)] transition-colors cursor-pointer"
                    >
                        <Maximize2 size={11} strokeWidth={2.5} />
                    </button>
                    <Link to={cat.path}>
                        <button className="text-[var(--button-bg)] text-[10px] cursor-pointer font-bold flex items-center gap-1 hover:opacity-80 transition-opacity">
                            View <ArrowRight size={10} strokeWidth={3} />
                        </button>
                    </Link>
                </div>
            </div>

            {isFullscreen && (
                <FullscreenChartModal
                    title={`${cat.title} Cost Trend`}
                    subtitle={fsActiveService}
                    onClose={() => setIsFullscreen(false)}
                >
                    {/* Single-select service dropdown inside fullscreen */}
                    {cat.services.length > 1 && (
                        <div className="flex items-center gap-3 mb-5">
                            <span className="text-xs font-semibold text-gray-700">Service:</span>
                            <div className="relative" ref={fsDropdownRef}>
                                <button
                                    onClick={() => setIsFsDropdownOpen((v) => !v)}
                                    className="flex items-center gap-2 px-3.5 py-1.5 rounded-lg border-[1.5px] border-[#E0E4EF] bg-white cursor-pointer text-xs font-semibold text-gray-700"
                                >
                                    <span className={`w-2 h-2 rounded-full inline-block ${COLOR_CLASSES[fsColor]?.bg ?? ""}`} />
                                    <span>{fsActiveService}</span>
                                    <ChevronDown size={13} className={`text-[#9098b1] transition-transform duration-200 ${isFsDropdownOpen ? "rotate-180" : ""}`} />
                                </button>
                                <AnimatePresence>
                                    {isFsDropdownOpen && (
                                        <motion.div
                                            initial={{ opacity: 0, y: -8, scale: 0.96 }}
                                            animate={{ opacity: 1, y: 6, scale: 1 }}
                                            exit={{ opacity: 0, y: -8, scale: 0.96 }}
                                            transition={{ duration: 0.15, ease: "easeOut" }}
                                            className="absolute top-full left-0 z-[100] min-w-40 bg-white rounded-[10px] border border-[#E0E4EF] shadow-[0_8px_32px_rgba(0,0,0,0.12)] overflow-hidden"
                                        >
                                            {cat.services.map((service) => {
                                                const isActive = fsActiveService === service.type;
                                                return (
                                                    <button
                                                        type="button"
                                                        key={service.type}
                                                        onClick={() => {
                                                            setFsActiveService(service.type);
                                                            setIsFsDropdownOpen(false);
                                                        }}
                                                        className={`w-full text-left border-none flex items-center gap-2.5 px-3.5 py-2 cursor-pointer transition-colors focus:outline-none ${isActive
                                                            ? COLOR_CLASSES[serviceColors[service.type]]?.tint ?? ""
                                                            : "bg-transparent hover:bg-gray-50"}`}
                                                    >
                                                        <span className={`w-2 h-2 rounded-full shrink-0 ${COLOR_CLASSES[serviceColors[service.type]]?.bg ?? ""}`} />
                                                        <span className="text-xs font-semibold text-gray-700 flex-1">{service.type}</span>
                                                        {isActive && <Check size={12} strokeWidth={3} color={serviceColors[service.type]} />}
                                                    </button>
                                                );
                                            })}
                                        </motion.div>
                                    )}
                                </AnimatePresence>
                            </div>
                        </div>
                    )}
                    {fullscreenChartJsx}
                </FullscreenChartModal>
            )}
        </>
    );
};

export const CostCategories = () => {
    return (
        <section className="w-full">
            <div className="mb-4">
                <span className="alters-header-title font-medium">Cost categories</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 2xl:grid-cols-5 gap-4 w-full">
                {categories.map((cat) => (
                    <CategoryCard key={cat.title} cat={cat} />
                ))}
            </div>
        </section>
    );
};
