import { Clock, ChevronLeft, ChevronRight } from "lucide-react";
import { memo, useMemo, useState } from "react";

export const Alerts = memo(({ alters }) => {
    const [currentPage, setCurrentPage] = useState(1);
    const itemsPerPage = 2;
    const totalPages = useMemo(() => Math.ceil(alters.length / itemsPerPage), [alters.length]);

    const startIndex = (currentPage - 1) * itemsPerPage;
    const currentItems = useMemo(() => alters.slice(startIndex, startIndex + itemsPerPage), [alters, startIndex]);

    return (
        <section className="alters" aria-label="alters-container">
            <div className=" bg-white ring-[.5px] ring-black/10 px-3 py-3 rounded-md flex flex-col shadow-[0_2px_4px_rgba(0,0,0,0.01)]">
                <div className="alters-header flex items-center justify-between mb-2">
                    <span className="alters-header-title font-bold text-xs text-[var(--text-primary-color)] uppercase tracking-wider">(Account Name) cloud spend — this month</span>
                    {totalPages > 0 && (
                        <div className="flex items-center gap-1 bg-black/3 px-1.5 py-0.5 rounded-md ring-1 ring-black/10">
                            <button
                                onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                                disabled={currentPage === 1}
                                className="p-0.5 rounded-sm hover:bg-white cursor-pointer disabled:opacity-50 hover:shadow-sm disabled:cursor-not-allowed disabled:hover:bg-transparent disabled:hover:shadow-none transition-all"
                            >
                                <ChevronLeft size={14} className="text-black" />
                            </button>
                            <div className="w-[.5px] bg-black/20 h-4"></div>
                            <button
                                onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
                                disabled={currentPage === totalPages}
                                className="p-0.5 rounded-sm hover:bg-white cursor-pointer disabled:opacity-50 hover:shadow-sm disabled:cursor-not-allowed disabled:hover:bg-transparent disabled:hover:shadow-none transition-all"
                            >
                                <ChevronRight size={14} className="text-black" />
                            </button>
                        </div>
                    )}
                </div>
                <div className="flex-1 flex flex-col gap-1.5">
                    {currentItems.length > 0 ? (
                        currentItems.map((alter) => (
                            <div key={alter.id || alter.description} className="alters-item shadow-xs flex items-center gap-3 bg-white border-[.5px] border-black/20 px-3 py-1.5 rounded-md">
                                <div className="alters-item-icon flex items-center justify-center shrink-0 size-6 bg-red-300/50 text-red-600 ring-[.5px] ring-red-400/50 rounded">
                                    <Clock size={14} className="fill-red-300/50 text-red-500" strokeWidth={2} />
                                </div>
                                <div className="flex flex-col min-w-0">
                                    <span className="alters-item-description text-black/80 text-[10px] leading-tight truncate">{alter.description}</span>
                                </div>
                            </div>
                        ))
                    ) : (
                        <div className="flex-1 flex items-center justify-center border-2 border-dashed border-black/5 rounded">
                            <span className="text-black/30 text-xs font-medium italic">No active alerts</span>
                        </div>
                    )}
                </div>
            </div>
        </section > 
    );
});
