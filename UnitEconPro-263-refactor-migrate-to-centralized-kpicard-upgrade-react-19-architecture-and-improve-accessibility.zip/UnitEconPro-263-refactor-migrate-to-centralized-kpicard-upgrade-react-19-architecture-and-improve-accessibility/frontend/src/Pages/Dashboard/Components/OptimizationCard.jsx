import { Card, CardContent, CardTitle } from "../../../components/ui/card";
import { Lightbulb } from "lucide-react";
import { cn } from "../../../lib/cn";
import { motion } from "framer-motion";

const opportunities = [
    {
        category: "COMPUTE",
        value: "$195",
        actions: "3 actions identified",
        description: "Fix EKS autoscaler thresholds - biggest lever",
        color: "border-orange-300",
        textColor: "text-orange-500",
        bgHover: "hover:bg-orange-50/30"
    },
    {
        category: "STORAGE",
        value: "$90",
        actions: "3 actions identified",
        description: "Investigate S3 egress anomaly · urgent",
        color: "border-blue-300",
        textColor: "text-blue-500",
        bgHover: "hover:bg-blue-50/30"
    },
    {
        category: "DATABASE",
        value: "$14",
        actions: "2 actions identified",
        description: "Switch DynamoDB to provisioned capacity",
        color: "border-purple-300",
        textColor: "text-purple-500",
        bgHover: "hover:bg-purple-50/30"
    },
    {
        category: "NETWORKING",
        value: "$23",
        actions: "3 actions identified",
        description: "Set CloudWatch log retention policies",
        color: "border-emerald-300",
        textColor: "text-emerald-500",
        bgHover: "hover:bg-emerald-50/30"
    }
];
const OptimizationCard = () => {
    return (
        <Card className="w-full ring-1 ring-black/10 shadow-[var(--shadow)] rounded-[var(--card-border-radius)] overflow-hidden p-0 gap-0 max-w-none bg-[var(--accent-1)]">
            <div className="flex flex-row items-center justify-between px-3 py-2 bg-white border-b border-slate-200">
                <div className="flex items-center gap-2.5">
                    <div className="bg-emerald-200 p-1.5 rounded-sm">
                        <Lightbulb className="w-4 h-4 text-emerald-600 fill-emerald-600/10" />
                    </div>
                    <CardTitle className="text-sm font-bold text-[#1D1D1F]">
                        Optimization Opportunities — All Services
                    </CardTitle>
                </div>
                <div className="flex items-center gap-3">
                    <span className="text-xs text-neutral-500 font-medium">Total potential this month:</span>
                    <div className="bg-green-200 text-green-700 px-2.5 py-1 text-xs font-bold rounded-full ring-1 ring-green-300">
                        $322 /mo
                    </div>
                </div>
            </div>
            <CardContent className="px-3 py-1.5 pb-2.5 block w-full mt-1">
                <div className="grid grid-cols-1 md:grid-cols-4 w-full gap-2">
                    {opportunities.map((opt, index) => (
                        <motion.div
                            key={opt.category}
                            transition={{ type: "spring", stiffness: 300 }}
                            className={cn(
                                "flex flex-col p-3 gap-4 transition-all hover:-translate-y-1 duration-200 cursor-default bg-white border-1 border-black/20 rounded-md"
                            )}
                        >
                            <span className={cn("text-sm font-extrabold")}>
                                {opt.category}
                            </span>
                            <div className="flex flex-col gap-2">
                                <span className={cn("text-2xl font-medium leading-none", opt.textColor)}>
                                    {opt.value} <span className={cn("text-[12px] text-neutral-600/80", opt.textColor)}>/mo</span>
                                </span>
                                <span className="text-[10px] text-neutral-600/80 font-medium">
                                    {opt.actions}
                                </span>
                            </div>
                            <div className="mt-auto border-t border-black/20 pt-2 w-full ">
                                <p className="text-[10px] text-[var(--text-secondary-color)] text-balance md:text-wrap">
                                    {opt.description}
                                </p>
                            </div>
                        </motion.div>
                    ))}
                </div>
            </CardContent>
        </Card>
    );
};

export default OptimizationCard;

