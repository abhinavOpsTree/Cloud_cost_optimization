// Cleanup: removed the commented-out Run Rate card feature along with everything
// that existed only to serve it — the run-rate useMemo (trend sorting, moving
// averages, prev-month pro-rata comparison), the daily/monthly mode state,
// periodDays/formatMoney helpers, and their now-unused imports (dayjs, useFilters,
// extra lucide icons, IconRegistry). The three live KPI cards are unchanged.
import { memo, useMemo } from "react";
import {
    ArrowUpRight,
    ArrowDownRight,
    DollarSign,
} from "lucide-react";
import { useDashboard } from "../../../hooks/useDashboard";
import IconDisplay from "../../../common/IconDisplay";

import { KpiCard } from "../../../components/common/KpiCard";

// Perf: memo'd for the same reason as KPICard.
const MultiKPICard = memo(({ kpis, isLoading, isError }) => {
    if (isLoading || isError) {
        return (
            <div className="flex flex-col justify-center h-full p-4 animate-pulse bg-white ring-[.5px] ring-black/10 rounded-md min-h-[140px]">
                <div className="flex items-center justify-between py-3 border-b border-black/5">
                    <div className="flex flex-col gap-1.5">
                        <div className="w-16 h-3 bg-black/10 rounded" />
                        <div className="w-12 h-6 bg-black/10 rounded" />
                    </div>
                    <div className="w-8 h-8 rounded-full bg-black/10" />
                </div>
                <div className="flex items-center justify-between py-3">
                    <div className="flex flex-col gap-1.5">
                        <div className="w-16 h-3 bg-black/10 rounded" />
                        <div className="w-12 h-6 bg-black/10 rounded" />
                    </div>
                    <div className="w-8 h-8 rounded-full bg-black/10" />
                </div>
            </div>
        );
    }

    return (
        <div className="flex flex-col shadow-[var(--shadow)] justify-center h-full px-4 py-2 min-h-[140px] bg-white rounded-md ring-[.5px] ring-black/10 hover:shadow-sm transition-all duration-200">
            {kpis.map((kpi, idx) => (
                <div
                    key={kpi?.key || idx}
                    className={`flex items-center justify-between py-3 ${idx === 0 ? "border-b border-black/5" : ""}`}
                >
                    <div className="flex flex-col">
                        <span className="text-[10px] font-medium text-[var(--text-primary-color)] uppercase">
                            {kpi?.key?.replace(/_/g, " ")}
                        </span>
                        <span className="text-2xl font-bold text-[var(--text-primary-color)]">
                            {kpi?.value ?? 0}
                        </span>
                    </div>
                    <IconDisplay icon={kpi?.icon} background={kpi?.background} />
                </div>
            ))}
        </div>
    );
});

const RunRate = () => {
    const {
        summary,
        isSummaryLoading,
        isSummaryError,
    } = useDashboard();

    // Perf: kpi objects (and the multi-card array) are memoized so the memo'd
    // cards above receive referentially stable props and skip re-rendering
    // unless the summary data actually changes.
    const { totalCostKpi, AvgCost, multiKpis } = useMemo(() => {
        const findKpiValue = (key) => {
            if (Array.isArray(summary)) {
                return summary.find(c => c.key === key)?.value ?? 0;
            }
            return summary?.[key] ?? 0;
        };

        return {
            totalCostKpi: {
                key: "total_cost",
                value: findKpiValue("total_cost"),
                background: "bg-green-300/20"
            },
            AvgCost: {
                key: "Avg_cost",
                value: findKpiValue("avg_daily_cost"),
                background: "bg-green-300/20"
            },
            multiKpis: [
                {
                    key: "active_services",
                    value: findKpiValue("active_services"),
                    background: "bg-red-300/20"
                },
                {
                    key: "active_regions",
                    value: findKpiValue("active_regions"),
                    background: "bg-yellow-300/20"
                },
            ],
        };
    }, [summary]);

    // ── Loading skeleton ──────────────────────────────────────────────────
    // Perf: gate only on the summary query — it is the sole data source for the
    // cards below, so there is no reason to keep showing skeletons while the
    // slower trend/comparison queries (used by other dashboard widgets) finish.
    if (isSummaryLoading || !summary) {
        return (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                {/* Skeleton for Run Rate card */}
                <div className="flex flex-col justify-between h-full p-4 animate-pulse bg-white ring-[.5px] ring-black/10 rounded-md min-h-[140px] shadow-[var(--shadow)]">
                    <div className="flex items-center justify-between mb-4">
                        <div className="w-24 h-4 bg-black/10 rounded" />
                        <div className="w-8 h-8 rounded-md bg-black/10" />
                    </div>
                    <div className="mb-2">
                        <div className="w-32 h-8 bg-black/10 rounded" />
                    </div>
                    <div className="flex items-center gap-2 pt-3 border-t border-black/5 mt-auto">
                        <div className="w-36 h-3 bg-black/10 rounded" />
                    </div>
                </div>
                {/* Skeleton for KPI card */}
                <div className="flex flex-col justify-between h-full p-4 animate-pulse bg-white ring-[.5px] ring-black/10 rounded-md min-h-[140px] shadow-[var(--shadow)]">
                    <div className="flex items-center justify-between mb-4">
                        <div className="w-24 h-4 bg-black/10 rounded" />
                    </div>
                    <div className="mb-2">
                        <div className="w-32 h-8 bg-black/10 rounded" />
                    </div>
                    <div className="flex items-center gap-2 pt-3 border-t border-black/5 mt-auto">
                        <div className="w-16 h-3 bg-black/10 rounded" />
                    </div>
                </div>
                {/* Skeleton for MultiKPI card */}
                <div className="flex flex-col justify-center h-full p-4 animate-pulse bg-white ring-[.5px] ring-black/10 rounded-md min-h-[140px] shadow-[var(--shadow)]">
                    <div className="flex items-center justify-between py-3 border-b border-black/5">
                        <div className="flex flex-col gap-1.5">
                            <div className="w-16 h-3 bg-black/10 rounded" />
                            <div className="w-12 h-6 bg-black/10 rounded" />
                        </div>
                    </div>
                    <div className="flex items-center justify-between py-3">
                        <div className="flex flex-col gap-1.5">
                            <div className="w-16 h-3 bg-black/10 rounded" />
                            <div className="w-12 h-6 bg-black/10 rounded" />
                        </div>
                    </div>
                </div>
            </div>
        );
    }


    return (
        <div className="grid grid-cols-1 lg:grid-cols-3 items-center gap-4">
            {/* ── KPI Cards ─────────────────────────────────────────────── */}
            <KpiCard variant="dashboard" kpi={totalCostKpi} isLoading={isSummaryLoading || !summary} isError={isSummaryError} />
            <KpiCard variant="dashboard" kpi={AvgCost} isLoading={isSummaryLoading || !summary} isError={isSummaryError} />
            <MultiKPICard kpis={multiKpis} isLoading={isSummaryLoading || !summary} isError={isSummaryError} />
        </div>
    );
}

export default RunRate;
