import { useState, useMemo, useContext } from "react";
import { Loader } from "lucide-react";
import { AreaChart, Area, CartesianGrid, ResponsiveContainer, XAxis, YAxis, Tooltip, ReferenceLine } from "recharts";
import { useAnnotationDates } from "../../../hooks/useAnnotations";
import { AnnotationModal } from "../../../common/Charts/AnnotationModal";
import { FiltersContext } from "../../../context/FiltersContext";

// RESPONSIVENESS: Custom tick component to align first label to the left ('start')
// and last label to the right ('end') to prevent truncation or overlap with the Y-axis.
const CustomXAxisTick = (props) => {
    const { x, y, payload, index, visibleTicksCount } = props;

    let textAnchor = "middle";
    if (index === 0) {
        textAnchor = "start";
    } else if (index === visibleTicksCount - 1) {
        textAnchor = "end";
    }

    return (
        <text x={x} y={y} dy={10} fontSize={10} fill="#9ca3af" textAnchor={textAnchor}>
            {payload.value}
        </text>
    );
};

const Trendgraph = ({ data = [], loading, error, budget, avgCost }) => {
    const chartData = data.map(d => ({
        ...d,
        avgCost: avgCost,
        originalDate: d.date,
        date: new Date(d.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
    }));

    const dateRange = useMemo(() => {
        if (!data || data.length === 0) return { start: null, end: null };
        const dates = data.map(d => new Date(d.date).getTime()).filter(t => !isNaN(t));
        if (dates.length === 0) return { start: null, end: null };
        return {
            start: new Date(Math.min(...dates)).toISOString().split('T')[0],
            end: new Date(Math.max(...dates)).toISOString().split('T')[0]
        };
    }, [data]);

    const { filters } = useContext(FiltersContext);
    const activeAccount = filters?.account || 'All';

    const { annotationDates } = useAnnotationDates(activeAccount, 'All', dateRange.start, dateRange.end);

    const annotatedDatesSet = useMemo(() => {
        return new Set(annotationDates.map(a => a.event_date));
    }, [annotationDates]);

    const [isModalOpen, setIsModalOpen] = useState(false);
    const [selectedDate, setSelectedDate] = useState(null);
    const [hiddenSeries, setHiddenSeries] = useState({ current: false, avg: false, annotations: false });

    const toggleSeries = (key) => {
        setHiddenSeries(prev => ({ ...prev, [key]: !prev[key] }));
    };

    const CustomDot = (props) => {
        const { cx, cy, payload } = props;
        if (!payload || !payload.originalDate || hiddenSeries.annotations) return null;

        try {
            const dateStr = new Date(payload.originalDate).toISOString().split('T')[0];
            if (annotatedDatesSet.has(dateStr)) {
                return (
                    <circle
                        cx={cx}
                        cy={cy}
                        r={4.5}
                        fill="#f97316"
                        stroke="#fff"
                        strokeWidth={1.5}
                        style={{ cursor: 'pointer', zIndex: 10, pointerEvents: 'auto' }}
                        onClick={(e) => {
                            e.preventDefault();
                            e.stopPropagation();
                            setSelectedDate(dateStr);
                            setIsModalOpen(true);
                        }}
                    />
                );
            }
        } catch (e) {
            return null;
        }
        return null;
    };

    const handleDotClick = (...args) => {
        let payload = null;
        args.forEach(arg => {
            if (arg && arg.payload) payload = arg.payload;
            else if (arg && arg.originalDate) payload = arg;
        });

        if (payload && payload.originalDate) {
            try {
                const dateStr = new Date(payload.originalDate).toISOString().split('T')[0];
                setSelectedDate(dateStr);
                setIsModalOpen(true);
            } catch (error) {
                console.error("Invalid date", error);
            }
        }
    };

    const handleChartClick = (e) => {
        if (e && e.activePayload && e.activePayload.length > 0) {
            const clickedData = e.activePayload[0].payload;
            if (clickedData && clickedData.originalDate) {
                try {
                    const dateStr = new Date(clickedData.originalDate).toISOString().split('T')[0];
                    setSelectedDate(dateStr);
                    setIsModalOpen(true);
                } catch (error) {
                    console.error("Invalid date", error);
                }
            }
        } else if (e && e.activeLabel) {
            const matchingData = chartData.find(d => d.date === e.activeLabel);
            if (matchingData && matchingData.originalDate) {
                try {
                    const dateStr = new Date(matchingData.originalDate).toISOString().split('T')[0];
                    setSelectedDate(dateStr);
                    setIsModalOpen(true);
                } catch (error) {
                    console.error("Invalid date", error);
                }
            }
        }
    };

    const intervalVal = Math.max(0, Math.ceil(chartData.length / 15) - 1);

    if (loading) {
        return (
            <div className="flex flex-col items-center justify-center h-64 bg-white rounded-xl ring-1 ring-black/5 shadow-sm">
                <Loader className="animate-spin text-blue-500 mb-2" size={24} />
                <span className="text-xs font-medium text-gray-400 uppercase tracking-widest">Loading trends...</span>
            </div>
        );
    }

    if (error) {
        return (
            <div className="flex flex-col items-center justify-center h-64 bg-white rounded-xl ring-1 ring-black/5 shadow-sm text-red-500">
                <p className="text-sm font-bold">Error fetching trend data</p>
                <button onClick={() => window.location.reload()} className="mt-2 text-xs underline cursor-pointer">Retry</button>
            </div>
        );
    }

    return (
        <section className="w-full bg-white p-4 rounded-xl ring-[.5px] ring-black/10 shadow-[var(--shadow)]">
            <div className="flex items-start justify-between mb-6">
                <span className="text-s font-bold text-[var(--text-primary-color)] capitalize">Cost Trends</span>
            </div>

            {/* RESPONSIVENESS: Wrapper to support horizontal scroll on mobile devices */}
            <div className="w-full overflow-x-auto pb-2">
                {/* RESPONSIVENESS: Establish min-width to ensure chart remains legible on smaller viewports */}
                <div className="w-full min-w-[600px] h-40">
                    <ResponsiveContainer width="100%" height="100%">
                        <AreaChart
                            data={chartData}
                            margin={{ top: 10, right: 10, left: -20, bottom: 0 }}
                            onClick={handleChartClick}
                        >
                            <defs>
                                <linearGradient id="colorCost" x1="0" y1="0" x2="0" y2="1">
                                    <stop offset="5%" stopColor="#3b82f6" stopOpacity={0.1} />
                                    <stop offset="95%" stopColor="#3b82f6" stopOpacity={0} />
                                </linearGradient>
                                <linearGradient id="colorAvgCost" x1="0" y1="0" x2="0" y2="1">
                                    <stop offset="5%" stopColor="#ed80f5ff" stopOpacity={0.2} />
                                    <stop offset="95%" stopColor="#ed80f5ff" stopOpacity={0} />
                                </linearGradient>
                            </defs>
                            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                            {/* RESPONSIVENESS: Zero padding extends line to Y-axis; CustomXAxisTick handles label alignment */}
                            <XAxis
                                dataKey="date"
                                axisLine={false}
                                tickLine={false}
                                tick={<CustomXAxisTick />}
                                interval={intervalVal}
                                padding={{ left: 0, right: 0 }}
                            />
                            <YAxis
                                axisLine={false}
                                tickLine={false}
                                tick={{ fontSize: 10, fill: "#9ca3af" }}
                                tickFormatter={(val) => `$${val}`}
                            />
                            <Tooltip
                                contentStyle={{
                                    fontSize: '12px',
                                    borderRadius: '8px',
                                    border: '1px solid rgba(0,0,0,0.1)',
                                    padding: '12px',
                                    backgroundColor: "rgba(209,213,219,0.15)",
                                }}
                                formatter={(value) => [
                                    <span style={{ color: "#3b82f6" }}>${value.toLocaleString()}</span>,
                                    ""
                                ]}
                            />

                            {!hiddenSeries.avg && avgCost !== undefined && avgCost !== null && (
                                <>
                                    <ReferenceLine
                                        y={avgCost}
                                        stroke="#ed80f5ff"
                                        strokeDasharray="3 3"
                                    />
                                    <Area
                                        type="monotone"
                                        dataKey="avgCost"
                                        stroke="none"
                                        fillOpacity={1}
                                        fill="url(#colorAvgCost)"
                                        animationDuration={1500}
                                        activeDot={false}
                                        tooltipType="none"
                                    />
                                </>
                            )}

                            {!hiddenSeries.current && (
                                <Area
                                    type="monotone"
                                    dataKey="cost"
                                    name="Current Period"
                                    stroke="#3b82f6"
                                    strokeWidth={1.5}
                                    fillOpacity={1}
                                    fill="url(#colorCost)"
                                    dot={<CustomDot />}
                                    activeDot={{ r: 5, fill: "#3b82f6", onClick: handleDotClick, style: { cursor: 'pointer', pointerEvents: 'auto' } }}
                                />
                            )}
                        </AreaChart>
                    </ResponsiveContainer>
                </div>
            </div>

            <div className="flex items-center gap-6 mt-4 pt-4 border-t border-gray-50">
                <div className="flex items-center justify-between w-full">
                    <div className="flex items-center gap-6">
                        <button 
                            type="button"
                            className={`flex items-center gap-2 cursor-pointer transition-all hover:opacity-80 bg-transparent border-none p-0 ${hiddenSeries.current ? 'opacity-40 grayscale' : ''}`}
                            onClick={() => toggleSeries('current')}
                        >
                            <div className="w-2 h-2 rounded-full bg-blue-500"></div>
                            <span className="text-[11px] font-medium text-gray-400">Current Period</span>
                        </button>
                        <button 
                            type="button"
                            className={`flex items-center gap-2 cursor-pointer transition-all hover:opacity-80 bg-transparent border-none p-0 ${hiddenSeries.avg ? 'opacity-40 grayscale' : ''}`}
                            onClick={() => toggleSeries('avg')}
                        >
                            <div className="w-2 h-2 rounded-full bg-[#ed80f5ff]"></div>
                            <span className="text-[11px] font-medium text-gray-400">
                                Avg Cost {avgCost !== undefined && avgCost !== null ? `($${Number(avgCost).toLocaleString(undefined, { maximumFractionDigits: 2 })})` : ''}
                            </span>
                        </button>
                    </div>
                    <button 
                        type="button"
                        className={`flex items-center gap-2 cursor-pointer transition-all hover:opacity-80 bg-transparent border-none p-0 ${hiddenSeries.annotations ? 'opacity-40 grayscale' : ''}`}
                        onClick={() => toggleSeries('annotations')}
                    >
                        <div className="w-2 h-2 rounded-full bg-orange-500"></div>
                        <span className="text-[11px] font-medium text-gray-400">Annotations</span>
                    </button>
                </div>
            </div>

            <AnnotationModal
                isOpen={isModalOpen}
                onClose={() => setIsModalOpen(false)}
                date={selectedDate}
                account_name={activeAccount}
                service="All"
            />
        </section>
    );
};

export default Trendgraph;
