import { toast } from "react-toastify";
import { apiRequest } from "../../lib/apiClient";
import { API_ENDPOINTS } from "../../APIs/ApiEndPoint";
import { buildQueryParams } from "../../lib/BuildQueryParams";

export const getDashboardSummary = async (filters) => {
    const query = buildQueryParams(filters)
    return apiRequest({ endpoint: `${API_ENDPOINTS.dashboardSummary}?${query}` });
};

export const getDashboardForecast = async (filters) => {
    const query = buildQueryParams(filters)
    return apiRequest({ endpoint: `${API_ENDPOINTS.dashboardForecast}?${query}` });
};

export const getDashboardTrend = async (filters) => {
    const query = buildQueryParams(filters)
    return apiRequest({ endpoint: `${API_ENDPOINTS.dashboardTrend}?${query}` });
};

export const getComparison = async (filter) => {
    const query = buildQueryParams(filter)
    return apiRequest({ endpoint: `${API_ENDPOINTS.dashboardComparison}?${query}` });
}

export const getBreakdownAccount = async (filter) => {
    const query = buildQueryParams(filter)
    return apiRequest({ endpoint: `${API_ENDPOINTS.dashboardBreakdownAccount}?${query}` });
}

export const getBreakdownService = async (filter) => {
    const query = buildQueryParams(filter)
    return apiRequest({ endpoint: `${API_ENDPOINTS.dashboardBreakdownService}?${query}` });
}

export const getForecastBudget = async (accountName) => {
    return apiRequest({ endpoint: API_ENDPOINTS.getForecastbudget(accountName) });
};

export const getBudgetBudget = async (accountName) => {
    try {
        const data = await apiRequest({ endpoint: API_ENDPOINTS.getBudgetStatus(accountName) });
        return data?.account || data;
    } catch (err) {
        // 404 = no budget configured for this account — prompt the user instead of surfacing a raw error
        if (String(err?.message || "").startsWith("HTTP 404")) {
            toast.info(`No budget set for "${accountName}". Please set a budget for this account.`, {
                toastId: `budget-not-set-${accountName}`,
            });
            return null;
        }
        throw err;
    }
}

