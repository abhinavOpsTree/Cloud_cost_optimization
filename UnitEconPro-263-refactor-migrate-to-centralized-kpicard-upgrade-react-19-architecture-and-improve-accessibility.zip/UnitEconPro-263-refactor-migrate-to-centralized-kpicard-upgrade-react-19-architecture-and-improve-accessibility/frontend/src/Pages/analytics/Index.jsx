
import { Header } from "./components/Header";

const Analytics = () => {

  return (
    <div className="w-full min-h-screen flex flex-col p-4 overflow-x-hidden">
      <Header />
    </div>
  );
}

export default Analytics;
