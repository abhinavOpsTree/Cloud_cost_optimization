import { useState } from "react";
import { ChevronDown, Check } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

const accounts = ["prod-payments", "prod-analytics", "staging-core", "dev-sandbox"];
const viewModes = ["Standard", "Business hours"];

export const Header = () => {
    const [selectedAccount, setSelectedAccount] = useState(accounts[0]);
    const [activeView, setActiveView] = useState(viewModes[0]);
    const [dropdownOpen, setDropdownOpen] = useState(false);

    return (
        <div className="w-full flex items-center justify-between mb-2 border-b border-black/20 pb-2 relative">
            <div className="flex items-center gap-4">
                <div className="relative">
                    <button
                        onClick={(e) => {
                            e.stopPropagation();
                            setDropdownOpen(!dropdownOpen);
                        }}
                        className="flex items-center w-fit gap-2 px-3 py-1 rounded bg-white border border-black/20 shadow-sm shadow-white  transition-all duration-200 cursor-pointer"
                    >
                        <span className="w-2 h-2 rounded-full bg-emerald-500 shadow-sm shadow-emerald-200" />
                        <span className="text-sm font-semibold text-black">{selectedAccount}</span>
                        <ChevronDown size={14} className={`text-neutral-400 transition-transform duration-200 ${dropdownOpen ? "rotate-180" : ""}`} />
                    </button>

                    <AnimatePresence>
                        {dropdownOpen && (
                            <motion.div
                                initial={{ opacity: 0, y: -10, scale: 0.95 }}
                                animate={{ opacity: 1, y: 4, scale: 1 }}
                                exit={{ opacity: 0, y: -10, scale: 0.95 }}
                                transition={{ duration: 0.15, ease: "easeOut" }}
                                className="absolute left-0 top-full z-50 min-w-48 bg-white shadow-[0_10px_40px_-10px_rgba(0,0,0,0.15)] border border-black/10 rounded overflow-hidden"
                            >
                                {accounts.map((account) => (
                                    <button
                                        type="button"
                                        key={account}
                                        onClick={(e) => {
                                            e.stopPropagation();
                                            setSelectedAccount(account);
                                            setDropdownOpen(false);
                                        }}
                                        className={`w-full flex items-center justify-between px-3 py-1.5 text-sm font-semibold cursor-pointer transition-colors duration-200 border-none focus:outline-none ${selectedAccount === account
                                                ? "bg-black text-white"
                                                : "text-neutral-600 hover:bg-neutral-50"
                                            }`}
                                    >
                                        <div className="flex items-center gap-2">
                                            <span className={`w-1.5 h-1.5 rounded-full ${selectedAccount === account ? "bg-emerald-400" : "bg-neutral-300"}`} />
                                            {account}
                                        </div>
                                        {selectedAccount === account && (
                                            <Check size={12} strokeWidth={3} />
                                        )}
                                    </button>
                                ))}
                            </motion.div>
                        )}
                    </AnimatePresence>
                </div>
                <div className="h-5 w-[1px] bg-neutral-200" />
                <div className="flex items-center gap-1 bg-[var(--accents-1)] border border-black/10 p-1 rounded-md">
                    {viewModes.map((mode) => (
                        <button
                            key={mode}
                            onClick={() => setActiveView(mode)}
                            className={`px-3 py-1 text-xs rounded-sm cursor-pointer transition-all ${activeView === mode
                                    ? "font-semibold text-black bg-blue-300 shadow-[var(--shadow)]"
                                    : "text-neutral-600 hover:text-neutral-700"
                                }`}
                        >
                            {mode}
                        </button>
                    ))}
                </div>
            </div>
        </div>
    );
};