import { useState, useEffect, useMemo } from "react";
import { splitSuggestionText } from "../../../lib/suggestionText";
import { AnimatePresence } from "framer-motion";
import { Filters } from "../../../common/Filters/Filter";
import PaginationControls from "../../../common/PaginationControls";
import Table from "../../../common/Table";
import CopyableCell from "../../../common/CopyableCell";
import { useVPC } from "../../../hooks/Networking/useVPC";
import { Linechart } from "../../../common/Charts/LazyLinechart";
import { useUnified } from "../../../hooks/useUnified";
import { Chips } from "../../../common/Chips";
import { RoundedPieChart } from "../../../common/Charts/LazyPiechart";
import { Activity, Box, DollarSign, Network, Zap, Globe, Server, Shield, Info } from "lucide-react";
import { CardSkeleton, KpiDropdownCard } from "../../../common/Cardoverview";
import { KpiCard } from "../../../components/common/KpiCard";
import VPCMetadataDrawer from "./VPCMetadataDrawer";
import { useSuggestions } from "../../../hooks/useSuggestions";
import { Link, useSearchParams } from "react-router-dom";
import { ForecastCardFinance } from "../../../common/MonthtoDate/LazyForecastCardFinance";

const VPC_SEARCH_KEYS = ["vpc_name", "vpc_id"];
const VPC_FILTER_CONFIGS = [
    { key: "account_name", label: "Account" },
    { key: "region", label: "Region" }
];
// Perf: fully static, so hoisted to module scope — stronger than useMemo (one
// allocation for the app's lifetime) and matches the consts above.
const BREAKDOWN_OPTIONS = [
    { label: "Account", value: "account" },
    { label: "Region", value: "region" },
    { label: "Usage Type", value: "usage-type" },
    { label: "Operation", value: "operation" },
    { label: "Pricing Model", value: "pricing-model" },
        { label: "Environment", value: "env" },
        { label: "Owner", value: "owner" },
        { label: "Project", value: "project" },
        { label: "Team", value: "team" },
        { label: "Application", value: "application" },
];

const VPC = () => {
    const [dimension, setDimension] = useState("region");
    const { vpcSummary, vpcPublicIP, vpcResources, isLoading, isError } = useVPC();
    const { suggestions: allSuggestions } = useSuggestions();
    const suggestions = (allSuggestions ?? []).filter(
        (s) => String(s.service).toLowerCase() === "vpc" && s.scope === "page"
    );
    const {
        trend,
        breakdown,
        isTrendLoading,
        isBreakdownLoading,
        isTrendError,
        isBreakdownError
    } = useUnified(dimension);

    const [selectedMetadataVPC, setSelectedMetadataVPC] = useState(null);
    const [searchParams] = useSearchParams();
    useEffect(() => {
        const resource = searchParams.get("resource");
        if (resource) setSelectedMetadataVPC({ vpc_id: resource });
    }, [searchParams]);

    // Perf: memoized so <Table actions={...}> gets a stable prop instead of a fresh
    // array every render; only a state setter inside, so empty deps are safe.
    const actions = useMemo(() => [
        {
            label: "Metadata",
            onClick: (row) => {
                setSelectedMetadataVPC(row);
            },
            icon: () => <Info size={16} color="#059669" className="cursor-pointer" />,
            tooltip: "View VPC Metadata"
        }
    ], []);

    // Perf: memoized so the KPI card list (including the dropdown groups) keeps a
    // stable identity between renders; recomputed only when the summary changes.
    const card = useMemo(() => [
        {
            title: "total_cost",
            value: vpcSummary?.total_cost,
            icon: <DollarSign size={16} className="text-green-500" />,
            icon2: <DollarSign size={16} className="text-green-600" />},

        {
            title: "avg_daily_cost",
            value: vpcSummary?.avg_daily_cost,
            icon: <Activity size={16} className="text-green-800" />,
            icon2: <DollarSign size={16} className="text-green-600" />},
        {
            title: "total_resources",
            value: vpcSummary?.total_resources},
        {
            title: "vpc_only_cost",
            value: vpcSummary?.vpc_only_cost,
            icon: <Activity size={16} className="text-green-800" />,
            icon2: <DollarSign size={16} className="text-green-600" />},

        // Dropdown Group
        {
            title: "costs",
            type: "dropdown",
            children: [
                {
                    title: "nat_gateway_cost",
                    value: vpcSummary?.costs?.nat_gateway_cost,
                    icon: <DollarSign size={16} className="text-orange-600" />},
                {
                    title: "public_ip_cost",
                    value: vpcSummary?.costs?.public_ip_cost,
                    icon: <DollarSign size={16} className="text-red-500" />},
                {
                    title: "vpc_endpoint_cost",
                    value: vpcSummary?.costs?.vpc_endpoint_cost,
                    icon: <DollarSign size={16} className="text-cyan-500" />},
                {
                    title: "total_nat_cost",
                    value: vpcSummary?.costs?.total_nat_cost,
                    icon: <DollarSign size={16} className="text-orange-400" />},
                {
                    title: "total_vpc_cost",
                    value: vpcSummary?.costs?.total_vpc_cost,
                    icon: <DollarSign size={16} className="text-blue-400" />},
            ]},

        // Resources Dropdown Group
        {
            title: "resources",
            type: "dropdown",
            children: [
                {
                    title: "network_interfaces",
                    value: vpcSummary?.resources?.network_interfaces},
                {
                    title: "elastic_ips",
                    value: vpcSummary?.resources?.elastic_ips},
                {
                    title: "nat_gateways",
                    value: vpcSummary?.resources?.nat_gateways},
                {
                    title: "vpc_endpoints",
                    value: vpcSummary?.resources?.vpc_endpoints},
                {
                    title: "vpn_connections",
                    value: vpcSummary?.resources?.vpn_connections},
            ]},
    ], [vpcSummary]);

    // Perf: memoized so <Table columns={...}> gets a stable prop; render closures
    // only use a module-level component, so empty deps are safe.
    const columns = useMemo(() => [
        {
            key: "vpc_id",
            label: "VPC ID",
            render: (value) => <CopyableCell value={value} />
        },
        {
            key: "vpc_name",
            label: "VPC Name",
            render: (value) => <CopyableCell value={value} />
        },
        { key: "region", label: "Region" },
        { key: "account_name", label: "Account" },
        { key: "total_cost", label: "Total Cost", sortable: true, showTotal: true },
    ], [])

    const [filteredList, setFilteredList] = useState(null);
    const [currentPage, setCurrentPage] = useState(1);
    const rowsPerPage = 10;
    const safeRows = rowsPerPage || 10

    const vpcResourcesData = useMemo(() => Array.isArray(vpcResources) ? vpcResources : [], [vpcResources]);
    const displayData = filteredList !== null ? filteredList : vpcResourcesData;

    const totalPages = Math.ceil(displayData.length / safeRows);

    const safePage = Math.max(currentPage, 1)

    const paginatedData = displayData.slice(
        (safePage - 1) * safeRows,
        safePage * safeRows
    )

    return (
        <div className="flex flex-col space-y-2 p-2">
            <div className="w-full">
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-2 w-full">
                    {isLoading
                        ? Array.from({ length: 9 }).map((_, i) => (
                            <CardSkeleton key={i} />
                        ))
                        : card.map((kpi) => {
                            if (kpi.type === "dropdown") {
                                return <KpiDropdownCard key={kpi.title} kpi={kpi} />;
                            }
                            return <KpiCard key={kpi.title} kpi={kpi} />;
                        })
                    }
                    {isError && (
                        <div className="flex items-center justify-center h-full col-span-full py-10">
                            <span className="text-destructive font-semibold">Error loading data</span>
                        </div>
                    )}
                </div>
            </div>
            <div className="py-1">
                <div className="flex justify-between items-center mb-2.5">
                    <p className="text-sm font-bold uppercase text-[var(--text-primary-color)]">Suggestions</p>
                    <Link to="/recommendation">
                        <button className="text-xs font-bold text-indigo-600 hover:text-indigo-800 transition-colors cursor-pointer bg-transparent border-0 p-0">View all</button>
                    </Link>
                </div>
                {suggestions.length > 0 ? (
                    <div className="space-y-2.5">
                        {suggestions.slice(0, 1).map((item) => {
                            const { title, desc } = splitSuggestionText(item.text);
                            return (
                                <div key={item.id} className="bg-white ring-1 ring-black/10 rounded-lg p-3">
                                    <p className="text-xs font-bold text-gray-900 leading-snug">{title}</p>
                                    {desc && <p className="text-[11px] text-gray-500 mt-1 leading-relaxed whitespace-pre-line">{desc}</p>}
                                    <div className="flex items-center gap-1.5 mt-2 text-[10px] text-gray-400 font-medium">
                                        <span>By {item.created_by || "User"}</span>
                                        <span>·</span>
                                        <span>{new Date(item.created_at).toLocaleDateString()}</span>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                ) : (
                    <div className="flex flex-col items-center justify-center py-12 text-center bg-gray-100 border border-dashed border-gray-200 rounded-xl">
                        <span className="text-xs text-[var(--text-secondary-color)] font-medium">No recommendations found.</span>
                    </div>
                )}
            </div>
            <ForecastCardFinance category="networking" service="vpc" trend={trend} isTrendLoading={isTrendLoading} />

            <Linechart 
                avgCost={vpcSummary?.avg_daily_cost} 
                chartdata={trend} 
                name="cost" 
                service="AmazonVPC"
                isLoading={isTrendLoading} 
                isError={isTrendError} 
            />

            <div className="w-full flex flex-col gap-2 items-center justify-between space-y-4 w-full">
                <div className="mt-4 flex gap-4 flex-col w-full ">
                    <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wider px-1">Breakdown By</h3>
                    <Chips
                        options={BREAKDOWN_OPTIONS}
                        selected={dimension}
                        onSelect={setDimension}
                    />
                </div>
                <div className="flex w-full gap-4">
                    <div className="w-1/2">
                        <RoundedPieChart
                            title={`${BREAKDOWN_OPTIONS.find(o => o.value === dimension)?.label} Breakdown`}
                            dataKey="cost"
                            nameKey="name"
                            chartData={breakdown}
                            isError={isBreakdownError}
                            isLoading={isBreakdownLoading}
                        />
                    </div>
                    <div className="flex flex-col space-y-4 w-1/2">
                        <RoundedPieChart
                            title="Public IPv4 Costs (Idle vs In-Use)"
                            dataKey="cost"
                            nameKey="name"
                            chartData={vpcPublicIP}
                            isError={isError}
                            isLoading={isLoading}
                        />
                    </div>
                </div>
            </div>

            <div className="w-full space-y-4">
                <h3 className="text-lg font-semibold mb-2">Top 50 VPC Resources</h3>
                <Filters 
                    data={vpcResourcesData} 
                    onFilter={(filtered) => {
                        setFilteredList(filtered);
                        setCurrentPage(1);
                    }} 
                    searchKeys={VPC_SEARCH_KEYS}
                    filterConfigs={VPC_FILTER_CONFIGS}
                    placeholder="Search by VPC name, ID..."
                />
                <Table columns={columns} data={paginatedData} actions={actions} isLoading={isLoading} isFiltered={filteredList !== null} />
            </div>
            <PaginationControls currentPage={currentPage} totalPages={totalPages} onPageChange={setCurrentPage} />

            <AnimatePresence>
                {selectedMetadataVPC && (
                    <VPCMetadataDrawer
                        vpc={selectedMetadataVPC}
                        onClose={() => setSelectedMetadataVPC(null)}
                    />
                )}
            </AnimatePresence>
        </div>
    );
};

export default VPC;