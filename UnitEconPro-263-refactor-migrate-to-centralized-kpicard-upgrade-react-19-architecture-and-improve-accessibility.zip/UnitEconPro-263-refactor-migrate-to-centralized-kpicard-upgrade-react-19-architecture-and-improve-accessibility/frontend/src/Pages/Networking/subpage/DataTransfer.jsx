import { useState, useMemo } from "react";
import PaginationControls from "../../../common/PaginationControls";
import Table from "../../../common/Table";
import CopyableCell from "../../../common/CopyableCell";
import { Linechart } from "../../../common/Charts/LazyLinechart";
import { useUnified } from "../../../hooks/useUnified";
import { Chips } from "../../../common/Chips";
import { RoundedPieChart } from "../../../common/Charts/LazyPiechart";
import { useDataTransfer } from "../../../hooks/Networking/useDataTransfer";
import { Activity, DollarSign, Zap, Box } from "lucide-react";
import { CardSkeleton } from "../../../common/Cardoverview";
import { KpiCard } from "../../../components/common/KpiCard";
import { ForecastCardFinance } from "../../../common/MonthtoDate/LazyForecastCardFinance";

// Perf: fully static, so hoisted to module scope — stronger than useMemo (one
// allocation for the app's lifetime).
const BREAKDOWN_OPTIONS = [
    { label: "Region", value: "region" },
    { label: "Account", value: "account" },
    { label: "Usage Type", value: "usage-type" },
    {
        label: "direction",
        value: "direction"
    },
    {
        label: "service",
        value: "service"
    },
    {
        label: "inter-region",
        value: "inter-region"
    },
        { label: "Environment", value: "env" },
        { label: "Owner", value: "owner" },
        { label: "Project", value: "project" },
        { label: "Team", value: "team" },
        { label: "Application", value: "application" },
];

const DataTransfer = () => {
    const [dimension, setDimension] = useState("region");
    const { summary, topResources, isLoading, isError } = useDataTransfer();
    const {
        trend,
        breakdown,
        isTrendLoading,
        isBreakdownLoading,
        isTrendError,
        isBreakdownError
    } = useUnified(dimension);
    // Perf: memoized so the KPI card list keeps a stable identity between renders;
    // recomputed only when the summary data actually changes.
    const card = useMemo(() => [
        { title: "total_cost", value: summary?.total_cost, icon: <DollarSign size={16} className="text-green-500" />, icon2: <DollarSign size={16} className="text-green-600" /> },
        { title: "avg_daily_cost", value: summary?.avg_daily_cost, icon: <Activity size={16} className="text-green-800" />, icon2: <DollarSign size={16} className="text-green-600" /> },
        { title: "total_tb", value: summary?.total_tb, icon: <Box size={16} className="text-blue-500" /> },
        { title: "unique_resources", value: summary?.unique_resources, icon: <Zap size={16} className="text-orange-500" />, icon2: <DollarSign size={16} className="text-green-600" /> },
    ], [summary])

    // Perf: memoized so <Table columns={...}> gets a stable prop; render closure
    // only does pure string ops plus a module-level component, so empty deps are safe.
    const columns = useMemo(() => [
        {
            key: "resource_id",
            label: "Resource ID",
            render: (value) => {
                let displayValue = value;
                if (typeof value === "string" && value.includes(":")) {
                    displayValue = value.split(":").pop();
                }
                return <CopyableCell value={displayValue} />;
            }
        },
        { key: "service", label: "Service" },
        { key: "region", label: "Region" },
        { key: "account", label: "Account" },
        { key: "total_gb", label: "Data (GB)", sortable: true },
        { key: "usage_type", label: "Usage Type" },
        { key: "total_cost", label: "Total Cost", sortable: true, showTotal: true },
    ], [])

    const [currentPage, setCurrentPage] = useState(1);
    const [selectedRegion, setSelectedRegion] = useState("All");
    const [selectedAccount, setSelectedAccount] = useState("All");
    
    const rowsPerPage = 10;
    const safeRows = rowsPerPage || 10

    const rawData = Array.isArray(topResources) ? topResources : []
    
    const uniqueRegions = ["All", ...new Set(rawData.map(item => item.region).filter(Boolean))];
    const uniqueAccounts = ["All", ...new Set(rawData.map(item => item.account).filter(Boolean))];

    const filteredData = rawData.filter(item => {
        const matchesRegion = selectedRegion === "All" || item.region === selectedRegion;
        const matchesAccount = selectedAccount === "All" || item.account === selectedAccount;
        return matchesRegion && matchesAccount;
    });

    const totalPages = Math.ceil(filteredData.length / safeRows);
    const safePage = Math.max(currentPage, 1)

    const paginatedData = filteredData.slice(
        (safePage - 1) * safeRows,
        safePage * safeRows
    )


    return (
        <div className="flex flex-col space-y-2 p-2">
            <div className="w-full">
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-2 w-full">
                    {isLoading
                        ? Array.from({ length: 5 }).map((_, i) => (
                            <CardSkeleton key={i} />
                        ))
                        : card.map((kpi) => (
                            <KpiCard key={kpi.title} kpi={kpi} />
                        ))
                    }
                    {isError && (
                        <div className="flex items-center justify-center h-full col-span-full py-10">
                            <span className="text-destructive font-semibold">Error loading data</span>
                        </div>
                    )}
                </div>
            </div>
            <ForecastCardFinance category="networking" service="data-transfer" trend={trend} isTrendLoading={isTrendLoading} />

            <Linechart 
                avgCost={summary?.avg_daily_cost} 
                chartdata={trend} 
                name="cost" 
                service="DataTransfer"
                isLoading={isTrendLoading} 
                isError={isTrendError} 
            />

            <div className="w-full flex flex-col space-y-2 mb-4">
                <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wider px-1">Breakdown By</h3>
                <Chips
                    options={BREAKDOWN_OPTIONS}
                    selected={dimension}
                    onSelect={setDimension}
                />
            </div>

            <RoundedPieChart
                title={`${BREAKDOWN_OPTIONS.find(o => o.value === dimension)?.label} Breakdown`}
                dataKey="cost"
                nameKey="name"
                chartData={breakdown}
                isError={isBreakdownError}
                isLoading={isBreakdownLoading}
            />

            <div className="w-full mt-4 bg-white rounded-md p-4 ring-[.5px] ring-black/10 shadow-[var(--shadow)]">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-4">
                    <h3 className="text-lg font-bold text-neutral-800">Top 50 Data Transfer Resources</h3>
                    <div className="flex flex-wrap items-center gap-4">
                        <div className="flex items-center gap-2">
                            <span className="text-xs font-bold text-neutral-500 uppercase tracking-wider">Region:</span>
                            <select
                                value={selectedRegion}
                                onChange={(e) => {
                                    setSelectedRegion(e.target.value);
                                    setCurrentPage(1);
                                }}
                                className="appearance-none text-xs font-semibold text-neutral-700 bg-neutral-50 border border-neutral-200 rounded-md px-3 py-1.5 pr-8 cursor-pointer hover:border-neutral-400 focus:outline-none focus:ring-1 focus:ring-neutral-300 transition-all relative"
                                style={{ backgroundImage: "url(\"data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 12 12' fill='none' stroke='%23888' stroke-width='1.5' stroke-linecap='round' stroke-linejoin='round'><path d='M2 4l4 4 4-4'/></svg>\")", backgroundPosition: "right 8px center", backgroundSize: "12px", backgroundRepeat: "no-repeat" }}
                            >
                                {uniqueRegions.map(region => (
                                    <option key={region} value={region}>{region}</option>
                                ))}
                            </select>
                        </div>
                        <div className="flex items-center gap-2">
                            <span className="text-xs font-bold text-neutral-500 uppercase tracking-wider">Account:</span>
                            <select
                                value={selectedAccount}
                                onChange={(e) => {
                                    setSelectedAccount(e.target.value);
                                    setCurrentPage(1);
                                }}
                                className="appearance-none text-xs font-semibold text-neutral-700 bg-neutral-50 border border-neutral-200 rounded-md px-3 py-1.5 pr-8 cursor-pointer hover:border-neutral-400 focus:outline-none focus:ring-1 focus:ring-neutral-300 transition-all relative"
                                style={{ backgroundImage: "url(\"data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 12 12' fill='none' stroke='%23888' stroke-width='1.5' stroke-linecap='round' stroke-linejoin='round'><path d='M2 4l4 4 4-4'/></svg>\")", backgroundPosition: "right 8px center", backgroundSize: "12px", backgroundRepeat: "no-repeat" }}
                            >
                                {uniqueAccounts.map(acc => (
                                    <option key={acc} value={acc}>{acc}</option>
                                ))}
                            </select>
                        </div>
                    </div>
                </div>
                <Table columns={columns} data={paginatedData} isLoading={isLoading} />
            </div>
            <PaginationControls currentPage={currentPage} totalPages={totalPages} onPageChange={setCurrentPage} />
        </div>
    );
};

export default DataTransfer;
