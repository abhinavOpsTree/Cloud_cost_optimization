import { KpiCard } from "../../../components/common/KpiCard";
import { useState, useMemo } from "react";
import { splitSuggestionText } from "../../../lib/suggestionText";
import { useVPC } from "../../../hooks/Networking/useVPC";
import PaginationControls from "../../../common/PaginationControls";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { useSuggestions } from "../../../hooks/useSuggestions";
import AddSuggestionModal from "../../../common/AddSuggestionModal";
import FinOpsFlagsContainer from "../../../common/FinOpsFlagsContainer";
import {
    X, Network, Tag, CheckCircle2, DollarSign, Activity, Pencil,
     Zap, Info,
} from "lucide-react";

// ─────────────────────────────────────────────
// Design primitives
// ─────────────────────────────────────────────

const MONO = "font-mono";
const TAGS_PER_PAGE = 10;

const SectionLabel = ({ children }) => (
    <p className="text-sm font-bold uppercase text-[var(--text-primary-color)] mb-2.5">{children}</p>
);

const MetaRow = ({ label, value, mono, bold, color }) => (
    <div className="flex justify-between items-center py-1.5 border-b border-slate-200 text-xs last:border-0 gap-3">
        <span className="text-gray-500 shrink-0">{label}</span>
        <span className={`text-right break-all ${mono ? `${MONO} text-[11px] text-blue-700` : ""} ${bold ? "font-semibold" : ""} ${color || "text-gray-900"}`}>
            {value ?? "—"}
        </span>
    </div>
);



const Badge = ({ children, variant }) => {
    const cls = {
        success: "bg-emerald-50 text-emerald-800 border-emerald-200",
        warning: "bg-amber-50 text-amber-800 border-amber-200",
        danger: "bg-red-50 text-red-800 border-red-200",
        info: "bg-blue-50 text-blue-800 border-blue-200",
        purple: "bg-purple-50 text-purple-800 border-purple-200",
    }[variant] || "bg-gray-100 text-gray-700 border-gray-200";
    return (
        <span className={`inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded border ${cls}`}>
            {variant === "success" && <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block" />}
            {children}
        </span>
    );
};

// ─────────────────────────────────────────────
// FinOps & NAT Components
// ─────────────────────────────────────────────


const NatGatewayCard = ({ gw }) => (
    <div className="bg-white border border-gray-200/60 rounded-xl overflow-hidden mb-3">
        <div className="flex items-center justify-between px-3.5 py-2.5 border-b border-slate-200 bg-gray-100/50">
            <span className={`${MONO} text-[11px] font-semibold text-blue-800`}>{gw.nat_gateway_id}</span>
            <Badge variant={gw.state === "available" ? "success" : "warning"}>{gw.state || "-"}</Badge>
        </div>
        <div className="px-3.5 py-1.5">
            <MetaRow label="Subnet ID" value={gw.subnet_id} mono />
            <MetaRow label="Availability Zone" value={gw.availability_zone} />
            <MetaRow label="Connectivity Type" value={gw.connectivity_type} />
            <MetaRow label="Elastic IP" value={gw.elastic_ip_address} />
            <MetaRow label="Age" value={gw.age_days != null ? `${gw.age_days} days` : "-"} />
            <MetaRow label="Active ENI Count" value={gw.subnet_active_eni_count ?? "-"} />
        </div>
    </div>
);

const EIPRow = ({ eip }) => (
    <div className="flex items-center gap-3 px-3.5 py-2.5 bg-white border border-gray-200/60 rounded-xl mb-2">
        <Zap size={14} className="text-amber-500 shrink-0" />
        <div className="min-w-0 flex-1">
            <div className="text-xs font-bold text-gray-900">{eip.public_ip}</div>
            <div className={`text-[10px] text-gray-500 ${MONO} truncate mt-0.5`}>{eip.allocation_id}</div>
        </div>
        <Badge variant={eip.is_attached ? "success" : "warning"}>
            {eip.is_attached ? "Attached" : "Unattached"}
        </Badge>
    </div>
);

// ─────────────────────────────────────────────
// Tab Components
// ─────────────────────────────────────────────

const OverviewTab = ({ data, vpcId, arch }) => (
    <div className="space-y-6">
        <div className="grid grid-cols-1 gap-7">
            <div>
                <SectionLabel>Identity & Location</SectionLabel>
                <MetaRow label="VPC ID" value={vpcId} mono />
                <MetaRow label="VPC Name" value={data.vpc_name} bold />
                <MetaRow label="Account ID" value={data.account_id} mono />
                <MetaRow label="Account Name" value={data.account_name} bold />
                <MetaRow label="Region" value={data.region} />
            </div>
            
            <div>
                <SectionLabel>Architecture</SectionLabel>
                <MetaRow label="Default VPC" value={arch.is_default_vpc ? "Yes" : "No"} />
                <MetaRow label="Total Subnets" value={arch.subnet_count ?? "—"} bold />
                <MetaRow label="Public Subnets" value={arch.public_subnet_count ?? "—"} />
                <MetaRow label="Private Subnets" value={arch.private_subnet_count ?? "—"} />
                <MetaRow label="Isolated Subnets" value={arch.isolated_subnet_count ?? "—"} />
                <MetaRow label="NAT Gateways" value={arch.nat_gateway_count ?? "—"} bold />
                <MetaRow label="Active NAT Gateways" value={arch.active_nat_gateway_count ?? "—"} />
                <MetaRow label="VPC Endpoint Count" value={arch.vpc_endpoint_count ?? "—"} />
            </div>

            <div>
                <SectionLabel>Features & Connectivity</SectionLabel>
                <MetaRow label="Internet Gateway" value={arch.has_internet_gateway ? "Yes" : "No"} color={arch.has_internet_gateway ? "text-emerald-700 font-semibold" : "text-amber-700 font-semibold"} />
                <MetaRow label="S3 Gateway Endpoint" value={arch.has_s3_gateway_endpoint ? "Yes" : "No"} color={arch.has_s3_gateway_endpoint ? "text-emerald-700 font-semibold" : "text-amber-700 font-semibold"} />
                <MetaRow label="DynamoDB Gateway Endpoint" value={arch.has_dynamodb_gateway_endpoint ? "Yes" : "No"} color={arch.has_dynamodb_gateway_endpoint ? "text-emerald-700 font-semibold" : "text-amber-700 font-semibold"} />
                <MetaRow label="VPC Flow Logs Enabled" value={arch.flow_logs_enabled ? "Yes" : "No"} color={arch.flow_logs_enabled ? "text-emerald-700 font-semibold" : "text-amber-700 font-semibold"} />
            </div>
        </div>
    </div>
);

const CostFinOpsTab = ({ totalCost, natHourlyCost, natDataCost, eipCost, finopsFlags, savings, onSuggest }) => (
    <div className="space-y-6">
        <div>
            <SectionLabel>Cost Breakdown (30d)</SectionLabel>
            <MetaRow label="NAT Gateway Hourly" value={`$${natHourlyCost.toFixed(2)}`} />
            <MetaRow label="NAT Data Processing" value={`$${natDataCost.toFixed(2)}`} />
            <MetaRow label="Elastic IP" value={`$${eipCost.toFixed(2)}`} />
            <MetaRow label="Total VPC Cost" value={`$${totalCost.toFixed(2)}`} bold color="text-emerald-700" />
        </div>

        {(finopsFlags.length > 0 || savings > 0) && (
            <div>
                <SectionLabel>Optimization & Savings</SectionLabel>
                {savings > 0 && (
                    <button
                        type="button"
                        onClick={() => onSuggest(`Estimated monthly savings: $${Number(savings).toFixed(2)}`)}
                        title="Click to add as suggestion"
                        className="w-full text-left mb-4 bg-emerald-50 border border-emerald-200/60 rounded-lg px-4 py-3 flex items-center gap-3 cursor-pointer hover:border-emerald-400 transition-colors focus:outline-none">
                        <Activity size={18} className="text-emerald-600 shrink-0" />
                        <div>
                            <p className="text-[10px] font-bold text-emerald-800 uppercase">Estimated Monthly Savings</p>
                            <p className="text-xl font-black text-emerald-700">${savings.toFixed(2)}</p>
                        </div>
                    </button>
                )}
                <FinOpsFlagsContainer flags={finopsFlags} onSuggest={onSuggest} />
            </div>
        )}
    </div>
);

const NatEipsTab = ({ natGws, eips }) => (
    <div className="space-y-6">
        {natGws.length > 0 && (
            <div>
                <SectionLabel>NAT Gateways ({natGws.length})</SectionLabel>
                <div className="space-y-1">
                    {natGws.map((gw) => (
                        <NatGatewayCard key={gw.nat_gateway_id} gw={gw} />
                    ))}
                </div>
            </div>
        )}

        {eips.length > 0 && (
            <div>
                <SectionLabel>Elastic IPs ({eips.length})</SectionLabel>
                <div className="space-y-1">
                    {eips.map((eip) => (
                        <EIPRow key={eip.allocation_id} eip={eip} />
                    ))}
                </div>
            </div>
        )}
        
        {natGws.length === 0 && eips.length === 0 && (
            <div className="text-center py-6 bg-white rounded-2xl border border-dashed border-gray-200">
                <span className="text-xs text-gray-400">No NAT Gateways or Elastic IPs found</span>
            </div>
        )}
    </div>
);

const TagsTab = ({ tagsPage, setTagsPage, tagsTotalPages, tagEntries, paginatedTags }) => (
    <div className="space-y-6">
        <div>
            <SectionLabel>Tags ({tagEntries.length})</SectionLabel>
            {paginatedTags.length > 0 ? (
                <div className="space-y-1.5">
                    {paginatedTags.map(([k, v]) => (
                        <div key={k} className="flex overflow-hidden border border-slate-200 rounded-lg">
                            <div className={`px-3.5 py-2.5 bg-white min-w-[140px] border-r border-slate-200 ${MONO} text-xs text-blue-700`}>{k}</div>
                            <div className="px-3.5 py-2.5 text-xs text-gray-900">{String(v)}</div>
                        </div>
                    ))}
                </div>
            ) : (
                <div className="text-center py-6 bg-white rounded-2xl border border-dashed border-gray-200">
                    <span className="text-xs text-gray-400">No resource tags available</span>
                </div>
            )}
            {tagEntries.length > TAGS_PER_PAGE && (
                <PaginationControls currentPage={tagsPage} totalPages={tagsTotalPages} onPageChange={setTagsPage} />
            )}
        </div>
    </div>
);

// ─────────────────────────────────────────────
// Main Drawer
// ─────────────────────────────────────────────

const TABS = [
    { id: "overview", label: "Overview", icon: Info },
    { id: "cost_finops", label: "Cost & FinOps", icon: DollarSign },
    { id: "nat_eips", label: "NAT & EIPs", icon: Activity },
    { id: "tags", label: "Tags", icon: Tag },
];

const VPCMetadataDrawer = ({ vpc, onClose }) => {
    const [activeTab, setActiveTab] = useState("overview");
    const [tagsPage, setTagsPage] = useState(1);
    const [isSugOpen, setIsSugOpen] = useState(false);
    const [sugPrefill, setSugPrefill] = useState("");
    const openSuggestion = (text = "") => {
        setSugPrefill(text);
        setIsSugOpen(true);
    };

    const { suggestions } = useSuggestions();

    const vpcId = vpc?.vpc_id || "";
    const { metadata: apiData, isMetadataLoading: isLoading } = useVPC(vpcId);
    
    const data = { ...vpc, ...(Array.isArray(apiData) ? apiData[0] : apiData) };

    const resourceSuggestions = useMemo(() => {
        return (suggestions || []).filter(item =>
            String(item.service).toLowerCase() === "vpc" &&
            item.scope === "resource" &&
            String(item.resource_id).toLowerCase() === String(vpcId).toLowerCase()
        );
    }, [suggestions, vpcId]);

    const financials = data.financials || {};
    const arch = data.architecture || {};
    const natGws = data.nat_gateways || [];
    const eips = data.elastic_ips || [];
    const tags = data.tags || {};
    const finopsFlags = data.finops_flags || [];
    const savings = Number(data.estimated_savings_potential || 0);

    const totalCost = Number(financials.total_vpc_cost || data.total_cost || 0);
    const natHourlyCost = Number(financials.nat_hourly_cost || 0);
    const natDataCost = Number(financials.nat_data_processing_cost || 0);
    const eipCost = Number(financials.eip_cost || 0);

    const tagEntries = useMemo(() => (data.tags ? Object.entries(data.tags) : []), [data.tags]);
    const tagsTotalPages = Math.max(1, Math.ceil(tagEntries.length / TAGS_PER_PAGE));
    const paginatedTags = tagEntries.slice((tagsPage - 1) * TAGS_PER_PAGE, tagsPage * TAGS_PER_PAGE);
    const [prevVpcId, setPrevVpcId] = useState(vpcId);
    if (vpcId !== prevVpcId) {
        setPrevVpcId(vpcId);
        setTagsPage(1);
        setActiveTab("overview");
    }

    if (!vpc) return null;

    const kpis = [
        { label: "Total Cost", value: `$${totalCost.toFixed(2)}`, unit: "/mo", sub: "30d trailing" },
        { label: "NAT Gateways", value: arch.nat_gateway_count ?? "—", unit: "", sub: "total count" },
        { label: "Elastic IPs", value: eips.length ?? "—", unit: "", sub: "total count" },
        { label: "Savings", value: savings > 0 ? `$${savings.toFixed(2)}` : "$0.00", unit: "/mo", sub: "potential" },
    ];

    return (
        <>
            <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.3 }}
                className="fixed inset-0 z-[999] bg-black/20 backdrop-blur-[1px] h-full cursor-pointer" 
                onClick={onClose} 
            />
            <motion.div 
                initial={{ x: "100%" }}
                animate={{ x: 0 }}
                exit={{ x: "100%" }}
                transition={{ type: "tween", duration: 0.3 }}
                className="fixed right-0 top-0 h-screen w-[70%] max-w-full bg-white shadow-[-8px_0_32px_rgba(0,0,0,0.12)] z-[9999] border-l border-gray-100 flex flex-col"
            >
                
                {/* ── Header ── */}
                <div className="px-6 py-4 border-b border-slate-200 shrink-0 bg-white">
                    <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3.5">
                            <div className="w-9 h-9 rounded-lg bg-[#8C4FFF] flex items-center justify-center shrink-0 ">
                                <Network size={18} className="text-white" />
                            </div>
                            <div>
                                <div className="flex items-center gap-1.5 flex-wrap mb-0.5">
                                    <span className={`${MONO} text-[13px] font-semibold text-[var(--text-primary-color)] tracking-tight`}>
                                        {data.vpc_name || vpcId}
                                    </span>
                                    {arch.is_default_vpc
                                        ? <Badge variant="info">Default VPC</Badge>
                                        : <Badge variant="default">Custom VPC</Badge>
                                    }
                                </div>
                                <p className="text-xs text-[var(--text-secondary-color)]">
                                    {vpcId}
                                </p>
                            </div>
                        </div>
                        <div className="flex items-center gap-2">
                            <motion.button
                                whileHover={{ scale: 1.02 }}
                                whileTap={{ scale: 0.98 }}
                                onClick={() => openSuggestion("")}
                                className="flex items-center justify-center gap-2 px-4 py-2 bg-[var(--button-bg)] text-white text-xs font-bold rounded-lg  hover:bg-[var(--button-bg)]/90 transition-all cursor-pointer uppercase tracking-wider shrink-0 mr-1"
                            >
                                <Pencil size={14} />
                                Add Suggestion
                            </motion.button>
                            <button
                                className="w-7 h-7 rounded border border-slate-200 flex items-center justify-center text-gray-400 hover:bg-white hover:text-gray-700 transition-colors cursor-pointer"
                                onClick={onClose}
                            >
                                <X size={14} />
                            </button>
                        </div>
                    </div>
                </div>

                {/* ── KPI strip ── */}
                {isLoading ? (
                    <div className="grid grid-cols-4 gap-2 px-6 py-3 border-b border-slate-200 shrink-0">
                        {Array.from({ length: 4 }).map((_, i) => (
                            <div key={i} className="h-14 bg-gray-100 rounded-lg animate-pulse" />
                        ))}
                    </div>
                ) : (
                    <div className="grid grid-cols-4 gap-2 px-6 py-3 border-b border-slate-200 shrink-0">
                        {kpis.map((k) => <KpiCard variant="compact" key={k.label} {...k} />)}
                    </div>
                )}

                <div className="px-6 py-1">
                    {resourceSuggestions && resourceSuggestions.length > 0 && (
                        <div className="">
                            <div className="flex justify-between items-center">
                                <SectionLabel>Suggestions</SectionLabel>
                                <Link to="/recommendation">
                                    <button className="text-xs font-bold text-indigo-600 hover:text-indigo-800 transition-colors cursor-pointer">
                                        View all
                                    </button>
                                </Link>
                            </div>
                            <div className="space-y-2.5">
                                {resourceSuggestions.slice(0, 1).map((item) => {
                                    const { title, desc } = splitSuggestionText(item.text);
                                    return (
                                        <div key={item.id} className="bg-white/50 border border-slate-200 rounded-lg p-3">
                                            <p className="text-xs font-bold text-gray-900 leading-snug">{title}</p>
                                            {desc && <p className="text-[11px] text-gray-500 mt-1 leading-relaxed whitespace-pre-line">{desc}</p>}
                                            <div className="flex items-center gap-1.5 mt-2 text-[10px] text-gray-400 font-medium">
                                                <span>By {item.created_by || "User"}</span>
                                                <span>·</span>
                                                <span>{new Date(item.created_at).toLocaleDateString()}</span>
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>
                        </div>
                    )}
                </div>

                {/* ── Tab bar ── */}
                <div className="flex border-b border-slate-200 px-6 mt-2.5 shrink-0 gap-0.5 overflow-x-auto scrollbar-none">
                    {TABS.map((t) => {
                        const Icon = t.icon;
                        const isActive = activeTab === t.id;
                        return (
                            <button
                                key={t.id}
                                onClick={() => setActiveTab(t.id)}
                                className={`flex items-center gap-1.5 px-3.5 py-2.5 text-xs whitespace-nowrap border-b-2 transition-colors cursor-pointer -mb-px ${isActive
                                    ? "border-[var(--button-bg)] font-semibold text-[var(--button-bg)]"
                                    : "border-transparent text-gray-500 hover:text-gray-900 font-normal"
                                    }`}
                            >
                                <Icon size={13} />
                                {t.label}
                                {t.id === "tags" && Object.keys(tags || {}).length > 0 && (
                                    <span className="ml-0.5 text-[9px] font-bold px-1.5 py-0.5 rounded-full bg-gray-100 text-gray-500">
                                        {Object.keys(tags).length}
                                    </span>
                                )}
                            </button>
                        );
                    })}
                </div>

                {/* ── Tab content ── */}
                <div className="flex-1 overflow-y-auto px-6 py-5">
                    {isLoading ? (
                        <div className="flex items-center justify-center py-16">
                            <div className="w-6 h-6 border-2 border-[var(--button-bg)] border-t-transparent rounded-full animate-spin mr-3" />
                            <span className="text-sm text-gray-500">Fetching VPC details...</span>
                        </div>
                    ) : (
                        <div className="pb-8">
                            {activeTab === "overview" && <OverviewTab data={data} vpcId={vpcId} arch={arch} />}
                            {activeTab === "cost_finops" && <CostFinOpsTab totalCost={totalCost} natHourlyCost={natHourlyCost} natDataCost={natDataCost} eipCost={eipCost} finopsFlags={finopsFlags} savings={savings} onSuggest={openSuggestion} />}
                            {activeTab === "nat_eips" && <NatEipsTab natGws={natGws} eips={eips} />}
                            {activeTab === "tags" && <TagsTab tagsPage={tagsPage} setTagsPage={setTagsPage} tagsTotalPages={tagsTotalPages} tagEntries={tagEntries} paginatedTags={paginatedTags} />}

                            {/* ── Footer ── */}
                            <div className="pt-6 mt-6 border-t border-gray-100 text-center">
                                <div className="inline-flex items-center gap-2 px-3 py-1 bg-gray-100 rounded-full">
                                    <CheckCircle2 size={12} className="text-emerald-500" />
                                    <span className="text-[10px] font-medium text-gray-500 uppercase tracking-tight">
                                        Last Synced: {data.metadata_last_synced || "-"}
                                    </span>
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            </motion.div>
            
            <AddSuggestionModal
                isOpen={isSugOpen}
                onClose={() => setIsSugOpen(false)}
                service="vpc"
                scope="resource"
                resourceId={vpcId}
                resourceName={data.vpc_name || vpcId}
                initialText={sugPrefill}
            />
        </>
    );
};

export default VPCMetadataDrawer;


