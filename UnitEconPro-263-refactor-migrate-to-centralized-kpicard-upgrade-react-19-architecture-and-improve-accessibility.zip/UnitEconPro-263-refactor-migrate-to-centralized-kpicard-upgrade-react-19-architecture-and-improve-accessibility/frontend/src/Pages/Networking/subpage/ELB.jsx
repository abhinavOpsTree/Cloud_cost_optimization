import { useState, useEffect, useMemo } from "react";
import { splitSuggestionText } from "../../../lib/suggestionText";
import { AnimatePresence } from "framer-motion";
import { Filters } from "../../../common/Filters/Filter";
import PaginationControls from "../../../common/PaginationControls";
import Table from "../../../common/Table";
import CopyableCell from "../../../common/CopyableCell";
import { useELB } from "../../../hooks/Networking/useELB";
import { Linechart } from "../../../common/Charts/LazyLinechart";
import { useUnified } from "../../../hooks/useUnified";
import { Chips } from "../../../common/Chips";
import { RoundedPieChart } from "../../../common/Charts/LazyPiechart";
import { Activity, DollarSign, Zap, Network, Shield, Info } from "lucide-react";
import { CardSkeleton } from "../../../common/Cardoverview";
import { KpiCard } from "../../../components/common/KpiCard";
import ELBMetadataDrawer from "./ELBMetadataDrawer";
import { useSuggestions } from "../../../hooks/useSuggestions";
import { Link, useSearchParams } from "react-router-dom";
import { ForecastCardFinance } from "../../../common/MonthtoDate/LazyForecastCardFinance";

const ELB_SEARCH_KEYS = ["load_balancer_name", "load_balancer_type"];
const ELB_FILTER_CONFIGS = [
    { key: "account_name", label: "Account" },
    { key: "region", label: "Region" },
    { key: "load_balancer_type", label: "Type" }
];
// Perf: fully static, so hoisted to module scope — stronger than useMemo (one
// allocation for the app's lifetime) and matches the consts above.
const BREAKDOWN_OPTIONS = [
    { label: "Region", value: "region" },
    { label: "Account", value: "account" },
    { label: "Usage Type", value: "usage-type" },
    { label: "Family", value: "family" },
        { label: "Environment", value: "env" },
        { label: "Owner", value: "owner" },
        { label: "Project", value: "project" },
        { label: "Team", value: "team" },
        { label: "Application", value: "application" },
];

const ELB = () => {
    const [dimension, setDimension] = useState("region");
    const { elbSummary, elbLoadBalancers, elbIdleLoadBalancers, isLoading, isError } = useELB();
    const { suggestions: allSuggestions } = useSuggestions();
    const suggestions = (allSuggestions ?? []).filter(
        (s) => String(s.service).toLowerCase() === "elb" && s.scope === "page"
    );
    const {
        trend,
        breakdown,
        isTrendLoading,
        isBreakdownLoading,
        isTrendError,
        isBreakdownError
    } = useUnified(dimension);

    const [selectedMetadataLB, setSelectedMetadataLB] = useState(null);
    const [searchParams] = useSearchParams();
    useEffect(() => {
        const resource = searchParams.get("resource");
        if (resource) setSelectedMetadataLB({ load_balancer_arn: resource });
    }, [searchParams]);

    // Perf: memoized so <Table actions={...}> gets a stable prop instead of a fresh
    // array every render; only a state setter inside, so empty deps are safe.
    const actions = useMemo(() => [
        {
            label: "Metadata",
            onClick: (row) => {
                setSelectedMetadataLB(row);
            },
            icon: () => <Info size={16} color="#059669" className="cursor-pointer" />,
            tooltip: "View Load Balancer Metadata"
        }
    ], []);

    // Perf: memoized so the KPI card list keeps a stable identity between renders;
    // recomputed only when the summary data actually changes.
    const card = useMemo(() => [
        { title: "total_cost", value: elbSummary?.total_cost, icon: <DollarSign size={16} className="text-green-500" />, icon2: <DollarSign size={16} className="text-green-600" /> },
        { title: "avg_daily_cost", value: elbSummary?.avg_daily_cost, icon: <Activity size={16} className="text-green-800" />, icon2: <DollarSign size={16} className="text-green-600" /> },
        { title: "total_lbs", value: elbSummary?.total_lbs, icon: <Zap size={16} className="text-blue-500" /> },
        { title: "idle_lbs", value: elbSummary?.idle_lbs, icon: <Zap size={16} className="text-red-500" />, icon2: <DollarSign size={16} className="text-green-600" /> },
        { title: "classic_lbs", value: elbSummary?.classic_lbs, icon: <Zap size={16} className="text-amber-500" /> },
        { title: "alb_count", value: elbSummary?.alb_count, icon: <Network size={16} className="text-indigo-500" /> },
        { title: "nlb_count", value: elbSummary?.nlb_count, icon: <Network size={16} className="text-cyan-500" /> },
        { title: "gwlb_count", value: elbSummary?.gwlb_count, icon: <Network size={16} className="text-teal-500" /> },
        { title: "albs_without_waf", value: elbSummary?.albs_without_waf, icon: <Shield size={16} className="text-orange-500" /> },
    ], [elbSummary])

    // Perf: memoized so <Table columns={...}> gets a stable prop (shared by both the
    // main and idle-LB tables); render closure only uses a module-level component.
    const columns = useMemo(() => [
        {
            key: "load_balancer_name",
            label: "ELB Name",
            render: (value) => <CopyableCell value={value} />
        },
        { key: "load_balancer_type", label: "ELB Type" },
        { key: "region", label: "Region" },
        { key: "account_name", label: "Account" },
        { key: "total_cost", label: "Total Cost", sortable: true, showTotal: true },
    ], [])

    const [filteredList, setFilteredList] = useState(null);
    const [currentPage, setCurrentPage] = useState(1);
    const rowsPerPage = 10;
    const safeRows = rowsPerPage || 10

    const elbLoadBalancersData = useMemo(() => Array.isArray(elbLoadBalancers) ? elbLoadBalancers : [], [elbLoadBalancers]);
    const displayData = filteredList !== null ? filteredList : elbLoadBalancersData;

    const totalPages = Math.ceil(displayData.length / safeRows);

    const safePage = Math.max(currentPage, 1)

    const paginatedData = displayData.slice(
        (safePage - 1) * safeRows,
        safePage * safeRows
    )


    return (
        <div className="flex flex-col space-y-2 p-2">
            <div className="w-full">
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-2 w-full">
                    {isLoading
                        ? Array.from({ length: 9 }).map((_, i) => (
                            <CardSkeleton key={i} />
                        ))
                        : card.map((kpi) => (
                            <KpiCard key={kpi.title} kpi={kpi} />
                        ))
                    }
                    {isError && (
                        <div className="flex items-center justify-center h-full col-span-full py-10">
                            <span className="text-destructive font-semibold">Error loading data</span>
                        </div>
                    )}
                </div>
            </div>
            <div className="py-1">
                <div className="flex justify-between items-center mb-2.5">
                    <p className="text-sm font-bold uppercase text-[var(--text-primary-color)]">Suggestions</p>
                    <Link to="/recommendation">
                        <button className="text-xs font-bold text-indigo-600 hover:text-indigo-800 transition-colors cursor-pointer bg-transparent border-0 p-0">View all</button>
                    </Link>
                </div>
                {suggestions.length > 0 ? (
                    <div className="space-y-2.5">
                        {suggestions.slice(0, 1).map((item) => {
                            const { title, desc } = splitSuggestionText(item.text);
                            return (
                                <div key={item.id} className="bg-white ring-1 ring-black/10 rounded-lg p-3">
                                    <p className="text-xs font-bold text-gray-900 leading-snug">{title}</p>
                                    {desc && <p className="text-[11px] text-gray-500 mt-1 leading-relaxed whitespace-pre-line">{desc}</p>}
                                    <div className="flex items-center gap-1.5 mt-2 text-[10px] text-gray-400 font-medium">
                                        <span>By {item.created_by || "User"}</span>
                                        <span>·</span>
                                        <span>{new Date(item.created_at).toLocaleDateString()}</span>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                ) : (
                    <div className="flex flex-col items-center justify-center py-12 text-center bg-gray-100 border border-dashed border-gray-200 rounded-xl">
                        <span className="text-xs text-[var(--text-secondary-color)] font-medium">No recommendations found.</span>
                    </div>
                )}
            </div>
            <ForecastCardFinance category="networking" service="elb" trend={trend} isTrendLoading={isTrendLoading} />


            <Linechart 
                avgCost={elbSummary?.avg_daily_cost} 
                chartdata={trend} 
                name="cost" 
                service="AmazonELB"
                isLoading={isTrendLoading} 
                isError={isTrendError} 
            />

            <div className="w-full flex flex-col space-y-2 mb-4">
                <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wider px-1">Breakdown By</h3>
                <Chips
                    options={BREAKDOWN_OPTIONS}
                    selected={dimension}
                    onSelect={setDimension}
                />
            </div>

            <RoundedPieChart
                title={`${BREAKDOWN_OPTIONS.find(o => o.value === dimension)?.label} Breakdown`}
                dataKey="cost"
                nameKey="name"
                chartData={breakdown}
                isError={isBreakdownError}
                isLoading={isBreakdownLoading}
            />

            <div className="w-full space-y-4">
                <h3 className="text-lg font-semibold mb-2">Top 50 Load Balancers</h3>
                <Filters 
                    data={elbLoadBalancersData} 
                    onFilter={(filtered) => {
                        setFilteredList(filtered);
                        setCurrentPage(1);
                    }} 
                    searchKeys={ELB_SEARCH_KEYS}
                    filterConfigs={ELB_FILTER_CONFIGS}
                    placeholder="Search by Load Balancer name, type..."
                />
                <Table columns={columns} data={paginatedData} actions={actions} isLoading={isLoading} isFiltered={filteredList !== null} />
            </div>
            <PaginationControls currentPage={currentPage} totalPages={totalPages} onPageChange={setCurrentPage} />

            {elbIdleLoadBalancers && elbIdleLoadBalancers.length > 0 && (
                <div className="w-full mt-8">
                    <h3 className="text-lg font-semibold mb-2 text-warning">Idle Load Balancers (Potential Savings)</h3>
                    <Table columns={columns} data={elbIdleLoadBalancers} actions={actions} isLoading={isLoading} isFiltered={filteredList !== null} />
                </div>
            )}

            <AnimatePresence>
                {selectedMetadataLB && (
                    <ELBMetadataDrawer
                        key="elb-drawer"
                        loadBalancer={selectedMetadataLB}
                        onClose={() => setSelectedMetadataLB(null)}
                    />
                )}
            </AnimatePresence>
        </div>
    );
};

export default ELB;