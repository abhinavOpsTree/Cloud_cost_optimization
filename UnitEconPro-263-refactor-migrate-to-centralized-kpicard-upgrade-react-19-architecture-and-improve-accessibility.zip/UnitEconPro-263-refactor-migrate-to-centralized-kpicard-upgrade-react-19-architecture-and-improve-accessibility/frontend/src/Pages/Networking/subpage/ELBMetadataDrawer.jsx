import { KpiCard } from "../../../components/common/KpiCard";
import { useState, useMemo } from "react";
import { splitSuggestionText } from "../../../lib/suggestionText";
import { useELB } from "../../../hooks/Networking/useELB";
import PaginationControls from "../../../common/PaginationControls";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { useSuggestions } from "../../../hooks/useSuggestions";
import AddSuggestionModal from "../../../common/AddSuggestionModal";
import FinOpsFlagsContainer from "../../../common/FinOpsFlagsContainer";
import {
    X, Pencil, DollarSign, Activity, Tag, CheckCircle2,
    Info, Network
} from "lucide-react";

// ─────────────────────────────────────────────
// Design primitives
// ─────────────────────────────────────────────

const MONO = "font-mono";
const TAGS_PER_PAGE = 10;

const SectionLabel = ({ children }) => (
    <p className="text-sm font-bold uppercase text-[var(--text-primary-color)] mb-2.5">{children}</p>
);

const MetaRow = ({ label, value, mono, bold, color }) => (
    <div className="flex justify-between items-center py-1.5 border-b border-slate-200 text-xs last:border-0 gap-3">
        <span className="text-gray-500 shrink-0">{label}</span>
        <span className={`text-right break-all ${mono ? `${MONO} text-[11px] text-blue-700` : ""} ${bold ? "font-semibold" : ""} ${color || "text-gray-900"}`}>
            {value ?? "—"}
        </span>
    </div>
);



const Badge = ({ children, variant }) => {
    const cls = {
        success: "bg-emerald-50 text-emerald-800 border-emerald-200",
        warning: "bg-amber-50 text-amber-800 border-amber-200",
        danger: "bg-red-50 text-red-800 border-red-200",
        info: "bg-blue-50 text-blue-800 border-blue-200",
        purple: "bg-purple-50 text-purple-800 border-purple-200",
    }[variant] || "bg-gray-100 text-gray-700 border-gray-200";
    return (
        <span className={`inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded border ${cls}`}>
            {variant === "success" && <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block" />}
            {children}
        </span>
    );
};

const getStatusVariant = (state) => {
    const s = String(state || '').toLowerCase();
    if (s === 'active' || s === 'healthy') return 'success';
    if (s === 'provisioning') return 'warning';
    if (s === 'failed') return 'danger';
    return 'info';
};


// ─────────────────────────────────────────────
// Tab Components
// ─────────────────────────────────────────────

const OverviewTab = ({ data }) => (
    <div className="space-y-6">
        <div className="grid grid-cols-1 gap-7">
            <div>
                <SectionLabel>Core Specifications</SectionLabel>
                <MetaRow label="Name" value={data.load_balancer_name} bold />
                <MetaRow label="Type" value={data.load_balancer_type} />
                <MetaRow label="Created Time" value={data.created_time} />
            </div>
            
            <div>
                <SectionLabel>Identity & Location</SectionLabel>
                <MetaRow label="AWS Account ID" value={data.account_id} mono />
                <MetaRow label="Account Name" value={data.account_name} bold />
                <MetaRow label="Region" value={data.region} />
                <MetaRow label="ARN" value={data.load_balancer_arn || data.load_balancer_name} mono />
            </div>
        </div>
    </div>
);

const NetworkingTab = ({ data }) => (
    <div className="space-y-6">
        <div>
            <SectionLabel>Network Configuration</SectionLabel>
            <MetaRow label="DNS Name" value={data.dns_name} mono />
            <MetaRow label="Scheme" value={data.scheme} />
            <MetaRow label="VPC ID" value={data.vpc_id} mono />
            {data.ip_address_type && <MetaRow label="IP Address Type" value={data.ip_address_type} />}
        </div>
    </div>
);

const CostFinOpsTab = ({ data, onSuggest }) => (
    <div className="space-y-6">
        {((data.finops_flags && data.finops_flags.length > 0) || data.estimated_savings_potential > 0 || data.idle) ? (
            <div>
                <SectionLabel>Optimization & Savings</SectionLabel>
                {(data.estimated_savings_potential > 0 || data.idle) && (
                    <button
                        type="button"
                        onClick={() => onSuggest(
                            data.idle
                                ? "Idle load balancer — little to no recent traffic; consider deleting to save on base hourly charges"
                                : `Rightsizing recommendation${data.estimated_savings_potential > 0 ? ` — estimated monthly savings: $${Number(data.estimated_savings_potential).toFixed(2)}` : ""}`
                        )}
                        title="Click to add as suggestion"
                        className="w-full text-left mb-4 bg-emerald-50 border border-emerald-200/60 rounded-lg px-4 py-3 flex items-start gap-3 cursor-pointer hover:border-emerald-400 transition-colors focus:outline-none">
                        <Activity size={18} className="text-emerald-600 shrink-0 mt-0.5" />
                        <div>
                            <p className="text-[10px] font-bold text-emerald-800 uppercase">Savings Recommendation</p>
                            <p className="text-xs text-emerald-900 leading-relaxed mt-1">
                                {data.idle
                                    ? "This load balancer has had little to no traffic recently. Consider deleting it to save on base hourly charges."
                                    : "Rightsizing recommendations available."}
                            </p>
                            {data.estimated_savings_potential > 0 && (
                                <p className="text-xl font-black text-emerald-700 mt-2">${Number(data.estimated_savings_potential).toFixed(2)}</p>
                            )}
                        </div>
                    </button>
                )}

                <FinOpsFlagsContainer flags={data.finops_flags} onSuggest={onSuggest} />
            </div>
        ) : (
            <div className="col-span-full text-center py-6 bg-white rounded-2xl border border-dashed border-gray-200">
                <span className="text-xs text-gray-400">No FinOps recommendations available</span>
            </div>
        )}
    </div>
);

const TagsTab = ({ tagsPage, setTagsPage, tagsTotalPages, tagEntries, paginatedTags }) => (
    <div className="space-y-6">
        <div>
            <SectionLabel>Tags ({tagEntries.length})</SectionLabel>
            {paginatedTags.length > 0 ? (
                <div className="space-y-1.5">
                    {paginatedTags.map(([k, v]) => (
                        <div key={k} className="flex overflow-hidden border border-slate-200 rounded-lg">
                            <div className={`px-3.5 py-2.5 bg-white min-w-[140px] border-r border-slate-200 ${MONO} text-xs text-blue-700`}>{k}</div>
                            <div className="px-3.5 py-2.5 text-xs text-gray-900">{String(v)}</div>
                        </div>
                    ))}
                </div>
            ) : (
                <div className="text-center py-6 bg-white rounded-2xl border border-dashed border-gray-200">
                    <span className="text-xs text-gray-400">No resource tags available</span>
                </div>
            )}
            {tagEntries.length > TAGS_PER_PAGE && (
                <PaginationControls currentPage={tagsPage} totalPages={tagsTotalPages} onPageChange={setTagsPage} />
            )}
        </div>
    </div>
);

// ─────────────────────────────────────────────
// Main Drawer
// ─────────────────────────────────────────────

const TABS = [
    { id: "overview", label: "Overview", icon: Info },
    { id: "networking", label: "Networking", icon: Network },
    { id: "cost_finops", label: "Cost & FinOps", icon: DollarSign },
    { id: "tags", label: "Tags", icon: Tag },
];

const ELBMetadataDrawer = ({ loadBalancer, onClose }) => {
    const [activeTab, setActiveTab] = useState("overview");
    const [tagsPage, setTagsPage] = useState(1);
    const [isSugOpen, setIsSugOpen] = useState(false);
    const [sugPrefill, setSugPrefill] = useState("");
    const openSuggestion = (text = "") => {
        setSugPrefill(text);
        setIsSugOpen(true);
    };

    const { suggestions } = useSuggestions();

    const lbArn = loadBalancer?.load_balancer_arn || loadBalancer?.load_balancer_name || "";
    const { metadata, isMetadataLoading: isLoading } = useELB(lbArn);
    
    const data = { ...loadBalancer, ...(Array.isArray(metadata) ? metadata[0] : metadata) };

    const resourceSuggestions = useMemo(() => {
        return (suggestions || []).filter(item =>
            String(item.service).toLowerCase() === "elb" &&
            item.scope === "resource" &&
            String(item.resource_id).toLowerCase() === String(lbArn).toLowerCase()
        );
    }, [suggestions, lbArn]);

    const tagEntries = useMemo(() => (data.tags ? Object.entries(data.tags) : []), [data.tags]);
    const tagsTotalPages = Math.max(1, Math.ceil(tagEntries.length / TAGS_PER_PAGE));
    const paginatedTags = tagEntries.slice((tagsPage - 1) * TAGS_PER_PAGE, tagsPage * TAGS_PER_PAGE);
    const [prevLbArn, setPrevLbArn] = useState(lbArn);
    if (lbArn !== prevLbArn) {
        setPrevLbArn(lbArn);
        setTagsPage(1);
        setActiveTab("overview");
    }

    if (!loadBalancer) return null;

    const kpis = [
        { label: "Total Cost", value: data.total_cost ? `$${Number(data.total_cost).toFixed(2)}` : "—", unit: "/mo", sub: "30d trailing" },
        { label: "Type", value: data.load_balancer_type ?? "—", unit: "", sub: "load balancer type" },
        { label: "Scheme", value: data.scheme ?? "—", unit: "", sub: data.idle ? "idle traffic" : "active traffic" },
        { label: "Savings", value: data.estimated_savings_potential > 0 ? `$${Number(data.estimated_savings_potential).toFixed(2)}` : "$0.00", unit: "/mo", sub: "potential" },
    ];

    return (
        <>
            <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.3 }}
                className="fixed inset-0 z-[999] bg-black/20 backdrop-blur-[1px] h-full cursor-pointer" 
                onClick={onClose} 
            />
            <motion.div 
                initial={{ x: "100%" }}
                animate={{ x: 0 }}
                exit={{ x: "100%" }}
                transition={{ type: "tween", duration: 0.3 }}
                className="fixed right-0 top-0 h-screen w-[70%] max-w-full bg-white shadow-[-8px_0_32px_rgba(0,0,0,0.12)] z-[9999] border-l border-gray-100 flex flex-col"
            >
                
                {/* ── Header ── */}
                <div className="px-6 py-4 border-b border-slate-200 shrink-0 bg-white">
                    <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3.5">
                            <div className="w-9 h-9 rounded-lg bg-[#8C4FFF] flex items-center justify-center shrink-0 ">
                                <Network size={18} className="text-white" />
                            </div>
                            <div>
                                <div className="flex items-center gap-1.5 flex-wrap mb-0.5">
                                    <span className={`${MONO} text-[13px] font-semibold text-[var(--text-primary-color)] tracking-tight`}>
                                        {data.load_balancer_name || "-"}
                                    </span>
                                    {(data.state || data.status) && (
                                        <Badge variant={getStatusVariant(data.state || data.status)}>
                                            {data.state || data.status}
                                        </Badge>
                                    )}
                                </div>
                                <p className="text-xs text-[var(--text-secondary-color)]">
                                    {data.region && <span>{data.region}</span>}
                                    {data.account_name && <span> · {data.account_name}</span>}
                                </p>
                            </div>
                        </div>
                        <div className="flex items-center gap-2">
                            <motion.button
                                whileHover={{ scale: 1.02 }}
                                whileTap={{ scale: 0.98 }}
                                onClick={() => openSuggestion("")}
                                className="flex items-center justify-center gap-2 px-4 py-2 bg-[var(--button-bg)] text-white text-xs font-bold rounded-lg  hover:bg-[var(--button-bg)]/90 transition-all cursor-pointer uppercase tracking-wider shrink-0 mr-1"
                            >
                                <Pencil size={14} />
                                Add Suggestion
                            </motion.button>
                            <button
                                className="w-7 h-7 rounded border border-slate-200 flex items-center justify-center text-gray-400 hover:bg-white hover:text-gray-700 transition-colors cursor-pointer"
                                onClick={onClose}
                            >
                                <X size={14} />
                            </button>
                        </div>
                    </div>
                </div>

                {/* ── KPI strip ── */}
                {isLoading ? (
                    <div className="grid grid-cols-4 gap-2 px-6 py-3 border-b border-slate-200 shrink-0">
                        {Array.from({ length: 4 }).map((_, i) => (
                            <div key={i} className="h-14 bg-gray-100 rounded-lg animate-pulse" />
                        ))}
                    </div>
                ) : (
                    <div className="grid grid-cols-4 gap-2 px-6 py-3 border-b border-slate-200 shrink-0">
                        {kpis.map((k) => <KpiCard variant="compact" key={k.label} {...k} />)}
                    </div>
                )}

                <div className="px-6 py-1">
                    {resourceSuggestions && resourceSuggestions.length > 0 && (
                        <div className="">
                            <div className="flex justify-between items-center">
                                <SectionLabel>Suggestions</SectionLabel>
                                <Link to="/recommendation">
                                    <button className="text-xs font-bold text-indigo-600 hover:text-indigo-800 transition-colors cursor-pointer">
                                        View all
                                    </button>
                                </Link>
                            </div>
                            <div className="space-y-2.5">
                                {resourceSuggestions.slice(0, 1).map((item) => {
                                    const { title, desc } = splitSuggestionText(item.text);
                                    return (
                                        <div key={item.id} className="bg-white/50 border border-slate-200 rounded-lg p-3">
                                            <p className="text-xs font-bold text-gray-900 leading-snug">{title}</p>
                                            {desc && <p className="text-[11px] text-gray-500 mt-1 leading-relaxed whitespace-pre-line">{desc}</p>}
                                            <div className="flex items-center gap-1.5 mt-2 text-[10px] text-gray-400 font-medium">
                                                <span>By {item.created_by || "User"}</span>
                                                <span>·</span>
                                                <span>{new Date(item.created_at).toLocaleDateString()}</span>
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>
                        </div>
                    )}
                </div>

                {/* ── Tab bar ── */}
                <div className="flex border-b border-slate-200 px-6 mt-2.5 shrink-0 gap-0.5 overflow-x-auto scrollbar-none">
                    {TABS.map((t) => {
                        const Icon = t.icon;
                        const isActive = activeTab === t.id;
                        return (
                            <button
                                key={t.id}
                                onClick={() => setActiveTab(t.id)}
                                className={`flex items-center gap-1.5 px-3.5 py-2.5 text-xs whitespace-nowrap border-b-2 transition-colors cursor-pointer -mb-px ${isActive
                                    ? "border-[var(--button-bg)] font-semibold text-[var(--button-bg)]"
                                    : "border-transparent text-gray-500 hover:text-gray-900 font-normal"
                                    }`}
                            >
                                <Icon size={13} />
                                {t.label}
                                {t.id === "tags" && Object.keys(data.tags || {}).length > 0 && (
                                    <span className="ml-0.5 text-[9px] font-bold px-1.5 py-0.5 rounded-full bg-gray-100 text-gray-500">
                                        {Object.keys(data.tags).length}
                                    </span>
                                )}
                            </button>
                        );
                    })}
                </div>

                {/* ── Tab content ── */}
                <div className="flex-1 overflow-y-auto px-6 py-5">
                    {isLoading ? (
                        <div className="flex items-center justify-center py-16">
                            <div className="w-6 h-6 border-2 border-[var(--button-bg)] border-t-transparent rounded-full animate-spin mr-3" />
                            <span className="text-sm text-gray-500">Fetching load balancer details...</span>
                        </div>
                    ) : (
                        <div className="pb-8">
                            {activeTab === "overview" && <OverviewTab data={data} />}
                            {activeTab === "networking" && <NetworkingTab data={data} />}
                            {activeTab === "cost_finops" && <CostFinOpsTab data={data} onSuggest={openSuggestion} />}
                            {activeTab === "tags" && <TagsTab tagsPage={tagsPage} setTagsPage={setTagsPage} tagsTotalPages={tagsTotalPages} tagEntries={tagEntries} paginatedTags={paginatedTags} />}

                            {/* ── Footer ── */}
                            <div className="pt-6 mt-6 border-t border-gray-100 text-center">
                                <div className="inline-flex items-center gap-2 px-3 py-1 bg-gray-100 rounded-full">
                                    <CheckCircle2 size={12} className="text-emerald-500" />
                                    <span className="text-[10px] font-medium text-gray-500 uppercase tracking-tight">
                                        Last Synced: {data.metadata_last_synced || "-"}
                                    </span>
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            </motion.div>
            
            <AddSuggestionModal
                isOpen={isSugOpen}
                onClose={() => setIsSugOpen(false)}
                service="elb"
                scope="resource"
                resourceId={lbArn}
                resourceName={data.load_balancer_name}
                initialText={sugPrefill}
            />
        </>
    );
};

export default ELBMetadataDrawer;


