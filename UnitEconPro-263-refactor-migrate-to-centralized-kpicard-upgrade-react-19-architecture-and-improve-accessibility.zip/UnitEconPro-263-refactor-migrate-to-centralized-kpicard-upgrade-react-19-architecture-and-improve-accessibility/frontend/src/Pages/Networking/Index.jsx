import { Outlet } from "react-router-dom";
import SubPageTabs from "../../common/SubPageTabs";

const Networking = () => {
    return (
        <div className="w-full min-h-screen space-y-2 px-6 py-2">
            <title>Networking | SpendSmart</title>
            <meta name="description" content="Monitor and optimize your cloud networking costs." />
            <SubPageTabs />
            <div className="mb-4 mt-4">
                <Outlet />
            </div>
        </div>
    );
};

export default Networking;
