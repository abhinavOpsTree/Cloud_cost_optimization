import { apiRequest } from "../../lib/apiClient";
import { API_ENDPOINTS } from "../../APIs/ApiEndPoint";
import { buildQueryParams } from "../../lib/BuildQueryParams";

export const getVPCSummary = async (filters) => {
  const query = buildQueryParams(filters)
  return apiRequest({ endpoint: `${API_ENDPOINTS.networkingVPCSummary}?${query}` });
};

export const getVPCPublicIPBreakdown = async (filters) => {
  const query = buildQueryParams(filters)
  return apiRequest({ endpoint: `${API_ENDPOINTS.networkingVPCBreakdownPublicIP}?${query}` });
};

export const getVPCResources = async (filters) => {
  const query = buildQueryParams(filters);
  return apiRequest({ endpoint: `${API_ENDPOINTS.networkingVPCResources}?${query}` });
};

export const getVPCMetadata = async (vpc_id, filters) => {
  const query = buildQueryParams(filters);
  return apiRequest({ endpoint: `${API_ENDPOINTS.networkingVPCMetadata(vpc_id)}?${query}` });
};

export const getELBSummary = async (filters) => {
  const query = buildQueryParams(filters)
  return apiRequest({ endpoint: `${API_ENDPOINTS.networkingELBSummary}?${query}` });
};

export const getELBLoadBalancers = async (filters) => {
  const query = buildQueryParams(filters)
  return apiRequest({ endpoint: `${API_ENDPOINTS.networkingELBLoadBalancers}?${query}` });
};


export const getELBMetadata = async (lb_arn, filters) => {
  const query = buildQueryParams(filters)
  return apiRequest({ endpoint: `${API_ENDPOINTS.networkingELBMetadata(lb_arn)}?${query}` });
};

export const getDataTransferSummary = async (filters) => {
  const query = buildQueryParams(filters)
  return apiRequest({ endpoint: `${API_ENDPOINTS.dataTransferSummary}?${query}` });
}
export const getDataTransferTopResources = async (filters) => {
  const query = buildQueryParams(filters)
  return apiRequest({ endpoint: `${API_ENDPOINTS.dataTransferResources}?${query}` });
}

export const getNetworkingFinancials = async (service, accountName) => {
  return apiRequest({ endpoint: API_ENDPOINTS.analyticsFinancials(service, accountName) });
};
