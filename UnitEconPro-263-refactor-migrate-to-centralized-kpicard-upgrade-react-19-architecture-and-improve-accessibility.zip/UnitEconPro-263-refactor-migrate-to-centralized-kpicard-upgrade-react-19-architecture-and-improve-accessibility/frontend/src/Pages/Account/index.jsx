import { useEffect, useState, useCallback, useMemo } from "react";
import {
  Trash2,
  Plus,
  CheckCircle,
  AlertCircle,
  PiggyBank,
  Edit2,
  Loader,
  Shield,
  ShieldAlert,
  Lock,
  Unlock
} from "lucide-react";
import { toast } from "react-toastify";
import PaginationControls from "../../common/PaginationControls";
import Table from "../../common/Table";
import CopyableCell from "../../common/CopyableCell";
import FilterHeader from "../../common/Filters/FilterHeader";
import UpdateBudgetModal from "./components/UpdateBudgetModal";
import OnboardAccount from "../Settings/Onboarding/OnboardAccount";
import { useAccounts, useDeleteAccount } from "../../hooks/useAccount";
import { usePermission, useUpdatePermission, prefetchPermissions } from "../../hooks/usePermission";
import { useQueryClient } from "@tanstack/react-query";
import { KpiCard } from "../../components/common/KpiCard";


function formatDate(iso) {
  if (!iso) return "—";
  const d = new Date(iso);
  return d.toLocaleString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    hour12: true,
  });
}

function BudgetBar({ pct }) {
  const color = pct >= 90 ? "bg-red-500" : pct >= 70 ? "bg-amber-400" : "bg-emerald-500";
  return (
    <div className="w-full bg-slate-100 rounded-full h-1.5 mt-1">
      <div
        className={`${color} h-1.5 rounded-full transition-all`}
        style={{ width: `${Math.min(pct, 100)}%` }}
      />
    </div>
  );
}

function BudgetChip({ budget }) {
  if (!budget) return <span className="text-xs text-slate-300 italic">No budget set</span>;

  const budget_amount = budget.limit_amount || budget.budget_amount || 0;
  const mtd_cost = budget.mtd_cost || budget.actual_spend || 0;
  const pct_used = budget.pct_used || (budget_amount > 0 ? parseFloat(((mtd_cost / budget_amount) * 100).toFixed(2)) : 0);

  const color = pct_used >= 90 ? "text-red-600" : pct_used >= 70 ? "text-amber-600" : "text-emerald-600";

  return (
    <div className="min-w-[140px]">
      <div className="flex items-baseline gap-1">
        <span className={`text-sm font-semibold ${color}`}>${mtd_cost.toFixed(2)}</span>
        <span className="text-xs text-slate-400">/ ${budget_amount.toLocaleString()}</span>
      </div>
      <BudgetBar pct={pct_used} />
      <span className="text-[10px] text-slate-400 mt-0.5 block">{pct_used}% used</span>
    </div>
  );
}

const PermissionRowContent = ({ account }) => {
  const { permissions, isLoading, isError } = usePermission(account);
  const { mutate: updatePermission } = useUpdatePermission();

  const handleToggle = (perm) => {
    updatePermission({
      account_id: String(perm.account_id),
      service: String(perm.service),
      enabled: Boolean(!perm.enabled)
    });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center p-6 bg-white/50 rounded-lg">
        <Loader className="animate-spin text-slate-400 mr-2" size={20} />
        <span className="text-sm text-slate-500">Loading permissions...</span>
      </div>
    );
  }

  if (isError) {
    return (
      <div className="flex items-center justify-center p-6 bg-red-50/50 rounded-lg">
        <ShieldAlert className="text-red-400 mr-2" size={20} />
        <span className="text-sm text-red-500">Failed to load permissions.</span>
      </div>
    );
  }

  if (!permissions || permissions.length === 0) {
    return (
      <div className="flex items-center justify-center p-6 bg-slate-50/50 rounded-lg">
        <Shield className="text-slate-400 mr-2" size={20} />
        <span className="text-sm text-slate-500">No permissions found.</span>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg border border-slate-200 overflow-hidden shadow-sm">
      <div className="px-4 py-3 bg-slate-50 border-b border-slate-200">
        <h4 className="text-sm font-semibold text-slate-700 uppercase tracking-wider">Service Permissions</h4>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 p-4">
        {permissions.map((perm, idx) => (
          <div key={idx} className="flex items-center justify-between p-3 rounded-lg border border-slate-100 hover:bg-slate-50/50 transition-colors">
            <span className="text-sm font-bold text-slate-700 uppercase">{perm.service}</span>
            <button
              onClick={() => handleToggle(perm)}
              className={`relative inline-flex h-5 w-9 shrink-0 cursor-pointer items-center justify-center rounded-full border-2 border-transparent transition-colors focus:outline-none ${perm.enabled ? 'bg-emerald-500' : 'bg-slate-300'}`}
              role="switch"
              aria-checked={perm.enabled}
            >
              <span className={`pointer-events-none inline-block h-4 w-4 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${perm.enabled ? 'translate-x-2' : '-translate-x-2'}`} />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

const AwsAccounts = () => {
  const queryClient = useQueryClient();
  const { data: accountsData, isLoading: loading, refetch } = useAccounts();
  const { mutate: deleteAccount } = useDeleteAccount();
  const accounts = useMemo(() => accountsData || [], [accountsData]);

  const accountKpis = useMemo(() => {
    const totalAccounts = accounts.length;
    const activeAccounts = accounts.filter(a => (a.status || "").toUpperCase() === "ACTIVE").length;
    const totalMtdCost = accounts.reduce((acc, curr) => {
      const budgetObj = curr.budget || {};
      const mtd = parseFloat(budgetObj.mtd_cost || budgetObj.actual_spend || 0);
      return acc + mtd;
    }, 0);
    const accountsAtRisk = 0;

    return [
      {
        title: "Total Accounts",
        value: totalAccounts,
        icon: <Shield size={16} className="text-blue-600" />,
        background: "bg-blue-100"
      },
      {
        title: "Active Accounts",
        value: activeAccounts,
        icon: <CheckCircle size={16} className="text-emerald-600" />,
        background: "bg-emerald-100"
      },
      {
        title: "Total MTD Cost",
        value: totalMtdCost.toLocaleString("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }),
        icon: <PiggyBank size={16} className="text-violet-600" />,
        background: "bg-violet-100"
      },
      {
        title: "Accounts at Risk",
        value: accountsAtRisk,
        icon: <ShieldAlert size={16} className="text-emerald-600" />,
        background: "bg-emerald-100"
      }
    ];
  }, [accounts]);

  const [filtered, setFiltered] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterSelector, setFilterSelector] = useState("");
  const [sortConfig, setSortConfig] = useState({ key: null, direction: null });

  const [showOnboard, setShowOnboard] = useState(false);
  const [isBudgetModalOpen, setIsBudgetModalOpen] = useState(false);
  const [selectedBudgetAccount, setSelectedBudgetAccount] = useState(null);
  const [deleteConfirm, setDeleteConfirm] = useState(null);

  const rowsPerPage = filtered.length > 0 ? filtered.length : 1;

  useEffect(() => {
    let filteredData = [...accounts];

    if (filterSelector && filterSelector !== "ALL") {
      filteredData = filteredData.filter(
        (item) => item.aws_region?.toLowerCase() === filterSelector.toLowerCase()
      );
    }

    if (searchTerm) {
      filteredData = filteredData.filter((item) => {
        const q = searchTerm.toLowerCase();
        const nameMatch = item.account_name?.toLowerCase().includes(q);
        const idMatch = (item.aws_account_id || item.account_id || "").toLowerCase().includes(q);
        return nameMatch || idMatch;
      });
    }

    // eslint-disable-next-line react-hooks/set-state-in-effect
    setFiltered(filteredData);
    setCurrentPage(1);
  }, [searchTerm, filterSelector, accounts]);

  const handleSort = useCallback((key) => {
    const isAsc = sortConfig.key === key && sortConfig.direction === "asc";
    const direction = isAsc ? "desc" : "asc";
    setSortConfig({ key, direction });

    setFiltered((prev) => {
      const sorted = [...prev].sort((a, b) => {
        const valA = a[key] || "";
        const valB = b[key] || "";
        if (valA < valB) return direction === "asc" ? -1 : 1;
        if (valA > valB) return direction === "asc" ? 1 : -1;
        return 0;
      });
      return sorted;
    });
  }, [sortConfig]);

  const handleConfirmDelete = async () => {
    if (!deleteConfirm) return;
    const { id, account_id, account_name } = deleteConfirm;
    const deleteId = id || account_id;
    
    deleteAccount(deleteId, {
      onSuccess: () => {
        toast.success(`${account_name || "Account"} deleted successfully`);
        setDeleteConfirm(null);
      },
      onError: (err) => {
        console.error("Delete failed:", err);
        toast.error("Failed to delete account");
        setDeleteConfirm(null);
      }
    });
  };

  const handleUpdateBudgetClick = useCallback((account) => {
    setSelectedBudgetAccount(account);
    setIsBudgetModalOpen(true);
  }, []);


  const handleRefresh = useCallback(() => {
    refetch();
    toast.success("Data refreshed");
  }, [refetch]);

  const handleReset = useCallback(() => {
    setSearchTerm("");
    setFilterSelector("");
    setCurrentPage(1);
  }, []);

  const filterOptions = useMemo(() => {
    const regions = Array.from(new Set(accounts.map((a) => a.aws_region).filter(Boolean)));
    return regions.map((r) => ({ value: r, label: r }));
  }, [accounts]);

  const columns = useMemo(() => [
    {
      key: "account_name",
      label: "Account Name",
      sortable: true,
      cellClassName: "font-semibold text-slate-800",
      render: (val) => <CopyableCell value={val} />
    },
    {
      key: "aws_account_id",
      label: "AWS Account ID",
      sortable: true,
      cellClassName: "text-slate-500 font-mono text-xs",
      render: (val, row) => <CopyableCell value={val || row.account_id || "—"} />,
    },
    {
      key: "aws_region",
      label: "Region",
      sortable: true,
      render: (val) =>
        val ? (
          <span className="px-2.5 py-1 bg-sky-50 text-sky-700 text-xs font-semibold rounded-lg border border-sky-100">
            {val}
          </span>
        ) : (
          "—"
        ),
    },
    {
      key: "budget",
      label: "Budget (MTD)",
      render: (val) => <BudgetChip budget={val} />,
    },
    {
      key: "status",
      label: "Status",
      sortable: true,
      render: (val) => (
        <span
          className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold uppercase tracking-wider ${(val || "").toUpperCase() === "ACTIVE"
              ? "bg-emerald-50 text-emerald-700 border border-emerald-100"
              : "bg-red-50 text-red-700 border border-red-100"
            }`}
        >
          {(val || "").toUpperCase() === "ACTIVE" ? (
            <CheckCircle size={11} className="text-emerald-500" />
          ) : (
            <AlertCircle size={11} className="text-red-500" />
          )}
          {val || "—"}
        </span>
      ),
    },
    {
      key: "last_validated",
      label: "Last Validated",
      render: (val) => (val ? formatDate(val) : "—"),
    },
    {
      key: "actions",
      label: "Actions",
      align: "right",
      render: (_, row) => (
        <div className="flex items-center justify-end gap-2">
          {row.budget ? (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                handleUpdateBudgetClick(row);
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-violet-50 text-violet-700 hover:bg-violet-100 text-xs font-bold transition-all cursor-pointer border-none"
            >
              <Edit2 size={13} className="text-violet-600" />
              Update Budget
            </button>
          ) : (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                handleUpdateBudgetClick(row);
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-50 text-emerald-700 hover:bg-emerald-100 text-xs font-bold transition-all cursor-pointer border-none"
            >
              <PiggyBank size={13} className="text-emerald-600" />
              Set Budget
            </button>
          )}
          {/* <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              handleDeleteClick(row);
            }}
            className="p-1.5 rounded-lg text-red-500 bg-red-50 hover:bg-red-100 transition-all cursor-pointer border-none flex items-center justify-center"
            title="Delete Account"
          >
            <Trash2 size={15} />
          </button> */}
        </div>
      ),
    },
  ], [handleUpdateBudgetClick]);

  const totalPages = Math.ceil(filtered.length / rowsPerPage);
  const paginatedData = useMemo(() => {
    return filtered.slice((currentPage - 1) * rowsPerPage, currentPage * rowsPerPage);
  }, [filtered, currentPage, rowsPerPage]);

  return (
    <div className="w-full">
      <title>Accounts | SpendSmart</title>
      <meta name="description" content="Manage your SpendSmart account and integration settings." />
      <div className="max-w-[1600px] mx-auto space-y-4 px-4 py-4">
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {accountKpis.map((kpi, i) => (
            <KpiCard key={i} kpi={kpi} isLoading={loading} variant="dashboard" />
          ))}
        </div>

        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-4">
          <div className="flex-1">
            <FilterHeader
              searchTerm={searchTerm}
              onSearchChange={setSearchTerm}
              filterSelector={filterSelector}
              onFilterChange={setFilterSelector}
              onReset={handleReset}
              filterOptions={filterOptions}
              onRefresh={handleRefresh}
              defaultLabel="ALL REGIONS"
            />
          </div>
          <button
            onClick={() => setShowOnboard(true)}
            className="flex items-center justify-center gap-2 px-4 py-2 bg-[var(--button-bg)] text-white text-xs font-bold rounded-lg shadow-sm shadow-violet-200 transition-all hover:scale-[1.02] active:scale-95 cursor-pointer uppercase tracking-wider shrink-0"
          >
            <Plus size={14} /> Onboard Account
          </button>
        </div>

        <div className="overflow-hidden">
          <Table
            columns={columns}
            data={paginatedData || []}
            rowsPerPage={rowsPerPage}
            actions={[]}
            isLoading={loading}
            onSort={handleSort}
            sortConfig={sortConfig}
            emptyState="No accounts found"
            expandable={true}
            singleExpand={true}
            expandIcon={Lock}
            collapseIcon={Unlock}
            expandTooltip="Permissions"
            onRowHover={(row) => prefetchPermissions(queryClient, row)}
            renderExpandedContent={(row) => <PermissionRowContent account={row} />}
          />

          {filtered.length > 0 && totalPages > 1 && (
            <div className="px-6 py-4 border-t border-slate-50 flex items-center justify-center">
              <PaginationControls
                currentPage={currentPage}
                totalPages={totalPages}
                onPageChange={setCurrentPage}
              />
            </div>
          )}
        </div>
      </div>

      <OnboardAccount
        isOpen={showOnboard}
        onClose={(hasCreated) => {
          setShowOnboard(false);
          if (hasCreated === true) {
            refetch();
          }
        }}
      />

      <UpdateBudgetModal
        isOpen={isBudgetModalOpen}
        onClose={() => {
          setIsBudgetModalOpen(false);
          setSelectedBudgetAccount(null);
        }}
        account={selectedBudgetAccount}
      />

      {deleteConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4 animate-in fade-in duration-200">
          <div className="bg-white rounded-[24px] w-full max-w-lg overflow-hidden animate-in zoom-in-95 duration-200 p-6">
            <div className="flex flex-col items-center text-center gap-4">
              <div className="w-14 h-14 bg-red-50 rounded-2xl flex items-center justify-center">
                <Trash2 size={24} className="text-red-500" />
              </div>
              <div>
                <p className="text-slate-800 font-semibold">
                  Delete <span className="text-red-600">{deleteConfirm.account_name}</span>?
                </p>
                <p className="text-sm text-slate-400 mt-1">
                  This will permanently remove the account and all associated data. This action cannot be undone.
                </p>
              </div>
              <div className="flex gap-3 w-full mt-2">
                <button
                  type="button"
                  onClick={() => setDeleteConfirm(null)}
                  className="flex-1 py-2.5 rounded-xl border border-slate-200 text-sm text-slate-600 hover:bg-slate-50 transition-colors font-semibold cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleConfirmDelete}
                  className="flex-1 py-2.5 rounded-xl bg-red-500 hover:bg-red-600 text-white text-sm font-semibold transition-colors cursor-pointer"
                >
                  Delete Account
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AwsAccounts;
