import { useState, useEffect } from "react";
import { X, Loader2 } from "lucide-react";
import { toast } from "react-toastify";
import { useQueryClient } from "@tanstack/react-query";
import { useCreateBudget, refreshAccountBudget } from "../../../hooks/useBudget";

const SERVICES_LIST = ["All", "EC2", "EBS", "S3", "EKS", "ECS", "ECR", "RDS", "VPC", "ELB", "CloudWatch", "Data Transfer"];

const UpdateBudgetModal = ({ isOpen, onClose, account }) => {
  const [budgets, setBudgets] = useState({});
  const { mutateAsync: createBudget } = useCreateBudget();
  const queryClient = useQueryClient();
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!isOpen) {
      setBudgets({});
      return;
    }
    if (!account) return;

    const initialBudgets = {};

    SERVICES_LIST.forEach((srv) => {
      initialBudgets[srv] = {
        limit: "",
        initial: "",
        mtd_cost: 0,
        pct_used: 0,
      };
    });

    if (account.budget) {
      // Set 'All' (Account level)
      const amt = account.budget.limit_amount || account.budget.budget_amount || "";
      initialBudgets["All"] = {
        limit: amt.toString(),
        initial: amt.toString(),
        mtd_cost: account.budget.mtd_cost || account.budget.actual_spend || 0,
        pct_used: account.budget.pct_used || 0,
      };

      // Set individual services if they exist in the response
      if (Array.isArray(account.budget.services)) {
        account.budget.services.forEach((srvData) => {
          // Normalize service name to match our static list roughly
          const serviceNameStr = srvData.service_name || srvData.service_code || srvData.service;
          if (!serviceNameStr) return;
          
          // Strip everything non-alphanumeric so "Data Transfer" matches "data-transfer"
          const normalize = (str) => str.toLowerCase().replace(/[^a-z0-9]/g, "");
          const matchedService = SERVICES_LIST.find(s => normalize(s) === normalize(serviceNameStr));
          if (matchedService) {
            const srvAmt = srvData.limit_amount || srvData.budget_amount || "";
            initialBudgets[matchedService] = {
              limit: srvAmt.toString(),
              initial: srvAmt.toString(),
              mtd_cost: srvData.mtd_cost || 0,
              pct_used: srvData.pct_used || 0,
            };
          }
        });
      }
    }

    setBudgets(initialBudgets);
  }, [isOpen, account]);

  const handleBudgetChange = (service, value) => {
    setBudgets((prev) => ({
      ...prev,
      [service]: {
        ...prev[service],
        limit: value,
      },
    }));
  };

  const hasAnyChanged = Object.values(budgets).some(
    (b) => b.limit.toString() !== b.initial.toString()
  );

  const handleSave = async () => {
    const changesToSave = Object.entries(budgets)
      .filter(([_, data]) => data.limit.toString() !== data.initial.toString())
      .map(([service, data]) => ({
        service,
        limit: parseFloat(data.limit),
      }));

    if (changesToSave.length === 0) return;

    // Validate
    if (changesToSave.some(c => isNaN(c.limit) || c.limit < 0)) {
      toast.error("Please enter a valid budget amount for all changed services.");
      return;
    }

    setSaving(true);
    try {
      const promises = changesToSave.map(({ service, limit }) => 
        createBudget({
          account_name: account.account_name,
          budget_amount: limit,
          service_code: service === "All" ? null : service.toLowerCase().replace(/\s+/g, '-'),
        })
      );

      await Promise.all(promises);

      // Refresh the cached accounts list once, after ALL saves have landed —
      // doing it per-mutation races concurrent saves and can cache stale data.
      await refreshAccountBudget(queryClient, account.account_name);

      toast.success("Budgets updated successfully");
      onClose(true);
    } catch (err) {
      console.error("Failed to save budgets:", err);
      toast.error("Failed to save one or more budgets");
    } finally {
      setSaving(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm p-4 animate-in fade-in duration-200">
      <div className="bg-white rounded-[24px] shadow-2xl w-full max-w-4xl overflow-hidden animate-in zoom-in-95 duration-200 flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-slate-100/50 shrink-0">
          <div>
            <h2 className="text-lg font-bold text-slate-800">Manage Budgets</h2>
            <p className="text-xs text-slate-400 mt-1">
              Account: <span className="font-semibold text-slate-600">{account?.account_name}</span> ({account?.aws_account_id})
            </p>
          </div>
          <button
            type="button"
            onClick={() => onClose(false)}
            className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-400 hover:text-slate-600 transition-colors"
          >
            <X size={18} />
          </button>
        </div>

        {/* Body */}
        <div className="overflow-y-auto p-6 flex-1">
          <div className="border border-slate-200 rounded-xl overflow-hidden shadow-sm">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200">
                  <th className="px-4 py-3 text-xs font-bold text-slate-600 uppercase tracking-wider">Service</th>
                  <th className="px-4 py-3 text-xs font-bold text-slate-600 uppercase tracking-wider text-right">MTD Cost</th>
                  <th className="px-4 py-3 text-xs font-bold text-slate-600 uppercase tracking-wider">Monthly Budget (USD)</th>
                  <th className="px-4 py-3 text-xs font-bold text-slate-600 uppercase tracking-wider w-1/4">% Used</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {SERVICES_LIST.map((srv) => {
                  const data = budgets[srv] || { limit: "", mtd_cost: 0, pct_used: 0 };
                  const isAccountLevel = srv === "All";
                  
                  // Calculate dynamic percentage if possible
                  const limitVal = parseFloat(data.limit);
                  let displayPct = data.pct_used;
                  if (!isNaN(limitVal) && limitVal > 0 && data.mtd_cost > 0) {
                      displayPct = Math.min(((data.mtd_cost / limitVal) * 100), 100).toFixed(1);
                  }

                  const colorClass = displayPct >= 90 ? "bg-red-500" : displayPct >= 70 ? "bg-amber-400" : "bg-emerald-500";
                  
                  return (
                    <tr key={srv} className="hover:bg-slate-50/50 transition-colors">
                      <td className="px-4 py-3">
                        <span className={`text-sm font-semibold ${isAccountLevel ? 'text-violet-700' : 'text-slate-700'}`}>
                          {isAccountLevel ? "Account Total" : srv}
                        </span>
                      </td>
                      <td className="px-4 py-3 text-right">
                        <span className="text-sm font-medium text-slate-600">${data.mtd_cost.toFixed(2)}</span>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2 px-3 py-2 rounded-lg border border-slate-200 bg-white focus-within:ring-2 focus-within:ring-violet-500/20 focus-within:border-violet-400 transition-all max-w-[150px]">
                          <span className="text-xs text-slate-400 font-semibold">$</span>
                          <input
                            type="number"
                            min="0"
                            value={data.limit}
                            onChange={(e) => handleBudgetChange(srv, e.target.value)}
                            placeholder={isAccountLevel ? "e.g. 5000" : "e.g. 500"}
                            className="w-full text-sm text-slate-800 outline-none border-none bg-transparent p-0 focus:ring-0 font-medium placeholder:text-slate-300"
                          />
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex flex-col gap-1.5">
                          <div className="flex justify-between items-center text-[10px] font-bold text-slate-500">
                            <span>Usage</span>
                            <span>{displayPct}%</span>
                          </div>
                          <div className="w-full bg-slate-100 rounded-full h-1.5">
                            <div
                              className={`${colorClass} h-1.5 rounded-full transition-all`}
                              style={{ width: `${Math.min(displayPct, 100)}%` }}
                            />
                          </div>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-5 border-t border-slate-100/50 flex gap-3 shrink-0">
          <button
            type="button"
            onClick={() => onClose(false)}
            className="flex-1 py-2.5 rounded-xl border border-slate-200 text-sm text-slate-600 hover:bg-slate-50 transition-colors font-semibold cursor-pointer max-w-[200px] ml-auto"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={handleSave}
            disabled={saving || !hasAnyChanged}
            className="flex-1 max-w-[200px] py-2.5 rounded-xl bg-violet-600 hover:bg-violet-700 disabled:bg-slate-300 disabled:cursor-not-allowed text-white text-sm font-semibold transition-colors shadow-sm shadow-violet-200 cursor-pointer flex items-center justify-center gap-2"
          >
            {saving && <Loader2 size={14} className="animate-spin" />}
            Save Changes
          </button>
        </div>
      </div>
    </div>
  );
};

export default UpdateBudgetModal;
