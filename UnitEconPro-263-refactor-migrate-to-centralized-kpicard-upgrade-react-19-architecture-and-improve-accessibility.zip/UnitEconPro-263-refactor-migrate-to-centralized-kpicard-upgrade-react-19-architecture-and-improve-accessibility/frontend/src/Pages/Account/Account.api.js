import { toast } from "react-toastify";
import { apiRequest } from "../../lib/apiClient";
import { API_ENDPOINTS } from "../../APIs/ApiEndPoint";

export const fetchAccountsWithBudgets = async (email) => {
    // 1. Fetch Accounts (scoped to the logged-in user's access when email is provided)
    let data;
    try {
        data = await apiRequest({
            endpoint: API_ENDPOINTS.listaccounts(email),
            method: "GET",
        });
    } catch (err) {
        toast.error(err?.message || "Failed to fetch accounts");
        return [];
    }
    const list = Array.isArray(data) ? data : data?.accounts ?? [];

    let budgetErrors = 0;

    // 2. Fetch Budget for each account concurrently
    const budgetPromises = list.map(async (acc) => {
        try {
            const budgetData = await apiRequest({
                endpoint: API_ENDPOINTS.getBudgetStatus(acc.account_name),
                method: "GET",
            });
            return { account_id: acc.account_id || acc.id, budget: budgetData };
        } catch (err) {
            console.error(err);
            if (!err.message?.includes("HTTP 404")) {
                budgetErrors++;
            }
            return { account_id: acc.account_id || acc.id, budget: null };
        }
    });

    const results = await Promise.all(budgetPromises);

    if (budgetErrors > 0) {
        toast.error(`Failed to load budget data for ${budgetErrors} account${budgetErrors > 1 ? 's' : ''}`);
    }

    // 3. Merge budget data into the account list
    const budgetMap = {};
    results.forEach((res) => {
        if (!res.budget) return;
        const accountData = res.budget.account || res.budget;
        const servicesData = res.budget.services || res.budget.service_budgets || [];
        
        // Always include budget data if it exists, even if account limit isn't set
        budgetMap[res.account_id] = {
            ...accountData,
            services: servicesData
        };
    });

    return list.map((acc) => {
        const id = acc.account_id || acc.id;
        return {
            ...acc,
            budget: budgetMap[id] || null,
        };
    });
};

export const deleteAccount = async (id) => {
    try {
        return await apiRequest({
            endpoint: API_ENDPOINTS.deleteaccount(id),
            method: "DELETE"
        });
    } catch (err) {
        toast.error(err?.message || "Failed to delete account");
        throw err;
    }
};

export const createBudget = async (budgetAmount, accountName, serviceCode) => {
    try {
        let url = `${API_ENDPOINTS.createBudget}/?account_name=${encodeURIComponent(accountName)}`;
        if (serviceCode && serviceCode.toLowerCase() !== "all") {
            url += `&service_code=${encodeURIComponent(serviceCode)}`;
        }
        return await apiRequest({
            endpoint: url,
            method: "POST",
            body: { budget_amount: budgetAmount }
        });
    } catch (err) {
        toast.error(err?.message || "Failed to create budget");
        throw err;
    }
};

