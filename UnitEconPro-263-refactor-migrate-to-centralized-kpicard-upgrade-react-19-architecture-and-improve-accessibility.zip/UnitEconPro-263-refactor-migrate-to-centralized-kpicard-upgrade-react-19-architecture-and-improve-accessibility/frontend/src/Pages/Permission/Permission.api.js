import { apiRequest } from "../../lib/apiClient";
import { API_ENDPOINTS } from "../../APIs/ApiEndPoint";

export const getPermissions = async (account_id) => {
    return apiRequest({ endpoint: API_ENDPOINTS.getPermissions(account_id) });
};

export const updatePermission = async (body) => {
    return apiRequest({
        endpoint: API_ENDPOINTS.upsertPermission,
        method: "POST",
        body
    });
};

