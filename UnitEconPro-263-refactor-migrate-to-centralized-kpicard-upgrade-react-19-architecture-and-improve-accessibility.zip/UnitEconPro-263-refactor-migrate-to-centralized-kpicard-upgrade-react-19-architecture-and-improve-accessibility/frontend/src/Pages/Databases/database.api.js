import { apiRequest } from "../../lib/apiClient";
import { API_ENDPOINTS } from "../../APIs/ApiEndPoint";
import { buildQueryParams } from "../../lib/BuildQueryParams";

export const getRDSSummary = async (filters) => {
  const query = buildQueryParams(filters)
  return apiRequest({ endpoint: `${API_ENDPOINTS.databaseRDSSummary}?${query}` });
};

export const getRDSInstances = async (filters) => {
  const query = buildQueryParams(filters)
  return apiRequest({ endpoint: `${API_ENDPOINTS.databaseRDSInstances}?${query}` });
};

export const getRDSMetadata = async (instance_id) => {
  return apiRequest({ endpoint: `${API_ENDPOINTS.databaseRDSMetadata(instance_id)}` });
};

export const getDatabaseFinancials = async (service, accountName) => {
  return apiRequest({ endpoint: API_ENDPOINTS.analyticsFinancials(service, accountName) });
};

