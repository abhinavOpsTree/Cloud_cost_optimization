import { useState, useEffect, useMemo } from "react";
import { splitSuggestionText } from "../../../lib/suggestionText";
import { AnimatePresence } from "framer-motion";
import { Filters } from "../../../common/Filters/Filter";
import PaginationControls from "../../../common/PaginationControls";
import Table from "../../../common/Table";
import CopyableCell from "../../../common/CopyableCell";
import { useDatabase } from "../../../hooks/useDatabase";
import { Linechart } from "../../../common/Charts/LazyLinechart";
import { useUnified } from "../../../hooks/useUnified";
import { Chips } from "../../../common/Chips";
import { RoundedPieChart } from "../../../common/Charts/LazyPiechart";

import { Activity, DollarSign, Server, Info } from "lucide-react";
import { CardSkeleton } from "../../../common/Cardoverview";
import { KpiCard } from "../../../components/common/KpiCard";
import RDSMetadataDrawer from "./RDSMetadataDrawer";
import { useSuggestions } from "../../../hooks/useSuggestions";
import { Link, useSearchParams } from "react-router-dom";
import { ForecastCardFinance } from "../../../common/MonthtoDate/LazyForecastCardFinance";

const RDS_SEARCH_KEYS = ["instance_id", "instance_type", "engine"];
const RDS_FILTER_CONFIGS = [
    { key: "account", label: "Account" },
    { key: "region", label: "Region" },
    { key: "instance_type", label: "Type" }
];


function formatUsageHours(hours) {
    const years = Math.floor(hours / (24 * 365));
    const days = Math.floor((hours % (24 * 365)) / 24);

    if (years > 0) {
        return `${years}y ${days}d`;
    }

    return `${(hours / 24).toFixed(0)}d`;
}

// Helper: extract friendly name from ARN or return value as-is. Pure function,
// hoisted to module scope so the memoized columns below need no deps.
// e.g. "arn:aws:rds:us-east-1:123:db:dev-tripare-postgres" → "dev-tripare-postgres"
const extractDbName = (val) => {
    if (!val) return "-";
    if (typeof val === "string" && val.startsWith("arn:")) {
        const parts = val.split(":");
        return parts[parts.length - 1];
    }
    return val;
};

// Perf: fully static, so hoisted to module scope — stronger than useMemo (one
// allocation for the app's lifetime) and matches the consts above.
const BREAKDOWN_OPTIONS = [
    { label: "Engine", value: "engine" },
    { label: "Instance Type", value: "instance-type" },
    { label: "Region", value: "region" },
    { label: "Account", value: "account" },
    { label: "Operation", value: "operation" },
    { label: "Usage Type", value: "usage-type" },
    { label: "Pricing Model", value: "pricing-model" },
        { label: "Environment", value: "env" },
        { label: "Owner", value: "owner" },
        { label: "Project", value: "project" },
        { label: "Team", value: "team" },
        { label: "Application", value: "application" },
];

const RDS = () => {
    const [dimension, setDimension] = useState("region");
    const { rdsSummary, rdsInstances, isLoading, isError } = useDatabase();
    const { suggestions: allSuggestions } = useSuggestions();
    const suggestions = (allSuggestions ?? []).filter(
        (s) => String(s.service).toLowerCase() === "rds" && s.scope === "page"
    );
    const {
        trend,
        breakdown,
        isTrendLoading,
        isBreakdownLoading,
        isTrendError,
        isBreakdownError
    } = useUnified(dimension);

    const [selectedMetadataInstance, setSelectedMetadataInstance] = useState(null);
    const [searchParams] = useSearchParams();
    useEffect(() => {
        const resource = searchParams.get("resource");
        if (resource) setSelectedMetadataInstance({ instance_id: resource });
    }, [searchParams]);

    // Perf: memoized so <Table actions={...}> gets a stable prop instead of a fresh
    // array every render; only a state setter inside, so empty deps are safe.
    const actions = useMemo(() => [
        {
            label: "Metadata",
            onClick: (row) => {
                setSelectedMetadataInstance(row);
            },
            icon: () => <Info size={16} color="#059669" className="cursor-pointer" />,
            tooltip: "View Instance Metadata"
        }
    ], []);

    // Perf: memoized so the KPI card list keeps a stable identity between renders;
    // recomputed only when the summary data actually changes.
    const card = useMemo(() => [
        { title: "total_cost", value: rdsSummary?.total_cost, icon: <DollarSign size={16} className="text-green-500" />, icon2: <DollarSign size={16} className="text-green-600" /> },
        { title: "avg_daily_cost", value: rdsSummary?.avg_daily_cost, icon: <Activity size={16} className="text-green-800" />, icon2: <DollarSign size={16} className="text-green-600" /> },
        { title: "total_instances", value: rdsSummary?.total_instances, icon: <Server size={16} className="text-blue-500" /> },
        // { title: "total_usage_hours", value: formatUsageHours(rdsSummary?.total_usage_hours), icon: <Activity size={16} className="text-orange-500" /> },
    ], [rdsSummary])

    // Perf: memoized table configuration; render closures only use module-level
    // helpers (extractDbName, CopyableCell), so empty deps are safe.
    const columns = useMemo(() => [
        { key: "account", label: "Account"},
        {
            key: "instance_id",
            label: "DB Instance",
            sortable: true,
            render: (val) => <CopyableCell value={extractDbName(val)} />},
        { key: "total_cost", label: "Total Cost", sortable: true, showTotal: true },
        { key: "usage_hours", label: "Usage Hours", sortable: true },
        { key: "engine", label: "Engine" },
        { key: "instance_type", label: "Instance Type" },
        { key: "region", label: "Region" }
    ], [])

    const [filteredList, setFilteredList] = useState(null);
    const [currentPage, setCurrentPage] = useState(1);
    const rowsPerPage = 10;
    const safeRows = rowsPerPage || 10

    const rdsInstancesData = useMemo(() => Array.isArray(rdsInstances) ? rdsInstances : [], [rdsInstances]);
    const displayData = filteredList !== null ? filteredList : rdsInstancesData;

    const totalPages = Math.ceil(displayData.length / safeRows);

    const safePage = Math.max(currentPage, 1)

    const paginatedData = displayData.slice(
        (safePage - 1) * safeRows,
        safePage * safeRows
    )

    return (
        <div className="flex flex-col space-y-2 p-2">
            <div className="w-full">
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-2 w-full">
                    {isLoading
                        ? Array.from({ length: 5 }).map((_, i) => (
                            <CardSkeleton key={i} />
                        ))
                        : card.map((kpi) => (
                            <KpiCard key={kpi.title} kpi={kpi} />
                        ))
                    }
                    {isError && (
                        <div className="flex items-center justify-center h-full col-span-full py-10">
                            <span className="text-destructive font-semibold">Error loading data</span>
                        </div>
                    )}
                </div>
            </div>
            <div className="py-1">
                <div className="flex justify-between items-center mb-2.5">
                    <p className="text-sm font-bold uppercase text-[var(--text-primary-color)]">Suggestions</p>
                    <Link to="/recommendation">
                        <button className="text-xs font-bold text-indigo-600 hover:text-indigo-800 transition-colors cursor-pointer bg-transparent border-0 p-0">View all</button>
                    </Link>
                </div>
                {suggestions.length > 0 ? (
                    <div className="space-y-2.5">
                        {suggestions.slice(0, 1).map((item) => {
                            const { title, desc } = splitSuggestionText(item.text);
                            return (
                                <div key={item.id} className="bg-white ring-1 ring-black/10 rounded-lg p-3">
                                    <p className="text-xs font-bold text-gray-900 leading-snug">{title}</p>
                                    {desc && <p className="text-[11px] text-gray-500 mt-1 leading-relaxed whitespace-pre-line">{desc}</p>}
                                    <div className="flex items-center gap-1.5 mt-2 text-[10px] text-gray-400 font-medium">
                                        <span>By {item.created_by || "User"}</span>
                                        <span>·</span>
                                        <span>{new Date(item.created_at).toLocaleDateString()}</span>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                ) : (
                    <div className="flex flex-col items-center justify-center py-12 text-center bg-gray-100 border border-dashed border-gray-200 rounded-xl">
                        <span className="text-xs text-[var(--text-secondary-color)] font-medium">No recommendations found.</span>
                    </div>
                )}
            </div>
            <ForecastCardFinance category="database" service="rds" trend={trend} isTrendLoading={isTrendLoading} />

            <Linechart 
                avgCost={rdsSummary?.avg_daily_cost} 
                chartdata={trend} 
                name="cost" 
                service="AmazonRDS"
                isLoading={isTrendLoading} 
                isError={isTrendError} 
            />

            <div className="w-full flex flex-col space-y-2 mb-4">
                <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wider px-1">Breakdown By</h3>
                <Chips
                    options={BREAKDOWN_OPTIONS}
                    selected={dimension}
                    onSelect={setDimension}
                />
            </div>

            <RoundedPieChart
                title={`${BREAKDOWN_OPTIONS.find(o => o.value === dimension)?.label} Breakdown`}
                dataKey="cost"
                nameKey="name"
                chartData={breakdown}
                isError={isBreakdownError}
                isLoading={isBreakdownLoading}
            />
            <div className="w-full space-y-4">
                <h3 className="text-lg font-semibold mb-2">RDS Instances</h3>
                <Filters 
                    data={rdsInstancesData} 
                    onFilter={(filtered) => {
                        setFilteredList(filtered);
                        setCurrentPage(1);
                    }} 
                    searchKeys={RDS_SEARCH_KEYS}
                    filterConfigs={RDS_FILTER_CONFIGS}
                    placeholder="Search by instance ID, type, engine..."
                />
                <Table columns={columns} data={paginatedData} actions={actions} isLoading={isLoading} isFiltered={filteredList !== null} />
            </div>
            <PaginationControls currentPage={currentPage} totalPages={totalPages} onPageChange={setCurrentPage} />

            <AnimatePresence>
                {selectedMetadataInstance && (
                    <RDSMetadataDrawer
                        key="rds-drawer"
                        instance={selectedMetadataInstance}
                        onClose={() => setSelectedMetadataInstance(null)}
                    />
                )}
            </AnimatePresence>
        </div>
    );
};

export default RDS;