import { KpiCard } from "../../../components/common/KpiCard";
import { useState, useMemo } from "react";
import { splitSuggestionText } from "../../../lib/suggestionText";
import { useDatabase } from "../../../hooks/useDatabase";
import PaginationControls from "../../../common/PaginationControls";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { useSuggestions } from "../../../hooks/useSuggestions";
import AddSuggestionModal from "../../../common/AddSuggestionModal";
import FinOpsFlagsContainer from "../../../common/FinOpsFlagsContainer";
import {
    X, Tag,  DollarSign, Activity,
     Database,  HardDrive,
    Info, Lock, Pencil
} from "lucide-react";

// ─────────────────────────────────────────────
// Design primitives
// ─────────────────────────────────────────────

const MONO = "font-mono";
const TAGS_PER_PAGE = 10;

const SectionLabel = ({ children }) => (
    <p className="text-sm font-bold uppercase text-[var(--text-primary-color)] mb-2.5">{children}</p>
);

const MetaRow = ({ label, value, mono, bold, color }) => (
    <div className="flex justify-between items-center py-1.5 border-b border-slate-200 text-xs last:border-0 gap-3">
        <span className="text-gray-500 shrink-0">{label}</span>
        <span className={`text-right break-all ${mono ? `${MONO} text-[11px] text-blue-700` : ""} ${bold ? "font-semibold" : ""} ${color || "text-gray-900"}`}>
            {value ?? "—"}
        </span>
    </div>
);



const Badge = ({ children, variant }) => {
    const cls = {
        success: "bg-emerald-50 text-emerald-800 border-emerald-200",
        warning: "bg-amber-50 text-amber-800 border-amber-200",
        danger: "bg-red-50 text-red-800 border-red-200",
        info: "bg-blue-50 text-blue-800 border-blue-200",
        purple: "bg-purple-50 text-purple-800 border-purple-200",
    }[variant] || "bg-gray-100 text-gray-700 border-gray-200";
    return (
        <span className={`inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded border ${cls}`}>
            {variant === "success" && <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block" />}
            {children}
        </span>
    );
};

const getStatusVariant = (s) => {
    const v = String(s || '').toLowerCase();
    if (v === "available" || v === "active" || v === "running") return "success";
    if (["backing-up", "modifying", "starting", "stopping"].includes(v)) return "warning";
    if (v === "stopped" || v === "failed") return "danger";
    return "info";
};

// ─────────────────────────────────────────────
// FinOps & Util components
// ─────────────────────────────────────────────


const UtilBar = ({ label, value, max = 100, unit = "%" }) => {
    const pct = max > 0 ? Math.min(100, (value / max) * 100) : 0;
    const color = pct > 80 ? "bg-red-400" : pct > 50 ? "bg-amber-400" : "bg-emerald-500";
    return (
        <div className="mb-3.5">
            <div className="flex justify-between mb-1 text-[11px]">
                <span className="text-gray-500">{label}</span>
                <span className={`${MONO} font-semibold text-[12px] text-gray-900`}>
                    {value !== null && value !== undefined ? `${Number(value).toFixed(1)} ${unit}` : "—"}
                </span>
            </div>
            <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
                <div className={`h-full rounded-full ${color} transition-all`} style={{ width: `${pct}%` }} />
            </div>
        </div>
    );
};

// ─────────────────────────────────────────────
// Tab Components
// ─────────────────────────────────────────────

const OverviewTab = ({ data, dbInstanceId, engineName, engineVersion, licenseModel, autoMinorVersionUpgrade, instanceClass, instanceFamily, dbInstanceStatus, multiAz, readReplicaCount, sourceDbInstanceId, publiclyAccessible }) => (
    <div className="space-y-6">
        <div className="grid grid-cols-1 gap-7">
            <div>
                <SectionLabel>Identity & Location</SectionLabel>
                <MetaRow label="AWS Account ID" value={data.account_id} mono />
                <MetaRow label="Account Name" value={data.account_name || data.account} bold />
                <MetaRow label="Region" value={data.region} />
                <MetaRow label="Availability Zone" value={data.availability_zone} />
            </div>
            <div>
                <SectionLabel>Architecture</SectionLabel>
                <MetaRow label="Multi-AZ" value={multiAz ? "Yes" : "No"} color={multiAz ? "text-emerald-700 font-semibold" : ""} />
                <MetaRow label="Read Replica Count" value={readReplicaCount ?? "—"} />
                {sourceDbInstanceId && <MetaRow label="Source DB Instance" value={sourceDbInstanceId} mono />}
                <MetaRow label="Publicly Accessible" value={publiclyAccessible ? "Yes" : "No"} color={publiclyAccessible ? "text-red-600 font-semibold" : "text-emerald-700 font-semibold"} />
            </div>
            <div>
                <SectionLabel>Engine & Compute</SectionLabel>
                <MetaRow label="DB Instance ID" value={data.db_instance_id || dbInstanceId} mono />
                <MetaRow label="Engine" value={engineName} bold />
                <MetaRow label="Engine Version" value={engineVersion} />
                <MetaRow label="License Model" value={licenseModel} />
                <MetaRow label="Auto Minor Upgrades" value={autoMinorVersionUpgrade ? "Yes" : "No"} />
                <MetaRow label="Instance Class" value={instanceClass} bold />
                <MetaRow label="Instance Family" value={instanceFamily} />
                <MetaRow label="Status" value={dbInstanceStatus} color={getStatusVariant(dbInstanceStatus) === "success" ? "text-emerald-700 font-semibold" : ""} />
                <MetaRow label="Cost / Instance Hour" value={data.cost_per_instance_hour != null ? `$${Number(data.cost_per_instance_hour).toFixed(4)}` : "—"} />
            </div>
        </div>
    </div>
);

const PerformanceTab = ({ utilization }) => (
    <div className="space-y-6">
        <div>
            <SectionLabel>
                Utilization {utilization.utilization_window_days ? `(${utilization.utilization_window_days}d window)` : ""}
            </SectionLabel>
            <UtilBar label="Avg CPU" value={utilization.avg_cpu_pct} max={100} unit="%" />
            <UtilBar label="Peak CPU" value={utilization.max_cpu_pct} max={100} unit="%" />
            <div className="my-5" />
            <UtilBar label="Avg Connections" value={utilization.avg_connections} max={Math.max(utilization.max_connections || 100, 1)} unit="" />
            <UtilBar label="Peak Connections" value={utilization.max_connections} max={Math.max(utilization.max_connections || 100, 1)} unit="" />
            <div className="my-5" />
            {utilization.iops_utilization_pct != null && (
                <UtilBar label="IOPS Utilization" value={utilization.iops_utilization_pct} max={100} unit="%" />
            )}
            <div className="mt-5" />
            <MetaRow label="Avg Read IOPS" value={utilization.avg_read_iops != null ? Number(utilization.avg_read_iops).toFixed(1) : "—"} />
            <MetaRow label="Avg Write IOPS" value={utilization.avg_write_iops != null ? Number(utilization.avg_write_iops).toFixed(1) : "—"} />
            <MetaRow label="Avg Free Memory" value={utilization.avg_freeable_memory_bytes != null ? `${(utilization.avg_freeable_memory_bytes / 1073741824).toFixed(2)} GB` : "—"} />
        </div>
    </div>
);

const StorageBackupTab = ({ storageType, allocatedStorageGb, maxAllocatedStorageGb, provisionedIops, storageThroughput, storageEncrypted, backupRetentionPeriod, backupWindow, maintenanceWindow, instanceCreateTime, ageDays, deletionProtection }) => (
    <div className="space-y-6">
        <div className="grid grid-cols-1 gap-7">
            <div>
                <SectionLabel>Storage</SectionLabel>
                <MetaRow label="Storage Type" value={storageType} bold />
                <MetaRow label="Allocated Storage" value={allocatedStorageGb ? `${allocatedStorageGb} GB` : "—"} bold />
                <MetaRow label="Max Allocated Storage" value={maxAllocatedStorageGb ? `${maxAllocatedStorageGb} GB` : "—"} />
                <MetaRow label="Provisioned IOPS" value={provisionedIops || "—"} />
                <MetaRow label="Storage Throughput" value={storageThroughput ? `${storageThroughput} MB/s` : "—"} />
                <MetaRow label="Encrypted" value={storageEncrypted ? "Yes" : "No"} color={storageEncrypted ? "text-emerald-700 font-semibold" : "text-amber-700 font-semibold"} />
            </div>
            <div>
                <SectionLabel>Backup & Maintenance</SectionLabel>
                <MetaRow label="Backup Retention" value={backupRetentionPeriod ? `${backupRetentionPeriod} days` : "—"} />
                <MetaRow label="Backup Window" value={backupWindow} />
                <MetaRow label="Maintenance Window" value={maintenanceWindow} />
            </div>
            <div>
                <SectionLabel>Lifecycle</SectionLabel>
                <MetaRow label="Created At" value={instanceCreateTime} />
                <MetaRow label="Age" value={ageDays != null ? `${ageDays} days` : "—"} />
                <MetaRow label="Deletion Protection" value={deletionProtection ? "Enabled" : "Disabled"} color={deletionProtection ? "text-emerald-700 font-semibold" : ""} />
            </div>
        </div>
    </div>
);

const CostFinOpsTab = ({ computeCost, storageCost, iopsCost, backupCost, transferCost, totalCost, finopsFlags, savingsPotential, onSuggest }) => (
    <div className="space-y-6">
        <div>
            <SectionLabel>Cost Breakdown (30d)</SectionLabel>
            <MetaRow label="Compute Cost" value={`$${computeCost.toFixed(2)}`} />
            <MetaRow label="Storage Cost" value={`$${storageCost.toFixed(2)}`} />
            <MetaRow label="IOPS Cost" value={`$${iopsCost.toFixed(2)}`} />
            <MetaRow label="Backup Cost" value={`$${backupCost.toFixed(2)}`} />
            <MetaRow label="Data Transfer Cost" value={`$${transferCost.toFixed(2)}`} />
            <MetaRow label="Total Cost" value={`$${totalCost.toFixed(2)}`} bold color="text-emerald-700" />
        </div>

        {(finopsFlags.length > 0 || savingsPotential > 0) && (
            <div>
                <SectionLabel>Optimization & Savings</SectionLabel>
                {savingsPotential > 0 && (
                    <button
                        type="button"
                        onClick={() => onSuggest(`Estimated monthly savings: $${Number(savingsPotential).toFixed(2)}`)}
                        title="Click to add as suggestion"
                        className="w-full text-left mb-4 bg-emerald-50 border border-emerald-200/60 rounded-lg px-4 py-3 flex items-center gap-3 cursor-pointer hover:border-emerald-400 transition-colors focus:outline-none">
                        <DollarSign size={18} className="text-emerald-600 shrink-0" />
                        <div>
                            <p className="text-[10px] font-bold text-emerald-800 uppercase">Estimated Monthly Savings</p>
                            <p className="text-xl font-black text-emerald-700">${savingsPotential.toFixed(2)}</p>
                        </div>
                    </button>
                )}
                <FinOpsFlagsContainer flags={finopsFlags} onSuggest={onSuggest} />
            </div>
        )}
    </div>
);

const SecurityObsTab = ({ storageEncrypted, caCertificateIdentifier, iamDbAuthEnabled, publiclyAccessible, performanceInsightsEnabled, performanceInsightsRetention, enhancedMonitoringInterval }) => (
    <div className="space-y-6">
        <div className="grid grid-cols-1 gap-7">
            <div>
                <SectionLabel>Security</SectionLabel>
                <MetaRow label="Storage Encrypted" value={storageEncrypted ? "Yes" : "No"} color={storageEncrypted ? "text-emerald-700 font-semibold" : "text-amber-700 font-semibold"} />
                <MetaRow label="CA Certificate" value={caCertificateIdentifier} mono />
                <MetaRow label="IAM DB Auth" value={iamDbAuthEnabled ? "Enabled" : "Disabled"} />
                <MetaRow label="Publicly Accessible" value={publiclyAccessible ? "Yes" : "No"} color={publiclyAccessible ? "text-red-600 font-semibold" : "text-emerald-700 font-semibold"} />
            </div>
            <div>
                <SectionLabel>Observability</SectionLabel>
                <MetaRow label="Performance Insights" value={performanceInsightsEnabled ? "Enabled" : "Disabled"} color={performanceInsightsEnabled ? "text-emerald-700 font-semibold" : ""} />
                <MetaRow label="PI Retention" value={performanceInsightsRetention ? `${performanceInsightsRetention} days` : "—"} />
                <MetaRow label="Enhanced Monitoring (sec)" value={enhancedMonitoringInterval || "—"} />
            </div>
        </div>
    </div>
);

const TagsTab = ({ tags, tagsPage, setTagsPage }) => {
    const tagEntries = useMemo(() => Object.entries(tags || {}), [tags]);
    const totalPages = Math.max(1, Math.ceil(tagEntries.length / TAGS_PER_PAGE));
    const paginated = tagEntries.slice((tagsPage - 1) * TAGS_PER_PAGE, tagsPage * TAGS_PER_PAGE);

    return (
        <div>
            <SectionLabel>Resource Tags ({tagEntries.length})</SectionLabel>
            {paginated.length > 0 ? (
                <div className="space-y-1.5">
                    {paginated.map(([k, v]) => (
                        <div key={k} className="flex overflow-hidden border border-slate-200 rounded-lg">
                            <div className={`px-3.5 py-2.5 bg-white min-w-[140px] border-r border-slate-200 ${MONO} text-xs text-blue-700`}>{k}</div>
                            <div className="px-3.5 py-2.5 text-xs text-gray-900">{String(v)}</div>
                        </div>
                    ))}
                </div>
            ) : (
                <div className="text-center py-6 bg-white rounded-2xl border border-dashed border-gray-200">
                    <span className="text-xs text-gray-400">No resource tags available</span>
                </div>
            )}
            {tagEntries.length > TAGS_PER_PAGE && (
                <PaginationControls currentPage={tagsPage} totalPages={totalPages} onPageChange={setTagsPage} />
            )}
        </div>
    );
};

// ─────────────────────────────────────────────
// Main Drawer
// ─────────────────────────────────────────────

const TABS = [
    { id: "overview", label: "Overview", icon: Info },
    { id: "performance", label: "Performance", icon: Activity },
    { id: "storage_backup", label: "Storage & Backup", icon: HardDrive },
    { id: "cost_finops", label: "Cost & FinOps", icon: DollarSign },
    { id: "security_obs", label: "Security & Obs", icon: Lock },
    { id: "tags", label: "Tags", icon: Tag },
];

const RDSMetadataDrawer = ({ instance, onClose }) => {
    const [activeTab, setActiveTab] = useState("overview");
    const [tagsPage, setTagsPage] = useState(1);
    const [isSugOpen, setIsSugOpen] = useState(false);
    const [sugPrefill, setSugPrefill] = useState("");
    const openSuggestion = (text = "") => {
        setSugPrefill(text);
        setIsSugOpen(true);
    };

    const { suggestions } = useSuggestions();

    const extractId = (val) => {
        if (!val) return "";
        if (typeof val === "string" && val.startsWith("arn:")) {
            const parts = val.split(":");
            return parts[parts.length - 1];
        }
        return val;
    };

    const rawInstanceId = instance?.instance_id || instance?.db_instance_id || "";
    const dbInstanceId = extractId(rawInstanceId);

    const { metadata: apiData, isMetadataLoading: isLoading } = useDatabase(dbInstanceId);
    const data = { ...instance, ...(Array.isArray(apiData) ? apiData[0] : apiData) };

    const resourceSuggestions = useMemo(() => {
        return (suggestions || []).filter(item =>
            String(item.service).toLowerCase() === "rds" &&
            item.scope === "resource" &&
            String(item.resource_id).toLowerCase() === String(dbInstanceId).toLowerCase()
        );
    }, [suggestions, dbInstanceId]);
    const [prevDbInstanceId, setPrevDbInstanceId] = useState(dbInstanceId);
    if (dbInstanceId !== prevDbInstanceId) {
        setPrevDbInstanceId(dbInstanceId);
        setActiveTab("overview");
        setTagsPage(1);
    }

    if (!instance) return null;

    const financials = data.financials || {};
    const meta = data.metadata || {};
    const engineBlock = meta.engine || {};
    const computeBlock = meta.compute || {};
    const storageBlock = meta.storage || {};
    const archBlock = meta.architecture || {};
    const backupBlock = meta.backup || {};
    const lifecycleBlock = meta.lifecycle || {};
    const obsBlock = meta.observability || {};
    const securityBlock = meta.security || {};
    const utilization = meta.utilization || {};
    const tags = meta.tags || data.tags || {};

    const engineName = engineBlock.engine || data.engine || "";
    const engineVersion = engineBlock.engine_version || data.engine_version || "";
    const licenseModel = engineBlock.license_model || data.license_model || "";
    const autoMinorVersionUpgrade = engineBlock.auto_minor_version_upgrade ?? data.auto_minor_version_upgrade;

    const instanceClass = computeBlock.instance_class || data.instance_class || data.instance_type || data.db_instance_class || "";
    const instanceFamily = computeBlock.instance_family || data.instance_family || "";
    const dbInstanceStatus = computeBlock.db_instance_status || data.db_instance_status || data.status || data.state || "";

    const storageType = storageBlock.storage_type || data.storage_type || "";
    const allocatedStorageGb = storageBlock.allocated_storage_gb || data.allocated_storage_gb || data.storage_gb || data.size_gb || 0;
    const maxAllocatedStorageGb = storageBlock.max_allocated_storage_gb || data.max_allocated_storage_gb || 0;
    const provisionedIops = storageBlock.provisioned_iops || data.provisioned_iops;
    const storageThroughput = storageBlock.storage_throughput || data.storage_throughput;
    const storageEncrypted = storageBlock.storage_encrypted ?? securityBlock.storage_encrypted ?? data.storage_encrypted ?? data.encrypted;

    const multiAz = archBlock.multi_az ?? data.multi_az;
    const readReplicaCount = archBlock.read_replica_count ?? data.read_replica_count;
    const sourceDbInstanceId = archBlock.source_db_instance_id || data.source_db_instance_id || "";
    const publiclyAccessible = archBlock.publicly_accessible ?? securityBlock.publicly_accessible ?? data.publicly_accessible;

    const backupRetentionPeriod = backupBlock.backup_retention_period ?? data.backup_retention_period;
    const backupWindow = backupBlock.backup_window || data.backup_window || "";
    const maintenanceWindow = backupBlock.maintenance_window || data.maintenance_window || "";

    const instanceCreateTime = lifecycleBlock.instance_create_time || data.instance_create_time || "";
    const ageDays = lifecycleBlock.age_days ?? data.age_days;
    const deletionProtection = lifecycleBlock.deletion_protection ?? data.deletion_protection;

    const performanceInsightsEnabled = obsBlock.performance_insights_enabled ?? data.performance_insights_enabled;
    const performanceInsightsRetention = obsBlock.performance_insights_retention ?? data.performance_insights_retention;
    const enhancedMonitoringInterval = obsBlock.enhanced_monitoring_interval ?? data.enhanced_monitoring_interval;

    const caCertificateIdentifier = securityBlock.ca_certificate_identifier || data.ca_certificate_identifier || "";
    const iamDbAuthEnabled = securityBlock.iam_db_auth_enabled ?? data.iam_db_auth_enabled;

    const finopsFlags = data.finops_flags || [];
    const savingsPotential = Number(data.estimated_savings_potential || 0);

    const totalCost = Number(financials.total_cost_30d || data.total_cost || 0);
    const computeCost = Number(financials.compute_cost || 0);
    const storageCost = Number(financials.storage_cost || 0);
    const iopsCost = Number(financials.iops_cost || 0);
    const backupCost = Number(financials.backup_cost || 0);
    const transferCost = Number(financials.data_transfer_cost || 0);

    const kpis = [
        { label: "Total Cost", value: `$${totalCost.toFixed(2)}`, unit: "/mo", sub: "30d trailing" },
        { label: "Storage", value: allocatedStorageGb ? `${allocatedStorageGb}` : "—", unit: "GB", sub: storageType },
        { label: "Engine", value: engineName || "—", unit: "", sub: engineVersion },
        { label: "Savings", value: savingsPotential > 0 ? `$${savingsPotential.toFixed(2)}` : "$0.00", unit: "/mo", sub: "potential" },
    ];

    return (
        <>
            {/* Backdrop */}
            <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.3 }}
                className="fixed inset-0 z-[999] bg-black/20 backdrop-blur-[1px] h-full cursor-pointer" 
                onClick={onClose} 
            />

            {/* Panel */}
            <motion.div 
                initial={{ x: "100%" }}
                animate={{ x: 0 }}
                exit={{ x: "100%" }}
                transition={{ type: "tween", duration: 0.3 }}
                className="fixed right-0 top-0 h-screen w-[70%] max-w-full bg-white shadow-[-8px_0_32px_rgba(0,0,0,0.12)] z-[9999] border-l border-gray-100 flex flex-col"
            >

                {/* ── Header ── */}
                <div className="px-6 py-4 border-b border-slate-200 shrink-0 bg-white">
                    <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3.5">
                            <div className="w-9 h-9 rounded-lg bg-[#3367d6] flex items-center justify-center shrink-0 ">
                                <Database size={18} className="text-white" />
                            </div>
                            <div>
                                <div className="flex items-center gap-1.5 flex-wrap mb-0.5">
                                    <span className={`${MONO} text-[13px] font-semibold text-[var(--text-primary-color)] tracking-tight`}>
                                        {dbInstanceId || "-"}
                                    </span>
                                    {dbInstanceStatus && (
                                        <Badge variant={getStatusVariant(dbInstanceStatus)}>
                                            {dbInstanceStatus}
                                        </Badge>
                                    )}
                                </div>
                                <p className="text-xs text-[var(--text-secondary-color)]">
                                    {engineName && <span className="font-medium text-gray-600">{engineName} {engineVersion}</span>}
                                    {data.region && <span> · {data.region}</span>}
                                </p>
                            </div>
                        </div>
                        <div className="flex items-center gap-2">
                            <motion.button
                                whileHover={{ scale: 1.02 }}
                                whileTap={{ scale: 0.98 }}
                                onClick={() => openSuggestion("")}
                                className="flex items-center justify-center gap-2 px-4 py-2 bg-[var(--button-bg)] text-white text-xs font-bold rounded-lg  hover:bg-[var(--button-bg)]/90 transition-all cursor-pointer uppercase tracking-wider shrink-0 mr-1"
                            >
                                <Pencil size={14} />
                                Add Suggestion
                            </motion.button>
                            <button
                                className="w-7 h-7 rounded border border-slate-200 flex items-center justify-center text-gray-400 hover:bg-white hover:text-gray-700 transition-colors cursor-pointer"
                                onClick={onClose}
                            >
                                <X size={14} />
                            </button>
                        </div>
                    </div>
                </div>

                {/* ── KPI strip ── */}
                {isLoading ? (
                    <div className="grid grid-cols-4 gap-2 px-6 py-3 border-b border-slate-200 shrink-0">
                        {Array.from({ length: 4 }).map((_, i) => (
                            <div key={i} className="h-14 bg-gray-100 rounded-lg animate-pulse" />
                        ))}
                    </div>
                ) : (
                    <div className="grid grid-cols-4 gap-2 px-6 py-3 border-b border-slate-200 shrink-0">
                        {kpis.map((k) => <KpiCard variant="compact" key={k.label} {...k} />)}
                    </div>
                )}

                <div className="px-6 py-1">
                    {resourceSuggestions && resourceSuggestions.length > 0 && (
                        <div className="">
                            <div className="flex justify-between items-center">
                                <SectionLabel>Suggestions</SectionLabel>
                                <Link to="/recommendation">
                                    <button className="text-xs font-bold text-indigo-600 hover:text-indigo-800 transition-colors cursor-pointer">
                                        View all
                                    </button>
                                </Link>
                            </div>
                            <div className="space-y-2.5">
                                {resourceSuggestions.slice(0, 1).map((item) => {
                                    const { title, desc } = splitSuggestionText(item.text);
                                    return (
                                        <div key={item.id} className="bg-white/50 border border-slate-200 rounded-lg p-3">
                                            <p className="text-xs font-bold text-gray-900 leading-snug">{title}</p>
                                            {desc && <p className="text-[11px] text-gray-500 mt-1 leading-relaxed whitespace-pre-line">{desc}</p>}
                                            <div className="flex items-center gap-1.5 mt-2 text-[10px] text-gray-400 font-medium">
                                                <span>By {item.created_by || "User"}</span>
                                                <span>·</span>
                                                <span>{new Date(item.created_at).toLocaleDateString()}</span>
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>
                        </div>
                    )}
                </div>

                {/* ── Tab bar ── */}
                <div className="flex border-b border-slate-200 px-6 mt-2.5 shrink-0 gap-0.5 overflow-x-auto scrollbar-none">
                    {TABS.map((t) => {
                        const Icon = t.icon;
                        const isActive = activeTab === t.id;
                        return (
                            <button
                                key={t.id}
                                onClick={() => setActiveTab(t.id)}
                                className={`flex items-center gap-1.5 px-3.5 py-2.5 text-xs whitespace-nowrap border-b-2 transition-colors cursor-pointer -mb-px ${isActive
                                    ? "border-[var(--button-bg)] font-semibold text-[var(--button-bg)]"
                                    : "border-transparent text-gray-500 hover:text-gray-900 font-normal"
                                    }`}
                            >
                                <Icon size={13} />
                                {t.label}
                                {t.id === "tags" && Object.keys(tags || {}).length > 0 && (
                                    <span className="ml-0.5 text-[9px] font-bold px-1.5 py-0.5 rounded-full bg-gray-100 text-gray-500">
                                        {Object.keys(tags).length}
                                    </span>
                                )}
                            </button>
                        );
                    })}
                </div>

                {/* ── Tab content ── */}
                <div className="flex-1 overflow-y-auto px-6 py-5">
                    {isLoading ? (
                        <div className="flex items-center justify-center py-16">
                            <div className="w-6 h-6 border-2 border-[var(--button-bg)] border-t-transparent rounded-full animate-spin mr-3" />
                            <span className="text-sm text-gray-500">Fetching instance details...</span>
                        </div>
                    ) : (
                        <>
                            {activeTab === "overview" && <OverviewTab data={data} dbInstanceId={dbInstanceId} engineName={engineName} engineVersion={engineVersion} licenseModel={licenseModel} autoMinorVersionUpgrade={autoMinorVersionUpgrade} instanceClass={instanceClass} instanceFamily={instanceFamily} dbInstanceStatus={dbInstanceStatus} multiAz={multiAz} readReplicaCount={readReplicaCount} sourceDbInstanceId={sourceDbInstanceId} publiclyAccessible={publiclyAccessible} />}
                            {activeTab === "performance" && <PerformanceTab utilization={utilization} />}
                            {activeTab === "storage_backup" && <StorageBackupTab storageType={storageType} allocatedStorageGb={allocatedStorageGb} maxAllocatedStorageGb={maxAllocatedStorageGb} provisionedIops={provisionedIops} storageThroughput={storageThroughput} storageEncrypted={storageEncrypted} backupRetentionPeriod={backupRetentionPeriod} backupWindow={backupWindow} maintenanceWindow={maintenanceWindow} instanceCreateTime={instanceCreateTime} ageDays={ageDays} deletionProtection={deletionProtection} />}
                            {activeTab === "cost_finops" && <CostFinOpsTab computeCost={computeCost} storageCost={storageCost} iopsCost={iopsCost} backupCost={backupCost} transferCost={transferCost} totalCost={totalCost} finopsFlags={finopsFlags} savingsPotential={savingsPotential} onSuggest={openSuggestion} />}
                            {activeTab === "security_obs" && <SecurityObsTab storageEncrypted={storageEncrypted} caCertificateIdentifier={caCertificateIdentifier} iamDbAuthEnabled={iamDbAuthEnabled} publiclyAccessible={publiclyAccessible} performanceInsightsEnabled={performanceInsightsEnabled} performanceInsightsRetention={performanceInsightsRetention} enhancedMonitoringInterval={enhancedMonitoringInterval} />}
                            {activeTab === "tags" && <TagsTab tags={tags} tagsPage={tagsPage} setTagsPage={setTagsPage} />}
                        </>
                    )}
                </div>
            </motion.div>
            <AddSuggestionModal
                isOpen={isSugOpen}
                onClose={() => setIsSugOpen(false)}
                service="rds"
                scope="resource"
                resourceId={dbInstanceId}
                resourceName={dbInstanceId}
                initialText={sugPrefill}
            />
        </>
    );
};

export default RDSMetadataDrawer;


