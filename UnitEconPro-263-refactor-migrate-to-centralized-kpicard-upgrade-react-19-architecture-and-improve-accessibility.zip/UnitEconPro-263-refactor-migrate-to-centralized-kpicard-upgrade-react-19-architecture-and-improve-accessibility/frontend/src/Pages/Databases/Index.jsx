import { Outlet } from "react-router-dom";
import SubPageTabs from "../../common/SubPageTabs";
const Databases = () => {
    return (
        <div className="w-full min-h-screen space-y-2 px-6 py-2">
            <title>Databases | SpendSmart</title>
            <meta name="description" content="Analyze and optimize your cloud database spending." />
            <SubPageTabs />
            <div className="mb-4 mt-4">
                <Outlet />
            </div>
        </div>
    );
};

export default Databases;
