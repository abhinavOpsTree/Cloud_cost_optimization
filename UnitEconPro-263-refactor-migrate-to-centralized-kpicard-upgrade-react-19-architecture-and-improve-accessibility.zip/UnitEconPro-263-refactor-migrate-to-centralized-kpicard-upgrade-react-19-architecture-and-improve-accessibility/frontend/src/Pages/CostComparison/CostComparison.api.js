import { apiRequest } from "../../lib/apiClient";
import { API_ENDPOINTS } from "../../APIs/ApiEndPoint";

/**
 * Fetches the overall cost comparison summary between two dates.
 * NOTE: The backend API endpoint `/api/v1/comparison/summary` strictly requires 
 * query parameters `day_a` and `day_b` (in YYYY-MM-DD format). We explicitly map 
 * `filters.start_date` to `day_a` and `filters.end_date` to `day_b` to avoid HTTP 422 errors.
 */
export const getCostComparisonSummary = async (filters) => {
    const params = new URLSearchParams();
    if (filters.compare_date_a) params.append("day_a", filters.compare_date_a);
    if (filters.compare_date_b) params.append("day_b", filters.compare_date_b);

    const account = filters.account || filters.account_name;
    if (account) params.append("account", account);

    return apiRequest({ endpoint: `${API_ENDPOINTS.comparsionSummary}?${params.toString()}` });
};


export const getCostComparisonDetails = async (filters) => {
    const params = new URLSearchParams();
    if (filters.compare_date_a) params.append("day_a", filters.compare_date_a);
    if (filters.compare_date_b) params.append("day_b", filters.compare_date_b);

    const account = filters.account || filters.account_name;
    if (account) params.append("account", account);

    if (filters.service) params.append("service", filters.service);

    return apiRequest({ endpoint: `${API_ENDPOINTS.comparsionDetails}?${params.toString()}` });
};
