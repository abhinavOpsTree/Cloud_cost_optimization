import { useState, useEffect, useRef, useMemo, memo } from 'react';
import { motion } from 'framer-motion';
import Highcharts from 'highcharts';
import HighchartsReact from 'highcharts-react-official';
import highchartsMore from 'highcharts/highcharts-more';

const initHighchartsMore = highchartsMore.default || highchartsMore;
if (typeof initHighchartsMore === 'function') {
    initHighchartsMore(Highcharts);
}
import { Info } from 'lucide-react';
import { useFilters } from '../../hooks/useFilters';
import dayjs from 'dayjs';
import { useComparison } from '../../hooks/useComparison';
import { LocalizationProvider, DatePicker } from '@mui/x-date-pickers';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import Table from '../../common/Table';
import PaginationControls from '../../common/PaginationControls';
import MetricBadge from '../../common/MetricBadge';
import { KpiCard } from '../../components/common/KpiCard';

// Pure formatter, hoisted to module scope so the memoized cards below don't
// depend on a function recreated every render.
const formatDelta = (val) => {
    if (val === 0) return '$0.00';
    const isNegative = val < 0;
    const formatted = Math.abs(val).toFixed(2);
    return `${isNegative ? '-' : '+'}$${formatted}`;
};

// Static placeholder data for the ghost (no-data) chart state — one allocation.
const GHOST_CATEGORIES = ["12 AM", "4 AM", "8 AM", "12 PM", "4 PM", "8 PM", "11 PM"];
const GHOST_DUMMY_DATA = [10, 15, 20, 15, 25, 30, 20];

// Static MUI date-picker tailwind class mapping
const DATE_PICKER_CLASS = [
    "[&_.MuiOutlinedInput-root]:rounded-md",
    "[&_.MuiOutlinedInput-root]:bg-gray-50",
    "[&_.MuiOutlinedInput-root]:h-[36px]",
    "[&_.MuiOutlinedInput-notchedOutline]:border-black/20",
    "hover:[&_.MuiOutlinedInput-notchedOutline]:border-black/30",
    "[&_.MuiOutlinedInput-root.Mui-focused_.MuiOutlinedInput-notchedOutline]:border-blue-500",
    "[&_.MuiOutlinedInput-root.Mui-focused_.MuiOutlinedInput-notchedOutline]:border",
    "[&_.MuiInputBase-root]:text-[12px]",
    "[&_.MuiInputLabel-root]:text-[12px]",
    "[&_.MuiInputLabel-root]:translate-x-[14px]",
    "[&_.MuiInputLabel-root]:translate-y-[8px]",
    "[&_.MuiInputLabel-root.Mui-focused]:translate-y-[-9px]",
    "[&_.MuiInputLabel-root.Mui-focused]:scale-75",
    "[&_.MuiInputLabel-root.MuiInputLabel-shrink]:translate-y-[-9px]",
    "[&_.MuiInputLabel-root.MuiInputLabel-shrink]:scale-75"
].join(" ");

const CustomDropdown = ({ value, onChange, options, placeholder, className }) => {
    const [isOpen, setIsOpen] = useState(false);
    const dropdownRef = useRef(null);

    useEffect(() => {
        if (!isOpen) return;
        const handleOutsideClick = (e) => {
            if (dropdownRef.current && !dropdownRef.current.contains(e.target)) {
                setIsOpen(false);
            }
        };
        window.addEventListener("mousedown", handleOutsideClick);
        return () => window.removeEventListener("mousedown", handleOutsideClick);
    }, [isOpen]);

    const selectedOption = options.find(opt => opt.value === value);
    const displayLabel = selectedOption ? selectedOption.label : placeholder;

    return (
        <div className="relative shrink-0" ref={dropdownRef}>
            <button
                type="button"
                onClick={() => setIsOpen(!isOpen)}
                className={`flex items-center justify-between gap-2 appearance-none text-[13px] font-medium text-accents-5 bg-[var(--accents-1)] ring-1 ring-black/20 hover:ring-black/30 shadow-geist-border hover:text-geist-foreground rounded-[6px] px-3 h-[40px] cursor-pointer focus:outline-none transition-all duration-200 relative ${className || ""}`}
            >
                <span className={`truncate ${!selectedOption && "text-accents-4"}`}>
                    {displayLabel}
                </span>
                <svg className={`w-4 h-4 text-accents-3 transition-transform duration-200 ${isOpen ? "rotate-180" : ""}`} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    <path d="m6 9 6 6 6-6" />
                </svg>
            </button>

            {/* Open/close animation: 200ms over opacity/translate/scale/visibility.
                NOTE: Tailwind v4 translate and scale utilities animate the modern
                `translate`/`scale` CSS properties — NOT `transform` — so those two
                must be named in the transition list or they snap instead of easing. */}
            <div
                className={`absolute left-0 min-w-full top-full mt-1.5 bg-white border border-neutral-200 rounded-lg shadow-lg py-1 overflow-y-auto max-h-[300px] z-50 transition-[opacity,translate,scale,visibility] duration-200 origin-top ${
                    isOpen ? "opacity-100 visible translate-y-0 scale-100" : "opacity-0 invisible pointer-events-none -translate-y-1.5 scale-95"
                }`}
            >
                {options.map((opt) => (
                    <button
                        key={opt.value}
                        type="button"
                        onClick={() => {
                            onChange(opt.value);
                            setIsOpen(false);
                        }}
                        className={`w-full text-left px-3 py-2 text-xs font-semibold transition-colors whitespace-nowrap ${
                            value === opt.value
                                ? "bg-neutral-100/80 text-neutral-900 font-bold"
                                : "text-neutral-500 hover:bg-neutral-50 hover:text-neutral-800"
                        }`}
                    >
                        {opt.label}
                    </button>
                ))}
            </div>
        </div>
    );
};

const CostComparison = () => {
    const { summaryData, detailsData, isLoading, isError } = useComparison();
    const { filters, setFilters } = useFilters();
    const [breakdownView, setBreakdownView] = useState('Service');
    const [currentPage, setCurrentPage] = useState(1);
    const [quickSelect, setQuickSelect] = useState("");

    const handleViewChange = (view) => {
        setBreakdownView(view);
        setCurrentPage(1);
    };

    const handleStartDateChange = (newValue) => {
        if (newValue && newValue.isValid()) {
            setFilters(prev => ({
                ...prev,
                compare_date_a: newValue.format('YYYY-MM-DD')
            }));
            setQuickSelect(""); // Reset dropdown if user manually picks a date
        }
    };

    const handleEndDateChange = (newValue) => {
        if (newValue && newValue.isValid()) {
            setFilters(prev => ({
                ...prev,
                compare_date_b: newValue.format('YYYY-MM-DD')
            }));
            setQuickSelect(""); // Reset dropdown if user manually picks a date
        }
    };

    const handleQuickSelect = (e) => {
        const value = e.target.value;
        if (!value) return;
        
        const currentDate = filters.compare_date_b ? dayjs(filters.compare_date_b) : dayjs();
        let priorDate = null;

        switch (value) {
            case 'yesterday':
                priorDate = currentDate.subtract(1, 'day');
                break;
            case 'last_week':
                priorDate = currentDate.subtract(7, 'day');
                break;
            case 'last_month':
                priorDate = currentDate.subtract(1, 'month');
                break;
            case 'last_quarter':
                priorDate = currentDate.subtract(3, 'month');
                break;
            case 'last_year':
                priorDate = currentDate.subtract(1, 'year');
                break;
            default:
                return;
        }

        setFilters(prev => ({
            ...prev,
            compare_date_a: priorDate.format('YYYY-MM-DD')
        }));
        
        setQuickSelect(value);
    };

    const handleServiceChange = (e) => {
        setFilters(prev => ({
            ...prev,
            service: e.target.value === 'all' ? '' : e.target.value
        }));
    };

    // Rules of Hooks: the useMemo calls below must run on EVERY render, so all
    // derived data lives above the loading/error early returns (which now sit
    // after the last hook). The `?? {}` fallback keeps the derivations null-safe
    // while data is still loading; their outputs are discarded on those renders.
    const displayData = useMemo(() => {
        return ((filters.service && detailsData) ? detailsData : summaryData) ?? {};
    }, [filters.service, detailsData, summaryData]);

    const dateAText = displayData.day_a ? dayjs(displayData.day_a).format('MMM D, YYYY') : '';
    const dateBText = displayData.day_b ? dayjs(displayData.day_b).format('MMM D, YYYY') : '';
    const headerSubtitle = dateAText && dateBText ? `Prior (${dateAText}) vs Current (${dateBText})` : 'Compare daily costs';

    const costA = displayData.cost_a ?? 0;
    const costB = displayData.cost_b ?? 0;
    const rawDelta = costB - costA;
    const isIncrease = rawDelta > 0;
    const pctChange = displayData.pct_change ?? 0;

    const cardLabelA = displayData.day_a ? dayjs(displayData.day_a).format('DD MMM YYYY') : 'DATE A';
    const cardLabelB = displayData.day_b ? dayjs(displayData.day_b).format('DD MMM YYYY') : 'DATE B';

    // Perf: memoized so the stat-card list — and the hourly peak scan feeding it —
    // recomputes only when the comparison data changes, not on every re-render
    // (this component re-renders on every dropdown/date-picker interaction).
    const cards = useMemo(() => {
        let overallPeakDay = 'N/A';
        let overallPeakHour = '';
        let overallPeakValue = 0;

        if (displayData.hourly && displayData.hourly.length > 0) {
            displayData.hourly.forEach(h => {
                const ampm = h.hour >= 12 ? 'PM' : 'AM';
                const displayHour = h.hour % 12 === 0 ? 12 : h.hour % 12;
                const hourStr = `@ ${displayHour} ${ampm}`;

                if (h.cost_a > overallPeakValue) {
                    overallPeakValue = h.cost_a;
                    overallPeakDay = cardLabelA;
                    overallPeakHour = hourStr;
                }
                if (h.cost_b > overallPeakValue) {
                    overallPeakValue = h.cost_b;
                    overallPeakDay = cardLabelB;
                    overallPeakHour = hourStr;
                }
            });
        }

        const avgDailyA = displayData.avg_daily_cost_month_a ?? displayData.avg_daily_cost_a;
        const avgDailyB = displayData.avg_daily_cost_month_b ?? displayData.avg_daily_cost_b;



        return [
            {
                label: `TOTAL — ${cardLabelA}`,
                value: `$${costA.toFixed(2)}`,
                subText: avgDailyA != null ? `Avg daily: $${Number(avgDailyA).toFixed(2)}` : null
            },
            {
                label: `TOTAL — ${cardLabelB}`,
                value: `$${costB.toFixed(2)}`,
                subText: avgDailyB != null ? `Avg daily: $${Number(avgDailyB).toFixed(2)}` : null
            },
            { label: 'NET DELTA', value: formatDelta(rawDelta), color: rawDelta > 0 ? 'text-red-500' : rawDelta < 0 ? 'text-emerald-500' : 'text-gray-500' },
            { label: `PEAK — ${overallPeakDay} ${overallPeakHour}`.trim(), value: `$${overallPeakValue.toFixed(2)}` }
        ];
    }, [displayData, cardLabelA, cardLabelB, costA, costB, rawDelta]);

    // Perf: memoized table configuration — previously an inline array literal in
    // JSX, which handed <Table> a brand-new columns prop on every render.
    // Recomputed only when the breakdown view or the compared dates change.
    const comparisonColumns = useMemo(() => [
        {
            label: 'Service',
            key: 'service',
            align: 'center',
            render: (_, row) => <span className="font-semibold text-blue-600">{row.service}</span>
        },
        ...(breakdownView === 'Operation' ? [{
            label: 'Operation',
            key: 'operation',
            align: 'center',
            render: (_, row) => <span className="text-gray-600">{row.operation}</span>
        }] : []),
        {
            label: displayData.day_a ? dayjs(displayData.day_a).format('DD MMM') : 'Day A',
            key: 'cost_a',
            align: 'center',
            render: (val) => <span className="text-gray-800 font-medium">${val?.toFixed(2)}</span>
        },
        {
            label: displayData.day_b ? dayjs(displayData.day_b).format('DD MMM') : 'Day B',
            key: 'cost_b',
            align: 'center',
            render: (val) => <span className="text-gray-800 font-medium">${val?.toFixed(2)}</span>
        },
        {
            label: 'Delta ($)',
            key: 'delta',
            align: 'center',
            render: (_, row) => {
                const itemDelta = row.cost_b - row.cost_a;
                return (
                    <MetricBadge value={itemDelta} zeroIsNeutral>
                        {itemDelta === 0 ? '$0.00' : `${itemDelta > 0 ? '+' : ''}$${itemDelta.toFixed(2)}`}
                    </MetricBadge>
                );
            }
        },
        {
            label: 'Change',
            key: 'change',
            align: 'center',
            render: (_, row) => {
                const itemPct = breakdownView === 'Operation'
                    ? (row.cost_a === 0 ? (row.cost_b > 0 ? 100 : 0) : ((row.cost_b - row.cost_a) / row.cost_a) * 100)
                    : (row.pct_change || 0);
                const isPositive = itemPct > 0;
                const isZero = itemPct === 0;
                return (
                    <div className="flex items-center justify-center gap-2">
                        <div className="w-16 h-1.5 rounded-full bg-gray-100 overflow-hidden relative">
                            <div className={`absolute top-0 left-0 h-full ${isPositive ? 'bg-red-300' : 'bg-emerald-300'}`} style={{ width: `${Math.min(Math.abs(itemPct), 100)}%` }}></div>
                        </div>
                        <span className={`text-[10px] font-bold ${isZero ? 'text-gray-500' : isPositive ? 'text-red-500' : 'text-emerald-500'}`}>
                            {isZero ? '0%' : `${itemPct > 0 ? '+' : ''}${itemPct.toFixed(1)}%`}
                        </span>
                    </div>
                );
            }
        }
    ], [breakdownView, displayData.day_a, displayData.day_b]);

    // Perf: the hourly series derivation — label building, ghost detection, and
    // the overspend/savings band construction with intersection-point math — is
    // the heaviest per-render work in this component. Memoized so it only reruns
    // when the hourly data itself changes.
    const { isChartGhost, chartCategories, overspendData, savingsData } = useMemo(() => {
        const hourly = displayData.hourly || [];

        const categories = hourly.map(h => {
            const hour = h.hour;
            const ampm = hour >= 12 ? 'PM' : 'AM';
            const displayHour = hour % 12 === 0 ? 12 : hour % 12;
            return `${displayHour} ${ampm}`;
        });

        const isChartGhost = hourly.length === 0 || hourly.every(h => Number(h.cost_a || 0) < 0.01 && Number(h.cost_b || 0) < 0.01);
        const chartCategories = isChartGhost ? GHOST_CATEGORIES : categories;

        const overspendData = [];
        const savingsData = [];

        for (let i = 0; i < hourly.length; i++) {
            const current = hourly[i];
            const a1 = current.cost_a;
            const b1 = current.cost_b;

            if (b1 >= a1) {
                overspendData.push([i, a1, b1]);
                savingsData.push([i, a1, a1]);
            } else {
                overspendData.push([i, a1, a1]);
                savingsData.push([i, b1, a1]); // low=b1, high=a1
            }

            if (i < hourly.length - 1) {
                const next = hourly[i + 1];
                const a2 = next.cost_a;
                const b2 = next.cost_b;

                const diff1 = b1 - a1;
                const diff2 = b2 - a2;

                if (diff1 * diff2 < 0) {
                    const t = diff1 / (diff1 - diff2);
                    const xIntersect = i + t;
                    const yIntersect = a1 + (a2 - a1) * t;

                    overspendData.push([xIntersect, yIntersect, yIntersect]);
                    savingsData.push([xIntersect, yIntersect, yIntersect]);
                }
            }
        }

        return { isChartGhost, chartCategories, overspendData, savingsData };
    }, [displayData.hourly]);

    // Perf: memoized Highcharts config — rebuilding this object every render makes
    // HighchartsReact diff/redraw the whole chart on unrelated state changes
    // (dropdowns, pagination). Now it only rebuilds when its inputs change.
    const lineChartOptions = useMemo(() => ({
        chart: {
            type: 'area',
            backgroundColor: 'transparent',
            height: 300,
            spacing: [20, 0, 20, 0]
        },
        title: { text: null },
        credits: { enabled: false },
        xAxis: {
            categories: chartCategories,
            labels: { style: { color: '#9ca3af', fontSize: '10px' } },
            lineWidth: 0,
            tickWidth: 0,
            gridLineWidth: 1,
            gridLineColor: 'rgba(0,0,0,0.03)',
            gridLineDashStyle: 'Dash'
        },
        yAxis: {
            title: { text: null },
            labels: {
                format: '${value}',
                style: { color: '#9ca3af', fontSize: '10px' }
            },
            gridLineWidth: 1,
            gridLineColor: 'rgba(0,0,0,0.03)',
            gridLineDashStyle: 'Dash'
        },
        legend: {
            enabled: !isChartGhost,
            align: 'right',
            verticalAlign: 'top',
            layout: 'horizontal',
            itemStyle: { fontSize: '10px', color: '#4b5563' },
            symbolRadius: 2
        },
        tooltip: {
            enabled: !isChartGhost,
            shared: true,
            useHTML: true,
            animation: false,
            backgroundColor: 'transparent',
            borderWidth: 0,
            shadow: false,
            borderRadius: 8,
            style: { color: '#111827', pointerEvents: 'none' },
            formatter: function () {
                let s = `<div class="glassy-tooltip">`;
                s += `<b style="display: block; margin-bottom: 4px;">${this.x}</b>`;
                let costA = 0;
                let costB = 0;
                let foundA = false;
                let foundB = false;

                this.points.forEach(point => {
                    if (point.series.userOptions.isDateA) {
                        costA = point.y;
                        foundA = true;
                        s += `<span style="color:${point.color}">\u25CF</span> ${point.series.name}: $${point.y.toFixed(2)}<br/>`;
                    } else if (point.series.userOptions.isDateB) {
                        costB = point.y;
                        foundB = true;
                        s += `<span style="color:${point.color}">\u25CF</span> ${point.series.name}: $${point.y.toFixed(2)}<br/>`;
                    }
                });

                if (foundA && foundB) {
                    const delta = costB - costA;
                    const deltaColor = delta > 0 ? '#ef4444' : delta < 0 ? '#10b981' : '#9ca3af'; // red positive, green negative
                    const sign = delta > 0 ? '+' : delta < 0 ? '-' : '';
                    s += `<br/><span style="color:${deltaColor}">\u25CF</span> Delta: ${sign}$${Math.abs(delta).toFixed(2)}`;
                }
                
                s += `</div>`;
                return s;
            }
        },
        plotOptions: {
            series: {
                enableMouseTracking: !isChartGhost,
                states: {
                    inactive: {
                        opacity: 1
                    }
                }
            },
            area: {
                marker: { enabled: false },
                lineWidth: 2
            },
            arearange: {
                lineWidth: 0,
                marker: {
                    enabled: false,
                    states: { hover: { enabled: false } }
                },
                trackByArea: false,
                enableMouseTracking: false
            }
        },
        series: isChartGhost ? [
            {
                type: 'area',
                name: 'No Data',
                showInLegend: false,
                color: '#cbd5e1',
                fillColor: {
                    linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
                    stops: [
                        [0, 'rgba(203, 213, 225, 0.2)'],
                        [1, 'rgba(203, 213, 225, 0)']
                    ]
                },
                data: GHOST_DUMMY_DATA,
                zIndex: 1
            }
        ] : [
            {
                type: 'arearange',
                name: 'Overspend',
                showInLegend: false,
                color: '#ef4444',
                fillOpacity: 0.3,
                data: overspendData,
                zIndex: 0
            },
            {
                type: 'arearange',
                name: 'Savings',
                showInLegend: false,
                color: '#10b981',
                fillOpacity: 0.3,
                data: savingsData,
                zIndex: 0
            },
            {
                name: displayData.day_b ? `${dayjs(displayData.day_b).format('MMM D')}` : 'Date B',
                isDateB: true,
                color: '#3b82f6',
                fillColor: {
                    linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
                    stops: [
                        [0, 'rgba(59, 130, 246, 0.1)'],
                        [1, 'rgba(59, 130, 246, 0)']
                    ]
                },
                data: displayData.hourly?.map(h => h.cost_b) || [],
                zIndex: 1
            },
            {
                name: displayData.day_a ? `${dayjs(displayData.day_a).format('MMM D')}` : 'Date A',
                isDateA: true,
                color: '#a855f7',
                dashStyle: 'Dash',
                fillColor: {
                    linearGradient: { x1: 0, y1: 0, x2: 0, y2: 1 },
                    stops: [
                        [0, 'rgba(168, 85, 247, 0.08)'],
                        [1, 'rgba(168, 85, 247, 0)']
                    ]
                },
                data: displayData.hourly?.map(h => h.cost_a) || [],
                zIndex: 1
            }
        ]
    }), [isChartGhost, chartCategories, overspendData, savingsData, displayData.hourly, displayData.day_a, displayData.day_b]);

    // Early returns AFTER all hooks (Rules of Hooks).
    if (isLoading) {
        return (
            <div className="flex justify-center items-center h-96 bg-white">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-500" />
            </div>
        );
    }

    if (isError || !summaryData) {
        return (
            <div className="flex flex-col justify-center items-center h-96 text-gray-500 bg-white">
                <p className="font-semibold text-sm text-[var(--text-primary-color)]">Failed to load cost comparison data.</p>
                <p className="text-xs mt-1 text-[var(--text-secondary-color)]">Please ensure you have selected a date range and an account.</p>
            </div>
        );
    }

    const absDeltaStr = `$${Math.abs(rawDelta).toFixed(2)}`;
    const absPctStr = `${Math.abs(pctChange).toFixed(0)}%`;

    return (
        <div className="p-4 bg-white min-h-screen text-gray-900 ">
            <title>Cost Comparison | SpendSmart</title>
            <meta name="description" content="Compare your cloud infrastructure costs with SpendSmart." />
            <style>
                {`
                    .highcharts-tooltip-container, .highcharts-tooltip {
                        pointer-events: none !important;
                    }
                    .glassy-tooltip {
                        background: rgba(255, 255, 255, 0.85);
                        backdrop-filter: blur(8px);
                        -webkit-backdrop-filter: blur(8px);
                        border: 1px solid rgba(0, 0, 0, 0.05);
                        border-radius: 8px;
                        padding: 10px 14px;
                        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
                        font-family: inherit;
                        pointer-events: none;
                    }
                `}
            </style>
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
                <div>
                    <h1 className="text-md font-bold text-gray-900">Cost comparison</h1>
                    <p className="text-xs text-gray-500 mt-1">{headerSubtitle}</p>
                </div>
                <LocalizationProvider dateAdapter={AdapterDayjs}>
                    <div className="flex gap-3 items-center">
                        <CustomDropdown
                            value={quickSelect}
                            onChange={(val) => handleQuickSelect({ target: { value: val }})}
                            placeholder="Quick Select"
                            options={[
                                { label: "Yesterday", value: "yesterday" },
                                { label: "Last Week", value: "last_week" },
                                { label: "Last Month", value: "last_month" },
                                { label: "Last Quarter", value: "last_quarter" },
                                { label: "Last Year", value: "last_year" }
                            ]}
                            className="min-w-[130px]"
                        />
                        <DatePicker
                            label="Prior Date"
                            value={filters.compare_date_a ? dayjs(filters.compare_date_a) : null}
                            onChange={handleStartDateChange}
                            maxDate={filters.compare_date_b ? dayjs(filters.compare_date_b).subtract(1, 'day') : dayjs()}
                            slotProps={{
                                textField: {
                                    size: 'small',
                                    className: DATE_PICKER_CLASS,
                                }
                            }}
                        />
                        <DatePicker
                            label="Current Date"
                            value={filters.compare_date_b ? dayjs(filters.compare_date_b) : null}
                            onChange={handleEndDateChange}
                            minDate={filters.compare_date_a ? dayjs(filters.compare_date_a).add(1, 'day') : null}
                            maxDate={dayjs()}
                            slotProps={{
                                textField: {
                                    size: 'small',
                                    className: DATE_PICKER_CLASS,
                                }
                            }}
                        />
                        <CustomDropdown
                            value={filters.service || 'all'}
                            onChange={(val) => handleServiceChange({ target: { value: val }})}
                            placeholder="All Services"
                            options={[
                                { label: "All Services", value: "all" },
                                ...(summaryData.available_services || []).map(svc => ({ label: svc, value: svc }))
                            ]}
                            className="min-w-[140px]"
                        />
                    </div>
                </LocalizationProvider>
            </div>
            {rawDelta !== 0 && (
                <div className={`border rounded-xl p-3 mb-8 flex justify-between items-center shadow-[var(--shadow)] ring-[.5px] ring-black/10 ${isIncrease
                    ? 'bg-red-50/40 border-red-100 ring-red-500/10'
                    : 'bg-emerald-50/40 border-emerald-100 ring-emerald-500/10'
                    }`}>
                    <div className="flex items-start gap-4">
                        <div className={`p-2 rounded-md mt-0.5 ${isIncrease ? 'bg-red-100 text-red-600' : 'bg-emerald-100 text-emerald-600'
                            }`}>
                            <Info size={14} />
                        </div>
                        <div>
                            <h3 className="text-sm font-bold text-[var(--text-primary-color)]">
                                {isIncrease
                                    ? `Spend increased by +${absDeltaStr} compared to prior period`
                                    : `Spend decreased by -${absDeltaStr} compared to prior period`
                                }
                            </h3>
                            <p className="text-xs text-[var(--text-secondary-color)] mt-0.5">
                                {dateBText} running {absPctStr} {isIncrease ? 'higher' : 'lower'} than {dateAText}
                            </p>
                        </div>
                    </div>
                    <div className={`text-md font-bold ${isIncrease ? 'text-red-500' : 'text-emerald-500'}`}>
                        {formatDelta(rawDelta)}
                    </div>
                </div>
            )}

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
                {cards.map((card, i) => (
                    <KpiCard 
                        key={i} 
                        variant="compact"
                        title={card.label}
                        value={card.value}
                        sub={card.subText}
                        valueColor={card.color}
                    />
                ))}
            </div>

            <div className="mb-8">
                <h2 className="text-sm font-bold text-[var(--text-primary-color)] mb-4 px-1">Daily cost — {dateBText} (current) vs {dateAText} (prior)</h2>
                <div className="bg-white border-0 rounded-md p-4 shadow-[var(--shadow)] ring-[.5px] ring-black/10 relative">
                    <HighchartsReact highcharts={Highcharts} options={lineChartOptions} />
                    {isChartGhost && (
                        <div className="absolute inset-0 z-10 flex flex-col items-center justify-center bg-white/20 backdrop-blur-[1.5px] rounded-md transition-opacity duration-300 pointer-events-none">
                            <span className="text-sm font-semibold text-gray-500 px-4 py-2 rounded-lg ">
                                No Data Available
                            </span>
                        </div>
                    )}
                </div>
            </div>

            <div className="bg-white rounded-md ring-[.5px] ring-black/10 shadow-[var(--shadow)] flex flex-col mt-8 mb-8">
                {/* Header */}
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center p-4 border-b border-gray-100 gap-4">
                    <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
                        <h2 className="text-sm font-bold text-[var(--text-primary-color)]">Cost breakdown</h2>
                        <div className="inline-flex p-1 bg-white rounded-comfortable w-fit ring-[.5px] ring-black/10 shadow-inner/2 rounded">
                            <button
                                onClick={() => handleViewChange('Service')}
                                className={`relative px-4 py-1 rounded text-sm font-medium transition-all ${breakdownView === 'Service' ? "text-[var(--text-primary-color)] shadow-geist-border" : "text-gray-500 hover:text-[var(--text-primary-color)]"}`}
                            >
                                {breakdownView === 'Service' && (
                                    <motion.div
                                        layoutId="breakdownTab"
                                        className="absolute inset-0 bg-white rounded-md ring-1 ring-black/10 shadow"
                                        initial={false}
                                        transition={{ type: "spring", bounce: 0.15, duration: 0.5 }}
                                    />
                                )}
                                <span className="relative z-10">By Service</span>
                            </button>
                            <button
                                onClick={() => handleViewChange('Operation')}
                                className={`relative px-4 py-1 rounded text-sm font-medium transition-all ${breakdownView === 'Operation' ? "text-[var(--text-primary-color)] shadow-geist-border" : "text-gray-500 hover:text-[var(--text-primary-color)]"}`}
                            >
                                {breakdownView === 'Operation' && (
                                    <motion.div
                                        layoutId="breakdownTab"
                                        className="absolute inset-0 bg-white rounded-md ring-1 ring-black/10 shadow"
                                        initial={false}
                                        transition={{ type: "spring", bounce: 0.15, duration: 0.5 }}
                                    />
                                )}
                                <span className="relative z-10">Top Δ Drivers</span>
                            </button>
                        </div>
                    </div>
                </div>

                {/* Table body */}
                <div className="p-4 pt-0">
                    <Table
                        columns={comparisonColumns}
                        data={(breakdownView === 'Operation' ? (displayData.top_drivers || []) : (displayData.by_service || [])).slice((currentPage - 1) * 10, currentPage * 10)}
                        rowKey={(row, idx) => `${row.service}-${row.operation || idx}`}
                    />
                    <PaginationControls
                        currentPage={currentPage}
                        totalPages={Math.ceil((breakdownView === 'Operation' ? (displayData.top_drivers || []) : (displayData.by_service || [])).length / 10)}
                        onPageChange={setCurrentPage}
                    />
                </div>
            </div>
        </div>
    );
}
export default memo(CostComparison);

