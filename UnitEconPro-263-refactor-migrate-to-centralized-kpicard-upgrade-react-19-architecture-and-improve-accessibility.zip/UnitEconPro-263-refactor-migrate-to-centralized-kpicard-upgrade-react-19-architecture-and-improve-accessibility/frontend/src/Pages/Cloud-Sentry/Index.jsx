import React from 'react';
import { Outlet, NavLink } from 'react-router-dom';
import { ShieldCheck, Bell, HelpCircle, ChevronDown } from 'lucide-react';

const tabs = [
  { name: 'Dashboard', path: 'dashboard' },
  { name: 'Recommendations', path: 'recommendations' },
  { name: 'Instances', path: 'instances' },
  { name: 'Tag Audit', path: 'tag-audit' },
  { name: 'Chatbot', path: 'chatbot' },
  { name: 'Audit log', path: 'audit-log' },
  { name: 'Skill Contribution', path: 'skill-contribution' }
];

export default function EmbeddedTabs() {
  return (
    <div className="flex flex-col h-full w-full bg-[#F4F7FE]">
      {/* Top Navigation Bar for Embedded Mode */}
      <div className="px-8 py-3 bg-white border-b border-gray-100 flex items-center justify-between shrink-0 gap-6">
        <div className="flex items-center gap-2.5 shrink-0">
          <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center">
            <ShieldCheck className="text-white" style={{ width: 18, height: 18 }} />
          </div>
          <div className="leading-tight">
            <p className="text-sm font-bold text-gray-900">Cloud Sentry</p>
            <p className="text-[11px] text-gray-400">by Opstree</p>
          </div>
        </div>

        <nav className="flex items-center gap-6 flex-1 overflow-x-auto" aria-label="Tabs">
          {tabs.map((tab) => (
            <NavLink
              key={tab.name}
              to={tab.path}
              className={({ isActive }) =>
                `py-1.5 text-sm font-medium whitespace-nowrap border-b-2 transition-colors ${
                  isActive
                    ? "text-blue-600 border-blue-600"
                    : "text-gray-500 border-transparent hover:text-gray-800"
                }`
              }
            >
              {tab.name}
            </NavLink>
          ))}
        </nav>

        <div className="flex items-center gap-3 shrink-0">
          <button className="w-8 h-8 rounded-full flex items-center justify-center text-gray-500 hover:bg-gray-100">
            <Bell style={{ width: 17, height: 17 }} />
          </button>
          <button className="w-8 h-8 rounded-full flex items-center justify-center text-gray-500 hover:bg-gray-100">
            <HelpCircle style={{ width: 17, height: 17 }} />
          </button>
          <button className="flex items-center gap-1 pl-0.5">
            <div className="w-8 h-8 rounded-full bg-blue-600 text-white flex items-center justify-center text-xs font-semibold">A</div>
            <ChevronDown className="w-3.5 h-3.5 text-gray-400" />
          </button>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 overflow-auto px-8 pb-8 pt-6">
        <Outlet />
      </div>
    </div>
  );
}
