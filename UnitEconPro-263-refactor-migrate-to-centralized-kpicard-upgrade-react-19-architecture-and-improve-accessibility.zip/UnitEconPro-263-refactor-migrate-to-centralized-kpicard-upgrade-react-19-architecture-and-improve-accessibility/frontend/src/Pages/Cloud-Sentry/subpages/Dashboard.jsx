import React, { useState, useRef, useEffect, useCallback, useMemo } from 'react';
import { Link } from 'react-router-dom';
import {
  DollarSign, TrendingUp, TrendingDown, Sparkles, Server, ShieldCheck, Gauge,
  Building2, ChevronDown, Play, ShieldAlert, Zap, Clock, Layers, MapPin, Info,
  CheckCircle2, PauseCircle,
} from 'lucide-react';
import { useCloudSentry } from '../../../hooks/Cloud-Sentry/useCloudSentry';
import { cloudSentryApi } from '../cloudSentry.api';
import GlassCard from '../components/common/GlassCard.jsx';
import TimeRangePicker from '../components/TimeRangePicker.jsx';

// Single-tenant pilot account (core/models.py ACCOUNT_NAME) — real accounts
// list should come from a backend endpoint once this is multi-tenant.
const ACCOUNTS = ['opstree'];

const TRACK_META = {
  rightsizing: { label: 'Rightsizing', icon: Server, color: 'text-blue-600', bg: 'bg-blue-100' },
  spot: { label: 'Spot conversions', icon: Zap, color: 'text-violet-600', bg: 'bg-violet-100' },
  schedule: { label: 'Scheduling', icon: Clock, color: 'text-amber-600', bg: 'bg-amber-100' },
  eks: { label: 'EKS recommendations', icon: Layers, color: 'text-teal-600', bg: 'bg-teal-100' },
  tagging: { label: 'Tagging', icon: ShieldCheck, color: 'text-gray-600', bg: 'bg-gray-100' },
};

// core/skill_registry.py's ANALYSIS_SKILLS → their TRACK — /api/skills doesn't
// expose this mapping itself, but the skill names and their tracks are fixed
// in that file, so this is a stable lookup, not a guess.
const SKILL_TRACK = {
  rightsizing: 'rightsizing',
  spot_conversion: 'spot',
  schedule_policy: 'schedule',
  eks_diagnosis: 'eks',
};

const money = (n) => `$${(n ?? 0).toLocaleString('en-US', { maximumFractionDigits: 2 })}`;
const average = (arr) => (arr.length ? arr.reduce((s, v) => s + v, 0) / arr.length : 0);
const mostCommon = (arr) => {
  if (!arr.length) return null;
  const counts = {};
  arr.forEach((v) => { if (v) counts[v] = (counts[v] || 0) + 1; });
  return Object.entries(counts).sort((a, b) => b[1] - a[1])[0]?.[0] || null;
};
// No backend field for a 0-10 priority score on Recommendation — this is a
// confidence-based heuristic, not a real prioritisation from the API.
const priorityFromConfidence = (c) => (c >= 0.9 ? 'High' : c >= 0.75 ? 'Medium' : 'Low');
const relativeTime = (iso) => {
  if (!iso) return null;
  const mins = Math.round((Date.now() - new Date(iso).getTime()) / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return `${mins} min ago`;
  const hrs = Math.round(mins / 60);
  return `${hrs} hr ago`;
};

function Delta({ deltaPct, direction, goodDirection }) {
  if (deltaPct == null) return null;
  const isGood = direction === goodDirection;
  const Icon = direction === 'up' ? TrendingUp : TrendingDown;
  return (
    <p className={`text-xs font-medium mt-2 flex items-center gap-1 ${isGood ? 'text-green-600' : 'text-red-600'}`}>
      <Icon className="w-3 h-3" />
      {Math.abs(deltaPct).toFixed(1)}%
      <span className="text-gray-400 font-normal">vs last month</span>
    </p>
  );
}

function KpiCard({ icon: Icon, iconBg, iconColor, label, value, unit, children }) {
  return (
    <GlassCard className="p-3 min-w-0">
      <div className="flex items-start gap-1.5 mb-3 min-w-0">
        <div className={`w-6 h-6 rounded-full flex items-center justify-center shrink-0 ${iconBg}`}>
          <Icon className={iconColor} style={{ width: 12, height: 12 }} />
        </div>
        <h3 className="text-gray-400 text-[10px] font-semibold uppercase leading-tight min-w-0 flex-1 pt-1">{label}</h3>
      </div>
      <p className="text-2xl font-bold text-gray-900">
        {value}{unit && <span className="text-sm font-semibold text-gray-500 ml-0.5">{unit}</span>}
      </p>
      {children}
    </GlassCard>
  );
}

function AccountSelector({ value, onChange }) {
  const [isOpen, setIsOpen] = useState(false);
  const wrapperRef = useRef(null);
  useEffect(() => {
    function handleClickOutside(e) {
      if (wrapperRef.current && !wrapperRef.current.contains(e.target)) setIsOpen(false);
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);
  return (
    <div className="relative inline-block text-left" ref={wrapperRef}>
      <button type="button" onClick={() => setIsOpen((o) => !o)}
        className="flex items-center gap-2 px-3 py-2 bg-white border border-gray-200 rounded-lg text-sm text-gray-700 shadow-sm hover:bg-gray-50">
        <Building2 className="w-4 h-4 text-gray-400" />
        {value}
        <ChevronDown className="w-4 h-4 text-gray-400" />
      </button>
      {isOpen && (
        <div className="origin-top-right absolute right-0 mt-2 w-48 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 z-50 py-1">
          {ACCOUNTS.map((acc) => (
            <button key={acc} onClick={() => { onChange(acc); setIsOpen(false); }}
              className={`w-full text-left px-3 py-2 text-sm hover:bg-blue-50 ${acc === value ? 'bg-blue-50 text-blue-700 font-medium' : 'text-gray-700'}`}>
              {acc}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function FleetPill({ icon: Icon, label, value, color, bg }) {
  return (
    <div className={`flex items-center gap-2 px-3 py-2 rounded-lg ${bg}`}>
      <Icon className={color} style={{ width: 15, height: 15 }} />
      <span className="text-xs font-medium text-gray-600">{label}</span>
      <span className={`text-sm font-bold ${color}`}>{value}</span>
    </div>
  );
}

function CategoryBar({ label, count, max }) {
  const pct = max > 0 ? Math.max(4, (count / max) * 100) : 0;
  return (
    <div className="flex items-center gap-3">
      <span className="text-sm text-gray-600 w-32 shrink-0">{label}</span>
      <div className="flex-1 h-2 rounded-full bg-blue-100">
        <div className="h-2 rounded-full bg-blue-600" style={{ width: `${pct}%` }} />
      </div>
      <span className="text-sm font-semibold text-gray-900 w-5 text-right">{count}</span>
    </div>
  );
}

function GovernanceDonut({ approved, flagged, blocked }) {
  const total = approved + flagged + blocked;
  const radius = 52, cx = 60, cy = 60, sw = 16;
  const circumference = 2 * Math.PI * radius;
  const segments = [
    { value: approved, color: '#16a34a' },
    { value: flagged, color: '#f59e0b' },
    { value: blocked, color: '#dc2626' },
  ];
  let acc = 0;
  return (
    <svg width={120} height={120} viewBox="0 0 120 120">
      <circle cx={cx} cy={cy} r={radius} fill="none" stroke="#f3f4f6" strokeWidth={sw} />
      {total > 0 && segments.map((seg, i) => {
        if (!seg.value) return null;
        const frac = seg.value / total;
        const dash = frac * circumference;
        const el = (
          <circle key={i} cx={cx} cy={cy} r={radius} fill="none" stroke={seg.color} strokeWidth={sw}
            strokeDasharray={`${dash} ${circumference - dash}`}
            strokeDashoffset={-acc}
            transform={`rotate(-90 ${cx} ${cy})`} />
        );
        acc += dash;
        return el;
      })}
      <text x={cx} y={cy - 4} textAnchor="middle" className="fill-gray-900" style={{ fontSize: 22, fontWeight: 700 }}>{total}</text>
      <text x={cx} y={cy + 14} textAnchor="middle" className="fill-gray-400" style={{ fontSize: 10 }}>Total</text>
    </svg>
  );
}

export default function Dashboard() {
  const {
    getInstances, getRecommendations, getSavings, getCompleteness,
    getFleetSummary, getTimeSeriesStats, postIngest, postAnalyse,
  } = useCloudSentry();

  const [account, setAccount] = useState(ACCOUNTS[0]);
  const [timeFilterDays, setTimeFilterDays] = useState(() => {
    const saved = localStorage.getItem('cloudSentryTimeFilter');
    return saved ? parseInt(saved, 10) : 30;
  });
  const [timeFilterStart, setTimeFilterStart] = useState(() => localStorage.getItem('cloudSentryTimeStart') || '');
  const [timeFilterEnd, setTimeFilterEnd] = useState(() => localStorage.getItem('cloudSentryTimeEnd') || '');

  const [instances, setInstances] = useState([]);
  const [instancesTotal, setInstancesTotal] = useState(0);
  const [recs, setRecs] = useState([]);
  const [recsTotal, setRecsTotal] = useState(0);
  const [savings, setSavings] = useState(null);
  const [completeness, setCompleteness] = useState(null);
  const [fleetSummary, setFleetSummary] = useState(null);
  const [timeSeries, setTimeSeries] = useState(null);
  const [prevTimeSeries, setPrevTimeSeries] = useState(null);
  const [skills, setSkills] = useState(null);
  const [pendingSkills, setPendingSkills] = useState(0);

  const [loading, setLoading] = useState(true);
  const [analysing, setAnalysing] = useState(false);
  const [progress, setProgress] = useState(null);
  const progressIntervalRef = useRef(null);

  useEffect(() => () => {
    if (progressIntervalRef.current) clearInterval(progressIntervalRef.current);
  }, []);

  const fetchAll = useCallback(async () => {
    setLoading(true);

    // Previous period of equal length, for a real "vs last month" delta on spend.
    const prevStart = new Date();
    prevStart.setDate(prevStart.getDate() - timeFilterDays * 2);
    const prevEnd = new Date();
    prevEnd.setDate(prevEnd.getDate() - timeFilterDays);

    const [
      instancesRes, recsRes, savingsRes, completenessRes, fleetRes,
      seriesRes, prevSeriesRes, skillsRes, pendingRes,
    ] = await Promise.all([
      getInstances({ limit: 500 }).catch(() => ({ instances: [], total: 0 })),
      getRecommendations({ limit: 500 }).catch(() => ({ recommendations: [], total: 0 })),
      getSavings().catch(() => null),
      getCompleteness().catch(() => null),
      getFleetSummary().catch(() => null),
      getTimeSeriesStats(timeFilterDays, timeFilterStart || undefined, timeFilterEnd || undefined).catch(() => null),
      getTimeSeriesStats(timeFilterDays, prevStart.toISOString().slice(0, 10), prevEnd.toISOString().slice(0, 10)).catch(() => null),
      cloudSentryApi.getSkills().catch(() => null),
      cloudSentryApi.getSkillSubmissions('pending').catch(() => ({ submissions: [] })),
    ]);

    setInstances(instancesRes?.instances || []);
    setInstancesTotal(instancesRes?.total || 0);
    setRecs(recsRes?.recommendations || []);
    setRecsTotal(recsRes?.total || 0);
    setSavings(savingsRes);
    setCompleteness(completenessRes);
    setFleetSummary(fleetRes);
    setTimeSeries(seriesRes);
    setPrevTimeSeries(prevSeriesRes);
    setSkills(skillsRes);
    setPendingSkills((pendingRes?.submissions || []).length);
    setLoading(false);
  }, [getInstances, getRecommendations, getSavings, getCompleteness, getFleetSummary, getTimeSeriesStats, timeFilterDays, timeFilterStart, timeFilterEnd]);

  useEffect(() => { fetchAll(); }, [fetchAll]);

  const handleTimeRangeChange = (days, start, end) => {
    setTimeFilterDays(days || 30);
    setTimeFilterStart(start || '');
    setTimeFilterEnd(end || '');
    if (days) localStorage.setItem('cloudSentryTimeFilter', days); else localStorage.removeItem('cloudSentryTimeFilter');
    if (start) localStorage.setItem('cloudSentryTimeStart', start); else localStorage.removeItem('cloudSentryTimeStart');
    if (end) localStorage.setItem('cloudSentryTimeEnd', end); else localStorage.removeItem('cloudSentryTimeEnd');
  };

  const handleRunAnalysis = async () => {
    try {
      setAnalysing(true);
      setProgress(null);
      await postIngest(timeFilterDays, timeFilterStart || undefined, timeFilterEnd || undefined);
      progressIntervalRef.current = setInterval(async () => {
        try { setProgress(await cloudSentryApi.getAnalyseProgress()); } catch (_) { /* skip tick */ }
      }, 2000);
      await postAnalyse();
      clearInterval(progressIntervalRef.current);
      setProgress(null);
      await fetchAll();
    } catch (err) {
      clearInterval(progressIntervalRef.current);
      setProgress(null);
      alert('Analysis failed: ' + err.message);
    } finally {
      setAnalysing(false);
    }
  };

  // ---- Derived, real-data aggregates (no fabricated numbers) ----------------
  // Only genuine AWS-current states count as "fleet": Active (Running) and
  // Stopped (paused but still exists). "Terminated" no longer exists in AWS
  // and "Unknown" means UnitEconPro has no lifecycle record for it at all —
  // both are excluded rather than shown as if they're part of the live fleet.
  const knownInstances = useMemo(() => instances.filter((i) => i.lifecycle_state === 'Active' || i.lifecycle_state === 'Stopped'), [instances]);
  const unknownCount = instancesTotal - knownInstances.length;
  const blockedCount = useMemo(() => knownInstances.filter((i) => i.safety_tier === 'HARD_BLOCK').length, [knownInstances]);
  const spotEligibleCount = useMemo(() => knownInstances.filter((i) => i.is_spot_eligible).length, [knownInstances]);
  const topRegion = useMemo(() => mostCommon(knownInstances.map((i) => i.region)), [knownInstances]);
  const runningCount = useMemo(() => knownInstances.filter((i) => i.lifecycle_state === 'Active').length, [knownInstances]);
  const stoppedCount = useMemo(() => knownInstances.filter((i) => i.lifecycle_state === 'Stopped').length, [knownInstances]);

  const avgConfidence = useMemo(() => (recs.length ? average(recs.map((r) => r.confidence || 0)) * 100 : 0), [recs]);
  const highPriorityCount = useMemo(() => recs.filter((r) => priorityFromConfidence(r.confidence || 0) === 'High').length, [recs]);

  const byTrack = useMemo(() => {
    const counts = {};
    recs.forEach((r) => { counts[r.track] = (counts[r.track] || 0) + 1; });
    return counts;
  }, [recs]);
  const maxTrackCount = Math.max(1, ...Object.values(byTrack));

  const governance = useMemo(() => {
    let approved = 0, flagged = 0, blocked = 0;
    recs.forEach((r) => {
      if (r.status === 'BLOCKED') blocked += 1;
      else if (r.status === 'FLAGGED') flagged += 1;
      else approved += 1; // APPROVED, PENDING_REVIEW, EXECUTING, REMEDIATED, etc. — cleared to move forward
    });
    return { approved, flagged, blocked };
  }, [recs]);
  const govTotal = governance.approved + governance.flagged + governance.blocked;

  const topRecs = useMemo(
    () => [...recs].sort((a, b) => (b.estimated_monthly_saving || 0) - (a.estimated_monthly_saving || 0)).slice(0, 5),
    [recs],
  );

  const spendDeltaPct = useMemo(() => {
    const cur = timeSeries?.total_spend_monthly_rate;
    const prev = prevTimeSeries?.total_spend_monthly_rate;
    if (!cur || !prev) return null;
    return ((cur - prev) / prev) * 100;
  }, [timeSeries, prevTimeSeries]);

  // Computed from knownInstances (not the raw /api/data-completeness total) so
  // this matches "Instances Scanned" instead of the unfiltered 50-instance count.
  const withTelemetryCount = useMemo(() => knownInstances.filter((i) => i.has_performance_data).length, [knownInstances]);
  const telemetryPct = knownInstances.length ? Math.round((withTelemetryCount / knownInstances.length) * 1000) / 10 : 0;
  const missingTelemetry = knownInstances.length - withTelemetryCount;
  const analysisSkills = skills?.skills?.filter((s) => ['rightsizing', 'spot_conversion', 'schedule_policy', 'eks_diagnosis'].includes(s.name)) || [];

  return (
    <div className="space-y-6 max-w-[1400px] mx-auto relative">
      {analysing && (
        <div className="absolute inset-0 bg-white/60 backdrop-blur-sm z-10 flex items-center justify-center rounded-lg">
          <div className="flex flex-col items-center bg-white p-6 rounded-lg shadow-xl min-w-[300px]">
            <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mb-4" />
            <p className="text-gray-800 font-medium">Running AI Analysis...</p>
            {progress?.total > 0 ? (
              <>
                <p className="text-sm text-gray-600 mt-2 font-mono">Analyzing instance {progress.current} of {progress.total}</p>
                <div className="w-full bg-gray-200 rounded-full h-2 mt-3">
                  <div className="bg-blue-600 h-2 rounded-full transition-all duration-500" style={{ width: `${Math.round((progress.current / progress.total) * 100)}%` }} />
                </div>
              </>
            ) : <p className="text-sm text-gray-500 mt-1">Preparing analysis...</p>}
          </div>
        </div>
      )}

      {/* Controls row */}
      <div className="flex flex-wrap justify-end items-center gap-3">
        <TimeRangePicker onChange={handleTimeRangeChange} initialDays={timeFilterDays} initialStart={timeFilterStart} initialEnd={timeFilterEnd} />
        <AccountSelector value={account} onChange={setAccount} />
        <button onClick={handleRunAnalysis} disabled={analysing}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium shadow-sm hover:bg-blue-700 disabled:opacity-50">
          <Play className="w-3.5 h-3.5 fill-current" />
          {analysing ? 'Running...' : 'Run Analysis'}
        </button>
      </div>
      <p className="text-xs text-gray-400 text-right -mt-4">
        Date range applies to Monthly Spend only &mdash; instances &amp; recommendations reflect the last "Run Analysis".
      </p>

      {/* KPI tiles */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        <KpiCard icon={DollarSign} iconBg="bg-blue-100" iconColor="text-blue-600" label="Monthly Spend" value={money(timeSeries?.total_spend_monthly_rate)}>
          <p className="text-xs text-gray-400 mt-2">EC2 &bull; {timeSeries?.active_regions || 0} region{timeSeries?.active_regions === 1 ? '' : 's'}</p>
          <Delta deltaPct={spendDeltaPct} direction={spendDeltaPct >= 0 ? 'up' : 'down'} goodDirection="down" />
        </KpiCard>

        <KpiCard icon={TrendingUp} iconBg="bg-green-100" iconColor="text-green-600" label="Potential Savings" value={money(savings?.total_identified)} unit="/mo">
          <p className="text-xs font-semibold text-gray-600 mt-2">{money((savings?.total_identified || 0) * 12)}/year</p>
        </KpiCard>

        <KpiCard icon={Sparkles} iconBg="bg-violet-100" iconColor="text-violet-600" label="Recommendations" value={recsTotal}>
          <p className="text-xs text-gray-400 mt-2">Awaiting review</p>
          <Link to="/recommendations" className="text-xs font-medium text-blue-600 hover:text-blue-700 mt-1 inline-block">{highPriorityCount} high priority</Link>
        </KpiCard>

        <KpiCard icon={Server} iconBg="bg-orange-100" iconColor="text-orange-600" label="Instances Scanned" value={knownInstances.length}>
          <p className="text-xs text-gray-400 mt-2">{runningCount} running &bull; {stoppedCount} stopped</p>
          {unknownCount > 0 && <p className="text-xs text-gray-400 mt-1">{unknownCount} excluded &mdash; terminated or no lifecycle data</p>}
        </KpiCard>

        <KpiCard icon={ShieldCheck} iconBg="bg-teal-100" iconColor="text-teal-600" label="Avg. Confidence" value={`${avgConfidence.toFixed(0)}%`}>
          <p className="text-xs text-gray-400 mt-2">{avgConfidence >= 80 ? 'High' : avgConfidence >= 50 ? 'Medium' : 'Low'}</p>
        </KpiCard>

        <KpiCard icon={Gauge} iconBg="bg-purple-100" iconColor="text-purple-600" label="Fleet Health" value="—" unit="/100">
          <p className="text-xs font-medium text-gray-400 mt-2">No backend metric yet</p>
        </KpiCard>
      </div>

      {/* AI Fleet Summary */}
      <GlassCard className="p-6">
        <div className="flex justify-between items-start mb-4">
          <h3 className="text-sm font-semibold text-gray-800 flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-violet-500" /> AI FLEET SUMMARY
          </h3>
          {fleetSummary?.generated_at && (
            <span className="text-xs text-gray-400">Last scan: {relativeTime(fleetSummary.generated_at)}</span>
          )}
        </div>

        <div className="flex flex-wrap gap-3 mb-4">
          <FleetPill icon={Server} label="Total" value={knownInstances.length} color="text-blue-600" bg="bg-blue-50" />
          <FleetPill icon={CheckCircle2} label="Running" value={runningCount} color="text-green-600" bg="bg-green-50" />
          <FleetPill icon={PauseCircle} label="Stopped" value={stoppedCount} color="text-gray-500" bg="bg-gray-50" />
          <FleetPill icon={ShieldAlert} label="Blocked" value={blockedCount} color="text-red-600" bg="bg-red-50" />
          <FleetPill icon={Zap} label="Spot Eligible" value={spotEligibleCount} color="text-violet-600" bg="bg-violet-50" />
          {topRegion && <FleetPill icon={MapPin} label="Region" value={topRegion} color="text-gray-700" bg="bg-gray-50" />}
        </div>

        <div className="flex flex-col md:flex-row gap-6">
          <div className="flex-1">
            <p className="text-sm text-gray-700 leading-relaxed">
              {fleetSummary?.summary || 'No fleet summary available yet. Click "Run Analysis" to generate one.'}
            </p>

            {Object.keys(byTrack).length > 0 && (
              <div className="flex flex-wrap items-center gap-3 mt-4">
                <span className="text-sm font-medium text-gray-600">Top opportunities</span>
                {Object.entries(byTrack).map(([track, count]) => {
                  const meta = TRACK_META[track] || { label: track, icon: Sparkles, color: 'text-gray-600', bg: 'bg-gray-100' };
                  const Icon = meta.icon;
                  return (
                    <span key={track} className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium ${meta.bg} ${meta.color}`}>
                      <Icon className="w-3 h-3" /> {count} {meta.label}
                    </span>
                  );
                })}
              </div>
            )}

            {recsTotal > 0 && (
              <Link to="/recommendations" className="inline-block mt-4 px-4 py-2 border border-blue-200 text-blue-600 rounded-lg text-sm font-medium hover:bg-blue-50">
                View all {recsTotal} recommendations
              </Link>
            )}
          </div>

          <div className="md:w-80 shrink-0 bg-amber-50 border border-amber-100 rounded-lg p-4">
            <p className="text-xs font-semibold text-amber-800 uppercase flex items-center gap-1.5">
              <Info className="w-3.5 h-3.5" /> Telemetry Coverage
            </p>
            <p className="text-2xl font-bold text-gray-900 mt-2">{telemetryPct}%</p>
            <p className="text-xs text-gray-500 mt-1">{withTelemetryCount} / {knownInstances.length} instances</p>
            <p className="text-xs text-gray-600 mt-2">
              {missingTelemetry > 0
                ? `${missingTelemetry} instances missing CloudWatch telemetry. Rightsizing unavailable for these instances.`
                : 'All analyzed instances have CloudWatch telemetry.'}
            </p>
            <Link to="/instances" className="text-xs font-medium text-blue-600 hover:text-blue-700 mt-2 inline-block">View excluded instances &rarr;</Link>
          </div>
        </div>
      </GlassCard>

      {/* Category breakdown / Skill approval / Governance */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <GlassCard className="p-6">
          <h3 className="text-sm font-semibold text-gray-800 mb-4">RECOMMENDATIONS BY CATEGORY</h3>
          {Object.keys(byTrack).length === 0 ? (
            <p className="text-sm text-gray-400">No recommendations yet.</p>
          ) : (
            <div className="space-y-3">
              {Object.entries(byTrack).map(([track, count]) => (
                <CategoryBar key={track} label={TRACK_META[track]?.label || track} count={count} max={maxTrackCount} />
              ))}
            </div>
          )}
        </GlassCard>

        <GlassCard className="p-6 flex flex-col items-center text-center">
          <h3 className="text-sm font-semibold text-gray-800 mb-4 self-start">SKILL APPROVAL</h3>
          <p className="text-4xl font-bold text-gray-900">{pendingSkills}</p>
          <p className="text-xs text-gray-400 mt-1 mb-4">submission{pendingSkills === 1 ? '' : 's'} awaiting admin review</p>
          {pendingSkills > 0 && (
            <span className="px-3 py-1.5 bg-amber-100 text-amber-700 rounded-md text-xs font-medium mb-3">Pending approval</span>
          )}
          <Link to="/skill-contribution" className="text-sm font-medium text-blue-600 hover:text-blue-700">Review</Link>
        </GlassCard>

        <GlassCard className="p-6">
          <h3 className="text-sm font-semibold text-gray-800 mb-4">SKILLS AVAILABLE</h3>
          <div className="space-y-3">
            {analysisSkills.length === 0 ? (
              <p className="text-sm text-gray-400">No skills registered.</p>
            ) : analysisSkills.map((s) => (
              <div key={s.name} className="flex items-start gap-2">
                <CheckCircle2 className="w-4 h-4 text-green-600 shrink-0 mt-0.5" />
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium text-gray-800">{s.display_name}</p>
                  <p className="text-xs text-gray-400">{s.description}</p>
                </div>
                <span className="text-xs font-medium text-gray-500 whitespace-nowrap shrink-0 mt-0.5">
                  {byTrack[SKILL_TRACK[s.name]] || 0} available
                </span>
              </div>
            ))}
          </div>
          <Link to="/skill-contribution" className="text-xs font-medium text-blue-600 hover:text-blue-700 mt-4 inline-block">View all skills &rarr;</Link>
        </GlassCard>
      </div>

      {/* Top recommendations + governance status */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <GlassCard className="p-6 lg:col-span-2">
          <h3 className="text-sm font-semibold text-gray-800 mb-4">TOP RECOMMENDATIONS</h3>
          {topRecs.length === 0 ? (
            <p className="text-sm text-gray-400">No recommendations yet &mdash; run an analysis to generate some.</p>
          ) : (
            <table className="w-full text-sm table-fixed">
              <thead>
                <tr className="text-left text-xs text-gray-400 border-b border-gray-100">
                  <th className="font-medium pb-2 w-[14%]">Priority</th>
                  <th className="font-medium pb-2 w-[30%]">Recommendation</th>
                  <th className="font-medium pb-2 w-[20%]">Instance</th>
                  <th className="font-medium pb-2 w-[16%]">Saving</th>
                  <th className="font-medium pb-2 w-[10%]">Conf.</th>
                  <th className="font-medium pb-2 w-[10%]"></th>
                </tr>
              </thead>
              <tbody>
                {topRecs.map((r) => {
                  const priority = priorityFromConfidence(r.confidence || 0);
                  const styles = { High: 'bg-red-100 text-red-700', Medium: 'bg-amber-100 text-amber-700', Low: 'bg-green-100 text-green-700' };
                  return (
                    <tr key={r.id} className="border-b border-gray-50 last:border-0 align-top">
                      <td className="py-2.5"><span className={`inline-block px-1.5 py-0.5 rounded text-[11px] font-medium whitespace-nowrap ${styles[priority]}`}>{priority}</span></td>
                      <td className="py-2.5 text-gray-800 pr-1">{r.action}</td>
                      <td className="py-2.5 text-gray-500 font-mono text-xs truncate">{r.resource_id}</td>
                      <td className="py-2.5 font-semibold text-gray-900">{money(r.estimated_monthly_saving)}/mo</td>
                      <td className="py-2.5 text-gray-500">{Math.round((r.confidence || 0) * 100)}%</td>
                      <td className="py-2.5"><Link to="/recommendations" className="text-blue-600 font-medium hover:text-blue-700 text-xs">Review</Link></td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
          {recsTotal > topRecs.length && (
            <Link to="/recommendations" className="text-xs font-medium text-blue-600 hover:text-blue-700 mt-3 inline-block">View all {recsTotal} recommendations &rarr;</Link>
          )}
        </GlassCard>

        <GlassCard className="p-6">
          <h3 className="text-sm font-semibold text-gray-800 mb-4">GOVERNANCE STATUS</h3>
          <div className="flex items-center gap-6">
            <GovernanceDonut approved={governance.approved} flagged={governance.flagged} blocked={governance.blocked} />
            <div className="space-y-2 text-sm flex-1 min-w-0">
              <div className="flex items-center justify-between gap-2">
                <span className="flex items-center gap-2 text-gray-600"><span className="w-2.5 h-2.5 rounded-full bg-green-600 shrink-0" />Approved &mdash; ready for review</span>
                <span className="font-semibold text-gray-900 shrink-0">{governance.approved} ({govTotal ? Math.round((governance.approved / govTotal) * 100) : 0}%)</span>
              </div>
              <div className="flex items-center justify-between gap-2">
                <span className="flex items-center gap-2 text-gray-600"><span className="w-2.5 h-2.5 rounded-full bg-amber-500 shrink-0" />Flagged &mdash; needs confirmation</span>
                <span className="font-semibold text-gray-900 shrink-0">{governance.flagged} ({govTotal ? Math.round((governance.flagged / govTotal) * 100) : 0}%)</span>
              </div>
              <div className="flex items-center justify-between gap-2">
                <span className="flex items-center gap-2 text-gray-600"><span className="w-2.5 h-2.5 rounded-full bg-red-600 shrink-0" />Blocked &mdash; production protected</span>
                <span className="font-semibold text-gray-900 shrink-0">{governance.blocked} ({govTotal ? Math.round((governance.blocked / govTotal) * 100) : 0}%)</span>
              </div>
            </div>
          </div>
          <p className="text-[11px] text-gray-400 text-center mt-4">3-tier governance &bull; all decisions audited &bull; no automated execution</p>
        </GlassCard>
      </div>

      {loading && <p className="text-center text-xs text-gray-400">Loading&hellip;</p>}
    </div>
  );
}
