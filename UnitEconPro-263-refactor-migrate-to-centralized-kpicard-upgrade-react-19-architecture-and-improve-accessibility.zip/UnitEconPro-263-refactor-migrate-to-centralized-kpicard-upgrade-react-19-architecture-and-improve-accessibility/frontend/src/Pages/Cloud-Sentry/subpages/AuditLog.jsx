import React, { useEffect, useMemo, useState } from 'react';
import { CheckCircle2, Download, Play, ShieldCheck, Sparkles, DollarSign } from 'lucide-react';
import { useCloudSentry } from '../../../hooks/Cloud-Sentry/useCloudSentry';
import { getCloudSentryApiUrl } from '../lib/ApiClient';

const statusClass = {
  BLOCKED: 'border-red-200 bg-red-50 text-red-700',
  FLAGGED: 'border-orange-200 bg-orange-50 text-orange-700',
  APPROVED: 'border-green-200 bg-green-50 text-green-700',
  COMPLETED: 'border-green-200 bg-green-50 text-green-700',
  PENDING_REVIEW: 'border-blue-200 bg-blue-50 text-blue-700',
};

const relativeTime = (value) => {
  if (!value) return '—';
  const seconds = Math.max(0, Math.floor((Date.now() - new Date(value).getTime()) / 1000));
  if (seconds < 60) return 'just now';
  if (seconds < 3600) return `${Math.floor(seconds / 60)} min ago`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)} hr ago`;
  return `${Math.floor(seconds / 86400)} d ago`;
};

function Badge({ value }) {
  return <span className={`inline-flex items-center gap-1.5 rounded border px-2.5 py-1 text-[10px] font-semibold ${statusClass[value] || 'border-slate-200 bg-slate-50 text-slate-600'}`}><span className="h-2 w-2 rounded-full bg-current" />{value?.replaceAll('_', ' ')}</span>;
}

function DownloadButton({ href }) {
  return <a href={getCloudSentryApiUrl(href)} className="inline-flex items-center gap-2 rounded border border-blue-500 bg-white px-3 py-2 text-xs font-semibold text-blue-600 hover:bg-blue-50"><Download className="h-4 w-4" /> Download CSV</a>;
}

function Kpi({ icon: Icon, iconClass, label, value, helper, progress }) {
  return (
    <div className="flex min-h-[130px] gap-5 rounded-lg border border-slate-200 bg-white px-5 py-5 shadow-sm">
      <div className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-full ${iconClass}`}><Icon className="h-6 w-6" /></div>
      <div className="min-w-0 flex-1">
        <p className="text-xs font-semibold text-slate-800">{label}</p>
        <p className="mt-1 text-3xl font-bold text-slate-950">{value}</p>
        <p className="mt-1 text-xs text-slate-500">{helper}</p>
        {progress != null && <div className="mt-3 flex items-center gap-3"><div className="h-2 flex-1 rounded-full bg-slate-200"><div className="h-full rounded-full bg-orange-500" style={{ width: `${Math.min(100, progress)}%` }} /></div><span className="text-xs font-semibold text-orange-600">{progress}%</span></div>}
      </div>
    </div>
  );
}

function Section({ title, action, children, subtitle }) {
  return (
    <section className="overflow-hidden rounded-lg border border-slate-200 bg-white shadow-sm">
      <header className="flex min-h-12 items-center justify-between border-b border-slate-200 px-5 py-2">
        <div><h2 className="text-base font-bold text-slate-900">{title}</h2>{subtitle && <p className="text-[11px] text-slate-600">{subtitle}</p>}</div>
        {action}
      </header>
      {children}
    </section>
  );
}

export default function AuditLog() {
  const { getExportAuditSummary } = useCloudSentry();
  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(true);
  const [decisionFilter, setDecisionFilter] = useState('ALL');

  useEffect(() => {
    let mounted = true;
    getExportAuditSummary().then((data) => mounted && setSummary(data)).catch(console.error).finally(() => mounted && setLoading(false));
    return () => { mounted = false; };
  }, []);

  const recommendations = summary?.recommendations || {};
  const governance = summary?.governance || {};
  const llm = summary?.llm_usage || {};
  const runs = summary?.analysis_runs?.preview || [];
  const decisions = useMemo(() => (governance.preview || []).filter((row) => decisionFilter === 'ALL' || row.decision === decisionFilter), [governance.preview, decisionFilter]);
  const budget = 20;
  const usedPct = Math.round(((llm.total_calls || 0) / budget) * 100);

  if (loading) return <div className="py-20 text-center text-sm text-slate-500">Loading audit history…</div>;

  return (
    <div className="mx-auto max-w-[1500px] space-y-4 text-slate-900">
      <h1 className="text-2xl font-bold tracking-tight">Audit Log</h1>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <Kpi icon={ShieldCheck} iconClass="bg-blue-600 text-white" label="Total Governance Decisions" value={governance.total || 0} helper={`Across ${summary?.analysis_runs?.total || 0} analysis run${summary?.analysis_runs?.total === 1 ? '' : 's'}`} />
        <Kpi icon={Play} iconClass="bg-green-600 text-white" label="Analysis Runs" value={summary?.analysis_runs?.total || 0} helper={runs[0] ? `Last run: ${relativeTime(runs[0].started_at)}` : 'No analysis run yet'} />
        <Kpi icon={Sparkles} iconClass="bg-violet-600 text-white" label="Gemini Calls Used" value={llm.total_calls || 0} helper={`Of ${budget} cap per run`} progress={usedPct} />
        <Kpi icon={DollarSign} iconClass="bg-orange-500 text-white" label="Estimated AI Cost" value={`$${Number(llm.total_cost_usd || 0).toFixed(4)}`} helper="This analysis run" />
      </div>

      <Section title="Analysis Runs" action={<DownloadButton href="/api/export/analysis-runs" />}>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[900px] text-left text-[11px]">
            <thead className="border-b bg-slate-50 font-semibold"><tr><th className="px-5 py-3">Run ID</th><th>Started</th><th>Completed</th><th>Instances</th><th>Recommendations</th><th>Blocked</th><th>Flagged</th><th>Approved</th><th>Status</th></tr></thead>
            <tbody className="divide-y">
              {runs.length ? runs.map((run) => <tr key={run.run_id}>
                <td className="px-5 py-3 font-semibold">{run.run_id?.length > 14 ? `${run.run_id.slice(0, 11)}…` : run.run_id}</td>
                <td>{relativeTime(run.started_at)}</td><td>{relativeTime(run.completed_at)}</td><td>{run.instances_analysed || 0}</td><td>{run.recommendations_generated || 0}</td><td>{run.blocked_count || 0}</td><td>{run.flagged_count || 0}</td><td>{run.approved_count || 0}</td>
                <td><Badge value={run.status || 'COMPLETED'} /></td>
              </tr>) : <tr><td colSpan="9" className="px-5 py-8 text-center text-slate-400">No analysis runs recorded yet.</td></tr>}
            </tbody>
          </table>
        </div>
      </Section>

      <Section title="Governance Decisions" action={<DownloadButton href="/api/export/governance" />}>
        <div className="flex flex-wrap gap-2 border-b px-5 py-3">
          {[['ALL', governance.total || 0], ['BLOCKED', recommendations.blocked || 0], ['FLAGGED', recommendations.flagged || 0], ['APPROVED', recommendations.approved || 0]].map(([value, count]) => (
            <button key={value} onClick={() => setDecisionFilter(value)} className={`rounded border px-4 py-1.5 text-xs font-semibold ${decisionFilter === value ? value === 'ALL' ? 'border-blue-600 bg-blue-600 text-white' : statusClass[value] : 'border-slate-200 bg-white text-slate-600'}`}>{value === 'ALL' ? 'All' : value} ({count})</button>
          ))}
        </div>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[850px] text-left text-[11px]">
            <thead className="border-b bg-slate-50 font-semibold"><tr><th className="px-5 py-3">Instance</th><th>Decision</th><th>Tier</th><th>Reason</th><th>Assessed At</th><th>AI Used</th></tr></thead>
            <tbody className="divide-y">
              {decisions.length ? decisions.map((row, index) => <tr key={`${row.resource_id}-${index}`}>
                <td className="px-5 py-3 font-semibold">{row.resource_name || row.resource_id}</td><td><Badge value={row.decision} /></td><td>Tier {row.tier || '—'}</td><td className="max-w-[430px] pr-4">{row.reason || '—'}</td><td>{relativeTime(row.assessed_at)}</td><td className={row.ai_used ? 'font-medium text-violet-600' : 'italic text-slate-500'}>{row.ai_used ? 'Yes — Gemini' : 'No'}</td>
              </tr>) : <tr><td colSpan="6" className="px-5 py-8 text-center text-slate-400">No governance decisions found.</td></tr>}
            </tbody>
          </table>
        </div>
      </Section>

      <Section title="Gemini API Usage" subtitle={`${llm.total_calls || 0} of ${budget} calls used this run`} action={<DownloadButton href="/api/export/llm-usage" />}>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[850px] text-left text-[11px]">
            <thead className="border-b bg-slate-50 font-semibold"><tr><th className="px-5 py-3">Agent</th><th>Resource</th><th>Model</th><th>Input Tokens</th><th>Output Tokens</th><th>Est. Cost</th><th>Called At</th></tr></thead>
            <tbody className="divide-y">
              {(llm.preview || []).length ? llm.preview.map((row, index) => <tr key={index}>
                <td className="px-5 py-3 font-semibold">{row.agent || '—'}</td><td>{row.resource_id || '—'}</td><td>{row.model || '—'}</td><td>{row.input_tokens || 0}</td><td>{row.output_tokens || 0}</td><td>${Number(row.estimated_cost_usd || 0).toFixed(4)}</td><td>{relativeTime(row.called_at)}</td>
              </tr>) : <tr><td colSpan="7" className="px-5 py-8 text-center text-slate-400">No Gemini calls recorded yet.</td></tr>}
            </tbody>
          </table>
        </div>
        {(llm.preview || []).length > 0 && <div className="flex justify-between border-t px-5 py-3 text-[11px] text-slate-500"><span>Showing {llm.preview.length} of {llm.total_calls} Gemini calls</span><a href={getCloudSentryApiUrl('/api/export/llm-usage')} className="font-semibold text-blue-600">View all</a></div>}
      </Section>
    </div>
  );
}
