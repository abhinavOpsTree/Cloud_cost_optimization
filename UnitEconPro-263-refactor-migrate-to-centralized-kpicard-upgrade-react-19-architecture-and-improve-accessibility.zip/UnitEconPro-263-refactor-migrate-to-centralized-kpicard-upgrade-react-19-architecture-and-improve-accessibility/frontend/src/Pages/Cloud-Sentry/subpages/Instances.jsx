import React, { useEffect, useMemo, useState } from 'react';
import { Search, ArrowLeft, ArrowRight, ChevronDown, Server, Shield, Zap, Lock, CloudLightning } from 'lucide-react';
import { useCloudSentry } from '../../../hooks/Cloud-Sentry/useCloudSentry';
import Table from '../common/Table.jsx';
import GlassBadge from '../components/common/GlassBadge.jsx';
import GlassCard from '../components/common/GlassCard.jsx';

const statusLabel = (value) => {
  if (!value) return 'Unknown';
  return value.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());
};

const formatMoney = (value) => {
  if (value == null || value === '') return 'No data';
  const number = Number(String(value).replace(/[^0-9.-]+/g, ''));
  if (Number.isFinite(number)) return `$${number.toFixed(2)}`;
  return String(value);
};

export default function Instances() {
  const { getInstances } = useCloudSentry();
  const [data, setData] = useState({ instances: [], total: 0 });
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [regionFilter, setRegionFilter] = useState('ALL');
  const [pricingFilter, setPricingFilter] = useState('ALL');
  const [envFilter, setEnvFilter] = useState('ALL');
  const [safetyFilter, setSafetyFilter] = useState('ALL');
  const [metricsFilter, setMetricsFilter] = useState('ALL');

  useEffect(() => {
    let isMounted = true;

    getInstances({ page: 1, limit: 500 })
      .then(res => {
        if (isMounted) {
          setData(res || { instances: [], total: 0 });
          setLoading(false);
        }
      })
      .catch(err => {
        console.error(err);
        if (isMounted) setLoading(false);
      });

    return () => { isMounted = false; };
  }, [getInstances]);

  const instances = data.instances || [];
  const totalInstances = data.total || instances.length;

  const regions = useMemo(() => Array.from(new Set(instances.map(i => i.region).filter(Boolean))), [instances]);
  const pricingModels = useMemo(() => Array.from(new Set(instances.map(i => i.pricing_model || i.pricing || '').filter(Boolean))), [instances]);
  const environments = useMemo(() => Array.from(new Set(instances.map(i => i.environment || i.env || 'Unknown').filter(Boolean))), [instances]);

  const filteredInstances = useMemo(() => {
    return instances.filter((instance) => {
      const searchValue = search.trim().toLowerCase();
      const name = String(instance.resource_name || instance.name || instance.resource_id || '').toLowerCase();
      const region = String(instance.region || '').toLowerCase();
      const pricing = String(instance.pricing_model || instance.pricing || '').toLowerCase();
      const env = String(instance.environment || instance.env || 'Unknown').toLowerCase();
      const safety = String(instance.safety_tier || '').toLowerCase();
      const hasMetrics = Boolean(instance.has_performance_data || instance.has_cloudwatch || instance.cpu_avg || instance.cpu_utilization);

      if (searchValue && !name.includes(searchValue)) return false;
      if (regionFilter !== 'ALL' && region !== regionFilter.toLowerCase()) return false;
      if (pricingFilter !== 'ALL' && pricing !== pricingFilter.toLowerCase()) return false;
      if (envFilter !== 'ALL' && env !== envFilter.toLowerCase()) return false;
      if (safetyFilter !== 'ALL' && safety !== safetyFilter.toLowerCase()) return false;
      if (metricsFilter === 'WITH' && !hasMetrics) return false;
      if (metricsFilter === 'WITHOUT' && hasMetrics) return false;
      return true;
    });
  }, [instances, search, regionFilter, pricingFilter, envFilter, safetyFilter, metricsFilter]);

  const pageSize = 10;
  const pages = Math.max(1, Math.ceil(filteredInstances.length / pageSize));
  const currentInstances = filteredInstances.slice((page - 1) * pageSize, page * pageSize);

  const blockedCount = instances.filter(i => (i.safety_tier || '').toUpperCase() === 'BLOCKED' || (i.safety_tier || '').toUpperCase() === 'HARD_BLOCK').length;
  const flaggedCount = instances.filter(i => (i.safety_tier || '').toUpperCase() === 'FLAG' || (i.safety_tier || '').toUpperCase() === 'FLAGGED').length;
  const approvedCount = instances.filter(i => (i.safety_tier || '').toUpperCase() === 'APPROVE' || (i.safety_tier || '').toUpperCase() === 'APPROVED').length;
  const eksCount = instances.filter(i => String(i.resource_id || i.resource_name || '').toLowerCase().includes('eks') || String(i.instance_type || '').toLowerCase().includes('eks')).length;
  const spotEligibleCount = instances.filter(i => i.is_spot_eligible || i.spot_eligible).length;
  const withCloudWatchCount = instances.filter(i => i.has_performance_data || i.has_cloudwatch).length;
  const savingsPotential = instances.reduce((sum, inst) => {
    const cost = Number(String(inst.monthly_cost_est || inst.monthly_cost || inst.cost || '').replace(/[^0-9.-]+/g, ''));
    return Number.isFinite(cost) ? sum + cost * 0.05 : sum;
  }, 0);

  const columns = [
    {
      key: 'resource_id',
      header: 'Instance Name + ID',
      render: (val, row) => {
        const name = row.resource_name && row.resource_name !== 'nan' && row.resource_name !== 'None' ? row.resource_name : (row.name || val);
        return (
          <div className="space-y-1">
            <div className="font-semibold text-slate-900">{name || 'Unknown'}</div>
            <div className="text-xs text-slate-500">{row.resource_id || '—'}</div>
          </div>
        );
      }
    },
    { key: 'instance_type', header: 'Type', render: (val, row) => <span className="text-sm text-slate-700">{val || row.type || '—'}</span> },
    { key: 'region', header: 'Region' },
    { key: 'environment', header: 'Environment', render: (val, row) => {
        const env = val || row.environment || row.env || 'Unknown';
        const color = env.toLowerCase().includes('prod') ? 'bg-red-100 text-red-700' : env.toLowerCase().includes('stag') ? 'bg-orange-100 text-orange-700' : env.toLowerCase().includes('dev') ? 'bg-amber-100 text-amber-700' : 'bg-slate-100 text-slate-700';
        return <span className={`inline-flex rounded-full px-3 py-1 text-xs font-semibold ${color}`}>{env}</span>;
      }
    },
    { key: 'pricing_model', header: 'Pricing', render: (val, row) => <span className="text-sm text-slate-700">{val || row.pricing || '—'}</span> },
    { key: 'monthly_cost_est', header: 'Monthly Cost', render: (val, row) => {
        const cost = val ?? row.monthly_cost_est ?? row.monthly_cost ?? row.cost;
        return <span className="font-semibold text-slate-900">{formatMoney(cost)} /mo</span>;
      }
    },
    { key: 'cpu_avg_pct', header: 'CPU Avg', render: (val, row) => {
        const avg = val ?? row.cpu_avg_pct ?? row.cpu_avg ?? row.cpu_utilization;
        return avg == null || avg === '' ? 'No data' : `${Number(avg).toFixed(0)}%`;
      }
    },
    { key: 'safety_tier', header: 'Safety', render: (val) => <GlassBadge>{statusLabel(val)}</GlassBadge> },
    { key: 'actions', header: 'Actions', render: () => (
        <button className="rounded-full border border-slate-200 bg-white px-3 py-1 text-sm font-semibold text-slate-700 transition hover:bg-slate-50">
          Details
        </button>
      )
    }
  ];

  const resetFilters = () => {
    setSearch('');
    setRegionFilter('ALL');
    setPricingFilter('ALL');
    setEnvFilter('ALL');
    setSafetyFilter('ALL');
    setMetricsFilter('ALL');
    setPage(1);
  };

  return (
    <div className="min-h-screen bg-[#F4F7FE] px-4 py-6">
      <div className="mx-auto max-w-[1280px] space-y-5">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <h1 className="text-3xl font-semibold text-slate-950">Instances</h1>
            <p className="text-sm text-slate-500 mt-1">Fleet snapshots and instance-level status across all regions.</p>
          </div>
          <div className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-4 py-2 text-sm font-semibold text-slate-700 shadow-sm">
            Sorted by: Monthly Cost
            <ChevronDown className="h-4 w-4 text-slate-500" />
          </div>
        </div>

        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
          <GlassCard className="p-5">
            <div className="flex items-center justify-between gap-3">
              <div className="rounded-2xl bg-blue-50 p-3 text-blue-600">
                <Server className="h-5 w-5" />
              </div>
              <div className="text-right">
                <p className="text-xs uppercase tracking-[0.28em] text-slate-500">Total Instances</p>
                <p className="mt-3 text-2xl font-semibold text-slate-950">{totalInstances}</p>
                <p className="text-sm text-slate-500">Across all regions</p>
              </div>
            </div>
          </GlassCard>

          <GlassCard className="p-5">
            <div className="flex items-center justify-between gap-3">
              <div className="rounded-2xl bg-orange-50 p-3 text-orange-600">
                <CloudLightning className="h-5 w-5" />
              </div>
              <div className="text-right">
                <p className="text-xs uppercase tracking-[0.28em] text-slate-500">EKS Nodes</p>
                <p className="mt-3 text-2xl font-semibold text-slate-950">{eksCount}</p>
                <p className="text-sm text-slate-500">{totalInstances ? `${((eksCount / totalInstances) * 100).toFixed(1)}% of fleet` : '—'}</p>
              </div>
            </div>
          </GlassCard>

          <GlassCard className="p-5">
            <div className="flex items-center justify-between gap-3">
              <div className="rounded-2xl bg-emerald-50 p-3 text-emerald-600">
                <Zap className="h-5 w-5" />
              </div>
              <div className="text-right">
                <p className="text-xs uppercase tracking-[0.28em] text-slate-500">Spot Eligible</p>
                <p className="mt-3 text-2xl font-semibold text-slate-950">{spotEligibleCount}</p>
                <p className="text-sm text-emerald-600">{formatMoney(savingsPotential)} potential</p>
              </div>
            </div>
          </GlassCard>

          <GlassCard className="p-5">
            <div className="flex items-center justify-between gap-3">
              <div className="rounded-2xl bg-red-50 p-3 text-red-600">
                <Lock className="h-5 w-5" />
              </div>
              <div className="text-right">
                <p className="text-xs uppercase tracking-[0.28em] text-slate-500">Hard Blocked</p>
                <p className="mt-3 text-2xl font-semibold text-slate-950">{blockedCount}</p>
                <p className="text-sm text-slate-500">Production protected</p>
              </div>
            </div>
          </GlassCard>

          <GlassCard className="p-5">
            <div className="flex items-center justify-between gap-3">
              <div className="rounded-2xl bg-sky-50 p-3 text-sky-600">
                <Shield className="h-5 w-5" />
              </div>
              <div className="text-right">
                <p className="text-xs uppercase tracking-[0.28em] text-slate-500">With CloudWatch</p>
                <p className="mt-3 text-2xl font-semibold text-slate-950">{withCloudWatchCount}</p>
                <p className="text-sm text-slate-500">{totalInstances - withCloudWatchCount} without telemetry</p>
              </div>
            </div>
          </GlassCard>
        </div>

        <div className="rounded-[28px] border border-slate-200 bg-white p-5 shadow-sm">
          <div className="grid gap-4 lg:grid-cols-[1fr_280px] xl:grid-cols-[1.2fr_320px]">
            <div className="relative">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
              <input
                value={search}
                onChange={(e) => { setSearch(e.target.value); setPage(1); }}
                placeholder="Search by name or instance ID…"
                className="h-11 w-full rounded-xl border border-slate-200 bg-slate-50 pl-10 pr-4 text-sm text-slate-900 outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100"
              />
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              <select value={regionFilter} onChange={(e) => { setRegionFilter(e.target.value); setPage(1); }} className="h-11 rounded-xl border border-slate-200 bg-white px-3 text-sm text-slate-900 outline-none">
                <option value="ALL">All regions</option>
                {regions.map((region) => <option key={region} value={region}>{region}</option>)}
              </select>
              <select value={pricingFilter} onChange={(e) => { setPricingFilter(e.target.value); setPage(1); }} className="h-11 rounded-xl border border-slate-200 bg-white px-3 text-sm text-slate-900 outline-none">
                <option value="ALL">Pricing Model</option>
                {pricingModels.map((pricing) => <option key={pricing} value={pricing}>{pricing}</option>)}
              </select>
              <select value={envFilter} onChange={(e) => { setEnvFilter(e.target.value); setPage(1); }} className="h-11 rounded-xl border border-slate-200 bg-white px-3 text-sm text-slate-900 outline-none">
                <option value="ALL">Environment</option>
                {environments.map((env) => <option key={env} value={env}>{env}</option>)}
              </select>
              <select value={safetyFilter} onChange={(e) => { setSafetyFilter(e.target.value); setPage(1); }} className="h-11 rounded-xl border border-slate-200 bg-white px-3 text-sm text-slate-900 outline-none">
                <option value="ALL">Safety Tier</option>
                <option value="BLOCKED">Hard Block</option>
                <option value="FLAGGED">Flagged</option>
                <option value="APPROVED">Clear</option>
              </select>
              <select value={metricsFilter} onChange={(e) => { setMetricsFilter(e.target.value); setPage(1); }} className="h-11 rounded-xl border border-slate-200 bg-white px-3 text-sm text-slate-900 outline-none">
                <option value="ALL">Has Metrics</option>
                <option value="WITH">Has metrics</option>
                <option value="WITHOUT">No metrics</option>
              </select>
              <button onClick={resetFilters} className="h-11 rounded-xl border border-slate-200 bg-white px-3 text-sm font-semibold text-slate-700 hover:bg-slate-50">
                Clear filters
              </button>
            </div>
          </div>
        </div>

        <div className="rounded-[28px] border border-slate-200 bg-white p-5 shadow-sm">
          <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <div>
              <p className="text-lg font-semibold text-slate-900">Instances</p>
              <p className="text-sm text-slate-500">Showing {filteredInstances.length ? (page - 1) * pageSize + 1 : 0}–{Math.min(page * pageSize, filteredInstances.length)} of {filteredInstances.length} instances</p>
            </div>
            <div className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-slate-100 px-3 py-2 text-sm text-slate-600">
              <span>Sorted by monthly cost</span>
              <ChevronDown className="h-4 w-4" />
            </div>
          </div>

          <div className="mt-6 overflow-hidden rounded-[24px] border border-slate-200">
            <Table columns={columns} data={currentInstances} isLoading={loading} />
          </div>

          <div className="mt-5 flex flex-col gap-3 border-t border-slate-200 pt-4 md:flex-row md:items-center md:justify-between">
            <p className="text-sm text-slate-500">Showing {filteredInstances.length ? (page - 1) * pageSize + 1 : 0}–{Math.min(page * pageSize, filteredInstances.length)} of {filteredInstances.length} instances</p>
            <div className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-slate-100 p-2 text-sm text-slate-600">
              <button disabled={page === 1} onClick={() => setPage(Math.max(1, page - 1))} className="rounded-full px-3 py-2 hover:bg-slate-200 disabled:cursor-not-allowed disabled:opacity-40">
                <ArrowLeft className="h-4 w-4" />
              </button>
              {Array.from({ length: pages }, (_, idx) => idx + 1).slice(0, 5).map((pageNumber) => (
                <button key={pageNumber} onClick={() => setPage(pageNumber)} className={`rounded-full px-3 py-2 ${pageNumber === page ? 'bg-slate-900 text-white' : 'hover:bg-slate-200 text-slate-700'}`}>
                  {pageNumber}
                </button>
              ))}
              <button disabled={page === pages} onClick={() => setPage(Math.min(pages, page + 1))} className="rounded-full px-3 py-2 hover:bg-slate-200 disabled:cursor-not-allowed disabled:opacity-40">
                <ArrowRight className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
