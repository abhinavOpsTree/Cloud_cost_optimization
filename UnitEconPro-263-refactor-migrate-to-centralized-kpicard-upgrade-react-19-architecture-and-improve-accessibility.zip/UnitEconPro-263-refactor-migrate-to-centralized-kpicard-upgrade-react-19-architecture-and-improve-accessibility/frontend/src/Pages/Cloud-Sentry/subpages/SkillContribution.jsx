import React, { useEffect, useState, useRef, useMemo } from 'react';
import { BookOpen, Code2, Plus, Sparkles, Trophy, X } from 'lucide-react';
import { useCloudSentry } from '../../../hooks/Cloud-Sentry/useCloudSentry.jsx';
import { getCurrentUserEmail } from '../lib/ApiClient';
import GlassBadge from '../components/common/GlassBadge.jsx';
import GlassCard from '../components/common/GlassCard.jsx';

function StatCard({ icon: Icon, iconBg, title, value, description }) {
  return (
    <GlassCard className="p-5 min-h-[140px]">
      <div className="flex h-full flex-col justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className={`flex h-12 w-12 items-center justify-center rounded-2xl ${iconBg}`}>
            <Icon className="h-6 w-6" />
          </div>
          <div className="min-w-0">
            <p className="text-xs uppercase tracking-[0.24em] text-slate-500">{title}</p>
          </div>
        </div>
        <div>
          <p className="text-2xl font-semibold text-slate-950 truncate">{value}</p>
          <p className="text-sm text-slate-500 mt-1">{description}</p>
        </div>
      </div>
    </GlassCard>
  );
}

const generateTemplate = (name, trackValue) => {
  const className = name.replace(/[^a-zA-Z0-9]/g, '') || 'MySkill';
  const nameSnake = name.toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '') || 'my_skill';
  return `from core.base_skill import BaseAnalysisSkill


class ${className}(BaseAnalysisSkill):
    """
    ${name || '[YOUR SKILL NAME]'} Skill

    Purpose:
        [Describe what this skill analyses and what recommendations it produces]

    Applies to:
        [Describe which instances this skill targets]

    Track: ${trackValue}
    """

    # Metadata — used by the skill registry and leaderboard
    NAME = "${nameSnake}"
    DISPLAY_NAME = "${name || 'Template Skill'}"
    DESCRIPTION = "A template for building new analysis skills"
    TRACK = "${trackValue}"  # Change to: rightsizing, spot, schedule, eks, tagging
    VERSION = "1.0.0"
    AUTHOR = "Your Name"

    def can_apply(self, instance: dict) -> bool:
        """
        Return True if this skill should run for the given instance.

        Args:
            instance: A dict row from enriched_instances.parquet
                Keys available:
                - resource_id, resource_name, instance_type, pricing_model
                - cpu_avg_pct, cpu_max_pct, net_in_mbps, net_out_mbps
                - has_performance_data (bool)
                - inferred_env, inferred_workload, safety_tier
                - is_spot_eligible (bool)
                - total_cost_90d, monthly_cost_est
                - cluster_name (str or None)

        Example:
            # Only apply to instances with performance data
            return instance.get("has_performance_data") == True

            # Only apply to OnDemand instances
            return instance.get("pricing_model") == "OnDemand"
        """
        # TODO: Replace with your logic
        return False

    def analyse(self, instance: dict) -> dict:
        """
        Analyse the instance and return findings.

        Returns:
            A dict with your findings. Return {} if no actionable finding.

        Example:
            cpu_avg = instance.get("cpu_avg_pct", 0)
            if cpu_avg < 10:
                return {
                    "signal": "UNDER_UTILISED",
                    "cpu_avg": cpu_avg,
                    "recommended_action": "Consider downsizing",
                }
            return {}
        """
        # TODO: Replace with your analysis logic
        return {}

    def recommend(self, instance: dict, finding: dict) -> dict | None:
        """
        Convert a finding into a recommendation.

        Args:
            instance: Instance data
            finding:  Dict returned by analyse()

        Returns:
            A recommendation dict or None.

        Required keys in recommendation:
            track:                    str   — "rightsizing"|"spot"|"schedule"|"eks"|"custom"
            action:                   str   — human-readable description
            current_monthly_cost:     float — from instance["monthly_cost_est"]
            estimated_monthly_saving: float — your estimate
            saving_pct:               float — percentage saved
            confidence:               float — 0.0 to 1.0
            rationale:                str   — shown to the engineer
            has_performance_data:     bool  — from instance["has_performance_data"]
            skill_name:               str   — self.NAME

        Example:
            return {
                "track": "rightsizing",
                "action": f"Downsize {instance['instance_type']} to t3.small",
                "current_monthly_cost": instance.get("monthly_cost_est", 0),
                "estimated_monthly_saving": 5.00,
                "saving_pct": 40.0,
                "confidence": 0.85,
                "rationale": f"CPU avg {finding['cpu_avg']:.1f}% — instance over-provisioned",
                "has_performance_data": instance.get("has_performance_data", False),
                "skill_name": self.NAME,
            }
        """
        # TODO: Replace with your recommendation logic
        return None

    def generate_script(self, instance: dict, recommendation: dict) -> dict:
        """
        Generate executable scripts for the recommendation.

        Returns:
            {
                "terraform_hcl":     str — complete Terraform code
                "aws_cli_command":   str — complete AWS CLI command
                "rollback_command":  str — complete rollback command
                "eventbridge_rule":  str — EventBridge JSON (schedule only, else "")
            }

        IMPORTANT:
            - Use real instance IDs, not placeholders
            - Always include a rollback command
            - Scripts must be copy-paste ready

        Example:
            resource_id = instance["resource_id"]
            return {
                "terraform_hcl": f'''
resource "aws_instance" "{instance['resource_name']}" {{
  instance_type = "t3.small"  # downsized from {instance['instance_type']}
}}
''',
                "aws_cli_command": f"aws ec2 modify-instance-attribute --instance-id {resource_id} --instance-type t3.small",
                "rollback_command": f"aws ec2 modify-instance-attribute --instance-id {resource_id} --instance-type {instance['instance_type']}",
                "eventbridge_rule": "",
            }
        """
        # TODO: Replace with your script generation logic
        return {
            "terraform_hcl": "# TODO: Add Terraform code",
            "aws_cli_command": "# TODO: Add AWS CLI command",
            "rollback_command": "# TODO: Add rollback command",
            "eventbridge_rule": "",
        }
`;
};

export default function SkillContribution() {
  const { submitSkill, getSkillSubmissions, approveSkillSubmission, rejectSkillSubmission, getSkillAdmins, addSkillAdmin, removeSkillAdmin } = useCloudSentry();
  const [userEmail, setUserEmail] = useState(getCurrentUserEmail() || '');
  const [manualEmail, setManualEmail] = useState(userEmail);
  const [submissions, setSubmissions] = useState([]);
  const [admins, setAdmins] = useState([]);
  const [masterAdmin, setMasterAdmin] = useState('');
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Form states
  const [skillName, setSkillName] = useState('');
  const [description, setDescription] = useState('');
  const [track, setTrack] = useState('custom');
  const [codeContent, setCodeContent] = useState('');
  
  const lastGeneratedTemplate = useRef('');

  useEffect(() => {
    // Only auto-fill if the content is empty or matches the last auto-generated template
    if (codeContent === '' || codeContent === lastGeneratedTemplate.current) {
      const newTemplate = generateTemplate(skillName, track);
      setCodeContent(newTemplate);
      lastGeneratedTemplate.current = newTemplate;
    }
  }, [skillName, track]);

  // Master admin form
  const [newAdminEmail, setNewAdminEmail] = useState('');

  // Review states
  const [reviewNotes, setReviewNotes] = useState({});

  const fetchData = async () => {
    setLoading(true);
    try {
      const subRes = await getSkillSubmissions('');
      setSubmissions(subRes.submissions || []);
      const adminRes = await getSkillAdmins();
      setAdmins(adminRes.admins || []);
      setMasterAdmin(adminRes.master_admin || '');
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const handleSetEmail = () => {
    window.__CLOUD_SENTRY_USER_EMAIL__ = manualEmail;
    setUserEmail(manualEmail);
  };

  const handleSubmitSkill = async (e) => {
    if (e && e.preventDefault) e.preventDefault();
    if (!userEmail) return alert("Please set a user email first.");
    try {
      await submitSkill({
        skill_name: skillName,
        description,
        track,
        code_content: codeContent,
        submitted_by: userEmail
      });
      setSkillName('');
      setDescription('');
      setTrack('custom');
      setCodeContent('');
      setIsModalOpen(false);
      alert("Skill submitted successfully!");
      fetchData();
    } catch (e) {
      alert("Failed to submit: " + e.message);
    }
  };

  const handleApprove = async (id) => {
    try {
      await approveSkillSubmission(id, userEmail, reviewNotes[id] || '');
      fetchData();
    } catch (e) {
      alert("Failed to approve: " + e.message);
    }
  };

  const handleReject = async (id) => {
    try {
      await rejectSkillSubmission(id, userEmail, reviewNotes[id] || '');
      fetchData();
    } catch (e) {
      alert("Failed to reject: " + e.message);
    }
  };

  const handleAddAdmin = async (e) => {
    e.preventDefault();
    try {
      await addSkillAdmin(newAdminEmail, userEmail);
      setNewAdminEmail('');
      fetchData();
    } catch (e) {
      alert("Failed to add admin: " + e.message);
    }
  };

  const handleRemoveAdmin = async (email) => {
    try {
      await removeSkillAdmin(email, userEmail);
      fetchData();
    } catch (e) {
      alert("Failed to remove admin: " + e.message);
    }
  };

  const isAdmin = admins.includes(userEmail);
  const isMasterAdmin = masterAdmin === userEmail;

  const uniqueSkillNames = useMemo(
    () => Array.from(new Set(submissions.map((s) => s.skill_name || '').filter(Boolean))),
    [submissions]
  );
  const totalRecommendations = useMemo(
    () => submissions.reduce((sum, sub) => sum + (Number(sub.recommendations) || Number(sub.recommendations_generated) || 0), 0),
    [submissions]
  );
  const topSkill = useMemo(() => {
    const best = submissions
      .slice()
      .sort((a, b) => (Number(b.estimated_monthly_saving) || 0) - (Number(a.estimated_monthly_saving) || 0));
    return best[0] || null;
  }, [submissions]);

  return (
    <div className="min-h-screen bg-[#F4F7FE] px-4 py-6">
      <div className="mx-auto max-w-[1280px] space-y-6">
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <h1 className="text-3xl font-semibold text-slate-950">Skill Contribution</h1>
            <p className="text-sm text-slate-500 mt-1">Submit custom analysis skills and manage approvals for Cloud Sentry AI.</p>
          </div>
          {!getCurrentUserEmail() && (
            <div className="flex items-center gap-2 rounded-full border border-amber-200 bg-amber-50 px-4 py-2 text-sm text-amber-800">
              <span className="font-semibold">Local tester email:</span>
              <input
                className="rounded-full border border-amber-300 bg-white px-3 py-1 text-sm text-amber-900 outline-none focus:border-amber-500 focus:ring-2 focus:ring-amber-100"
                value={manualEmail}
                onChange={e => setManualEmail(e.target.value)}
                placeholder="email@example.com"
              />
              <button onClick={handleSetEmail} className="rounded-full bg-amber-600 px-3 py-1 text-sm font-semibold text-white hover:bg-amber-700 transition">
                Set
              </button>
            </div>
          )}
        </div>

        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <StatCard
            icon={Code2}
            iconBg="bg-blue-100 text-blue-600"
            title="Active Skills"
            value={uniqueSkillNames.length}
            description="Running in production"
          />
          <StatCard
            icon={Sparkles}
            iconBg="bg-violet-100 text-violet-600"
            title="Total Recommendations Generated"
            value={totalRecommendations}
            description="Across all skills"
          />
          <StatCard
            icon={Trophy}
            iconBg="bg-amber-100 text-amber-600"
            title="Top Skill"
            value={topSkill?.skill_name || '—'}
            description={topSkill ? `${(Number(topSkill.estimated_monthly_saving) || 0).toFixed(2)} /mo saved` : 'No data'}
          />
          <StatCard
            icon={BookOpen}
            iconBg="bg-sky-100 text-sky-600"
            title="Contribution Guide"
            value="CONTRIBUTING_A_SKILL.md"
            description="Add a new skill in 15–30 min"
          />
        </div>

        <div className="space-y-6">
          <GlassCard className="p-6">
            <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
              <div>
                <h2 className="text-lg font-semibold text-slate-900">Skill Leaderboard</h2>
                <p className="text-sm text-slate-500 mt-1">Skills ranked by total estimated monthly savings.</p>
              </div>
              <div className="flex flex-wrap items-center gap-3 justify-start md:justify-end">
                <button onClick={() => setIsModalOpen(true)} className="inline-flex items-center gap-2 rounded-full bg-blue-600 px-4 py-2 text-sm font-semibold text-white shadow-sm hover:bg-blue-700">
                  <Plus className="h-4 w-4" /> Submit New Skill
                </button>
              </div>
            </div>

            <div className="mt-6 overflow-hidden rounded-[28px] border border-slate-200 bg-white shadow-sm">
              <table className="min-w-full divide-y divide-slate-200 text-left text-sm">
                <thead className="bg-slate-50">
                  <tr className="text-slate-500">
                    <th className="px-6 py-4 uppercase tracking-[0.18em]">Rank</th>
                    <th className="px-6 py-4 uppercase tracking-[0.18em]">Skill</th>
                    <th className="px-6 py-4 uppercase tracking-[0.18em]">Recommendations</th>
                    <th className="px-6 py-4 uppercase tracking-[0.18em]">Instances Analyzed</th>
                    <th className="px-6 py-4 uppercase tracking-[0.18em]">Saving/mo</th>
                    <th className="px-6 py-4 uppercase tracking-[0.18em]">Contributor</th>
                    <th className="px-6 py-4 uppercase tracking-[0.18em]">Status</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-slate-200">
                  {submissions.length === 0 ? (
                    <tr>
                      <td colSpan={7} className="px-6 py-10 text-center text-slate-500">No skills submitted yet.</td>
                    </tr>
                  ) : submissions.map((sub, idx) => (
                    <tr key={sub.id || `${sub.skill_name}-${idx}`} className="hover:bg-slate-50">
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <span className={`inline-flex h-9 w-9 items-center justify-center rounded-full ${idx === 0 ? 'bg-amber-100 text-amber-700' : idx === 1 ? 'bg-slate-100 text-slate-700' : idx === 2 ? 'bg-slate-100 text-slate-700' : 'bg-slate-100 text-slate-500'}`}>
                            {idx + 1}
                          </span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="font-semibold text-slate-900">{sub.skill_name}</div>
                        {sub.description && <div className="text-sm text-slate-500">{sub.description}</div>}
                      </td>
                      <td className="px-6 py-4 text-slate-700">{sub.recommendations ?? sub.recommendations_generated ?? '—'}</td>
                      <td className="px-6 py-4 text-slate-700">{sub.instances_analyzed ?? sub.instances ?? '—'}</td>
                      <td className="px-6 py-4 text-slate-700">${(Number(sub.estimated_monthly_saving) || 0).toFixed(2)}</td>
                      <td className="px-6 py-4 text-slate-700">{sub.submitted_by || sub.contributor || 'Core Team'}</td>
                      <td className="px-6 py-4"><GlassBadge>{sub.status?.toUpperCase() || 'UNKNOWN'}</GlassBadge></td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </GlassCard>

          <GlassCard className="p-6">
            <div className="flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
              <div className="flex items-center gap-4">
                <div className="flex h-16 w-16 items-center justify-center rounded-3xl bg-blue-600 text-white shadow-sm">
                  <Code2 className="h-8 w-8" />
                </div>
                <div>
                  <h2 className="text-xl font-semibold text-slate-900">Add Your Own Skill</h2>
                  <p className="mt-2 max-w-xl text-sm text-slate-500">Any team member can contribute a new optimization skill in 15–30 minutes. Copy the template, implement 4 methods (can_apply, analyse, recommend, generate_script), and it appears here automatically.</p>
                </div>
              </div>
              <div className="flex flex-wrap gap-3">
                <button className="inline-flex items-center justify-center rounded-full bg-blue-600 px-5 py-3 text-sm font-semibold text-white shadow-sm transition hover:bg-blue-700">
                  View Template
                </button>
                <button className="inline-flex items-center justify-center rounded-full border border-slate-200 bg-white px-5 py-3 text-sm font-semibold text-slate-700 shadow-sm transition hover:bg-slate-50">
                  Read Guide
                </button>
              </div>
            </div>
          </GlassCard>
        </div>

        {isModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
            <div className="w-full max-w-[680px] max-h-[90vh] flex flex-col rounded-[28px] bg-white shadow-[0_32px_120px_rgba(15,23,42,0.16)] ring-1 ring-slate-200">
              {/* Header */}
              <div className="flex items-center justify-between gap-4 border-b border-slate-200 px-6 py-4">
                <div>
                  <h2 className="text-lg font-semibold text-slate-950">Submit a New Skill</h2>
                  <p className="text-xs text-slate-500 mt-0.5">Complete all fields to submit your custom analysis skill.</p>
                </div>
                <button onClick={() => setIsModalOpen(false)} className="rounded-full p-2 text-slate-500 transition hover:bg-slate-100 hover:text-slate-900">
                  <X className="h-4 w-4" />
                </button>
              </div>

              {/* Body */}
              <div className="px-6 py-4 space-y-4 overflow-y-auto flex-1">
                {/* Row 1: Skill Name + Track */}
                <div className="grid grid-cols-[2fr_1fr] gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-600 mb-1">Skill Name</label>
                    <input
                      value={skillName}
                      onChange={(e) => setSkillName(e.target.value)}
                      className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-900 outline-none transition focus:border-sky-500 focus:ring-2 focus:ring-sky-100"
                      placeholder="e.g. StorageCostSkill"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-600 mb-1">Track</label>
                    <select
                      value={track}
                      onChange={(e) => setTrack(e.target.value)}
                      className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-900 outline-none transition focus:border-sky-500 focus:ring-2 focus:ring-sky-100"
                    >
                      <option value="custom">Custom</option>
                      <option value="rightsizing">Rightsizing</option>
                      <option value="spot">Spot</option>
                      <option value="schedule">Schedule</option>
                      <option value="eks">EKS</option>
                      <option value="tagging">Tagging</option>
                    </select>
                  </div>
                </div>

                {/* Row 2: Description */}
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1">Description</label>
                  <textarea
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    rows={2}
                    className="w-full rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-900 outline-none transition focus:border-sky-500 focus:ring-2 focus:ring-sky-100 resize-none"
                    placeholder="Briefly describe what this skill analyses and the recommendation it generates."
                  />
                </div>

                {/* Row 3: Code Editor */}
                <div className="rounded-2xl border border-slate-200 bg-slate-50 overflow-hidden">
                  <div className="flex items-center justify-between px-4 py-2.5 border-b border-slate-200">
                    <span className="text-sm font-semibold text-slate-900">Code Content</span>
                    <button type="button" className="text-xs font-semibold text-sky-600 hover:text-sky-500">Format guide</button>
                  </div>
                  <div className="p-3">
                    <textarea
                      value={codeContent}
                      onChange={(e) => setCodeContent(e.target.value)}
                      rows={12}
                      className="w-full rounded-xl border border-slate-700 bg-slate-950 px-3 py-3 text-[12px] font-mono text-slate-100 outline-none transition focus:border-sky-500 focus:ring-2 focus:ring-sky-900 resize-none"
                    />
                  </div>
                </div>
              </div>

              {/* Footer */}
              <div className="flex justify-end gap-2 border-t border-slate-200 px-6 py-4">
                <button type="button" onClick={() => setIsModalOpen(false)} className="rounded-full border border-slate-200 bg-white px-4 py-2 text-sm font-semibold text-slate-700 transition hover:bg-slate-50">
                  Cancel
                </button>
                <button type="button" onClick={handleSubmitSkill} className="rounded-full bg-blue-600 px-4 py-2 text-sm font-semibold text-white transition hover:bg-blue-700">
                  Submit Skill
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
