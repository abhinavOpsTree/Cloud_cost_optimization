import React, { useEffect, useMemo, useState } from 'react';
import {
  AlertTriangle, Check, ChevronLeft, ChevronRight, Clock3, Filter,
  LockKeyhole, RefreshCw, Search, Server, Sparkles, X,
} from 'lucide-react';
import { useCloudSentry } from '../../../hooks/Cloud-Sentry/useCloudSentry';
import RecommendationDrawer from '../components/RecommendationDrawer';

const trackLabels = {
  rightsizing: 'Rightsizing',
  spot: 'Spot',
  schedule: 'Scheduling',
  eks: 'EKS',
  tagging: 'Tagging',
};

const statusStyle = {
  BLOCKED: 'border-red-300 bg-red-50 text-red-700',
  FLAGGED: 'border-orange-300 bg-orange-50 text-orange-700',
  PENDING_REVIEW: 'border-blue-300 bg-blue-50 text-blue-700',
  APPROVED: 'border-green-300 bg-green-50 text-green-700',
  IGNORED: 'border-gray-300 bg-gray-50 text-gray-600',
};

const money = (value) => `$${Number(value || 0).toFixed(2)}`;
const confidence = (value) => Math.round(Number(value || 0) * (Number(value || 0) <= 1 ? 100 : 1));
const actionTitle = (rec) => {
  const track = rec.track?.toLowerCase();
  if (track === 'spot') return 'Convert to Spot';
  if (track === 'schedule') return 'Schedule Instance';
  if (track === 'eks') return 'Optimize EKS Node';
  if (track === 'tagging') return 'Fix Resource Tags';
  return 'Resize Instance';
};
const recommendedType = (rec) =>
  rec.recommended_instance_type ||
  rec.action?.match(/\bto\s+([a-z0-9.]+)\b/i)?.[1] ||
  (rec.track === 'spot' ? `${rec.instance_type} + Spot` : 'Optimized');

function Lifecycle({ recommendations }) {
  const total = recommendations.length;
  const blocked = recommendations.filter((r) => r.status === 'BLOCKED').length;
  const flagged = recommendations.filter((r) => r.status === 'FLAGGED').length;
  const approved = recommendations.filter((r) => r.status === 'APPROVED').length;
  const steps = [
    ['Generated', total, '100% of total', 'from-blue-600 to-blue-700'],
    ['Blocked', blocked, 'Tier 1 — Production', 'from-red-500 to-red-600'],
    ['Flagged', flagged, 'Tier 2 — Needs review', 'from-orange-400 to-orange-500'],
    ['Approved', approved, 'Ready for human action', 'from-green-500 to-green-600'],
  ];
  return (
    <section className="rounded-lg border border-slate-200 bg-white px-4 py-3 shadow-sm">
      <h2 className="mb-3 flex items-center gap-2 text-sm font-semibold text-slate-800">
        <Filter className="h-4 w-4 text-blue-600" /> Governance Lifecycle
      </h2>
      <div className="grid overflow-hidden rounded-md md:grid-cols-4">
        {steps.map(([label, value, helper, color], index) => (
          <div key={label} className={`relative bg-gradient-to-r ${color} px-4 py-3 text-center text-white ${index ? 'border-l-4 border-white' : ''}`}>
            <p className="text-xs font-semibold">{label}</p>
            <p className="text-2xl font-bold leading-7">{value}</p>
            <p className="text-[11px]">{helper}</p>
          </div>
        ))}
      </div>
      <p className="mt-2 text-center text-[11px] text-slate-500">
        Cloud Sentry does not auto-execute. Approved recommendations are handed off to engineers for manual implementation.
      </p>
    </section>
  );
}

function Kpi({ icon: Icon, iconClass, label, value, helper, helperClass = 'text-slate-500' }) {
  return (
    <div className="flex min-h-[88px] items-center gap-3 rounded-lg border border-slate-200 bg-white px-4 py-3 shadow-sm">
      <div className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-full ${iconClass}`}><Icon className="h-5 w-5" /></div>
      <div className="min-w-0">
        <p className="text-[11px] font-semibold text-slate-700">{label}</p>
        <p className="truncate text-xl font-bold text-slate-900">{value}</p>
        <p className={`text-[11px] ${helperClass}`}>{helper}</p>
      </div>
    </div>
  );
}

function StatusBadge({ value }) {
  return (
    <span className={`inline-flex items-center gap-1 rounded border px-2 py-1 text-[9px] font-bold ${statusStyle[value] || statusStyle.PENDING_REVIEW}`}>
      <span className="h-1.5 w-1.5 rounded-full bg-current" /> {String(value || 'PENDING_REVIEW').replaceAll('_', ' ')}
    </span>
  );
}

export default function Recommendations() {
  const { getRecommendations, getInstances, updateRecommendationStatus } = useCloudSentry();
  const [recommendations, setRecommendations] = useState([]);
  const [instancesScanned, setInstancesScanned] = useState(0);
  const [telemetryCount, setTelemetryCount] = useState(0);
  const [loading, setLoading] = useState(true);
  const [selectedRec, setSelectedRec] = useState(null);
  const [track, setTrack] = useState('all');
  const [status, setStatus] = useState('all');
  const [priority, setPriority] = useState('all');
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const pageSize = 6;

  const load = async () => {
    setLoading(true);
    try {
      const [recs, allInstances, telemetry] = await Promise.all([
        getRecommendations({ page: 1, limit: 500 }),
        getInstances({ limit: 1 }),
        getInstances({ has_performance_data: true, limit: 1 }),
      ]);
      setRecommendations(recs?.recommendations || []);
      setInstancesScanned(allInstances?.total || 0);
      setTelemetryCount(telemetry?.total || 0);
    } catch (error) {
      console.error('Failed to load recommendations', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const enriched = useMemo(() => recommendations.map((rec) => ({
    ...rec,
    priority: rec.status === 'BLOCKED' || confidence(rec.confidence) >= 90 ? 'High'
      : confidence(rec.confidence) >= 80 ? 'Medium' : 'Low',
  })), [recommendations]);

  const filtered = useMemo(() => enriched.filter((rec) => {
    const haystack = `${rec.resource_name} ${rec.resource_id} ${rec.action} ${rec.rationale}`.toLowerCase();
    return (track === 'all' || rec.track === track)
      && (status === 'all' || rec.status === status)
      && (priority === 'all' || rec.priority === priority)
      && (!search || haystack.includes(search.toLowerCase()));
  }), [enriched, track, status, priority, search]);

  useEffect(() => setPage(1), [track, status, priority, search]);
  const pages = Math.max(1, Math.ceil(filtered.length / pageSize));
  const visible = filtered.slice((page - 1) * pageSize, page * pageSize);
  const savings = enriched.reduce((sum, rec) => sum + Number(rec.estimated_monthly_saving || 0), 0);
  const blocked = enriched.filter((rec) => rec.status === 'BLOCKED').length;
  const review = enriched.filter((rec) => ['PENDING_REVIEW', 'FLAGGED'].includes(rec.status)).length;
  const missingTelemetry = Math.max(0, instancesScanned - telemetryCount);
  const trackCount = (value) => enriched.filter((rec) => rec.track === value).length;

  const persistStatus = async (rec, nextStatus) => {
    const result = await updateRecommendationStatus(rec.id, nextStatus);
    const updated = result.recommendation;
    setRecommendations((current) => current.map((item) => item.id === updated.id ? { ...item, ...updated } : item));
    setSelectedRec(updated);
  };

  return (
    <div className="mx-auto max-w-[1500px] space-y-3 text-slate-900">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold tracking-tight">Recommendations</h1>
        <button onClick={load} className="flex items-center gap-2 rounded-md border border-slate-200 bg-white px-3 py-2 text-xs font-semibold text-slate-600 shadow-sm hover:bg-slate-50">
          <RefreshCw className={`h-3.5 w-3.5 ${loading ? 'animate-spin' : ''}`} /> Refresh data
        </button>
      </div>

      <Lifecycle recommendations={enriched} />

      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-5">
        <Kpi icon={Sparkles} iconClass="bg-blue-600 text-white" label="Potential Savings" value={`${money(savings)} /mo`} helper={`${money(savings * 12)}/year`} helperClass="font-semibold text-green-600" />
        <Kpi icon={Sparkles} iconClass="bg-violet-100 text-violet-600" label="Total Recommendations" value={enriched.length} helper={`${enriched.filter((r) => r.priority === 'High').length} high priority`} helperClass="text-orange-600" />
        <Kpi icon={Clock3} iconClass="bg-blue-100 text-blue-600" label="Ready for Review" value={review} helper="Pending human action" />
        <Kpi icon={LockKeyhole} iconClass="bg-red-100 text-red-600" label="Blocked / Excluded" value={blocked} helper="Production protected" />
        <Kpi icon={Server} iconClass="bg-blue-100 text-blue-600" label="EC2 Instances Analyzed" value={instancesScanned} helper={`${telemetryCount} with telemetry`} />
      </div>

      {missingTelemetry > 0 && (
        <div className="flex items-center gap-3 rounded-md border border-orange-200 bg-orange-50 px-4 py-2.5 text-xs text-orange-950">
          <AlertTriangle className="h-5 w-5 shrink-0 fill-orange-300 text-orange-500" />
          <span><strong>{missingTelemetry} of {instancesScanned} instances</strong> have no CloudWatch telemetry. Rightsizing is available only where performance data exists.</span>
          <button className="ml-auto text-blue-700"><X className="h-4 w-4" /></button>
        </div>
      )}

      <div className="flex flex-col gap-2 xl:flex-row xl:items-center xl:justify-between">
        <div className="flex flex-wrap gap-2">
          {[['all', `All (${enriched.length})`], ['rightsizing', `Rightsizing (${trackCount('rightsizing')})`], ['spot', `Spot (${trackCount('spot')})`], ['schedule', `Scheduling (${trackCount('schedule')})`], ['eks', `EKS (${trackCount('eks')})`]].map(([value, label]) => (
            <button key={value} onClick={() => setTrack(value)} className={`rounded-md border px-4 py-2 text-xs font-semibold ${track === value ? 'border-blue-600 bg-blue-600 text-white' : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'}`}>{label}</button>
          ))}
        </div>
        <div className="flex flex-wrap gap-2">
          <label className="relative min-w-[280px] flex-1">
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
            <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search instance or recommendation..." className="h-9 w-full rounded-md border border-slate-200 bg-white pl-9 pr-3 text-xs outline-none focus:border-blue-500" />
          </label>
          <select value={priority} onChange={(e) => setPriority(e.target.value)} className="h-9 rounded-md border border-slate-200 bg-white px-3 text-xs font-semibold">
            <option value="all">Priority</option><option>High</option><option>Medium</option><option>Low</option>
          </select>
          <select value={status} onChange={(e) => setStatus(e.target.value)} className="h-9 rounded-md border border-slate-200 bg-white px-3 text-xs font-semibold">
            <option value="all">Status</option><option value="PENDING_REVIEW">Pending review</option><option value="FLAGGED">Flagged</option><option value="BLOCKED">Blocked</option><option value="APPROVED">Approved</option><option value="IGNORED">Ignored</option>
          </select>
        </div>
      </div>

      <section className="overflow-hidden rounded-lg border border-slate-200 bg-white shadow-sm">
        <div className="flex items-center justify-between border-b border-slate-200 px-4 py-2 text-[11px] text-slate-600">
          <span>Showing {filtered.length ? (page - 1) * pageSize + 1 : 0}–{Math.min(page * pageSize, filtered.length)} of {filtered.length} recommendations</span>
          <span className="text-slate-400">Sorted by potential saving</span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[1040px] text-left">
            <thead className="border-b border-slate-200 bg-slate-50 text-[10px] font-semibold text-slate-600">
              <tr>
                <th className="w-10 px-4 py-2"><input type="checkbox" /></th>
                <th className="px-2 py-2">Priority</th><th className="px-2 py-2">Recommendation + Reason</th>
                <th className="px-2 py-2">Instance + ID</th><th className="px-2 py-2">Current → Recommended</th>
                <th className="px-2 py-2">Saving</th><th className="px-2 py-2">Confidence</th><th className="px-2 py-2">Status</th><th className="px-4 py-2">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {loading ? <tr><td colSpan="9" className="px-4 py-12 text-center text-sm text-slate-400">Loading recommendations…</td></tr>
                : visible.length === 0 ? <tr><td colSpan="9" className="px-4 py-12 text-center text-sm text-slate-400">No recommendations match these filters.</td></tr>
                : visible.map((rec) => {
                  const score = confidence(rec.confidence);
                  const priorityColor = rec.priority === 'High' ? 'bg-red-500' : rec.priority === 'Medium' ? 'bg-orange-400' : 'bg-green-500';
                  return (
                    <tr key={rec.id} onClick={() => setSelectedRec(rec)} className={`cursor-pointer text-[11px] hover:bg-blue-50/40 ${rec.status === 'BLOCKED' ? 'bg-red-50/50' : rec.status === 'FLAGGED' ? 'bg-orange-50/50' : ''}`}>
                      <td onClick={(e) => e.stopPropagation()} className="px-4 py-2"><input type="checkbox" /></td>
                      <td className="px-2 py-2"><span className="flex items-center gap-2 font-semibold"><span className={`h-2 w-2 rounded-full ${priorityColor}`} />{rec.priority}</span></td>
                      <td className="max-w-[310px] px-2 py-2">
                        <p className="font-bold text-slate-900">{actionTitle(rec)}</p>
                        <p className={`line-clamp-2 ${rec.status === 'BLOCKED' ? 'font-medium text-red-600' : rec.status === 'FLAGGED' ? 'text-orange-600' : 'text-slate-600'}`}>{rec.gate_reason || rec.rationale}</p>
                      </td>
                      <td className="px-2 py-2"><p className="font-medium">{rec.resource_name || 'Unnamed instance'}</p><p className="text-slate-500">({rec.resource_id})</p></td>
                      <td className="whitespace-nowrap px-2 py-2"><span>{rec.instance_type || '—'} → </span><span className="font-medium">{recommendedType(rec)}</span></td>
                      <td className="whitespace-nowrap px-2 py-2"><p>{money(rec.estimated_monthly_saving)} /mo</p><p className="font-bold text-green-600">+{money(rec.estimated_monthly_saving * 12)} /yr</p></td>
                      <td className="px-2 py-2">
                        <p className="font-bold">{score}%</p>
                        <div className="mt-1 h-1.5 w-20 rounded-full bg-slate-200"><div className={`h-full rounded-full ${score >= 90 ? 'bg-green-600' : score >= 80 ? 'bg-lime-500' : 'bg-yellow-400'}`} style={{ width: `${score}%` }} /></div>
                      </td>
                      <td className="px-2 py-2"><StatusBadge value={rec.status} /></td>
                      <td className="px-4 py-2">
                        {rec.status === 'BLOCKED' ? <LockKeyhole className="mx-auto h-4 w-4 text-slate-600" /> :
                          <button className="rounded bg-blue-600 px-3 py-1.5 font-semibold text-white hover:bg-blue-700">Review</button>}
                      </td>
                    </tr>
                  );
                })}
            </tbody>
          </table>
        </div>
        <div className="flex items-center justify-between border-t border-slate-200 px-4 py-2 text-[11px] text-slate-500">
          <span>Showing {filtered.length ? (page - 1) * pageSize + 1 : 0}–{Math.min(page * pageSize, filtered.length)} of {filtered.length} recommendations</span>
          <div className="flex items-center gap-1">
            <button disabled={page === 1} onClick={() => setPage((p) => p - 1)} className="rounded border p-1 disabled:opacity-40"><ChevronLeft className="h-3.5 w-3.5" /></button>
            <span className="rounded border border-blue-500 px-2 py-1 text-blue-600">{page}</span><span>of {pages}</span>
            <button disabled={page === pages} onClick={() => setPage((p) => p + 1)} className="rounded border p-1 disabled:opacity-40"><ChevronRight className="h-3.5 w-3.5" /></button>
          </div>
        </div>
      </section>

      {selectedRec && <RecommendationDrawer recommendation={selectedRec} onClose={() => setSelectedRec(null)} onStatusChange={persistStatus} />}
    </div>
  );
}
