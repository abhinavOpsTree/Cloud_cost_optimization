import React, { useEffect, useState } from 'react';
import { useCloudSentry } from '../../../hooks/Cloud-Sentry/useCloudSentry';
import Table from '../common/Table.jsx';
import { Download } from 'lucide-react';
import { getCloudSentryApiUrl } from '../lib/ApiClient';

export default function TagAudit() {
  const { getTagAudit } = useCloudSentry();
  const [data, setData] = useState({ instances: [], total_untagged: 0 });
  const [loading, setLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 6;

  useEffect(() => {
    let isMounted = true;
    getTagAudit()
      .then(res => {
        if (isMounted) {
          setData(res || { instances: [], total_untagged: 0 });
          setLoading(false);
        }
      })
      .catch(err => {
        console.error(err);
        if (isMounted) setLoading(false);
      });
    return () => { isMounted = false; };
  }, [getTagAudit]);

  const instances = data.instances || [];
  const totalUntagged = data.total_untagged ?? instances.length;
  const totalInstances = totalUntagged > 0 ? totalUntagged : instances.length;
  const envCount = instances.filter(i => i.has_env).length;
  const ownerCount = instances.filter(i => i.has_owner).length;
  const teamCount = instances.filter(i => i.has_team).length;
  const appCount = instances.filter(i => i.has_app).length;
  const nameCount = instances.filter(i => !!(i.resource_name || i.name)).length;
  const tagHealthScore = totalInstances > 0 ? Math.round((envCount / totalInstances) * 100) : 0;
  const pct = (value) => totalInstances > 0 ? ((value / totalInstances) * 100).toFixed(1) : '0.0';

  const currentPageInstances = instances.slice((currentPage - 1) * pageSize, currentPage * pageSize);
  const totalPages = Math.max(1, Math.ceil(totalUntagged / pageSize));

  const confidenceLabel = (value) => {
    if (value >= 0.7) return 'High';
    if (value >= 0.4) return 'Medium';
    return 'Low';
  };

  const confidenceColor = (value) => {
    if (value >= 0.7) return 'bg-emerald-100 text-emerald-700';
    if (value >= 0.4) return 'bg-amber-100 text-amber-700';
    return 'bg-slate-100 text-slate-700';
  };

  const columns = [
    {
      key: 'resource_id',
      header: 'Instance',
      render: (val, row) => {
        if (row.resource_name && row.resource_name !== 'nan' && row.resource_name !== 'None' && row.resource_name.trim() !== '') return row.resource_name;
        if (row.name && row.name !== 'nan' && row.name.trim() !== '') return row.name;
        return val;
      }
    },
    { key: 'instance_type', header: 'Type' },
    { key: 'region', header: 'Region' },
    {
      key: 'monthly_cost',
      header: 'Monthly Cost',
      render: (val) => typeof val === 'number' ? `$${val.toFixed(2)}/mo` : '-'
    },
    {
      key: 'missing_tags',
      header: 'Missing Tags',
      render: (val) => (
        <div className="flex flex-wrap gap-2">
          {Array.isArray(val) && val.length > 0 ? val.map(tag => (
            <span key={tag} className="rounded-full border border-red-200 bg-red-50 px-2.5 py-1 text-[11px] font-semibold uppercase tracking-[0.18em] text-red-700">
              {tag}
            </span>
          )) : <span className="text-sm text-slate-500">None</span>}
        </div>
      )
    },
    {
      key: 'suggested_env',
      header: 'Suggested Env',
      render: (val) => val || 'unknown'
    },
    {
      key: 'confidence',
      header: 'Tag Confidence',
      render: (val) => {
        const label = confidenceLabel(val ?? 0);
        return (
          <span className={`inline-flex rounded-full px-3 py-1 text-xs font-semibold ${confidenceColor(val ?? 0)}`}>
            {label}
          </span>
        );
      }
    }
  ];

  const fieldData = [
    { label: 'env / environment', value: pct(envCount), count: envCount, color: 'rose' },
    { label: 'owner', value: pct(ownerCount), count: ownerCount, color: 'rose' },
    { label: 'team', value: pct(teamCount), count: teamCount, color: 'rose' },
    { label: 'app', value: pct(appCount), count: appCount, color: 'slate' },
    { label: 'name (inferred)', value: pct(nameCount), count: nameCount, color: 'amber' }
  ];

  const paginationItems = totalPages <= 5 ?
    Array.from({ length: totalPages }, (_, idx) => idx + 1) :
    [1, 2, 'dots', totalPages];

  return (
    <div className="min-h-screen bg-[#F4F7FE] px-4 py-6">
      <div className="mx-auto max-w-[1320px] space-y-6">
        <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
          <h1 className="text-3xl font-semibold text-slate-950">Tag Audit</h1>
          <div className="flex flex-wrap items-center gap-3 text-sm text-slate-500">
            <div className="inline-flex items-center rounded-full border border-slate-200 bg-slate-100 px-4 py-2">24 Jun 2026 – 23 Jul 2026</div>
            <div className="inline-flex items-center rounded-full border border-slate-200 bg-white px-4 py-2 shadow-sm">Opstree</div>
          </div>
        </div>

        <div className="rounded-[32px] border border-slate-200 bg-white p-5 shadow-sm">
          <div className="grid gap-4 lg:grid-cols-[1.15fr_0.85fr]">
            <div className="rounded-[24px] border border-slate-200 bg-white p-6">
              <p className="text-xs uppercase tracking-[0.32em] text-slate-500">Tag Health Score</p>
              <div className="mt-5 flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
                <h2 className="text-[4rem] font-bold tracking-tight text-rose-600">{tagHealthScore}%</h2>
                <p className="max-w-[360px] text-sm leading-6 text-slate-500">Based on environment tag coverage across {totalInstances} instances</p>
              </div>
            </div>

            <div className="rounded-[24px] border border-slate-200 bg-white p-6">
              <div className="flex flex-col gap-5 lg:flex-row lg:items-start lg:justify-between">
                <div>
                  <p className="text-xs uppercase tracking-[0.32em] text-slate-500">Impact</p>
                  <p className="mt-4 text-3xl font-semibold text-rose-600">$300.06</p>
                </div>
                <a
                  href={getCloudSentryApiUrl('/api/tag-audit/download')}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center rounded-full bg-blue-600 px-5 py-3 text-sm font-semibold text-white shadow-sm transition hover:bg-blue-700"
                >
                  <Download className="h-4 w-4" />
                  Download CSV
                </a>
              </div>
              <p className="mt-4 text-sm text-slate-500">in unattributed spend over 90 days</p>
              <p className="mt-2 text-sm text-slate-500">{totalUntagged} instances have no tags</p>
            </div>
          </div>
        </div>

        <div className="rounded-[32px] border border-slate-200 bg-white p-6 shadow-sm">
          <div className="flex items-center justify-between">
            <p className="text-lg font-semibold text-slate-900">Tag Coverage by Field</p>
          </div>

          <div className="mt-6 space-y-4">
            {fieldData.map((field) => {
              const colorClass = field.color === 'rose' ? 'bg-rose-500' : field.color === 'amber' ? 'bg-amber-500' : 'bg-slate-300';
              const valueText = field.value === '0.0' ? '0.0' : field.value;
              const countText = field.count === 0 ? '—' : field.count;
              return (
                <div key={field.label} className="grid gap-4 items-center sm:grid-cols-[1.2fr_2fr_0.9fr]">
                  <div className="text-sm font-medium text-slate-800">{field.label}:</div>
                  <div className="h-3 rounded-full bg-slate-100">
                    <div className={`${colorClass} h-full rounded-full transition-all`} style={{ width: `${field.value}%` }} />
                  </div>
                  <div className="flex items-center justify-end gap-4 text-sm">
                    <span className={`${field.color === 'rose' ? 'text-rose-600' : field.color === 'amber' ? 'text-amber-600' : 'text-slate-500'} font-semibold`}>{valueText}%</span>
                    <span className="text-slate-500">{countText} of {totalInstances} instances</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="rounded-[32px] border border-slate-200 bg-white p-6 shadow-sm">
          <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <div>
              <p className="text-lg font-semibold text-slate-900">Untagged Instances</p>
              <p className="text-sm text-slate-500">Showing 1–{Math.min(pageSize, totalUntagged)} of {totalUntagged} untagged instances</p>
            </div>
            <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
              <span className="inline-flex items-center rounded-full border border-slate-200 bg-slate-100 px-3 py-2 text-sm font-semibold text-slate-700">
                Sorted by monthly cost
              </span>
              <a
                href={getCloudSentryApiUrl('/api/tag-audit/download')}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-2 rounded-full bg-blue-600 px-4 py-3 text-sm font-semibold text-white shadow-sm transition hover:bg-blue-700"
              >
                <Download className="h-4 w-4" />
                Download CSV
              </a>
            </div>
          </div>

          <div className="mt-6 overflow-hidden rounded-[24px] border border-slate-200">
            <Table
              columns={columns}
              data={currentPageInstances}
              isLoading={loading}
            />
          </div>

          <div className="mt-5 flex flex-col gap-3 border-t border-slate-200 pt-4 md:flex-row md:items-center md:justify-between">
            <p className="text-sm text-slate-500">Showing 1–{Math.min(pageSize, totalUntagged)} of {totalUntagged} untagged instances</p>
            <div className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-slate-100 p-2 text-sm text-slate-600">
              <button
                onClick={() => setCurrentPage((page) => Math.max(1, page - 1))}
                className="rounded-full px-3 py-2 hover:bg-slate-200 disabled:opacity-50"
                disabled={currentPage === 1}
              >
                ←
              </button>
              {paginationItems.map((item, idx) => (
                item === 'dots' ? (
                  <span key={idx} className="px-3 py-2 text-sm text-slate-500">…</span>
                ) : (
                  <button
                    key={item}
                    onClick={() => setCurrentPage(item)}
                    className={`rounded-full px-3 py-2 ${currentPage === item ? 'bg-slate-950 text-white' : 'hover:bg-slate-200'}`}
                  >
                    {item}
                  </button>
                )
              ))}
              <button
                onClick={() => setCurrentPage((page) => Math.min(totalPages, page + 1))}
                className="rounded-full px-3 py-2 hover:bg-slate-200 disabled:opacity-50"
                disabled={currentPage === totalPages}
              >
                →
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
