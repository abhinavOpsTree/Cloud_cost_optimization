import React, { useEffect, useRef, useState } from 'react';
import {
  Search,
  Send,
  RefreshCcw,
  MessageCircle,
  DollarSign,
  Shield,
  Zap,
  Cpu,
  Tag,
  Clock
} from 'lucide-react';
import GlassCard from '../components/common/GlassCard.jsx';
import GlassBadge from '../components/common/GlassBadge.jsx';
import { getCloudSentryApiUrl } from '../lib/ApiClient';

const suggestedQuestions = [
  { icon: DollarSign, label: 'Which instance costs the most?' },
  { icon: Shield, label: 'Why was the VPN server blocked?' },
  { icon: Zap, label: 'How much would Spot save us?' },
  { icon: Cpu, label: 'Show all instances under 5% CPU' },
  { icon: Tag, label: 'How many untagged instances are there?' },
  { icon: Clock, label: 'Which track saves the most money?' }
];

const formatRelativeTime = (timestamp) => {
  const diff = Math.floor((Date.now() - timestamp) / 1000);
  if (diff < 60) return `${diff}s ago`;
  if (diff < 3600) return `${Math.floor(diff / 60)} min ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)} hr ago`;
  return `${Math.floor(diff / 86400)} days ago`;
};

export default function Chatbot() {
  const [messages, setMessages] = useState([]);
  const [inputValue, setInputValue] = useState('');
  const [loading, setLoading] = useState(false);
  const messagesEndRef = useRef(null);

  const [sessionId] = useState(() => {
    let sid = localStorage.getItem('cs_chat_session');
    if (!sid) {
      sid = 'sess-' + Math.random().toString(36).slice(2, 10);
      localStorage.setItem('cs_chat_session', sid);
    }
    return sid;
  });

  const [sessionStart] = useState(() => {
    const saved = localStorage.getItem('cs_chat_start');
    if (saved) return Number(saved);
    const now = Date.now();
    localStorage.setItem('cs_chat_start', String(now));
    return now;
  });

  useEffect(() => {
    const history = JSON.parse(localStorage.getItem('cs_chat_messages') || '[]');
    setMessages(history);
  }, []);

  const saveHistory = (msgs) => {
    localStorage.setItem('cs_chat_messages', JSON.stringify(msgs));
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, loading]);

  const addMessage = (msg) => {
    setMessages((prev) => {
      const next = [...prev, msg];
      saveHistory(next);
      return next;
    });
  };

  const handleClearChat = () => {
    setMessages([]);
    localStorage.removeItem('cs_chat_messages');
  };

  const handleSend = async () => {
    if (!inputValue.trim()) return;

    const userMsg = inputValue.trim();
    setInputValue('');
    addMessage({ role: 'user', content: userMsg, createdAt: Date.now() });
    setLoading(true);

    try {
      const response = await fetch(getCloudSentryApiUrl('/api/chat'), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ message: userMsg, session_id: sessionId })
      });

      if (!response.ok) {
        throw new Error(`Server returned ${response.status}`);
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let fullResponse = '';
      let responseSource = 'gemini';
      addMessage({ role: 'assistant', content: '', source: responseSource, createdAt: Date.now() });

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        const text = decoder.decode(value);
        const lines = text.split('\n');

        for (const line of lines) {
          if (!line.startsWith('data: ')) continue;
          try {
            const data = JSON.parse(line.slice(6));
            if (data.type === 'source') {
              responseSource = data.source;
            } else if (data.done) {
              fullResponse = data.full_response || fullResponse;
              if (data.source) responseSource = data.source;
            } else if (data.chunk) {
              fullResponse += data.chunk;
              setMessages((prev) => {
                const updated = [...prev];
                updated[updated.length - 1] = {
                  role: 'assistant',
                  content: fullResponse,
                  source: responseSource,
                  createdAt: updated[updated.length - 1]?.createdAt || Date.now()
                };
                saveHistory(updated);
                return updated;
              });
            }
          } catch {
            // Ignore parse errors
          }
        }
      }

      setMessages((prev) => {
        const updated = [...prev];
        updated[updated.length - 1] = {
          role: 'assistant',
          content: fullResponse,
          source: responseSource,
          createdAt: updated[updated.length - 1]?.createdAt || Date.now()
        };
        saveHistory(updated);
        return updated;
      });
    } catch (err) {
      console.error('Chat error:', err);
      addMessage({ role: 'assistant', content: `Error: ${err.message}`, source: 'error', createdAt: Date.now() });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 px-4 py-6">
      <div className="mx-auto max-w-[1320px] space-y-6">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <h1 className="text-3xl font-semibold text-slate-950">Chatbot</h1>
            <p className="text-sm text-slate-500">Ask the FinOps assistant about your fleet, spend, and cloud health.</p>
          </div>
          <button
            onClick={handleClearChat}
            className="inline-flex items-center gap-2 rounded-full border border-slate-200 bg-white px-4 py-3 text-sm font-semibold text-slate-700 shadow-sm hover:bg-slate-50"
          >
            <RefreshCcw className="h-4 w-4" />
            Clear chat
          </button>
        </div>

        <div className="grid gap-6 xl:grid-cols-[320px_1.2fr] rounded-[32px] border border-slate-200 bg-white shadow-sm overflow-hidden">
          <aside className="border-b border-slate-200 bg-slate-50 p-6 xl:border-b-0 xl:border-r">
            <div className="rounded-[28px] border border-slate-200 bg-white p-5">
              <p className="text-xs uppercase tracking-[0.32em] text-slate-500">FinOps Assistant</p>
              <h2 className="mt-4 text-xl font-semibold text-slate-950">FinOps Assistant</h2>
              <p className="mt-2 text-sm text-slate-500">279 instances · Powered by Gemini</p>
            </div>

            <div className="mt-5 rounded-[28px] border border-slate-200 bg-white p-5">
              <p className="text-sm font-semibold text-slate-900 mb-4">Suggested Questions</p>
              <div className="space-y-2">
                {suggestedQuestions.map(({ icon: Icon, label }) => (
                  <button
                    key={label}
                    onClick={() => setInputValue(label)}
                    className="flex items-center gap-3 w-full rounded-2xl border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-700 hover:border-blue-300 hover:bg-blue-50"
                  >
                    <Icon className="h-4 w-4 text-slate-500" />
                    <span className="text-left">{label}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="mt-5 rounded-[28px] border border-slate-200 bg-white p-5">
              <p className="text-sm font-semibold text-slate-900 mb-3">Session Info</p>
              <div className="space-y-2 text-sm text-slate-600">
                <div>
                  <span className="font-semibold text-slate-900">Session ID:</span> {sessionId}
                </div>
                <div>
                  <span className="font-semibold text-slate-900">Messages:</span> {messages.length}
                </div>
                <div>
                  <span className="font-semibold text-slate-900">Started:</span> {formatRelativeTime(sessionStart)}
                </div>
              </div>
            </div>

            <button
              onClick={handleClearChat}
              className="mt-4 inline-flex items-center gap-2 rounded-full border border-red-200 bg-red-50 px-4 py-3 text-sm font-semibold text-red-700 hover:bg-red-100"
            >
              <RefreshCcw className="h-4 w-4" />
              Clear conversation
            </button>
          </aside>

          <main className="flex flex-col p-6">
            <div className="rounded-[28px] border border-slate-200 bg-white p-5">
              <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
                <div className="flex items-center gap-3">
                  <div className="flex h-11 w-11 items-center justify-center rounded-3xl bg-slate-100 text-slate-700">
                    <MessageCircle className="h-5 w-5" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold uppercase tracking-[0.28em] text-slate-500">FinOps Assistant — OpsTree Fleet</p>
                    <h2 className="mt-1 text-lg font-semibold text-slate-950">Chatbot</h2>
                  </div>
                </div>
                <div className="inline-flex items-center gap-2 rounded-full bg-emerald-50 px-4 py-2 text-sm font-semibold text-emerald-700 border border-emerald-200">
                  <span className="h-2.5 w-2.5 rounded-full bg-emerald-600" />
                  Connected
                </div>
              </div>
            </div>

            <div className="mt-5 rounded-[28px] border border-slate-200 bg-slate-50 p-5 flex-1 flex flex-col">
              <div className="flex-1 overflow-y-auto pr-1 space-y-4">
                {messages.length === 0 ? (
                  <div className="flex h-full min-h-[360px] items-center justify-center rounded-[28px] border border-dashed border-slate-200 bg-white p-10 text-center text-slate-500">
                    <div>
                      <p className="text-sm font-semibold text-slate-900">Start your conversation</p>
                      <p className="mt-2 text-sm">Ask the assistant anything about your cloud fleet.</p>
                    </div>
                  </div>
                ) : (
                  messages.map((msg, idx) => (
                    <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                      <div className={`max-w-[82%] rounded-[28px] border px-4 py-4 ${msg.role === 'user' ? 'bg-blue-600 text-white border-blue-600 rounded-br-[10px]' : 'bg-white text-slate-900 border border-slate-200 rounded-bl-[10px]'}`}>
                        <div className="flex items-center justify-between gap-3">
                          <p className="text-sm font-semibold">{msg.role === 'user' ? 'You' : 'FinOps Assistant'}</p>
                          {msg.role === 'assistant' && msg.source && (
                            <GlassBadge className="bg-slate-100 text-slate-700 border-slate-200">
                              {msg.source === 'error' ? 'Error' : msg.source === 'gemini' ? 'AI-generated' : 'From billing data'}
                            </GlassBadge>
                          )}
                        </div>
                        <p className="mt-3 whitespace-pre-wrap text-sm leading-6">{msg.content}</p>
                        <div className="mt-3 text-[11px] text-slate-500 text-right">{new Date(msg.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</div>
                      </div>
                    </div>
                  ))
                )}
                {loading && (
                  <div className="flex justify-start">
                    <div className="max-w-[70%] rounded-[28px] border border-slate-200 bg-white px-4 py-4 text-sm text-slate-500 animate-pulse">
                      Assistant is typing...
                    </div>
                  </div>
                )}
                <div ref={messagesEndRef} />
              </div>

              <div className="mt-5 rounded-[28px] border border-slate-200 bg-white p-4">
                <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
                  <input
                    type="text"
                    value={inputValue}
                    onChange={(e) => setInputValue(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleSend()}
                    placeholder="Ask anything about your fleet..."
                    className="flex-1 min-w-0 rounded-full border border-slate-200 bg-slate-50 px-4 py-3 text-sm text-slate-900 outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-100"
                  />
                  <button
                    onClick={handleSend}
                    disabled={loading || !inputValue.trim()}
                    className="inline-flex items-center justify-center gap-2 rounded-full bg-blue-600 px-5 py-3 text-sm font-semibold text-white transition hover:bg-blue-700 disabled:opacity-50"
                  >
                    <Send className="h-4 w-4" />
                    Send
                  </button>
                </div>
                <p className="mt-3 text-xs text-slate-500">Powered by Gemini · Conversation saved for this session.</p>
              </div>
            </div>
          </main>
        </div>
      </div>
    </div>
  );
}
