import { apiRequest } from './lib/ApiClient.js';
import { buildQueryParams } from './lib/BuildQueryParams.js';

export const cloudSentryApi = {
  getHealth: () => apiRequest('/api/health', 'GET'),
  getCompleteness: () => apiRequest('/api/data-completeness', 'GET'),
  
  postIngest: (days = 90, startDate = null, endDate = null) => {
    let url = `/api/ingest?days=${days}`;
    if (startDate) url += `&start_date=${startDate}`;
    if (endDate) url += `&end_date=${endDate}`;
    return apiRequest(url, 'POST');
  },
  
  postAnalyse: () => apiRequest('/api/analyse', 'POST'),
  
  getAnalyseProgress: () => apiRequest('/api/analyse/progress', 'GET'),
  
  getInstances: (params) => {
    const qs = buildQueryParams(params);
    return apiRequest(`/api/instances?${qs}`, 'GET');
  },
  
  getRecommendations: (params) => {
    const qs = buildQueryParams(params);
    return apiRequest(`/api/recommendations?${qs}`, 'GET');
  },
  
  updateRecommendationStatus: (recId, status) =>
    apiRequest(`/api/recommendations/${recId}/status`, 'PATCH', { status }),
    
  getSavings: () => apiRequest('/api/savings', 'GET'),
  
  getTagAudit: () => apiRequest('/api/tag-audit', 'GET'),
  
  getFleetSummary: () => apiRequest('/api/fleet-summary', 'GET'),
  
  getTimeSeriesStats: (days = 90, startDate = null, endDate = null) => {
    let url = `/api/time-series-stats?days=${days}`;
    if (startDate) url += `&start_date=${startDate}`;
    if (endDate) url += `&end_date=${endDate}`;
    return apiRequest(url, 'GET');
  },
  
  postChat: (body) => apiRequest('/api/chat', 'POST', body),
  
  getChatHistory: (sessionId) => apiRequest(`/api/chat/history?session_id=${sessionId}`, 'GET'),
  
  getWhatIf: (resourceId) => apiRequest(`/api/what-if/${resourceId}`, 'GET'),
  
  getSpotSimulator: (searchTerm) => apiRequest(`/api/spot-simulator/${searchTerm}`, 'GET'),
  
  getSpotSimulatorFleet: () => apiRequest('/api/spot-simulator-fleet', 'GET'),
  
  getProjection: () => apiRequest('/api/projection', 'GET'),
  
  getAnomalies: () => apiRequest('/api/anomalies', 'GET'),
  
  getLlmUsage: () => apiRequest('/api/llm-usage', 'GET'),
  
  getSkills: () => apiRequest('/api/skills', 'GET'),
  
  getRemediations: () => apiRequest('/api/remediations', 'GET'),
  
  getExportRecommendations: () => apiRequest('/api/export/recommendations', 'GET'),
  
  getExportGovernance: () => apiRequest('/api/export/governance', 'GET'),
  
  getExportLlmUsage: () => apiRequest('/api/export/llm-usage', 'GET'),
  
  getExportRemediations: () => apiRequest('/api/export/remediations', 'GET'),
  
  getExportAuditSummary: () => apiRequest('/api/export/audit-summary', 'GET'),
  
  submitSkill: (body) => apiRequest('/api/skill-submissions', 'POST', body),
  getSkillSubmissions: (status) => apiRequest(`/api/skill-submissions${status ? `?status=${status}` : ''}`, 'GET'),
  approveSkillSubmission: (id, userEmail, reviewNotes) =>
    apiRequest(`/api/skill-submissions/${id}/approve`, 'POST', { review_notes: reviewNotes }, { 'X-User-Email': userEmail }),
  rejectSkillSubmission: (id, userEmail, reviewNotes) =>
    apiRequest(`/api/skill-submissions/${id}/reject`, 'POST', { review_notes: reviewNotes }, { 'X-User-Email': userEmail }),
  getSkillAdmins: () => apiRequest('/api/skill-admins', 'GET'),
  addSkillAdmin: (email, userEmail) =>
    apiRequest('/api/skill-admins', 'POST', { email }, { 'X-User-Email': userEmail }),
  removeSkillAdmin: (email, userEmail) =>
    apiRequest(`/api/skill-admins/${email}`, 'DELETE', null, { 'X-User-Email': userEmail }),
};
