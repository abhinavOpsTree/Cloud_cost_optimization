import React from 'react';

export default function GlassBadge({ children, className = '' }) {
  let colorClasses = 'bg-gray-100 text-gray-600 border-gray-200';
  
  if (typeof children === 'string') {
    const text = children.toUpperCase();
    if (text === 'FLAGGED' || text === 'PENDING') {
      colorClasses = 'bg-yellow-100 text-yellow-800 border-yellow-200';
    } else if (text === 'BLOCKED' || text === 'HARD BLOCK' || text === 'HARD_BLOCK' || text === 'REJECTED') {
      colorClasses = 'bg-red-100 text-red-800 border-red-200';
    } else if (text === 'APPROVE' || text === 'APPROVED') {
      colorClasses = 'bg-green-100 text-green-800 border-green-200';
    }
  }

  return (
    <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium border ${colorClasses} ${className}`}>
      {children}
    </span>
  );
}
