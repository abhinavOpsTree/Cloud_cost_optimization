import React, { useState, useRef, useEffect } from 'react';

export default function TimeRangePicker({ onChange, initialDays, initialStart, initialEnd }) {
  const [isOpen, setIsOpen] = useState(false);
  const [startDate, setStartDate] = useState(initialStart || '');
  const [endDate, setEndDate] = useState(initialEnd || '');
  const [selectedQuick, setSelectedQuick] = useState(initialDays || 90);
  const wrapperRef = useRef(null);

  useEffect(() => {
    function handleClickOutside(event) {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [wrapperRef]);

  const quickRanges = [
    { label: 'Last week', days: 7 },
    { label: 'Last 30 days', days: 30 },
    { label: 'Last 90 days', days: 90 },
    { label: 'Last 6 months', days: 180 },
    { label: 'Last 1 year', days: 365 },
    { label: 'This month so far', days: 'this_month' }
  ];

  const handleQuickSelect = (days, label) => {
    setSelectedQuick(days);
    setStartDate('');
    setEndDate('');
    setIsOpen(false);
    
    if (days === 'this_month') {
      const now = new Date();
      const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
      const today = new Date();
      
      const s = firstDay.toLocaleDateString('en-CA');
      const e = today.toLocaleDateString('en-CA');
      const daysDiff = Math.max(1, Math.ceil((today - firstDay) / (1000 * 60 * 60 * 24)));
      onChange(daysDiff, s, e, label);
    } else {
      const today = new Date();
      const past = new Date();
      past.setDate(today.getDate() - days);
      
      // en-CA format gives YYYY-MM-DD in local time
      const s = past.toLocaleDateString('en-CA');
      const e = today.toLocaleDateString('en-CA');
      onChange(days, s, e, label);
    }
  };

  const handleApplyAbsolute = () => {
    if (startDate && endDate) {
      const s = new Date(startDate);
      const e = new Date(endDate);
      const daysDiff = Math.max(1, Math.ceil((e - s) / (1000 * 60 * 60 * 24)));
      setSelectedQuick(null);
      setIsOpen(false);
      onChange(daysDiff, startDate, endDate, `${startDate} to ${endDate}`);
    }
  };

  let displayLabel = "Select Time Range";
  if (selectedQuick) {
    const found = quickRanges.find(r => r.days === selectedQuick);
    if (found) displayLabel = found.label;
    else displayLabel = `Last ${selectedQuick} days`;
  } else if (startDate && endDate) {
    displayLabel = `${startDate} - ${endDate}`;
  }

  return (
    <div className="relative inline-block text-left" ref={wrapperRef}>
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className="inline-flex justify-center w-full rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none"
      >
        {displayLabel}
        <svg className="-mr-1 ml-2 h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
          <path fillRule="evenodd" d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z" clipRule="evenodd" />
        </svg>
      </button>

      {isOpen && (
        <div className="origin-top-right absolute right-0 mt-2 w-96 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5 z-50 flex flex-col md:flex-row">
          
          <div className="p-4 border-b md:border-b-0 md:border-r border-gray-200 flex-1">
            <h3 className="text-sm font-semibold text-gray-900 mb-4">Absolute Time Range</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">From</label>
                <input 
                  type="date" 
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="w-full border-gray-300 rounded-md shadow-sm text-sm focus:ring-blue-500 focus:border-blue-500 px-2 py-1"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">To</label>
                <input 
                  type="date" 
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  className="w-full border-gray-300 rounded-md shadow-sm text-sm focus:ring-blue-500 focus:border-blue-500 px-2 py-1"
                />
              </div>
              <button 
                onClick={handleApplyAbsolute}
                disabled={!startDate || !endDate}
                className="w-full bg-gray-200 text-gray-700 py-2 rounded-md text-sm font-medium hover:bg-gray-300 disabled:opacity-50"
              >
                Apply time Range
              </button>
            </div>
          </div>

          <div className="p-4 flex-1">
            <h3 className="text-sm font-semibold text-gray-900 mb-2">Quick Ranges</h3>
            <div className="space-y-1">
              {quickRanges.map((range) => (
                <button
                  key={range.label}
                  onClick={() => handleQuickSelect(range.days, range.label)}
                  className={`w-full text-left px-3 py-2 text-sm rounded-md hover:bg-blue-50 ${selectedQuick === range.days ? 'bg-blue-100 text-blue-700 font-medium' : 'text-gray-700'}`}
                >
                  {range.label}
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
