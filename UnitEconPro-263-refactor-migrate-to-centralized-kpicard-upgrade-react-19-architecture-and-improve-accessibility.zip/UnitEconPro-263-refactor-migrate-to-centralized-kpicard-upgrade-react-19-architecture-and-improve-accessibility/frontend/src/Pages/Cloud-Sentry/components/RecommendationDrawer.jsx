import React, { useState } from 'react';
import { Check, ChevronRight, CheckCircle2, MoreHorizontal, LockKeyhole, X } from 'lucide-react';

const money = (value) => `$${Number(value || 0).toFixed(2)}`;
const pct = (value) => Math.round(Number(value || 0) * (Number(value || 0) <= 1 ? 100 : 1));
const actionTitle = (rec) => rec.track === 'spot' ? 'Convert to Spot' : rec.track === 'schedule' ? 'Schedule Instance' : rec.track === 'eks' ? 'Optimize EKS Node' : 'Resize Instance';
const recommendedType = (rec) => rec.recommended_instance_type || rec.action?.match(/\bto\s+([a-z0-9.]+)\b/i)?.[1] || (rec.track === 'spot' ? `${rec.instance_type} + Spot` : 'Optimized');

function CheckRow({ children }) {
  return <li className="flex gap-2"><CheckCircle2 className="mt-0.5 h-3.5 w-3.5 shrink-0 text-green-600" /><span>{children}</span></li>;
}

export default function RecommendationDrawer({ recommendation, onClose, onStatusChange }) {
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const score = pct(recommendation.confidence);
  const currentSpecs = recommendation.current_instance_specs || {};
  const nextSpecs = recommendation.recommended_instance_specs || {};
  const blocked = recommendation.status === 'BLOCKED';

  const decide = async (status) => {
    setSaving(true); setError('');
    try { await onStatusChange(recommendation, status); }
    catch (e) { setError(e.message || 'Could not update status'); }
    finally { setSaving(false); }
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-slate-950/20" onMouseDown={onClose}>
      <aside className="h-full w-full max-w-[390px] overflow-y-auto border-l border-slate-200 bg-white shadow-2xl" onMouseDown={(e) => e.stopPropagation()}>
        <header className="sticky top-0 z-10 border-b border-slate-200 bg-white px-4 py-3">
          <div className="flex items-center justify-between">
            <h2 className="text-xs font-bold text-slate-700">Recommendation Details</h2>
            <div className="flex gap-3"><MoreHorizontal className="h-4 w-4" /><button onClick={onClose}><X className="h-4 w-4" /></button></div>
          </div>
        </header>
        <div className="space-y-4 px-4 py-3 text-[11px] text-slate-700">
          <div>
            <div className="mb-2 flex gap-2">
              <span className="rounded border border-red-200 bg-red-50 px-2 py-0.5 text-[9px] font-bold text-red-600">High Priority</span>
              <span className={`rounded border px-2 py-0.5 text-[9px] font-bold ${blocked ? 'border-red-200 bg-red-50 text-red-600' : 'border-blue-200 bg-blue-50 text-blue-600'}`}>● {recommendation.status?.replaceAll('_', ' ')}</span>
            </div>
            <h1 className="text-lg font-bold text-slate-900">{actionTitle(recommendation)}</h1>
            <p className="mt-1">{recommendation.resource_name || 'Unnamed instance'}<br />({recommendation.resource_id})</p>
            <div className="mt-3 flex flex-wrap gap-1.5">
              <span className="rounded border bg-slate-50 px-2 py-1">● {recommendation.region}</span>
              <span className="rounded border bg-slate-50 px-2 py-1">⌘ {recommendation.track}</span>
              <span className="rounded border bg-slate-50 px-2 py-1">◉ {recommendation.instance_type}</span>
            </div>
          </div>

          <section className="border-t pt-3">
            <h3 className="mb-2 font-bold text-slate-900">AI Rationale</h3>
            <p className="leading-relaxed">{recommendation.rationale || 'This recommendation was generated from the latest fleet analysis and available CloudWatch telemetry.'}</p>
          </section>

          <section className="border-t pt-3">
            <h3 className="mb-2 font-bold text-slate-900">Why AI recommends this</h3>
            <div className="grid grid-cols-3 gap-2">
              {[['CPU', recommendation.cpu_avg_pct ?? 'Low'], ['Memory', recommendation.memory_avg_pct ?? '—'], ['Network I/O', recommendation.network_avg ?? 'Low']].map(([label, value]) => (
                <div key={label} className="rounded border bg-slate-50 p-2 text-center"><p className="text-base font-bold text-slate-900">{value}{typeof value === 'number' ? '%' : ''}</p><p className="text-[9px]">{label}</p></div>
              ))}
            </div>
            <p className="mt-1 text-center text-[9px] text-slate-500">Observed over available CloudWatch history</p>
          </section>

          <section className="border-t pt-3">
            <h3 className="mb-2 font-bold text-slate-900">Instance Specs</h3>
            <table className="w-full border-collapse text-[10px]">
              <thead><tr className="border-y bg-slate-50"><th className="p-1 text-left">Instance Specs</th><th>Current</th><th>Recommended</th></tr></thead>
              <tbody className="divide-y">
                <tr><td className="py-1">Instance</td><td>{recommendation.instance_type || '—'}</td><td>{recommendedType(recommendation)}</td></tr>
                <tr><td className="py-1">vCPU</td><td>{currentSpecs.vcpu ?? '—'}</td><td>{nextSpecs.vcpu ?? '—'}</td></tr>
                <tr><td className="py-1">RAM</td><td>{currentSpecs.ram_gb ? `${currentSpecs.ram_gb} GB` : '—'}</td><td>{nextSpecs.ram_gb ? `${nextSpecs.ram_gb} GB` : '—'}</td></tr>
                <tr><td className="py-1">Network</td><td>{currentSpecs.network || '—'}</td><td>{nextSpecs.network || '—'}</td></tr>
              </tbody>
            </table>
          </section>

          <section className="border-t pt-3">
            <h3 className="mb-2 font-bold text-slate-900">Financial Impact</h3>
            <div className="flex items-center justify-between text-center">
              <div><p className="text-[9px]">Current Spend</p><strong>{money(recommendation.current_monthly_cost)}/mo</strong></div>
              <ChevronRight className="h-4 w-4" />
              <div><p className="text-[9px]">Recommended</p><strong>{money(Math.max(0, recommendation.current_monthly_cost - recommendation.estimated_monthly_saving))}/mo</strong></div>
              <ChevronRight className="h-4 w-4" />
              <div className="text-green-700"><p className="text-[9px]">You Save</p><strong>{money(recommendation.estimated_monthly_saving)}/mo</strong><p className="font-bold">+{money(recommendation.estimated_monthly_saving * 12)}/year</p></div>
            </div>
          </section>

          <section className="border-t pt-3">
            <h3 className="mb-2 font-bold text-slate-900">Governance Checks</h3>
            <ul className="space-y-1.5">
              <CheckRow><strong>Tier 1 — Production Shield</strong><br />{recommendation.gate_tier === 1 ? recommendation.gate_reason : 'No protected production rule triggered.'}</CheckRow>
              <CheckRow><strong>Tier 2 — Risk Flagging</strong><br />{recommendation.gate_tier === 2 ? recommendation.gate_reason : 'Automated risk checks completed.'}</CheckRow>
              <CheckRow><strong>Tier 3 — AI Reasoning</strong><br />Recommendation confidence and workload evidence reviewed.</CheckRow>
            </ul>
          </section>

          <section className="border-t pt-3">
            <h3 className="mb-2 font-bold text-slate-900">Confidence & Risk</h3>
            <div className="grid grid-cols-2 gap-2">
              <div className="rounded border p-2 text-center"><p className="text-[9px]">Confidence</p><p className="text-2xl font-bold text-green-700">{score}%</p><div className="h-1 rounded bg-slate-100"><div className="h-full rounded bg-green-600" style={{ width: `${score}%` }} /></div></div>
              <div className="rounded border p-2"><p className="text-[9px]">Risk Level</p><p className="mt-2 font-bold"><span className={`mr-1 inline-block h-2 w-2 rounded-full ${blocked ? 'bg-red-500' : 'bg-green-600'}`} />{blocked ? 'Protected' : recommendation.gate_tier === 2 ? 'Medium' : 'Low'}</p></div>
            </div>
          </section>

          <section className="border-t pt-3">
            <h3 className="font-bold text-slate-900">Approval Trail</h3>
            <p className="mt-1">Approver: — &nbsp; | &nbsp; Date: — &nbsp; | &nbsp; Notes: —</p>
          </section>

          <section className="border-t pt-3">
            <h3 className="mb-2 font-bold text-slate-900">Actions</h3>
            {blocked ? (
              <div className="flex items-center gap-2 rounded border border-red-200 bg-red-50 p-3 text-red-700"><LockKeyhole className="h-4 w-4" /> Tier 1 blocked recommendations cannot be approved.</div>
            ) : (
              <div className="space-y-2">
                <button disabled={saving} onClick={() => decide('APPROVED')} className="w-full rounded bg-blue-600 py-2 font-bold text-white hover:bg-blue-700 disabled:opacity-50"><Check className="mr-1 inline h-3.5 w-3.5" /> Approve</button>
                <button disabled={saving} onClick={() => decide('IGNORED')} className="w-full rounded border border-slate-300 bg-white py-2 font-semibold hover:bg-slate-50 disabled:opacity-50">Ignore</button>
              </div>
            )}
            {error && <p className="mt-2 text-red-600">{error}</p>}
            <p className="mt-2 text-center text-[10px] text-slate-500">Approving logs your decision for audit purposes.<br />Your team implements the change manually.</p>
          </section>
        </div>
      </aside>
    </div>
  );
}
