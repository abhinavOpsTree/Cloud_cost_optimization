import { GlassCard } from "../../components/common/GlassCard";

const Optimization = () => {
    return (
        <div className="p-6 h-full ">
            <GlassCard className="p-8 h-full flex flex-col justify-center items-center text-center">
                <h1 className="text-3xl font-bold mb-4 text-foreground tracking-tight">Optimization</h1>
                <p className="text-muted-foreground mb-8 text-lg">This is a placeholder for the Optimization analysis page.</p>
                <div className="px-12 py-8 bg-black/5 dark:bg-white/5 border-2 border-dashed border-white/20 rounded-2xl flex items-center justify-center text-muted-foreground font-medium text-lg backdrop-blur-sm">
                    Optimization Recommendations Coming Soon
                </div>
            </GlassCard>
        </div>
    );
};

export default Optimization;

