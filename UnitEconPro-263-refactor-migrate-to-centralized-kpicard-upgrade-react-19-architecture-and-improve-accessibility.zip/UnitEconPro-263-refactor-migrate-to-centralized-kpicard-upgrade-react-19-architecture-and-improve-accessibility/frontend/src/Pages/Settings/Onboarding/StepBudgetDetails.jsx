import React from "react";
import { User, Key, DollarSign } from "lucide-react";
import { motion } from "framer-motion";
import { InputField } from "./InputField";

export default function StepBudgetDetails({ form, onChange, errors }) {
    return (
        <motion.div
            key="step1"
            // initial={{ opacity: 0, x: -10 }}
            // animate={{ opacity: 1, x: 0 }}
            // exit={{ opacity: 0, x: 10 }}
            // transition={{ duration: 0.12 }}
            className="flex flex-col gap-6"
        >
            <div>
                <h3 className="text-md font-bold text-slate-800">Establish Budget Limit</h3>
                <p className="text-[11px] text-slate-500 font-medium">
                    Define the monthly cost threshold for this account. You will receive notifications when forecasts cross this line.
                </p>
            </div>

            <div className="flex flex-col gap-5">
                <InputField label="AWS Account ID" icon={Key} hint="12-digit AWS billing account number" error={errors.account_id}>
                    <input
                        type="text"
                        value={form.account_id}
                        onChange={onChange("account_id")}
                        maxLength="12"
                        placeholder="e.g. 123456789012"
                        className={`w-full h-10 px-3 text-xs text-slate-800 bg-slate-50 border rounded-md outline-none transition-all placeholder:text-neutral-400 ${errors.account_id ? "border-red-300 ring-2 ring-red-500/5 shadow-sm" : "border-slate-200 focus:border-blue-500 focus:bg-white"}`}
                    />
                </InputField>

                <InputField label="Display Label" icon={User} hint="Display label for the budget threshold" error={errors.account_name}>
                    <input
                        type="text"
                        value={form.account_name}
                        onChange={onChange("account_name")}
                        placeholder="e.g. Core Billing Budget"
                        className={`w-full h-10 px-3 text-xs text-slate-800 bg-slate-50 border rounded-md outline-none transition-all placeholder:text-neutral-400 ${errors.account_name ? "border-red-300 ring-2 ring-red-500/5 shadow-sm" : "border-slate-200 focus:border-blue-500 focus:bg-white"}`}
                    />
                </InputField>

                <InputField label="Monthly Budget Limit ($)" icon={DollarSign} hint="Maximum monthly spend limit in USD" error={errors.budget_amount}>
                    <div className="relative w-full">
                        <input
                            type="number"
                            value={form.budget_amount}
                            onChange={onChange("budget_amount")}
                            placeholder="1000.00"
                            min="1"
                            className={`w-full h-10 pl-9 pr-3 text-xs text-slate-800 bg-slate-50 border rounded-md outline-none transition-all placeholder:text-neutral-400 ${errors.budget_amount ? "border-red-300 ring-2 ring-red-500/5 shadow-sm" : "border-slate-200 focus:border-blue-500 focus:bg-white"}`}
                        />
                        <div className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400">
                            <DollarSign size={15} />
                        </div>
                    </div>
                </InputField>
            </div>
        </motion.div>
    );
}
