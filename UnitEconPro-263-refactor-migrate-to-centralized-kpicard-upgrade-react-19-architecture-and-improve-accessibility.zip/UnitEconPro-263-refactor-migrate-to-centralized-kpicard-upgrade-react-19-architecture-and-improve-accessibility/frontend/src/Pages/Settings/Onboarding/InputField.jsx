import React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { AlertCircle } from "lucide-react";

export const InputField = ({ label, hint, children, error, icon: Icon }) => (
    <label className="flex flex-col gap-1.5 cursor-pointer w-full">
        <span className="flex items-center gap-2 text-xs font-semibold capitalize text-neutral-600">
            {Icon && <Icon size={14} className="text-neutral-400" />}
            {label}
        </span>
        {children}
        <AnimatePresence mode="wait">
            {error ? (
                <motion.p
                    initial={{ opacity: 0, y: -4 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -4 }}
                    className="text-[10px] text-red-500 font-bold pl-0.5 flex items-center gap-1"
                >
                    <AlertCircle size={10} /> {error}
                </motion.p>
            ) : hint ? (
                <p className="text-[10px] text-neutral-600 font-medium pl-0.5">
                    {hint}
                </p>
            ) : null}
        </AnimatePresence>
    </label>
);
