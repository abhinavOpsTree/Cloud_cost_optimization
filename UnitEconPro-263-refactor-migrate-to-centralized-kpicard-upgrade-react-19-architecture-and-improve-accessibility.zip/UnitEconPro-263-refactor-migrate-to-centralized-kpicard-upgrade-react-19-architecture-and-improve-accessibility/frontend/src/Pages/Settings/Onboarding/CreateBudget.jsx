import { useState, useActionState } from "react";
import {
    DollarSign,
    X,
    Plus,
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "react-toastify";
import { API_ENDPOINTS } from "../../../APIs/ApiEndPoint";
import { apiRequest } from "../../../lib/apiClient";
import SubmitButton from "../../../common/SubmitButton";

const InputField = ({ label, hint, children, error }) => (
    <label className="flex flex-col gap-1.5 cursor-pointer">
        <span className="flex items-center gap-2 text-xs font-semibold capitalize text-neutral-600">
            {label}
        </span>
        {children}
        <AnimatePresence mode="wait">
            {error ? (
                <motion.p
                    key="error"
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: "auto" }}
                    exit={{ opacity: 0, height: 0 }}
                    className="text-[10px] text-red-500 font-bold pl-0.5"
                >
                    {error}
                </motion.p>
            ) : hint ? (
                <motion.p
                    key="hint"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    className="text-[10px] text-neutral-600 font-medium"
                >
                    {hint}
                </motion.p>
            ) : null}
        </AnimatePresence>
    </label>
);

export default function BudgetForm({ isOpen, onClose }) {
    const [form, setForm] = useState({
        account_id: "",
        account_name: "",
        budget_amount: ""
    });
    const [errors, setErrors] = useState({});

    const set = (key) => (e) => {
        setForm((f) => ({ ...f, [key]: e.target.value }));
        if (errors[key]) {
            setErrors(prev => {
                const next = { ...prev };
                delete next[key];
                return next;
            });
        }
    };

    const validate = () => {
        const newErrors = {};
        if (!form.account_id.trim()) newErrors.account_id = "Account ID is required";
        if (!form.account_name.trim()) newErrors.account_name = "Account name is required";
        if (!form.budget_amount) newErrors.budget_amount = "Budget amount is required";
        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleReset = () => {
        setForm({
            account_id: "",
            account_name: "",
            budget_amount: ""
        });
        setErrors({});
    };

    const [state, formAction] = useActionState(async () => {
        if (!validate()) return { error: "Validation failed" };

        try {
            const finalData = {
                account_id: form.account_id,
                account_name: form.account_name,
                budget_amount: parseFloat(form.budget_amount) || 0,
            };

            await apiRequest({
                endpoint: API_ENDPOINTS.createBudget,
                method: "POST",
                body: finalData,
            });

            toast.success("Budget created successfully");
            handleReset();
            onClose();
            return { success: true };
        } catch (error) {
            console.error("Error in creating budget: ", error);
            toast.error(error?.message || "Failed to create budget");
            return { error: error?.message || "Failed to create budget" };
        }
    }, null);

    return (
        <AnimatePresence>
            {isOpen && (
                <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-6 overflow-hidden">
                    <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        exit={{ opacity: 0 }}
                        onClick={onClose}
                        className="absolute inset-0 bg-black/10 backdrop-blur-sm"
                    />
                    <motion.div
                        initial={{ opacity: 0, scale: 0.95, y: 20 }}
                        animate={{ opacity: 1, scale: 1, y: 0 }}
                        exit={{ opacity: 0, scale: 0.95, y: 20 }}
                        transition={{ type: "spring", damping: 25, stiffness: 350 }}
                        className="relative w-full max-w-lg bg-white border border-neutral-200 rounded-md shadow-2xl overflow-hidden max-h-[92vh] flex flex-col"
                    >
                        <div className="overflow-y-auto px-4 py-4 scrollbar-hide">
                            <div className="flex flex-col gap-6">
                                <div className="flex items-center justify-between">
                                    <div>
                                        <p className="text-xl font-bold text-black ">Create Budget</p>
                                        <span className="text-xs text-neutral-500 font-medium">
                                            Define spend limits for your account
                                        </span>
                                    </div>
                                    <button
                                        onClick={onClose}
                                        className="cursor-pointer text-neutral-400 hover:text-black transition-all hover:rotate-90 z-[110] bg-neutral-100 p-2 rounded-full border border-neutral-200"
                                    >
                                        <X size={16} />
                                    </button>
                                </div>

                                {/* Form Fields */}
                                <form action={formAction} className="flex flex-col gap-6">
                                    {state?.error && (
                                        <div className="p-3 bg-red-50 border border-red-200 text-red-600 text-sm rounded-md font-medium">
                                            {state.error}
                                        </div>
                                    )}
                                    <div className="grid grid-cols-2 gap-6">
                                        <InputField label="Account ID" hint="Linked billing account ID" error={errors.account_id}>
                                            <input
                                                type="text"
                                                value={form.account_id}
                                                onChange={set("account_id")}
                                                placeholder="e.g. 1234567890"
                                                className={`w-full h-10 px-3 text-sm text-black bg-neutral-50 border rounded-md select-none outline-none transition-all placeholder:text-neutral-400 ${errors.account_id ? "border-red-300 ring-2 ring-red-500/5 shadow-sm shadow-red-100" : "border-neutral-200"}`}
                                            />
                                        </InputField>
                                        <InputField label="Account Name" hint="Display name for budget" error={errors.account_name}>
                                            <input
                                                type="text"
                                                value={form.account_name}
                                                onChange={set("account_name")}
                                                placeholder="e.g. Marketing Dept"
                                                className={`w-full h-10 px-3 text-sm text-black bg-neutral-50 border rounded-md select-none outline-none transition-all placeholder:text-neutral-400 ${errors.account_name ? "border-red-300 ring-2 ring-red-500/5 shadow-sm shadow-red-100" : "border-neutral-200"}`}
                                            />
                                        </InputField>
                                    </div>

                                    <InputField label="Budget Amount" hint="Max monthly spend limit" error={errors.budget_amount}>
                                        <div className="relative group">
                                            <input
                                                type="number"
                                                value={form.budget_amount}
                                                onChange={set("budget_amount")}
                                                placeholder="0.00"
                                                min="0"
                                                step="0.01"
                                                className={`w-full h-10 pl-10 pr-3 text-sm text-black bg-neutral-50 border rounded-md select-none outline-none transition-all placeholder:text-neutral-400 ${errors.budget_amount ? "border-red-300 ring-2 ring-red-500/5 shadow-sm shadow-red-100" : "border-neutral-200"}`}
                                            />
                                            <div className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400">
                                                <DollarSign size={16} />
                                            </div>
                                        </div>
                                    </InputField>

                                    <div className="flex items-end justify-end gap-4 pt-4">
                                        <button
                                            type="button"
                                            onClick={handleReset}
                                            className="px-3 py-1 text-sm font-bold text-neutral-500 ring-1 ring-black/20 rounded-md cursor-pointer hover:bg-neutral-50"
                                        >
                                            Reset
                                        </button>
                                        <SubmitButton
                                            icon={Plus}
                                            pendingText="Creating..."
                                            defaultText="Create Budget"
                                            className="px-3 py-1 text-sm ring-1 ring-black/10 rounded-md"
                                        />
                                    </div>
                                </form>
                            </div>
                        </div>
                    </motion.div>
                </div>
            )}
        </AnimatePresence>
    );
}
