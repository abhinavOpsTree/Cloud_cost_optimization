import { useState } from "react";
import { ArrowLeft, ArrowRight, X, RotateCw } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { toast } from "react-toastify";
import { apiRequest } from "../../../lib/apiClient";
import { API_ENDPOINTS } from "../../../APIs/ApiEndPoint";

import CustomStepper from "./CustomStepper";
import StepAWSDetails from "./StepAWSDetails";
import StepBudgetDetails from "./StepBudgetDetails";
import StepSuccess from "./StepSuccess";

export default function AccountOnboardingModal({ isOpen, onClose }) {
    const [step, setStep] = useState(0);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [errors, setErrors] = useState({});

    // Step 1 Form: AWS Account details
    const [accountForm, setAccountForm] = useState({
        account_name: "",
        access_key_id: "",
        secret_access_key: "",
        athena_database: "",
        athena_table: "",
        athena_bucket: "",
        aws_region: "us-east-1"
    });

    // Step 2 Form: Budget limits
    const [budgetForm, setBudgetForm] = useState({
        account_id: "",
        account_name: "",
        budget_amount: ""
    });

    const handleAccountChange = (key) => (e) => {
        setAccountForm(prev => ({ ...prev, [key]: e.target.value }));
        if (errors[key]) {
            setErrors(prev => {
                const next = { ...prev };
                delete next[key];
                return next;
            });
        }
    };

    const handleBudgetChange = (key) => (e) => {
        setBudgetForm(prev => ({ ...prev, [key]: e.target.value }));
        if (errors[key]) {
            setErrors(prev => {
                const next = { ...prev };
                delete next[key];
                return next;
            });
        }
    };

    const validateStep1 = () => {
        const errs = {};
        if (!accountForm.account_name.trim()) errs.account_name = "Account Name is required";
        if (!accountForm.access_key_id.trim()) errs.access_key_id = "Access Key ID is required";
        if (!accountForm.secret_access_key.trim()) errs.secret_access_key = "Secret Access Key is required";
        if (!accountForm.athena_database.trim()) errs.athena_database = "Athena Database is required";
        if (!accountForm.athena_table.trim()) errs.athena_table = "Athena Table is required";
        if (!accountForm.athena_bucket.trim()) errs.athena_bucket = "Athena S3 Bucket is required";
        if (!accountForm.aws_region.trim()) errs.aws_region = "AWS Region is required";

        setErrors(errs);
        return Object.keys(errs).length === 0;
    };

    const validateStep2 = () => {
        const errs = {};
        if (!budgetForm.account_id.trim()) errs.account_id = "Account ID is required";
        if (!budgetForm.account_name.trim()) errs.account_name = "Account name display label is required";
        if (!budgetForm.budget_amount || Number(budgetForm.budget_amount) <= 0) {
            errs.budget_amount = "A valid budget amount greater than 0 is required";
        }

        setErrors(errs);
        return Object.keys(errs).length === 0;
    };

    const handleContinue = async () => {
        if (step === 0) {
            if (!validateStep1()) return;
            setIsSubmitting(true);
            try {
                await apiRequest({
                    endpoint: API_ENDPOINTS.createaccount,
                    method: "POST",
                    body: accountForm,
                });
                toast.success("AWS Account onboarded successfully!");
                setBudgetForm(prev => ({
                    ...prev,
                    account_name: accountForm.account_name
                }));
                setStep(1);
            } catch (err) {
                console.error("Onboarding API error:", err);
                toast.error(err?.message || "Failed to onboard AWS Account");
            } finally {
                setIsSubmitting(false);
            }
        } else if (step === 1) {
            if (!validateStep2()) return;
            setIsSubmitting(true);
            try {
                const payload = {
                    account_id: budgetForm.account_id,
                    account_name: budgetForm.account_name,
                    budget_amount: parseFloat(budgetForm.budget_amount) || 0,
                };
                await apiRequest({
                    endpoint: API_ENDPOINTS.createBudget,
                    method: "POST",
                    body: payload,
                });
                toast.success("Budget threshold configured successfully!");
                setStep(2);
            } catch (err) {
                console.error("Budget API error:", err);
                toast.error(err?.message || "Failed to configure budget");
            } finally {
                setIsSubmitting(false);
            }
        }
    };

    const handleReset = () => {
        setAccountForm({
            account_name: "",
            access_key_id: "",
            secret_access_key: "",
            athena_database: "",
            athena_table: "",
            athena_bucket: "",
            aws_region: "us-east-1"
        });
        setBudgetForm({
            account_id: "",
            account_name: "",
            budget_amount: ""
        });
        setErrors({});
        setStep(0);
    };

    const handleFinish = () => {
        handleReset();
        if (onClose) onClose();
    };

    if (!isOpen) return null;

    return (
        <AnimatePresence>
            <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 sm:p-6 overflow-hidden">
                <button
                    type="button"
                    onClick={onClose}
                    className="absolute inset-0 w-full h-full bg-black/20 backdrop-blur-sm border-none p-0 m-0 focus:outline-none cursor-default"
                />

                <div
                    className="relative bg-white rounded-2xl border border-slate-200 w-full max-w-[580px] shadow-2xl overflow-hidden max-h-[92vh] flex flex-col z-[110]"
                >
                    {/* Header */}
                    <div className="border-b border-slate-100 bg-slate-50/50 px-8 pt-7 pb-4 relative">
                        <button
                            onClick={onClose}
                            className="absolute right-6 top-7 cursor-pointer text-black hover:text-slate-900 transition-all hover:rotate-90 bg-white shadow-sm hover:shadow border border-slate-200 p-2 rounded-full"
                        >
                            <X size={14} />
                        </button>

                        {/* <div className="flex items-center gap-1.5 mb-6">
                            <span className="text-[13px] font-semibold text-slate-900 tracking-tight">SpendSmart</span>
                            <span className="text-[13px] text-slate-400 font-medium">/</span>
                            <span className="text-[13px] text-slate-500 font-medium">AWS Onboarding Setup</span>
                        </div> */}

                        <CustomStepper current={step} />
                    </div>

                    {/* Body */}
                    <div className="px-8 py-6 overflow-y-auto scrollbar-hide flex-1">
                        {step === 0 && (
                            <StepAWSDetails
                                form={accountForm}
                                onChange={handleAccountChange}
                                errors={errors}
                            />
                        )}

                        {step === 1 && (
                            <StepBudgetDetails
                                form={budgetForm}
                                onChange={handleBudgetChange}
                                errors={errors}
                            />
                        )}

                        {step === 2 && (
                            <StepSuccess
                                budgetAmount={budgetForm.budget_amount}
                            />
                        )}
                    </div>

                    {/* Footer */}
                    <div className="px-8 py-5 bg-slate-50 border-t border-slate-100 flex items-center justify-between">
                        {step < 2 ? (
                            <>
                                {step > 0 ? (
                                    <button
                                        disabled={isSubmitting}
                                        onClick={() => setStep((s) => s - 1)}
                                        className="h-9 px-4 rounded-lg text-xs font-bold text-slate-500 border border-slate-200 bg-white shadow-sm hover:bg-slate-50 hover:text-slate-800 transition-colors flex items-center gap-1.5 disabled:opacity-50"
                                    >
                                        <ArrowLeft size={14} /> Back
                                    </button>
                                ) : (
                                    <div />
                                )}

                                <button
                                    disabled={isSubmitting}
                                    onClick={handleContinue}
                                    className="h-9 px-5 rounded-lg text-xs font-bold bg-blue-600 text-white hover:bg-blue-700 transition-all flex items-center gap-1.5 shadow-md shadow-blue-500/20 disabled:opacity-50 cursor-pointer"
                                >
                                    {isSubmitting ? (
                                        <>
                                            <motion.div
                                                animate={{ rotate: 360 }}
                                                transition={{ repeat: Infinity, duration: 1, ease: "linear" }}
                                            >
                                                <RotateCw size={14} />
                                            </motion.div>
                                            Processing...
                                        </>
                                    ) : (
                                        <>
                                            {step === 1 ? "Finish Setup" : "Continue"} <ArrowRight size={14} />
                                        </>
                                    )}
                                </button>
                            </>
                        ) : (
                            <button
                                onClick={handleFinish}
                                className="h-10 w-full rounded-lg text-xs font-bold bg-[var(--button-bg)] text-white  transition-all shadow-sm shadow-[var(--button-bg)]/20 cursor-pointer flex items-center justify-center"
                            >
                                Complete Onboarding
                            </button>
                        )}
                    </div>
                </div>
            </div>
        </AnimatePresence>
    );
}
