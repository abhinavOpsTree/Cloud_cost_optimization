import React from "react";
import { CheckCircle2 } from "lucide-react";
import { motion } from "framer-motion";

export default function StepSuccess({ budgetAmount }) {
    return (
        <motion.div
            key="step2"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="flex flex-col items-center justify-center py-6 text-center gap-5"
        >
            <div className="w-16 h-16 bg-blue-50 rounded-full flex items-center justify-center text-blue-600 shadow-sm border border-blue-100 mb-2">
                <CheckCircle2 size={36} strokeWidth={2.5} />
            </div>
            <div>
                <h3 className="text-lg font-bold text-slate-800">Setup Fully Configured!</h3>
                <p className="text-xs text-slate-500 max-w-sm mt-1 leading-relaxed">
                    Your account credentials have been onboarded and your budget threshold has been set. Cost records will begin synchronizing shortly.
                </p>
            </div>

            {/* Success Checklist */}
            <div className="w-full max-w-xs bg-slate-50 rounded-xl border border-slate-100 p-4 flex flex-col gap-3 text-left">
                <div className="flex items-center gap-2.5 text-xs font-semibold text-slate-700">
                    <span className="text-green-500">✓</span>
                    <span>AWS IAM Access Granted</span>
                </div>
                <div className="flex items-center gap-2.5 text-xs font-semibold text-slate-700">
                    <span className="text-green-500">✓</span>
                    <span>Athena DB CUR Linked</span>
                </div>
                <div className="flex items-center gap-2.5 text-xs font-semibold text-slate-700">
                    <span className="text-green-500">✓</span>
                    <span>Monthly Budget Set (${budgetAmount})</span>
                </div>
            </div>
        </motion.div>
    );
}
