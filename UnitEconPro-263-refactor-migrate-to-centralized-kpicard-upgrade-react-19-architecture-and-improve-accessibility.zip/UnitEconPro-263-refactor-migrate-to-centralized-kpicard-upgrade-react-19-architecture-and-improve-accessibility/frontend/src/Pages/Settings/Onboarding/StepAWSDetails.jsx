import React from "react";
import { User, Key, Lock, Database, Cloud, Globe } from "lucide-react";
import { motion } from "framer-motion";
import { InputField } from "./InputField";

export default function StepAWSDetails({ form, onChange, errors }) {
    return (
        <motion.div
            key="step0"
            // initial={{ opacity: 0, x: -10 }}
            // animate={{ opacity: 1, x: 0 }}
            // exit={{ opacity: 0, x: 10 }}
            // transition={{ duration: 0.12 }}
            className="flex flex-col gap-5"
        >
            <div>
                <h3 className="text-md font-bold text-slate-800">Connect AWS Account</h3>
                <p className="text-[11px] text-slate-500 font-medium">
                    Provide your IAM security credentials and CUR/Athena setup to import cost records.
                </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="sm:col-span-2">
                    <InputField label="Account Display Name" icon={User} hint="Name to represent this AWS account" error={errors.account_name}>
                        <input
                            type="text"
                            value={form.account_name}
                            onChange={onChange("account_name")}
                            placeholder="e.g. Production AWS Account"
                            className={`w-full h-10 px-3 text-xs text-slate-800 bg-slate-50 border rounded-md outline-none transition-all placeholder:text-neutral-400 ${errors.account_name ? "border-red-300 ring-2 ring-red-500/5 shadow-sm" : "border-slate-200 focus:border-blue-500 focus:bg-white"}`}
                        />
                    </InputField>
                </div>

                <InputField label="Access Key ID" icon={Key} hint="AWS IAM User Access Key" error={errors.access_key_id}>
                    <input
                        type="text"
                        value={form.access_key_id}
                        onChange={onChange("access_key_id")}
                        placeholder="AKIA..."
                        className={`w-full h-10 px-3 text-xs text-slate-800 bg-slate-50 border rounded-md outline-none transition-all placeholder:text-neutral-400 ${errors.access_key_id ? "border-red-300 ring-2 ring-red-500/5 shadow-sm" : "border-slate-200 focus:border-blue-500 focus:bg-white"}`}
                    />
                </InputField>

                <InputField label="Secret Access Key" icon={Lock} hint="AWS IAM User Secret Key" error={errors.secret_access_key}>
                    <input
                        type="password"
                        value={form.secret_access_key}
                        onChange={onChange("secret_access_key")}
                        placeholder="••••••••••••••••"
                        className={`w-full h-10 px-3 text-xs text-slate-800 bg-slate-50 border rounded-md outline-none transition-all placeholder:text-neutral-400 ${errors.secret_access_key ? "border-red-300 ring-2 ring-red-500/5 shadow-sm" : "border-slate-200 focus:border-blue-500 focus:bg-white"}`}
                    />
                </InputField>

                <InputField label="Athena Database" icon={Database} hint="Athena DB hosting the CUR tables" error={errors.athena_database}>
                    <input
                        type="text"
                        value={form.athena_database}
                        onChange={onChange("athena_database")}
                        placeholder="e.g. athenacurcfn_billing_db"
                        className={`w-full h-10 px-3 text-xs text-slate-800 bg-slate-50 border rounded-md outline-none transition-all placeholder:text-neutral-400 ${errors.athena_database ? "border-red-300 ring-2 ring-red-500/5 shadow-sm" : "border-slate-200 focus:border-blue-500 focus:bg-white"}`}
                    />
                </InputField>

                <InputField label="Athena Table" icon={Database} hint="Athena Table for cost queries" error={errors.athena_table}>
                    <input
                        type="text"
                        value={form.athena_table}
                        onChange={onChange("athena_table")}
                        placeholder="e.g. cur_cost_report"
                        className={`w-full h-10 px-3 text-xs text-slate-800 bg-slate-50 border rounded-md outline-none transition-all placeholder:text-neutral-400 ${errors.athena_table ? "border-red-300 ring-2 ring-red-500/5 shadow-sm" : "border-slate-200 focus:border-blue-500 focus:bg-white"}`}
                    />
                </InputField>

                <InputField label="Athena S3 Bucket" icon={Cloud} hint="S3 bucket query results destination" error={errors.athena_bucket}>
                    <input
                        type="text"
                        value={form.athena_bucket}
                        onChange={onChange("athena_bucket")}
                        placeholder="s3://cur-billing-results-bucket/"
                        className={`w-full h-10 px-3 text-xs text-slate-800 bg-slate-50 border rounded-md outline-none transition-all placeholder:text-neutral-400 ${errors.athena_bucket ? "border-red-300 ring-2 ring-red-500/5 shadow-sm" : "border-slate-200 focus:border-blue-500 focus:bg-white"}`}
                    />
                </InputField>

                <InputField label="AWS Region" icon={Globe} hint="AWS Region where Athena is configured" error={errors.aws_region}>
                    <input
                        type="text"
                        value={form.aws_region}
                        onChange={onChange("aws_region")}
                        placeholder="us-east-1"
                        className={`w-full h-10 px-3 text-xs text-slate-800 bg-slate-50 border rounded-md outline-none transition-all placeholder:text-neutral-400 ${errors.aws_region ? "border-red-300 ring-2 ring-red-500/5 shadow-sm" : "border-slate-200 focus:border-blue-500 focus:bg-white"}`}
                    />
                </InputField>
            </div>
        </motion.div>
    );
}
