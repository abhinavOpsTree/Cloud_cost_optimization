import { Settings as SettingsIcon } from "lucide-react";
import { useState } from "react";
import { useSettings } from "../../providers/SettingsContext";
import AccountOnboardingModal from "./Onboarding/MultiStepModule";
import { navigationItems } from "../../sidebar/sidebarConfig";

const Settings = () => {
    const { visibleNavItems, toggleNavItem } = useSettings();
    const [isBudgetModalOpen, setIsBudgetModalOpen] = useState(false);

    return (
        <div className="p-6 max-w-1xl mx-auto space-y-3">
            <title>Settings | SpendSmart</title>
            <meta name="description" content="Configure your SpendSmart platform settings." />
            <div className="flex items-center justify-between border-b border-black/10 dark:border-white/10 p-2">
                <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center text-blue-600 dark:text-blue-400">
                        <SettingsIcon size={16} />
                    </div>
                    <h2 className="text-xl font-semibold text-slate-800 dark:text-slate-200">Sidebar Modules</h2>
                </div>
                
            </div>

            <div className="p-6">
                <p className="text-sm text-slate-500 dark:text-slate-400 mb-6">
                    Customize your experience by toggling sidebar modules on or off. Unselected modules will be hidden from the navigation menu.
                </p>

                <div className="space-y-4 mt-4">
                    {navigationItems.filter(item => item.type !== "separator" && item.name !== "Settings").map((item) => {
                        const isVisible = visibleNavItems[item.name] ?? true;
                        return (
                            <div key={item.name} className="flex items-center justify-between px-2 py-3 ring-[.5px] ring-black/10 dark:ring-white/10 rounded-md bg-white/50 dark:bg-slate-800/50 shadow-sm">
                                <div className="flex items-center gap-4">
                                    <div className="w-10 h-10 rounded-full bg-blue-50 dark:bg-white/50 flex items-center justify-center text-blue-600 dark:text-blue-400 border border-blue-100 dark:border-blue-900/30">
                                        <item.icon size={20} />
                                    </div>
                                    <div className="flex flex-col">
                                        <span className="font-semibold text-slate-900 dark:text-white tracking-wide">{item.name}</span>
                                    </div>
                                </div>
                                <button
                                    onClick={() => toggleNavItem(item.name)}
                                    className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none ${isVisible ? 'bg-blue-600' : 'bg-slate-300 dark:bg-slate-600'}`}
                                >
                                    <span
                                        className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${isVisible ? 'translate-x-6' : 'translate-x-1'}`}
                                    />
                                </button>
                            </div>
                        );
                    })}
                </div>
            </div>
            {isBudgetModalOpen && (
                <AccountOnboardingModal isOpen={isBudgetModalOpen} onClose={() => setIsBudgetModalOpen(false)} />
            )}
        </div>
    );
};

export default Settings;
