import { apiRequest } from "../../lib/apiClient";
import { API_ENDPOINTS } from "../../APIs/ApiEndPoint";
import { buildQueryParams } from "../../lib/BuildQueryParams";

export const getCloudWatchSummary = async (filters) => {
  const query = buildQueryParams(filters)
  return apiRequest({ endpoint: `${API_ENDPOINTS.monitoringCloudWatchSummary}?${query}` });
};

export const getCloudWatchEKSClusters = async (filters) => {
  const query = buildQueryParams(filters)
  return apiRequest({ endpoint: `${API_ENDPOINTS.monitoringCloudWatchEKSClusters}?${query}` });
};

export const getCloudWatchLogGroups = async (filters) => {
  const query = buildQueryParams(filters)
  return apiRequest({ endpoint: `${API_ENDPOINTS.monitoringCloudWatchLogGroups}?${query}` });
};

export const getMonitoringFinancials = async (service, accountName) => {
  return apiRequest({ endpoint: API_ENDPOINTS.analyticsFinancials(service, accountName) });
};

