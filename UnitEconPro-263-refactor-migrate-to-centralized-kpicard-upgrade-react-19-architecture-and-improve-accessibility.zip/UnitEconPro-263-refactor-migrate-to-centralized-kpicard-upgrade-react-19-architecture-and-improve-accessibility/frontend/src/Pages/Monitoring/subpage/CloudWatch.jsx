import { useMemo, useState } from "react";
import { splitSuggestionText } from "../../../lib/suggestionText";
import Table from "../../../common/Table";
import CopyableCell from "../../../common/CopyableCell";
import { useMonitoring } from "../../../hooks/useMonitoring";
import { Linechart } from "../../../common/Charts/LazyLinechart";
import { useUnified } from "../../../hooks/useUnified";
import PaginationControls from "../../../common/PaginationControls";
import { RoundedPieChart } from "../../../common/Charts/LazyPiechart";
import { Chips } from "../../../common/Chips";
import { Activity, Database, DollarSign, List } from "lucide-react";
import { CardSkeleton } from "../../../common/Cardoverview";
import { KpiCard } from "../../../components/common/KpiCard";
import { ForecastCardFinance } from "../../../common/MonthtoDate/LazyForecastCardFinance";
import { useSuggestions } from "../../../hooks/useSuggestions";
import { Link } from "react-router-dom";

// Perf: fully static, so hoisted to module scope — stronger than useMemo (one
// allocation for the app's lifetime).
const BREAKDOWN_OPTIONS = [
    { label: "Cost Group", value: "cost-group" },
    { label: "Region", value: "region" },
    { label: "Account", value: "account" },
    { label: "Operation", value: "operation" },
    { label: "Log Prefix", value: "log-prefix" },
    { label: "EKS Cluster", value: "eks-cluster" },
        { label: "Environment", value: "env" },
        { label: "Owner", value: "owner" },
        { label: "Project", value: "project" },
        { label: "Team", value: "team" },
        { label: "Application", value: "application" },
];

const CloudWatch = () => {
    const [dimension, setDimension] = useState("region");
    const { cloudWatchSummary, eksClusters, logGroups, isLoading, isError } = useMonitoring();
    const { suggestions: allSuggestions } = useSuggestions();
    const suggestions = (allSuggestions ?? []).filter(
        (s) => String(s.service).toLowerCase() === "cloudwatch" && s.scope === "page"
    );
    // Perf: memoized so the KPI card list keeps a stable identity between renders;
    // recomputed only when the summary data actually changes.
    const card = useMemo(() => [
        { title: "total_cost", value: cloudWatchSummary?.total_cost, icon: <DollarSign size={16} className="text-green-500" />, icon2: <DollarSign size={16} className="text-green-600" /> },
        { title: "avg_daily_cost", value: cloudWatchSummary?.avg_daily_cost, icon: <Activity size={16} className="text-green-800" />, icon2: <DollarSign size={16} className="text-green-600" /> },
        { title: "total_log_gb", value: cloudWatchSummary?.total_log_gb, icon: <Database size={16} className="text-amber-500" /> },
        { title: "total_alarms", value: cloudWatchSummary?.total_alarms, icon: <Activity size={16} className="text-blue-500" /> },
        { title: "total_api_calls", value: cloudWatchSummary?.total_api_calls, icon: <List size={16} className="text-indigo-500" /> },
    ], [cloudWatchSummary])

    const rowsPerPage = 10;

    const [currentPageEKS, setCurrentPageEKS] = useState(1);
    const [currentPageLogs, setCurrentPageLogs] = useState(1);

    const totalPagesEKS = Math.ceil((eksClusters ?? []).length / rowsPerPage);
    const paginatedEKS = (eksClusters ?? []).slice((currentPageEKS - 1) * rowsPerPage, currentPageEKS * rowsPerPage);

    const totalPagesLogs = Math.ceil((logGroups ?? []).length / rowsPerPage);
    const paginatedLogs = (logGroups ?? []).slice((currentPageLogs - 1) * rowsPerPage, currentPageLogs * rowsPerPage);

    const {
        trend,
        breakdown,
        isTrendLoading,
        isBreakdownLoading,
        isTrendError,
        isBreakdownError
    } = useUnified(dimension);

    // Perf: memoized so both <Table columns={...}> props stay stable between
    // renders; render closures only use a module-level component, so empty deps.
    const ekscolumns = useMemo(() => [
        {
            key: "cluster_name",
            label: "EKS Cluster",
            render: (value) => <CopyableCell value={value} />
        },
        { key: "gb_ingested", label: "Ingested (GB)" },
        { key: "cost", label: "Cost", sortable: true, showTotal: true },
    ], [])

    const logcolumns = useMemo(() => [
        {
            key: "log_group_name",
            label: "Log Group",
            render: (value) => <CopyableCell value={value} />
        },
        { key: "region", label: "Region" },
        { key: "account", label: "Account" },
        { key: "gb_ingested", label: "Ingested (GB)", sortable: true },
        { key: "total_cost", label: "Cost", sortable: true, showTotal: true },
    ], [])

    return (
        <div className="flex flex-col space-y-2 p-2">
            <div className="w-full">
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-2 w-full">
                    {isLoading
                        ? Array.from({ length: 5 }).map((_, i) => (
                            <CardSkeleton key={i} />
                        ))
                        : card.map((kpi) => (
                            <KpiCard key={kpi.title} kpi={kpi} />
                        ))
                    }
                    {isError && (
                        <div className="flex items-center justify-center h-full col-span-full py-10">
                            <span className="text-destructive font-semibold">Error loading data</span>
                        </div>
                    )}
                </div>

            </div>
            <div className="py-1">
                <div className="flex justify-between items-center mb-2.5">
                    <p className="text-sm font-bold uppercase text-[var(--text-primary-color)]">Suggestions</p>
                    <Link to="/recommendation">
                        <button className="text-xs font-bold text-indigo-600 hover:text-indigo-800 transition-colors cursor-pointer bg-transparent border-0 p-0">View all</button>
                    </Link>
                </div>
                {suggestions.length > 0 ? (
                    <div className="space-y-2.5">
                        {suggestions.slice(0, 1).map((item) => {
                            const { title, desc } = splitSuggestionText(item.text);
                            return (
                                <div key={item.id} className="bg-white ring-1 ring-black/10 rounded-lg p-3">
                                    <p className="text-xs font-bold text-gray-900 leading-snug">{title}</p>
                                    {desc && <p className="text-[11px] text-gray-500 mt-1 leading-relaxed whitespace-pre-line">{desc}</p>}
                                    <div className="flex items-center gap-1.5 mt-2 text-[10px] text-gray-400 font-medium">
                                        <span>By {item.created_by || "User"}</span>
                                        <span>·</span>
                                        <span>{new Date(item.created_at).toLocaleDateString()}</span>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                ) : (
                    <div className="flex flex-col items-center justify-center py-12 text-center bg-gray-100 border border-dashed border-gray-200 rounded-xl">
                        <span className="text-xs text-[var(--text-secondary-color)] font-medium">No recommendations found.</span>
                    </div>
                )}
            </div>
            <ForecastCardFinance category="monitoring" service="cloudwatch" trend={trend} isTrendLoading={isTrendLoading} />


            <Linechart 
                avgCost={cloudWatchSummary?.avg_daily_cost} 
                chartdata={trend} 
                name="cost" 
                service="AmazonCloudWatch"
                isLoading={isTrendLoading} 
                isError={isTrendError} 
            />

            <div className="w-full flex flex-col space-y-2 mb-4">
                <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wider px-1">Breakdown By</h3>
                <Chips
                    options={BREAKDOWN_OPTIONS}
                    selected={dimension}
                    onSelect={setDimension}
                />
            </div>

            <RoundedPieChart
                title={`${BREAKDOWN_OPTIONS.find(o => o.value === dimension)?.label} Breakdown`}
                dataKey="cost"
                nameKey="name"
                chartData={breakdown}
                isError={isBreakdownError}
                isLoading={isBreakdownLoading}
            />

            <div className="flex flex-col gap-8 w-full">
                <div className="w-full">
                    <h3 className="text-lg font-semibold mb-2">EKS Cluster CloudWatch Costs</h3>
                    <Table
                        columns={ekscolumns}
                        data={paginatedEKS}
                        isLoading={isLoading}
                    />
                    <PaginationControls
                        currentPage={currentPageEKS}
                        totalPages={totalPagesEKS}
                        onPageChange={setCurrentPageEKS}
                    />
                </div>
                <div className="w-full">
                    <h3 className="text-lg font-semibold mb-2">Top 20 Log Groups</h3>
                    <Table
                        columns={logcolumns}
                        data={paginatedLogs}
                        isLoading={isLoading}
                    />
                    <PaginationControls
                        currentPage={currentPageLogs}
                        totalPages={totalPagesLogs}
                        onPageChange={setCurrentPageLogs}
                    />
                </div>
            </div>
        </div>
    );
};

export default CloudWatch;
