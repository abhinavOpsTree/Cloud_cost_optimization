import { Outlet } from "react-router-dom";
import SubPageTabs from "../../common/SubPageTabs";

const Monitoring = () => {
    return (
        <div className="w-full min-h-screen space-y-2 px-6 py-2">
            <title>Monitoring | SpendSmart</title>
            <meta name="description" content="Monitor your cloud resources and financial health." />
            <SubPageTabs />
            <div className="mb-4 mt-4">
                <Outlet />
            </div>
        </div>
    );
};

export default Monitoring;
