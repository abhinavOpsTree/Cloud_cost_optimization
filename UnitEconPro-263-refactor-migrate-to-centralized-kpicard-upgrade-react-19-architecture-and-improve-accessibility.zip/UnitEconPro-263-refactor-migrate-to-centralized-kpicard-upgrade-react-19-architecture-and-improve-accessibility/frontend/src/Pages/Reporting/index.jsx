import { useMemo, useState, memo } from "react";
import { useParams } from "react-router-dom";
import dayjs from "dayjs";
import {
    ResponsiveContainer, LineChart, Line, XAxis, YAxis,
    CartesianGrid, Tooltip,
} from "recharts";
import {
    AlertCircle, TrendingUp, TrendingDown, BarChart3, Box,
    CalendarDays, Info,
} from "lucide-react";
import { useReports, useReportTrend } from "../../hooks/useReporting";
import { useFilters } from "../../hooks/useFilters";
import Table from "../../common/Table";
import Select from "../../common/Select";
import Skeleton from "../../common/Skeleton";
import Toggle from "../../common/Toggle";
import MetricBadge from "../../common/MetricBadge";

const GHOST_CHART_DATA = [
    { label: "Jan", actual: 1000, trend: 1100, forecast: 1050 },
    { label: "Feb", actual: 1200, trend: 1150, forecast: 1100 },
    { label: "Mar", actual: 1100, trend: 1200, forecast: 1150 },
    { label: "Apr", actual: 1400, trend: 1250, forecast: 1200 },
    { label: "May", actual: 1300, trend: 1300, forecast: 1250 },
    { label: "Jun", actual: 1500, trend: 1350, forecast: 1400 },
];

// ─────────────────────────────────────────────
// Formatting helpers
// ─────────────────────────────────────────────
const CURRENCY_SYMBOL = { usd: "$", inr: "₹" };

const fmtMoney = (value, currency = "usd") => {
    if (value === null || value === undefined) return "—";
    const sym = CURRENCY_SYMBOL[String(currency).toLowerCase()] || "$";
    const locale = String(currency).toLowerCase() === "inr" ? "en-IN" : "en-US";
    return `${sym}${Number(value).toLocaleString(locale, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
};

const fmtCompact = (value, currency = "usd") => {
    if (value === null || value === undefined) return "—";
    const sym = CURRENCY_SYMBOL[String(currency).toLowerCase()] || "$";
    const v = Number(value);
    if (String(currency).toLowerCase() === "inr") {
        if (Math.abs(v) >= 1e7) return `${sym}${(v / 1e7).toFixed(2)} Cr`;
        if (Math.abs(v) >= 1e5) return `${sym}${(v / 1e5).toFixed(2)} L`;
    } else {
        if (Math.abs(v) >= 1e6) return `${sym}${(v / 1e6).toFixed(2)}M`;
        if (Math.abs(v) >= 1e3) return `${sym}${(v / 1e3).toFixed(2)}K`;
    }
    const locale = String(currency).toLowerCase() === "inr" ? "en-IN" : "en-US";
    return `${sym}${v.toLocaleString(locale, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
};

const fmtSignedMoney = (value, currency) => {
    if (value === null || value === undefined) return "—";
    return `${value > 0 ? "+" : ""}${fmtMoney(value, currency)}`;
};

const fmtSignedPct = (value) => {
    if (value === null || value === undefined) return "—";
    return `${value > 0 ? "+" : ""}${Number(value).toFixed(1)}%`;
};

const serviceLabel = (svc) => {
    const known = { ec2: "EC2", ebs: "EBS", s3: "S3", eks: "EKS", ecs: "ECS", ecr: "ECR", rds: "RDS", vpc: "VPC", elb: "ELB", cloudwatch: "CloudWatch", datatransfer: "Data Transfer", "data-transfer": "Data Transfer", unallocated: "Unallocated" };
    return known[String(svc).toLowerCase()] || String(svc).toUpperCase();
};

// ─────────────────────────────────────────────
// Unified Status / Risk Enum & Styling Mappings
// ─────────────────────────────────────────────
const REPORTING_STATUS_ENUM = {
    Critical: {
        key: "Critical",
        label: "Critical",
        description: "Spending exceeds the budget by more than 50%. Immediate attention is recommended to identify and resolve the cause.",
        text: "text-[var(--red-fg)]",
        bg: "bg-[var(--red-bg)]",
        ring: "ring-[var(--red-ring)]",
        dot: "bg-[var(--red-dot)]",
        sub: "Exceeds budget by >50%",
    },
    High: {
        key: "High",
        label: "High",
        description: "Spending is 20–50% above budget. Significant overspend that should be investigated and addressed.",
        text: "text-[var(--orange-fg)]",
        bg: "bg-orange-50",
        ring: "ring-[var(--orange-border)]",
        dot: "bg-orange-500",
        sub: "20–50% above budget",
    },
    Medium: {
        key: "Medium",
        label: "Medium",
        description: "Spending is 10–20% above budget. Moderate budget overrun that may require optimization.",
        text: "text-[var(--amber-fg)]",
        bg: "bg-yellow-50",
        ring: "ring-[var(--amber-ring)]",
        dot: "bg-[var(--amber-dot)]",
        sub: "10–20% above budget",
    },
    Low: {
        key: "Low",
        label: "Low",
        description: "Spending is 5–10% above budget. A small overage that should be monitored but is not immediately concerning.",
        text: "text-[var(--yellow-fg)]",
        bg: "bg-[var(--yellow-bg)]",
        ring: "ring-[var(--yellow-ring)]",
        dot: "bg-[var(--yellow-dot)]",
        sub: "5–10% above budget",
    },
    "On Track": {
        key: "On Track",
        label: "On Track",
        description: "Spending is within ±5% of the budget, indicating expected and well-controlled costs.",
        text: "text-[var(--green-fg)]",
        bg: "bg-[var(--green-bg)]",
        ring: "ring-[var(--green-ring)]",
        dot: "bg-[var(--green-dot)]",
        sub: "Within ±5% of budget",
    },
    Efficient: {
        key: "Efficient",
        label: "Efficient",
        description: "Spending is 5–10% below budget, reflecting efficient resource usage and close alignment with the budget.",
        text: "text-cyan-600",
        bg: "bg-cyan-50",
        ring: "ring-cyan-200",
        dot: "bg-cyan-500",
        sub: "5–10% below budget",
    },
    "Under Budget": {
        key: "Under Budget",
        label: "Under Budget",
        description: "Spending is 10–30% below budget, indicating healthy cost savings while remaining within expected usage.",
        text: "text-[var(--blue-fg)]",
        bg: "bg-[var(--blue-bg)]",
        ring: "ring-[var(--blue-border)]",
        dot: "bg-blue-600",
        sub: "10–30% below budget",
    },
    Underbudget: {
        key: "Underbudget",
        label: "Under Budget",
        description: "Spending is 10–30% below budget, indicating healthy cost savings while remaining within expected usage.",
        text: "text-[var(--blue-fg)]",
        bg: "bg-[var(--blue-bg)]",
        ring: "ring-[var(--blue-border)]",
        dot: "bg-blue-600",
        sub: "10–30% below budget",
    },
    Investigate: {
        key: "Investigate",
        label: "Investigate",
        description: "Spending is more than 30% below budget. This may indicate an outage, missing usage, or incomplete cost reporting and should be reviewed.",
        text: "text-[var(--purple-fg)]",
        bg: "bg-[var(--purple-bg)]",
        ring: "ring-[var(--purple-border)]",
        dot: "bg-purple-600",
        sub: ">30% below budget",
    },
};

// Derived helper mappings for backward compatibility across components
const STATUS_STYLE = new Proxy(REPORTING_STATUS_ENUM, {
    get(target, prop) {
        if (prop in target) {
            const item = target[prop];
            return {
                text: item.text,
                bg: item.bg,
                ring: item.ring,
                sub: item.description,
                label: item.label
            };
        }
        const key = String(prop || "").trim();
        const found = Object.values(target).find(
            item => item.key.toLowerCase() === key.toLowerCase() || item.label.toLowerCase() === key.toLowerCase() || item.key.toLowerCase().replace(/[\s-_]+/g, "") === key.toLowerCase().replace(/[\s-_]+/g, "")
        );
        if (found) {
            return {
                text: found.text,
                bg: found.bg,
                ring: found.ring,
                sub: found.description,
                label: found.label
            };
        }
        return { text: "text-slate-600", bg: "bg-slate-50", ring: "ring-slate-200", sub: "Not Enough History", label: String(prop) };
    }
});

const RISK_STYLE = new Proxy(REPORTING_STATUS_ENUM, {
    get(target, prop) {
        if (prop in target) {
            const item = target[prop];
            return {
                dot: item.dot,
                text: item.text,
                bg: item.bg,
                ring: item.ring,
                line2: item.description,
                label: item.label
            };
        }
        const key = String(prop || "").trim();
        const found = Object.values(target).find(
            item => item.key.toLowerCase() === key.toLowerCase() || item.label.toLowerCase() === key.toLowerCase() || item.key.toLowerCase().replace(/[\s-_]+/g, "") === key.toLowerCase().replace(/[\s-_]+/g, "")
        );
        if (found) {
            return {
                dot: found.dot,
                text: found.text,
                bg: found.bg,
                ring: found.ring,
                line2: found.description,
                label: found.label
            };
        }
        return { dot: "bg-slate-400", text: "text-slate-600", bg: "bg-slate-100", ring: "ring-slate-200", line2: "No budget assigned", label: String(prop) };
    }
});

const SectionHeading = memo(({ title, subtitle, right }) => (
    <div className="flex items-start justify-between gap-4 mb-4">
        <div className="flex items-start gap-2.5">
            <div>
                <h2 className="text-sm font-bold text-[var(--purple-fg)] uppercase tracking-wide">{title}</h2>
                {subtitle && <p className="text-xs text-slate-500 mt-0.5">{subtitle}</p>}
            </div>
        </div>
        {right}
    </div>
));

const InsightRow = memo(({ icon: Icon, iconClass, large, children }) => (
    large ? (
        // Boxed variant used by the Executive Summary grid — fills its cell
        <div className="flex items-start gap-4 p-5 rounded-xl bg-slate-100/60 ring-1 ring-black/5 h-full">
            <div className={`w-11 h-11 rounded-xl flex items-center justify-center shrink-0 ${iconClass}`}>
                <Icon size={19} />
            </div>
            <p className="text-sm text-slate-700 leading-relaxed mt-0.5">{children}</p>
        </div>
    ) : (
        <div className="flex items-start gap-4 py-4 border-b border-slate-100 last:border-0">
            <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${iconClass}`}>
                <Icon size={15} />
            </div>
            <p className="text-xs text-slate-700 leading-relaxed mt-0.5">{children}</p>
        </div>
    )
));

// Green pill label rendered on the forecast point of the chart.
// The label fires for every point of the series — lastIndex restricts it to the
// real forecast slot so the MTD-side connector point doesn't get a pill too.
const ForecastLabel = memo(({ x, y, value, currency, index, lastIndex }) => {
    if (value === null || value === undefined) return null;
    if (lastIndex != null && index !== lastIndex) return null;
    const text = fmtCompact(value, currency);
    const w = text.length * 7 + 16;
    return (
        <g transform={`translate(${x - w / 2},${y - 30})`}>
            <rect width={w} height={20} rx={5} fill="var(--green-fg)" />
            <text x={w / 2} y={13} textAnchor="middle" fill="#fff" fontSize={11} fontWeight={700}>{text}</text>
        </g>
    );
});

const ChartTooltip = memo(({ active, payload, label, currency }) => {
    if (!active || !payload?.length) return null;
    return (
        <div className="bg-white rounded-lg ring-1 ring-black/10 shadow-lg px-3 py-2">
            <p className="text-[10px] font-bold text-slate-400 uppercase mb-1">{label}</p>
            {payload.filter(p =>
                p.value != null &&
                !(p.dataKey === "mtd" && p.payload?.mtdConnector) &&
                !(p.dataKey === "forecast" && p.payload?.forecastConnector)
            ).map((p) => (
                <p key={p.dataKey} className="text-xs font-semibold" style={{ color: p.stroke }}>
                    {p.name}: {fmtMoney(p.value, currency)}
                </p>
            ))}
        </div>
    );
});

// Structured loading state mirroring the Executive Summary layout:
// header line, status circle + status text, and the 2×2 insight tile grid.
const ExecSummarySkeleton = memo(() => (
    <div className="bg-white rounded-2xl ring-1 ring-black/10 p-8 min-h-[300px] flex flex-col">
        <Skeleton variant="text" width={190} height={18} className="mb-6" />
        <div className="flex flex-col lg:flex-row gap-10 flex-1">
            <div className="shrink-0 lg:w-96 flex items-center justify-center gap-8">
                <Skeleton variant="circular" width={128} />
                <div className="space-y-2.5">
                    <Skeleton variant="text" width={56} height={12} />
                    <Skeleton variant="text" width={120} height={34} />
                    <Skeleton variant="text" width={96} height={12} />
                </div>
            </div>
            <div className="flex-1 lg:border-l lg:border-slate-100 lg:pl-10 grid grid-cols-1 xl:grid-cols-2 gap-4 content-center">
                {Array.from({ length: 4 }).map((_, i) => (
                    <div key={i} className="flex items-start gap-4 p-5 rounded-xl bg-slate-50/60 ring-1 ring-black/5">
                        <Skeleton variant="rectangular" width={44} height={44} />
                        <div className="flex-1 space-y-2 mt-1">
                            <Skeleton variant="text" width="90%" height={12} />
                            <Skeleton variant="text" width="60%" height={12} />
                        </div>
                    </div>
                ))}
            </div>
        </div>
    </div>
));

// ─────────────────────────────────────────────
// Page
// ─────────────────────────────────────────────
const Reporting = () => {
    const { role } = useParams();
    const { filters } = useFilters();
    const account = filters.account || "All";
    const [lookback, setLookback] = useState(12);
    const [periodToggle, setPeriodToggle] = useState("current");
    const [timeframe, setTimeframe] = useState("month");

    const { data: summary, isLoading: summaryLoading } = useReports({ 
        account, 
        persona: role || "cto", 
        period: periodToggle, 
        scope: timeframe 
    });
    const { data: trend, isLoading: trendLoading } = useReportTrend({ 
        account, 
        persona: role || "cto", 
        lookback, 
        period: periodToggle, 
        scope: timeframe 
    });

    const meta = summary?.meta;
    const currency = meta?.currency || "usd";
    const exec = summary?.executive_summary;
    const breakdown = summary?.budget_breakdown;
    const totals = summary?.total_summary;

    const statusStyle = STATUS_STYLE[exec?.status] || STATUS_STYLE["Insufficient Data"];

    // Build the recharts array from the trend API.
    // Live shape: trend_data.spend_series [{month, label, spend, type: actual|mtd|projected}]
    // (older documented shape with actual_spend_series/historical_trend_series kept as fallback)
    const chartData = useMemo(() => {
        const t = trend?.trend_data;
        if (!t) return [];
        let rows = [];

        if (Array.isArray(t.spend_series) && t.spend_series.length) {
            const actualsList = [];
            t.spend_series.forEach((p) => {
                const label = dayjs(`${p.month}-01`).format("MMM 'YY");
                if (p.type === "actual") {
                    rows.push({ month: p.month, sortKey: p.month, label, actual: p.spend });
                    actualsList.push({ month: p.month, spend: p.spend });
                } else if (p.type === "mtd") {
                    // partial month — standalone dot on the current month's slot only
                    rows.push({ month: p.month, sortKey: p.month, label, mtd: p.spend });
                } else if (p.type === "projected") {
                    // month-end projection — its own x slot, just after the current month
                    rows.push({ month: p.month, sortKey: `${p.month}~`, label: `${label} (Forecast)`, forecast: p.spend });
                }
            });
            rows.sort((a, b) => a.sortKey.localeCompare(b.sortKey));

            // Purple baseline: expected value per month = avg of the prior (up to 3) completed months.
            // Keyed by month, so the MTD and Forecast slots of the current month share one expected value.
            actualsList.sort((a, b) => a.month.localeCompare(b.month));
            rows.forEach((r) => {
                const prior = actualsList.filter(a => a.month < r.month).slice(-3);
                if (prior.length) r.trend = prior.reduce((s, a) => s + a.spend, 0) / prior.length;
            });

            // Trace the MTD line from the last completed month — the connector point is
            // flagged so the tooltip on that month doesn't list an MTD entry.
            const mIdx = rows.findIndex(r => r.mtd != null && r.actual == null);
            if (mIdx > 0 && rows[mIdx - 1].actual != null) {
                rows[mIdx - 1].mtd = rows[mIdx - 1].actual;
                rows[mIdx - 1].mtdConnector = true;
            }

            // Trace the forecast from the MTD point — flagged so the MTD slot's tooltip
            // doesn't list a Forecast entry and no green dot/pill renders there.
            const hasForecastSlot = rows.some(r => r.forecast != null);
            const mtdRow = rows.find(r => r.mtd != null && !r.mtdConnector);
            if (hasForecastSlot && mtdRow) {
                mtdRow.forecast = mtdRow.mtd;
                mtdRow.forecastConnector = true;
            }
        } else {
            const labels = t.x_axis_labels || [];
            const byMonth = new Map();
            (t.actual_spend_series || []).forEach((p, i) => {
                byMonth.set(p.month, {
                    month: p.month,
                    label: labels[i] || dayjs(`${p.month}-01`).format("MMM 'YY"),
                    actual: p.is_forecast ? null : p.spend,
                    forecast: p.is_forecast ? p.spend : null,
                });
            });
            (t.historical_trend_series || []).forEach((p) => {
                const row = byMonth.get(p.month) || { month: p.month, label: dayjs(`${p.month}-01`).format("MMM 'YY") };
                row.trend = p.spend;
                byMonth.set(p.month, row);
            });
            rows = [...byMonth.values()].sort((a, b) => a.month.localeCompare(b.month));
            // Old shape draws forecast as a dashed continuation — connect it to the last actual
            const fIdx = rows.findIndex(r => r.forecast != null && r.actual == null);
            if (fIdx > 0 && rows[fIdx - 1].actual != null) rows[fIdx - 1].forecast = rows[fIdx - 1].actual;
        }

        return rows;
    }, [trend]);

    // Live executive_summary fields: status, account_budget, projected_spend,
    // mtd_actual, budget_overrun_pct, projected_overage_amount, headline_insight
    const projectedDisplay = exec?.projected_spend != null
        ? fmtCompact(exec.projected_spend, currency)
        : (exec?.projected_spend_display || null);
    const overBudgetPct = exec?.budget_overrun_pct ?? exec?.over_budget_pct ?? null;

    // % vs expected trend — not sent by the API; derived from the chart's baseline
    const overTrendPct = useMemo(() => {
        if (exec?.over_historical_trend_pct != null) return exec.over_historical_trend_pct;
        const slot = chartData.find(r => r.forecast != null && !r.forecastConnector && r.actual == null);
        const projected = exec?.projected_spend ?? slot?.forecast;
        if (slot?.trend > 0 && projected != null) return ((projected - slot.trend) / slot.trend) * 100;
        return null;
    }, [exec, chartData]);

    // Breakdown rows + a synthetic Total row for the shared Table component
    const tableRows = useMemo(() => {
        if (!breakdown || !breakdown.length) return [];
        const rows = breakdown.map((r, i) => ({ ...r, id: r.service || String(i) }));
        if (totals) {
            rows.push({
                id: "__total",
                isTotal: true,
                service: "Total",
                budget: totals.total_budget,
                actual: totals.total_actual,
                projected_spend: exec?.projected_spend,
                variance_amount: Math.round((totals.total_actual - totals.total_budget) * 100) / 100,
                overage_pct: totals.total_variance_pct,
                risk: totals.status,
            });
        }
        return rows;
    }, [breakdown, totals, exec?.projected_spend]);

    const reportColumns = useMemo(() => [
        {
            key: "service",
            label: "Service",
            cellClassName: "text-left",
            render: (v, row) => (
                <span className={row.isTotal ? "font-black text-slate-900" : "font-semibold text-slate-800"}>
                    {row.isTotal ? "Total" : serviceLabel(v)}
                </span>
            ),
        },
        {
            key: "budget",
            label: "Budget",
            render: (v, row) => <span className={row.isTotal ? "font-bold" : ""}>{fmtMoney(v, currency)}</span>,
        },
        {
            key: "actual",
            label: "Actual (MTD)",
            render: (v, row) => <span className={row.isTotal ? "font-bold" : ""}>{fmtMoney(v, currency)}</span>,
        },
        {
            key: "projected_spend",
            label: "Projected",
            render: (v, row) => <span className={row.isTotal ? "font-bold" : ""}>{fmtMoney(v, currency)}</span>,
        },
        {
            key: "variance_amount",
            label: "Variance",
            render: (v, row) => (
                <MetricBadge value={v} isTotal={row.isTotal}>
                    {fmtSignedMoney(v, currency)}
                </MetricBadge>
            ),
        },
        {
            key: "overage_pct",
            label: "Variance %",
            render: (v, row) => (
                <MetricBadge value={v} isTotal={row.isTotal}>
                    {fmtSignedPct(v)}
                </MetricBadge>
            ),
        },
        {
            key: "risk",
            label: "Business Risk",
            className: "w-[26%]",
            cellClassName: "whitespace-normal",
            render: (v, row) => {
                const risk = RISK_STYLE[v] || RISK_STYLE["Unbudgeted"];

                const labelText = row.isTotal
                    ? `Overall: ${(row.overage_pct ?? 0) > 0 ? "Overspending" : "Within budget"}`
                    : v === "Unbudgeted"
                        ? "No budget set"
                        : (risk.label || v);

                const bgClass = row.isTotal
                    ? ((row.overage_pct ?? 0) > 0 ? "bg-[var(--red-bg)] ring-1 ring-inset ring-[var(--red-ring)]" : "bg-[var(--green-bg)] ring-1 ring-inset ring-[var(--green-ring)]")
                    : (v === "Unbudgeted" ? "bg-slate-100 ring-1 ring-inset ring-slate-200" : `${risk.bg || "bg-slate-100"} ${risk.ring ? `ring-1 ring-inset ${risk.ring}` : ""}`);

                const colorClass = row.isTotal
                    ? ((row.overage_pct ?? 0) > 0 ? "text-[var(--red-fg)]" : "text-[var(--green-fg)]")
                    : (v === "Unbudgeted" ? "text-slate-600" : (risk.text || "text-slate-800"));

                return (
                    <span className={`inline-flex items-center px-2.5 py-1 rounded-md text-xs font-bold ${colorClass} ${bgClass}`}>
                        {labelText}
                    </span>
                );
            },
        },
    ], [currency]);

    // Memoized chart element — recharts is the most expensive subtree on the page,
    // so it only rebuilds when the trend data / currency / loading state change.
    const trendChart = useMemo(() => (
        <div className="relative w-full h-[320px]">
            {chartData.length === 0 && !trendLoading ? (
                <div className="absolute inset-0 flex items-center justify-center text-xs text-slate-400 bg-slate-50/50 rounded-xl border border-dashed border-slate-200">
                    No trend data available for this selection.
                </div>
            ) : (
                <>
                    <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={trendLoading ? GHOST_CHART_DATA : chartData} margin={{ top: 36, right: 24, left: 8, bottom: 4 }}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                            <XAxis dataKey="label" tick={{ fontSize: 10, fill: "#94a3b8" }} axisLine={{ stroke: "#e2e8f0" }} tickLine={false} />
                            <YAxis tickFormatter={(v) => fmtCompact(v, currency)} tick={{ fontSize: 10, fill: "#94a3b8" }} axisLine={false} tickLine={false} width={64} />
                            {!trendLoading && <Tooltip content={<ChartTooltip currency={currency} />} />}
                            <Line type="monotone" dataKey="actual" name="Actual Spend" stroke={trendLoading ? "#cbd5e1" : "var(--running-fg)"} strokeWidth={2.5} dot={trendLoading ? false : { r: 3, fill: "var(--running-fg)" }} activeDot={trendLoading ? false : { r: 5 }} connectNulls={false} />
                            <Line type="monotone" dataKey="trend" name="Historical Trend" stroke={trendLoading ? "#e2e8f0" : "var(--purple-fg)"} strokeWidth={2} strokeDasharray="6 4" dot={false} />
                            <Line
                                type="monotone" dataKey="mtd" name="MTD Actual"
                                stroke={trendLoading ? "#e2e8f0" : "var( --amber-dot)"} strokeWidth={2} strokeDasharray="4 3"
                                dot={trendLoading ? false : (props) => {
                                    const { cx, cy, payload, index, value } = props;
                                    // recharts calls this for EVERY row — skip null values (cy is NaN there,
                                    // which would pin half-clipped dots to the top edge) and the connector point
                                    if (value == null || payload?.mtdConnector || cx == null || cy == null || Number.isNaN(cy)) {
                                        return <g key={`mtd-dot-${index}`} />;
                                    }
                                    return <circle key={`mtd-dot-${index}`} cx={cx} cy={cy} r={5} fill="var( --amber-dot)" stroke="#fff" strokeWidth={1.5} />;
                                }}
                                activeDot={(props) => {
                                    const { cx, cy, payload, index } = props;
                                    // suppress hover highlight on the connector point — its green twin
                                    // (forecast connector) sits at the same coords and they'd flicker
                                    if (payload?.mtd == null || payload?.mtdConnector || cx == null) {
                                        return <g key={`mtd-active-${index}`} />;
                                    }
                                    return <circle key={`mtd-active-${index}`} cx={cx} cy={cy} r={6} fill="var( --amber-dot)" stroke="#fff" strokeWidth={2} />;
                                }}
                            />
                            <Line
                                type="monotone" dataKey="forecast" name="Forecast"
                                stroke={trendLoading ? "#94a3b8" : "var(--green-fg)"} strokeWidth={2} strokeDasharray="6 4"
                                dot={trendLoading ? false : (props) => {
                                    const { cx, cy, payload, index, value } = props;
                                    if (value == null || payload?.forecastConnector || cx == null || cy == null || Number.isNaN(cy)) {
                                        return <g key={`fc-dot-${index}`} />;
                                    }
                                    return <circle key={`fc-dot-${index}`} cx={cx} cy={cy} r={5} fill="var(--green-fg)" stroke="#fff" strokeWidth={1.5} />;
                                }}
                                activeDot={(props) => {
                                    const { cx, cy, payload, index } = props;
                                    if (payload?.forecast == null || payload?.forecastConnector || cx == null) {
                                        return <g key={`fc-active-${index}`} />;
                                    }
                                    return <circle key={`fc-active-${index}`} cx={cx} cy={cy} r={6} fill="var(--green-fg)" stroke="#fff" strokeWidth={2} />;
                                }}
                                label={trendLoading ? null : <ForecastLabel currency={currency} lastIndex={chartData.length - 1} />}
                            />
                        </LineChart>
                    </ResponsiveContainer>

                    {trendLoading && (
                        <div className="absolute inset-0 z-10 flex flex-col items-center justify-center bg-white/20 backdrop-blur-[1.5px] rounded-xl transition-opacity duration-300 pointer-events-none">
                            <div className="flex flex-col items-center gap-2 text-slate-500 bg-white/80 px-4 py-2 rounded-lg shadow-sm">
                                <div className="w-6 h-6 border-[3px] border-teal-200 border-t-teal-500 rounded-full animate-spin" />
                                <span className="text-xs font-semibold">Loading chart...</span>
                            </div>
                        </div>
                    )}
                </>
            )}
        </div>
    ), [trendLoading, chartData, currency]);

    return (
        <div className="w-full pb-8">
            <title>Reports | SpendSmart</title>
            <meta name="description" content="Generate and view detailed cloud cost reports." />
            <div className="max-w-[1400px] mx-auto space-y-6 px-5 py-5">

                {/* ── Page header ── */}
                <div className="flex flex-col md:flex-row md:items-start justify-between gap-2">
                    <div>
                        <h1 className="text-2xl font-black text-slate-900 tracking-tight">
                            {meta?.title || "AWS Spend Executive Dashboard"}
                        </h1>
                    </div>
                    <div className="flex items-center gap-3 shrink-0">
                        <Toggle 
                            value={periodToggle}
                            onChange={setPeriodToggle}
                            options={[
                                { label: "Current", value: "current" },
                                { label: "Previous", value: "previous" }
                            ]}
                            disabled={true}
                        />
                        <Select
                            value={timeframe}
                            onChange={(val) => setTimeframe(val)}
                            options={[
                                { label: "Month", value: "month" },
                                { label: "Week", value: "week" },
                                { label: "Day", value: "day" }
                            ]}
                            className="py-2 min-w-[120px]"
                            disabled={true}
                        />
                        <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-600 shrink-0 ml-2">
                            <CalendarDays size={14} className="text-slate-400" />
                            Data as on: {meta?.data_as_of_date ? dayjs(meta.data_as_of_date).format("MMM D, YYYY") : "—"}
                        </div>
                    </div>
                </div>

                {/* ── Executive summary ── */}
                {summaryLoading ? <ExecSummarySkeleton /> : (
                    <div className="relative bg-white rounded-2xl ring-1 ring-black/5 p-8 min-h-[300px] flex flex-col overflow-hidden">
                        <p className="relative z-10 text-base font-bold text-slate-800 uppercase tracking-wide mb-6">
                            Executive Summary <span className="text-violet-500"></span>
                        </p>
                        <div className="relative z-10 flex flex-col lg:flex-row gap-10 flex-1">
                            <div className="shrink-0 lg:w-96 flex flex-col">
                                <div className="flex items-center justify-center gap-8 flex-1">
                                    <div className={`relative w-32 h-32 rounded-full flex items-center justify-center shrink-0 ${statusStyle.bg} ring-8 ${statusStyle.ring}`}>
                                        <AlertCircle size={52} className={`${statusStyle.text} relative z-10`} />
                                    </div>
                                    <div className="flex-1 min-w-0 max-w-[240px]">
                                        <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Status</p>
                                        <p className={`text-3xl font-black ${statusStyle.text} tracking-tight`}>{statusStyle.label || exec?.status || "—"}</p>
                                        <p className="text-xs text-slate-500 font-medium mt-1.5 whitespace-normal break-words leading-relaxed">{statusStyle.sub}</p>
                                    </div>
                                </div>
                            </div>
                            <div className="flex-1 lg:border-l lg:border-slate-100 lg:pl-10 grid grid-cols-1 xl:grid-cols-2 gap-4 content-center">
                                {projectedDisplay && (
                                    <InsightRow large icon={TrendingUp} iconClass="bg-[var(--red-bg)] text-[var(--red-fg)]">
                                        Projected month-end spend: <b>{projectedDisplay}</b>
                                        {(exec?.account_budget ?? totals?.total_budget) > 0 && overBudgetPct != null && (
                                            <> — {Math.abs(overBudgetPct).toFixed(1)}% {overBudgetPct >= 0 ? "above" : "below"} budget of <b>{fmtCompact(exec?.account_budget ?? totals?.total_budget, currency)}</b></>
                                        )}
                                    </InsightRow>
                                )}
                                {overTrendPct != null && (
                                    <InsightRow large icon={TrendingDown} iconClass="bg-[var(--orange-bg)] text-[var(--orange-fg)]">
                                        <b>{Math.abs(overTrendPct).toFixed(1)}%</b> {overTrendPct >= 0 ? "higher" : "lower"} than the expected trend based on recent months
                                    </InsightRow>
                                )}
                                {exec?.headline_insight && (
                                    <InsightRow large icon={Box} iconClass="bg-[var(--blue-bg)] text-[var(--running-fg)]">
                                        {exec.headline_insight}
                                    </InsightRow>
                                )}
                                {(exec?.mtd_actual != null || totals) && (
                                    <InsightRow large icon={BarChart3} iconClass="bg-[var(--purple-bg)] text-[var(--purple-fg)]">
                                        Month-to-date actual is <b>{fmtCompact(exec?.mtd_actual ?? totals?.total_actual, currency)}</b> against a budget of <b>{fmtCompact(exec?.account_budget ?? totals?.total_budget, currency)}</b>
                                        {exec?.projected_overage_amount > 0 && (
                                            <> — projected overage of <b className="text-[var(--red-fg)]">{fmtCompact(exec.projected_overage_amount, currency)}</b></>
                                        )}
                                    </InsightRow>
                                )}
                            </div>
                        </div>
                    </div>
                )}

                {/* ── Section 1: Historical trend ── */}
                <div className="bg-white rounded-2xl ring-1 ring-black/10 p-6">
                    <SectionHeading
                        title="Historical Trend"
                        subtitle="Visualize historical, current, and projected spending"
                        right={
                            <div className="relative shrink-0">
                                <Select
                                    value={lookback}
                                    onChange={(val) => setLookback(val)}
                                    options={[
                                        { label: "Last 6 Months", value: 6 },
                                        { label: "Last 12 Months", value: 12 },
                                        { label: "Last 24 Months", value: 24 },
                                    ]}
                                    className="py-2 min-w-[140px] focus:ring-violet-500/30"
                                    iconClassName="text-violet-600"
                                />
                            </div>
                        }
                    />

                    <div className="w-full">
                        <div className="w-full">
                            {/* Legend */}
                            <div className="flex items-center justify-end gap-5 mb-2 text-[11px] font-semibold text-slate-600">
                                <span className="flex items-center gap-1.5"><span className="w-5 h-0.5 bg-[var(--running-fg)] rounded-full inline-block" /> Actual Spend</span>
                                <span className="flex items-center gap-1.5"><span className="w-5 border-t-2 border-dashed border-[var(--purple-fg)] inline-block" /> Historical Trend</span>
                                <span className="flex items-center gap-1.5"><span className="w-5 border-t-2 border-dashed border-[var(--amber-dot)] inline-block" /> MTD Actual</span>
                                <span className="flex items-center gap-1.5"><span className="w-5 border-t-2 border-dashed border-[var(--green-fg)] inline-block" /> Forecast (Month-End)</span>
                            </div>
                            {trendChart}
                        </div>
                    </div>
                </div>

                {/* ── Section 2: Current financial position ── */}
                <div className="bg-white rounded-2xl ring-1 ring-black/10 p-6">
                    <SectionHeading
                        title="Current Financial Position"
                        subtitle="Today's spend vs budget"
                        right={
                            <div className="relative group shrink-0">
                                <button type="button" className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold transition-colors cursor-help">
                                    <Info size={14} className="text-slate-500" />
                                    <span>Business Risk Legend</span>          
                                </button>
                                {/* Tooltip explaining all risk levels — rendered outside Table wrapper so it is NEVER clipped */}
                                <div className="absolute right-0 top-full mt-2 hidden group-hover:flex flex-col items-end z-[9999] pointer-events-none w-96 font-normal normal-case tracking-normal">
                                    <div className="bg-white text-slate-800 text-xs px-4 py-3 rounded-lg shadow-2xl border border-slate-200/90 whitespace-normal break-words text-left leading-relaxed relative z-0 w-96 max-h-[450px] overflow-y-auto space-y-2.5">
                                        {[
                                            "Critical",
                                            "High",
                                            "Medium",
                                            "Low",
                                            "On Track",
                                            "Efficient",
                                            "Under Budget",
                                            "Investigate",
                                        ].map((key) => {
                                            const item = REPORTING_STATUS_ENUM[key];
                                            if (!item) return null;
                                            return (
                                                <p key={key}>
                                                    <b className={`${item.text} font-bold`}>{item.label}:</b> {item.description}
                                                </p>
                                            );
                                        })}
                                    </div>
                                </div>
                            </div>
                        }
                    />

                    <Table
                        columns={reportColumns}
                        data={tableRows}
                        isLoading={summaryLoading}
                        rowsPerPage={Math.max(tableRows.length, 5)}
                        emptyState="No budget breakdown available. Set budgets on the Accounts page to populate this view."
                    />
                </div>
            </div>
        </div>
    );
};

export default memo(Reporting);
