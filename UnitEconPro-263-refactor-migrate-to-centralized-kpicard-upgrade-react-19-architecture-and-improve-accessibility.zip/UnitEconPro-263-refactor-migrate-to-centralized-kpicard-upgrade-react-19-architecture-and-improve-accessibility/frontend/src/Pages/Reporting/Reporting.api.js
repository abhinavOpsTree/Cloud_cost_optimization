import { apiRequest } from "../../lib/apiClient";
import { API_ENDPOINTS } from "../../APIs/ApiEndPoint";

export const fetchReports = async ({ account = "All", scope = "month", period = "current", persona = "finops" } = {}) => {
    return await apiRequest({
        endpoint: API_ENDPOINTS.reportSummary(account, scope, period, persona),
        method: "GET",
    });
};

export const fetchReportTrend = async ({ account = "All", scope = "month", period = "current", persona = "finops", lookback = 6 } = {}) => {
    return await apiRequest({
        endpoint: API_ENDPOINTS.reportTrend(account, scope, period, persona, lookback),
        method: "GET",
    });
};

