import React, { useState, useMemo } from "react";
import { KpiCard } from "../../../components/common/KpiCard";
import { splitSuggestionText } from "../../../lib/suggestionText";
import { X, HardDrive, Info, Box, DollarSign, Activity, Tag, Pencil } from "lucide-react";
import AddSuggestionModal from "../../../common/AddSuggestionModal";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { useSuggestions } from "../../../hooks/useSuggestions";

const MONO = "font-mono";

const MetaRow = ({ label, value }) => (
    <div className="flex justify-between items-center py-2.5 border-b border-slate-200 text-sm last:border-0 gap-3">
        <span className="text-gray-500 shrink-0 capitalize font-medium">{label.replace(/_/g, " ")}</span>
        <span className="text-right font-medium text-gray-900 break-all">
            {value !== null && value !== undefined ? value : "—"}
        </span>
    </div>
);

const ChipList = ({ items, icon: Icon }) => {
    if (!items || items.length === 0) return <span className="text-gray-400">None</span>;
    return (
        <div className="flex flex-wrap gap-2 justify-end">
            {items.map((item, idx) => (
                <span key={idx} className={`${MONO} text-xs bg-gray-100 text-gray-700 px-2 py-1 rounded-md border border-gray-200 flex items-center gap-1`}>
                    {Icon && <Icon size={12} className="text-gray-500" />}
                    {item}
                </span>
            ))}
        </div>
    );
};

const TABS = [
    { id: "overview", label: "Overview", icon: Info },
    { id: "resources", label: "Resources", icon: Box },
    { id: "cost", label: "Usage & Cost", icon: DollarSign },
    { id: "tags", label: "Tags", icon: Tag },
];

const AMIMetaDataDrawer = ({ amiData, onClose }) => {
    const [activeTab, setActiveTab] = useState("overview");
    const [isSugOpen, setIsSugOpen] = useState(false);

    const { suggestions } = useSuggestions();

    const resourceSuggestions = useMemo(() => {
        if (!amiData) return [];
        return (suggestions || []).filter(item =>
            String(item.service).toLowerCase() === "ec2" &&
            item.scope === "resource" &&
            String(item.resource_id).toLowerCase() === String(amiData.image_id).toLowerCase()
        );
    }, [suggestions, amiData]);

    if (!amiData) return null;

    const { 
        name, image_id, state,
        description, account_name, region, owner_id, creation_date, last_launched_time, age_days, is_public, architecture, platform_details,
        snapshot_ids, instance_ids, instance_states,
        snapshot_count, snapshot_cost_30d, active_instance_count,
        tags
    } = amiData;

    return (
        <>
            {/* Backdrop */}
            <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.3 }}
                className="fixed inset-0 z-[999] bg-black/20 backdrop-blur-[1px] h-full cursor-pointer" 
                onClick={onClose} 
            />

            {/* Panel */}
            <motion.div 
                initial={{ x: "100%" }}
                animate={{ x: 0 }}
                exit={{ x: "100%" }}
                transition={{ type: "tween", duration: 0.3 }}
                className="fixed right-0 top-0 h-screen w-[70%] max-w-full bg-white shadow-[-8px_0_32px_rgba(0,0,0,0.12)] z-[9999] border-l border-gray-100 flex flex-col"
            >
                
                {/* Header */}
                <div className="px-6 py-5 shrink-0 bg-white flex justify-between items-start pb-2">
                    <div className="flex items-center gap-4">
                        <div className="w-12 h-12 rounded-xl bg-blue-600 flex items-center justify-center shrink-0 ">
                            <HardDrive size={24} className="text-white" />
                        </div>
                        <div>
                            <div className="flex items-center gap-3">
                                <h2 className="text-xl font-bold text-gray-900 leading-tight">
                                    {name || "Unnamed AMI"}
                                </h2>
                                {state && (
                                    <span className="px-3 py-0.5 rounded-full bg-green-100 text-green-700 text-[10px] font-bold uppercase tracking-wider border border-green-200 flex items-center gap-1 ">
                                        <span className="w-1.5 h-1.5 rounded-full bg-green-500 "></span>
                                        {state}
                                    </span>
                                )}
                            </div>
                            <p className={`${MONO} text-sm text-gray-500 mt-1 bg-gray-100 px-2 py-0.5 rounded inline-block`}>
                                {image_id}
                            </p>
                        </div>
                    </div>
                    <div className="flex items-center gap-2 mt-1">
                        <motion.button
                            whileHover={{ scale: 1.02 }}
                            whileTap={{ scale: 0.98 }}
                            onClick={() => setIsSugOpen(true)}
                            className="flex items-center justify-center gap-2 px-4 py-2 bg-[var(--button-bg)] text-white text-xs font-bold rounded-lg hover:bg-[var(--button-bg)]/90 transition-all cursor-pointer uppercase tracking-wider shrink-0 mr-1"
                        >
                            <Pencil size={14} />
                            Add Suggestion
                        </motion.button>
                        <button
                            className="w-8 h-8 rounded border border-black/10 flex items-center justify-center text-gray-400 hover:bg-gray-100 hover:text-gray-700 transition-colors cursor-pointer"
                            onClick={onClose}
                        >
                            <X size={16} />
                        </button>
                    </div>
                </div>

                {resourceSuggestions && resourceSuggestions.length > 0 && (
                    <div className="px-6 py-2 shrink-0 bg-white">
                        <div className="flex justify-between items-center mb-2">
                            <p className="text-sm font-bold uppercase text-[var(--text-primary-color)]">Suggestions</p>
                            <Link to="/recommendation">
                                <button className="text-xs font-bold text-indigo-600 hover:text-indigo-800 transition-colors cursor-pointer">
                                    View all
                                </button>
                            </Link>
                        </div>
                        <div className="space-y-2.5 pb-2">
                            {resourceSuggestions.slice(0, 1).map((item) => {
                                const { title, desc } = splitSuggestionText(item.text);
                                return (
                                    <div key={item.id} className="bg-white/50 border border-slate-200 rounded-lg p-3">
                                        <p className="text-xs font-bold text-gray-900 leading-snug">{title}</p>
                                        {desc && <p className="text-[11px] text-gray-500 mt-1 leading-relaxed whitespace-pre-line">{desc}</p>}
                                        <div className="flex items-center gap-1.5 mt-2 text-[10px] text-gray-400 font-medium">
                                            <span>By {item.created_by || "User"}</span>
                                            <span>·</span>
                                            <span>{new Date(item.created_at).toLocaleDateString()}</span>
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                    </div>
                )}

                {/* Tabs */}
                <div className="flex items-center px-6 pt-2 gap-4 border-b border-slate-200 bg-white shrink-0">
                    {TABS.map((t) => {
                        const Icon = t.icon;
                        const isActive = activeTab === t.id;
                        return (
                            <button
                                key={t.id}
                                onClick={() => setActiveTab(t.id)}
                                className={`flex items-center gap-1.5 px-3.5 py-2.5 text-xs whitespace-nowrap border-b-2 transition-colors cursor-pointer -mb-px ${isActive
                                    ? "border-[var(--button-bg)] font-semibold text-[var(--button-bg)]"
                                    : "border-transparent text-gray-500 hover:text-gray-900 font-normal"
                                    }`}
                            >
                                <Icon size={13} />
                                {t.label}
                                
                            </button>
                        );
                    })}
                </div>

                {/* Content */}
                <div className="flex-1 overflow-y-auto px-6 py-6 bg-white/30">
                    <div className="bg-white rounded-xl border border-slate-200  p-5">
                        
                        {activeTab === "overview" && (
                            <div className="space-y-6">
                                {description && (
                                    <div className="bg-blue-50 border border-blue-100 rounded-lg p-3">
                                        <p className="text-xs text-blue-800 leading-relaxed">
                                            {description}
                                        </p>
                                    </div>
                                )}
                                <div>
                                    <MetaRow label="account name" value={account_name} />
                                <MetaRow label="region" value={region} />
                                <MetaRow label="owner id" value={owner_id} />
                                <MetaRow label="creation date" value={creation_date} />
                                <MetaRow label="last launched time" value={last_launched_time} />
                                <MetaRow label="age (days)" value={age_days} />
                                <MetaRow label="state" value={state} />
                                <MetaRow label="is public" value={is_public ? "Yes" : "No"} />
                                <MetaRow label="architecture" value={architecture} />
                                    <MetaRow label="platform details" value={platform_details} />
                                </div>
                            </div>
                        )}

                        {activeTab === "resources" && (
                            <>
                                <MetaRow label="snapshot ids" value={<ChipList items={snapshot_ids} icon={HardDrive} />} />
                                <MetaRow label="instance ids" value={<ChipList items={instance_ids} icon={Activity} />} />
                                <MetaRow label="instance states" value={<ChipList items={instance_states} />} />
                            </>
                        )}

                        {activeTab === "cost" && (
                            <>
                                <MetaRow label="snapshot count" value={snapshot_count} />
                                <MetaRow label="snapshot cost (30d)" value={snapshot_cost_30d !== null ? `$${Number(snapshot_cost_30d).toFixed(2)}` : "—"} />
                                <MetaRow label="active instance count" value={active_instance_count} />
                            </>
                        )}

                        {activeTab === "tags" && (
                            <>
                                {(!tags || Object.keys(tags).length === 0) ? (
                                    <div className="py-8 text-center text-gray-500 text-sm font-medium">No tags available</div>
                                ) : (
                                    Object.entries(tags).map(([key, val]) => (
                                        <MetaRow key={key} label={key} value={String(val)} />
                                    ))
                                )}
                            </>
                        )}

                    </div>
                </div>
            </motion.div>
            <AddSuggestionModal
                isOpen={isSugOpen}
                onClose={() => setIsSugOpen(false)}
                service="ec2"
                scope="resource"
                resourceId={image_id}
                resourceName={name || ""}
            />
        </>
    );
};

export default AMIMetaDataDrawer;


