import { useState, useEffect, useMemo, lazy, Suspense } from "react";
import { splitSuggestionText } from "../../../lib/suggestionText";
import { AnimatePresence } from "framer-motion";
import { useQueryClient } from "@tanstack/react-query";
import { getComputeEKSMetadata } from "../Compute.api";
import { useFilters } from "../../../hooks/useFilters";
import { CardSkeleton } from "../../../common/Cardoverview";
import { KpiCard } from "../../../components/common/KpiCard";
import Table from "../../../common/Table";
import CopyableCell from "../../../common/CopyableCell";
import { useEKS } from "../../../hooks/Compute/useEKS";
import PaginationControls from "../../../common/PaginationControls";
import { Linechart } from "../../../common/Charts/LazyLinechart";
import { useUnified } from "../../../hooks/useUnified";
// import { StackedBarChart } from "../../../common/Charts/StackedBarChart";
import { Chips } from "../../../common/Chips";
import { RoundedPieChart } from "../../../common/Charts/LazyPiechart";
import { Filters } from "../../../common/Filters/Filter";
// OPTIMIZATION: Code-split drawer components using React.lazy to reduce the initial bundle size.
const EKSMetaDrawer = lazy(() => import("./EKSMetaDrawer"));

const EKS_SEARCH_KEYS = ["cluster_name"];
const EKS_FILTER_CONFIGS = [
    { key: "account_name", label: "Account" },
    { key: "region", label: "Region" }
];
// Perf: fully static, so hoisted to module scope — stronger than useMemo (one
// allocation for the app's lifetime) and matches the consts above.
const BREAKDOWN_OPTIONS = [
    { label: "Cluster", value: "cluster" },
    { label: "Region", value: "region" },
    { label: "Account", value: "account" },
    { label: "Operation", value: "operation" },
    { label: "Usage Type", value: "usage-type" },
    { label: "Pricing Model", value: "pricing-model" },
        { label: "Environment", value: "env" },
        { label: "Owner", value: "owner" },
        { label: "Project", value: "project" },
        { label: "Team", value: "team" },
        { label: "Application", value: "application" },
];
import { Activity, Box, DollarSign, Info } from "lucide-react";
import { useSuggestions } from "../../../hooks/useSuggestions";
import { Link, useSearchParams } from "react-router-dom";
import { ForecastCardFinance } from "../../../common/MonthtoDate/LazyForecastCardFinance";


const SectionLabel = ({ children }) => (
    <p className="text-sm font-bold uppercase text-[var(--text-primary-color)] mb-2.5">{children}</p>
);


const EKS = () => {
    const queryClient = useQueryClient();
    const { filters } = useFilters();
    const [dimension, setDimension] = useState("cluster");
    const { suggestions: allSuggestions } = useSuggestions();
    const suggestions = (allSuggestions ?? []).filter(
        (s) => String(s.service).toLowerCase() === "eks" && s.scope === "page"
    );
    const { summary: EKSsummary, clusters: EKSinstance, isLoading, isError } = useEKS();
    const {
        trend,
        breakdown,
        isTrendLoading,
        isBreakdownLoading,
        isTrendError,
        isBreakdownError
    } = useUnified(dimension);

    // Perf: memoized so <Table columns={...}> gets a stable prop instead of a fresh
    // array every render; the render closure only uses a module-level component.
    const columns = useMemo(() => [
        {
            key: "cluster_name",
            label: "Cluster Name",
            className: "w-[25%]",
            render: (value) => <CopyableCell value={value} />
        },
        { key: "region", label: "Region", className: "w-[15%]" },
        { key: "account_name", label: "Account", className: "w-[20%]" },
        { key: "cluster_hours", label: "Cluster Hours", sortable: true, className: "w-[20%]" },
        { key: "total_cost", label: "Total Cost", sortable: true, showTotal: true, className: "w-[12%]" }
    ], []);

    const [filteredList, setFilteredList] = useState(null);
    const [currentPage, setCurrentPage] = useState(1);
    const rowsPerPage = 10;
    const [selectedClusterName, setSelectedClusterName] = useState(null);
    const [searchParams] = useSearchParams();
    useEffect(() => {
        const resource = searchParams.get("resource");
        if (resource) setSelectedClusterName({ cluster_name: resource });
    }, [searchParams]);

    const displayData = filteredList !== null ? filteredList : (EKSinstance ?? []);
    const totalPages = Math.ceil(displayData.length / rowsPerPage);
    const paginatedData = displayData.slice(
        (currentPage - 1) * rowsPerPage,
        currentPage * rowsPerPage
    );

    const closeDrawer = () => {
        setSelectedClusterName(null);
    };

    // Perf: memoized so the KPI card list keeps a stable identity between renders;
    // recomputed only when the summary data actually changes.
    const card = useMemo(() => [
        { title: "total cost", value: EKSsummary?.total_cost, icon: <DollarSign size={16} className="text-green-500" />, icon2: <DollarSign size={16} className="text-green-500" /> },
        { title: "avg daily cost", value: EKSsummary?.avg_daily_cost, icon: <Activity size={16} className="text-green-800" />, icon2: <DollarSign size={16} className="text-green-500" /> },
        { title: "total clusters", value: EKSsummary?.total_clusters, icon: <Box size={16} className="text-indigo-500" /> },
    ], [EKSsummary])

    // Perf: memoized table actions. NOTE: the onHover prefetch closes over the
    // current date/account filters, so they are deps — otherwise a filter change
    // would prefetch with stale keys.
    const action = useMemo(() => [
        {
            label: "Metadata",
            onClick: (row) => {
                setSelectedClusterName(row);
            },
            onHover: (row) => {
                const cName = row.cluster_name || row;
                queryClient.prefetchQuery({
                    queryKey: ["eks", "metadata", cName, filters.start_date, filters.end_date, filters.account],
                    queryFn: () => getComputeEKSMetadata({
                        cluster_name: cName,
                        start_date: filters.start_date,
                        end_date: filters.end_date,
                        account: filters.account}),
                    staleTime: 5 * 60 * 1000
                });
            },
            icon: () => <Info size={16} className="cursor-pointer" />,
            color: "success",
            tooltip: "View Cluster Metadata"
        }], [queryClient, filters.start_date, filters.end_date, filters.account])



    return (
        <div className="flex flex-col pb-6">
            <div className="space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-2 w-full">
                    {isLoading
                        ? Array.from({ length: 5 }).map((_, i) => (
                            <CardSkeleton key={i} />
                        ))
                        : card.map((kpi) => (
                            <KpiCard key={kpi.title} kpi={kpi} />
                        ))
                    }
                    {isError && (
                        <div className="flex items-center justify-center h-full col-span-full py-10">
                            <span className="text-destructive font-semibold">Error loading data</span>
                        </div>
                    )}

                </div>
                <div className="py-1">
                    <div className="flex justify-between items-center mb-2.5">
                        <p className="text-sm font-bold uppercase text-[var(--text-primary-color)]">Suggestions</p>
                        <Link to="/recommendation">
                            <button className="text-xs font-bold text-indigo-600 hover:text-indigo-800 transition-colors cursor-pointer bg-transparent border-0 p-0">View all</button>
                        </Link>
                    </div>
                    {suggestions.length > 0 ? (
                        <div className="space-y-2.5">
                            {suggestions.slice(0, 1).map((item) => {
                                const { title, desc } = splitSuggestionText(item.text);
                                return (
                                    <div key={item.id} className="bg-white ring-1 ring-black/10 rounded-lg p-3">
                                        <p className="text-xs font-bold text-gray-900 leading-snug">{title}</p>
                                        {desc && <p className="text-[11px] text-gray-500 mt-1 leading-relaxed whitespace-pre-line">{desc}</p>}
                                        <div className="flex items-center gap-1.5 mt-2 text-[10px] text-gray-400 font-medium">
                                            <span>By {item.created_by || "User"}</span>
                                            <span>·</span>
                                            <span>{new Date(item.created_at).toLocaleDateString()}</span>
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                    ) : (
                        <div className="flex flex-col items-center justify-center py-12 text-center bg-gray-100 border border-dashed border-gray-200 rounded-xl">
                            <span className="text-xs text-[var(--text-secondary-color)] font-medium">No recommendations found.</span>
                        </div>
                    )}
                </div>
                <ForecastCardFinance category="compute" service="eks" trend={trend} isTrendLoading={isTrendLoading} />

                <Linechart avgCost={EKSsummary?.avg_daily_cost} chartdata={trend}
                    name="cost"
                    service="AmazonEKS"
                    isLoading={isTrendLoading}
                    isError={isTrendError}
                />

                <div className="w-full flex flex-col space-y-2 mb-4">
                    <h3 className="text-md font-medium text-[var(--text-primary-color)] capitalize px-1">Breakdown By</h3>
                    <Chips
                        options={BREAKDOWN_OPTIONS}
                        selected={dimension}
                        onSelect={setDimension}
                    />
                </div>

                <RoundedPieChart
                    title={`${BREAKDOWN_OPTIONS.find(o => o.value === dimension)?.label} Breakdown`}
                    subtitle={`Total cost distribution by ${BREAKDOWN_OPTIONS.find(o => o.value === dimension)?.label.toLowerCase()}`}
                    dataKey="cost"
                    nameKey="name"
                    chartData={breakdown}
                    isError={isBreakdownError}
                    isLoading={isBreakdownLoading}
                />

                <div className="w-full">
                    <h3 className="text-md font-semibold mb-3">EKS Clusters</h3>
                    <Filters 
                        data={EKSinstance ?? []} 
                        onFilter={(filtered) => {
                            setFilteredList(filtered);
                            setCurrentPage(1);
                        }} 
                        searchKeys={EKS_SEARCH_KEYS}
                        filterConfigs={EKS_FILTER_CONFIGS}
                        placeholder="Search by cluster name..."
                    />
                    <Table
                        data={paginatedData}
                        columns={columns}
                        actions={action}
                        isLoading={isLoading}
                        isFiltered={filteredList !== null}
                        emptyState={"No Data Available"}
                    />
                    <PaginationControls currentPage={currentPage} totalPages={totalPages} onPageChange={setCurrentPage} />
                </div>
            </div>
            <AnimatePresence>
                {selectedClusterName && (
                    <Suspense fallback={null}>
                        <EKSMetaDrawer key="eks-drawer" clusterData={selectedClusterName} onClose={closeDrawer} />
                    </Suspense>
                )}
            </AnimatePresence>
        </div>
    );
};

export default EKS;
