import { KpiCard } from "../../../components/common/KpiCard";
import { useState, useMemo, useEffect } from "react";
import { splitSuggestionText } from "../../../lib/suggestionText";
import { useECR } from "../../../hooks/Compute/useECR";
import PaginationControls from "../../../common/PaginationControls";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { useSuggestions } from "../../../hooks/useSuggestions";
import AddSuggestionModal from "../../../common/AddSuggestionModal";
import {
    X, Database, Info, Shield, Activity, Tag, Pencil,
    AlertTriangle, CheckCircle2, DollarSign, ImageIcon, Clock
} from "lucide-react";

// ─────────────────────────────────────────────
// Design primitives (matching LifecycleDrawer)
// ─────────────────────────────────────────────

const MONO = "font-mono";
const TAGS_PER_PAGE = 10;

const SectionLabel = ({ children }) => (
    <p className="text-sm font-bold uppercase text-[var(--text-primary-color)] mb-2.5">{children}</p>
);

const MetaRow = ({ label, value, mono, bold, color }) => (
    <div className="flex justify-between items-center py-1.5 border-b border-slate-200 text-xs last:border-0 gap-3">
        <span className="text-gray-500 shrink-0">{label}</span>
        <span className={`text-right break-all ${mono ? `${MONO} text-[11px] text-blue-700` : ""} ${bold ? "font-semibold" : ""} ${color || "text-gray-900"}`}>
            {value ?? "—"}
        </span>
    </div>
);



const Badge = ({ children, variant }) => {
    const cls = {
        success: "bg-emerald-50 text-emerald-800 border-emerald-200",
        warning: "bg-amber-50 text-amber-800 border-amber-200",
        danger: "bg-red-50 text-red-800 border-red-200",
        info: "bg-blue-50 text-blue-800 border-blue-200",
        purple: "bg-purple-50 text-purple-800 border-purple-200",
    }[variant] || "bg-gray-100 text-gray-700 border-gray-200";
    return (
        <span className={`inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded border ${cls}`}>
            {variant === "success" && <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block" />}
            {children}
        </span>
    );
};

const getStatusVariant = (status) => {
    const s = String(status || "").toLowerCase();
    if (s === 'ok' || s === 'healthy') return 'success';
    if (s === 'warning') return 'warning';
    if (s === 'error' || s === 'alert' || s === 'critical') return 'danger';
    return 'info';
};

const formatDate = (dateStr) => {
    if (!dateStr) return "—";
    try {
        const date = new Date(dateStr);
        if (isNaN(date.getTime())) return dateStr;
        const d = date.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }).replace(/ /g, '-');
        const t = date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: true });
        return `${d} ${t}`;
    } catch (e) {
        return dateStr;
    }
};


// ─────────────────────────────────────────────
// Tab content components
// ─────────────────────────────────────────────

const Overview = ({ data }) => (
    <div className="space-y-6">
        <div className="grid grid-cols-1 gap-7">
            <div>
                <SectionLabel>Infrastructure</SectionLabel>
                <MetaRow label="Region" value={data.region} />
                <MetaRow label="Account Name" value={data.account_name} bold />
                <MetaRow label="AWS Account ID" value={data.aws_account_id} mono />
                <MetaRow label="Data Transfer" value={`${(data.transfer_gb || 0).toFixed(2)} GB`} />
            </div>

            <div>
                <SectionLabel>Cost Details (USD)</SectionLabel>
                <MetaRow label="Storage Cost" value={`$${(data.storage_cost || 0).toFixed(2)}`} />
                <MetaRow label="Transfer Cost" value={`$${(data.transfer_cost || 0).toFixed(2)}`} />
                <MetaRow label="Scan Cost" value={`$${(data.scan_cost || 0).toFixed(2)}`} />
                <MetaRow label="Total Monthly Cost" value={`$${(data.total_cost || 0).toFixed(2)}`} bold color="text-blue-700" />
            </div>
        </div>
    </div>
);

const VulnerabilitiesTab = ({ data }) => (
    <div className="space-y-6">
        <div>
            <SectionLabel>Vulnerability Scanning</SectionLabel>
            <MetaRow label="Critical Vulnerabilities" value={data.critical_vulnerabilities || 0} color={data.critical_vulnerabilities > 0 ? "text-red-600 font-bold" : "text-emerald-600 font-bold"} />
            <MetaRow label="High Severity" value={data.high_vulnerabilities || 0} color={data.high_vulnerabilities > 0 ? "text-amber-600 font-bold" : "text-emerald-600 font-bold"} />
            
            <div className="mx-0 mt-5 bg-blue-50 border border-blue-200/60 rounded-lg px-3.5 py-2.5 flex items-start gap-2">
                <Shield size={15} className="text-blue-700 shrink-0 mt-0.5" />
                <p className="text-xs text-blue-800 leading-snug">
                    Check your image scanning configuration. Enable "Scan on Push" to automatically identify vulnerabilities when new images are pushed to this repository.
                </p>
            </div>
        </div>
    </div>
);

const LifecyclePoliciesTab = ({ data }) => (
    <div className="space-y-6">
        <div>
            <SectionLabel>Settings</SectionLabel>
            <MetaRow label="Lifecycle Policy" value={data.lifecycle_policy_enabled ? "Auto Cleanup Enabled" : "No Automatic Cleanup"} color={data.lifecycle_policy_enabled ? "text-emerald-600 font-semibold" : "text-amber-600 font-semibold"} />
            
            <div className={`mx-0 mt-5 border rounded-lg px-3.5 py-2.5 flex items-start gap-2 ${data.lifecycle_policy_enabled ? "bg-emerald-50 border-emerald-200/60" : "bg-amber-50 border-amber-200/60"}`}>
                <Activity size={15} className={`shrink-0 mt-0.5 ${data.lifecycle_policy_enabled ? "text-emerald-700" : "text-amber-700"}`} />
                <p className={`text-xs leading-snug ${data.lifecycle_policy_enabled ? "text-emerald-800" : "text-amber-800"}`}>
                    {!data.lifecycle_policy_enabled ? 
                        "We recommend configuring lifecycle policies to automatically clean up untagged or old images to reduce storage costs." :
                        "Lifecycle policies are actively managing old or untagged images in this repository."}
                </p>
            </div>
        </div>
    </div>
);

const TagsTab = ({ data, tagsPage, setTagsPage }) => {
    const tagEntries = useMemo(() => (data.tags ? Object.entries(data.tags) : []), [data.tags]);
    const totalPages = Math.max(1, Math.ceil(tagEntries.length / TAGS_PER_PAGE));
    const paginated = tagEntries.slice((tagsPage - 1) * TAGS_PER_PAGE, tagsPage * TAGS_PER_PAGE);

    return (
        <div>
            <SectionLabel>Resource Tags ({tagEntries.length})</SectionLabel>
            {paginated.length > 0 ? (
                <div className="space-y-1.5">
                    {paginated.map(([k, v]) => (
                        <div key={k} className="flex overflow-hidden border border-slate-200 rounded-lg">
                            <div className={`px-3.5 py-2.5 bg-white min-w-[140px] border-r border-slate-200 ${MONO} text-xs text-blue-700`}>{k}</div>
                            <div className="px-3.5 py-2.5 text-xs text-gray-900">{String(v)}</div>
                        </div>
                    ))}
                </div>
            ) : (
                <div className="text-center py-6 bg-white rounded-2xl border border-dashed border-gray-200">
                    <span className="text-xs text-gray-400">No resource tags available</span>
                </div>
            )}
            {tagEntries.length > TAGS_PER_PAGE && (
                <PaginationControls currentPage={tagsPage} totalPages={totalPages} onPageChange={setTagsPage} />
            )}
        </div>
    );
};

// ─────────────────────────────────────────────
// Main Drawer
// ─────────────────────────────────────────────

const TABS = [
    { id: "overview", label: "Overview", icon: Info },
    { id: "vulnerabilities", label: "Vulnerabilities", icon: Shield },
    { id: "lifecycle", label: "Lifecycle Policies", icon: Activity },
    { id: "tags", label: "Tags", icon: Tag },
];

const ECRMetadataDrawer = ({ repositoryName, onClose }) => {
    const [activeTab, setActiveTab] = useState("overview");
    const [tagsPage, setTagsPage] = useState(1);
    const [isSugOpen, setIsSugOpen] = useState(false);

    const { suggestions } = useSuggestions();

    const { metadata, isMetadataLoading } = useECR(repositoryName);
    const metaRaw = metadata || {};

    const resourceSuggestions = useMemo(() => {
        return (suggestions || []).filter(item =>
            String(item.service).toLowerCase() === "ecr" &&
            item.scope === "resource" &&
            String(item.resource_id).toLowerCase() === String(repositoryName).toLowerCase()
        );
    }, [suggestions, repositoryName]);

    useEffect(() => {
        setActiveTab("overview");
        setTagsPage(1);
    }, [repositoryName]);

    if (!repositoryName) return null;

    const kpis = [
        { label: "Storage", value: metaRaw.storage_gb ? `${Number(metaRaw.storage_gb).toFixed(2)}` : "—", unit: "GB", sub: `Status: ${metaRaw.storage_status || 'OK'}` },
        { label: "Images", value: metaRaw.image_count ?? "—", unit: "count", sub: `${metaRaw.untagged_images || 0} untagged` },
        { label: "Total Cost", value: metaRaw.total_cost ? `$${Number(metaRaw.total_cost).toFixed(2)}` : "—", unit: "/mo", sub: "storage + transfer" },
        { label: "Latest Push", value: metaRaw.latest_push ? formatDate(metaRaw.latest_push).split(' ')[0] : "—", unit: "", sub: "Date updated" },
    ];

    return (
        <>
            {/* Backdrop */}
            <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.3 }}
                className="fixed inset-0 z-[999] bg-black/20 backdrop-blur-[1px] h-full cursor-pointer" 
                onClick={onClose} 
            />

            {/* Panel */}
            <motion.div 
                initial={{ x: "100%" }}
                animate={{ x: 0 }}
                exit={{ x: "100%" }}
                transition={{ type: "tween", duration: 0.3 }}
                className="fixed right-0 top-0 h-screen w-[70%] max-w-full bg-white shadow-[-8px_0_32px_rgba(0,0,0,0.12)] z-[9999] border-l border-gray-100 flex flex-col"
            >

                {/* ── Header ── */}
                <div className="px-6 py-4 border-b border-slate-200 shrink-0 bg-white">
                    <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3.5">
                            <div className="w-9 h-9 rounded-lg bg-[#FF9900] flex items-center justify-center shrink-0 ">
                                <Database size={18} className="text-white" />
                            </div>
                            <div>
                                <div className="flex items-center gap-1.5 flex-wrap mb-0.5">
                                    <span className={`${MONO} text-[13px] font-semibold text-[var(--text-primary-color)] tracking-tight`}>
                                        {repositoryName}
                                    </span>
                                    {metaRaw.cost_status && (
                                        <Badge variant={getStatusVariant(metaRaw.cost_status)}>
                                            {metaRaw.cost_status}
                                        </Badge>
                                    )}
                                </div>
                                <p className="text-xs text-[var(--text-secondary-color)]">
                                    {metaRaw.region || "-"} · {metaRaw.account_name || "-"}
                                </p>
                            </div>
                        </div>
                        <div className="flex items-center gap-2">
                            <motion.button
                                whileHover={{ scale: 1.02 }}
                                whileTap={{ scale: 0.98 }}
                                onClick={() => setIsSugOpen(true)}
                                className="flex items-center justify-center gap-2 px-4 py-2 bg-[var(--button-bg)] text-white text-xs font-bold rounded-lg  hover:bg-[var(--button-bg)]/90 transition-all cursor-pointer uppercase tracking-wider shrink-0 mr-1"
                            >
                                <Pencil size={14} />
                                Add Suggestion
                            </motion.button>
                            <button
                                className="w-7 h-7 rounded border border-slate-200 flex items-center justify-center text-gray-400 hover:bg-white hover:text-gray-700 transition-colors cursor-pointer"
                                onClick={onClose}
                            >
                                <X size={14} />
                            </button>
                        </div>
                    </div>
                </div>

                {/* ── KPI strip ── */}
                {isMetadataLoading ? (
                    <div className="grid grid-cols-4 gap-2 px-6 py-3 border-b border-slate-200 shrink-0">
                        {Array.from({ length: 4 }).map((_, i) => (
                            <div key={i} className="h-14 bg-gray-100 rounded-lg animate-pulse" />
                        ))}
                    </div>
                ) : (
                    <div className="grid grid-cols-4 gap-2 px-6 py-3 border-b border-slate-200 shrink-0">
                        {kpis.map((k) => <KpiCard variant="compact" key={k.label} {...k} />)}
                    </div>
                )}

                <div className="px-6 py-1">
                    {resourceSuggestions && resourceSuggestions.length > 0 && (
                        <div className="">
                            <div className="flex justify-between items-center">
                                <SectionLabel>Suggestions</SectionLabel>
                                <Link to="/recommendation">
                                    <button className="text-xs font-bold text-indigo-600 hover:text-indigo-800 transition-colors cursor-pointer">
                                        View all
                                    </button>
                                </Link>
                            </div>
                            <div className="space-y-2.5">
                                {resourceSuggestions.slice(0, 1).map((item) => {
                                    const { title, desc } = splitSuggestionText(item.text);
                                    return (
                                        <div key={item.id} className="bg-white/50 border border-slate-200 rounded-lg p-3">
                                            <p className="text-xs font-bold text-gray-900 leading-snug">{title}</p>
                                            {desc && <p className="text-[11px] text-gray-500 mt-1 leading-relaxed whitespace-pre-line">{desc}</p>}
                                            <div className="flex items-center gap-1.5 mt-2 text-[10px] text-gray-400 font-medium">
                                                <span>By {item.created_by || "User"}</span>
                                                <span>·</span>
                                                <span>{new Date(item.created_at).toLocaleDateString()}</span>
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>
                        </div>
                    )}
                </div>

                {/* ── Tab bar ── */}
                <div className="flex border-b border-slate-200 px-6 mt-2.5 shrink-0 gap-0.5 overflow-x-auto scrollbar-none">
                    {TABS.map((t) => {
                        const Icon = t.icon;
                        const isActive = activeTab === t.id;
                        return (
                            <button
                                key={t.id}
                                onClick={() => setActiveTab(t.id)}
                                className={`flex items-center gap-1.5 px-3.5 py-2.5 text-xs whitespace-nowrap border-b-2 transition-colors cursor-pointer -mb-px ${isActive
                                    ? "border-[var(--button-bg)] font-semibold text-[var(--button-bg)]"
                                    : "border-transparent text-gray-500 hover:text-gray-900 font-normal"
                                    }`}
                            >
                                <Icon size={13} />
                                {t.label}
                                {t.id === "tags" && Object.keys(metaRaw.tags || {}).length > 0 && (
                                    <span className="ml-0.5 text-[9px] font-bold px-1.5 py-0.5 rounded-full bg-gray-100 text-gray-500">
                                        {Object.keys(metaRaw.tags).length}
                                    </span>
                                )}
                            </button>
                        );
                    })}
                </div>

                {/* ── Tab content ── */}
                <div className="flex-1 overflow-y-auto px-6 py-5">
                    {isMetadataLoading ? (
                        <div className="flex items-center justify-center py-16">
                            <div className="w-6 h-6 border-2 border-[var(--button-bg)] border-t-transparent rounded-full animate-spin mr-3" />
                            <span className="text-sm text-gray-500">Loading repository data...</span>
                        </div>
                    ) : metaRaw ? (
                        <>
                            {activeTab === "overview" && <Overview data={metaRaw} />}
                            {activeTab === "vulnerabilities" && <VulnerabilitiesTab data={metaRaw} />}
                            {activeTab === "lifecycle" && <LifecyclePoliciesTab data={metaRaw} />}
                            {activeTab === "tags" && (
                                <TagsTab data={metaRaw} tagsPage={tagsPage} setTagsPage={setTagsPage} />
                            )}
                        </>
                    ) : (
                        <div className="flex-1 flex flex-col items-center justify-center p-12 text-center space-y-3">
                            <AlertTriangle size={32} className="text-gray-200" />
                            <p className="text-sm font-bold text-gray-500">Metadata Unavailable</p>
                            <p className="text-xs text-gray-400 max-w-[240px]">
                                We couldn't retrieve the details for this repository. Please check your AWS permissions.
                            </p>
                        </div>
                    )}
                </div>
            </motion.div>

            <AddSuggestionModal
                isOpen={isSugOpen}
                onClose={() => setIsSugOpen(false)}
                service="ecr"
                scope="resource"
                resourceId={repositoryName}
                resourceName={repositoryName}
            />
        </>
    );
};

export default ECRMetadataDrawer;


