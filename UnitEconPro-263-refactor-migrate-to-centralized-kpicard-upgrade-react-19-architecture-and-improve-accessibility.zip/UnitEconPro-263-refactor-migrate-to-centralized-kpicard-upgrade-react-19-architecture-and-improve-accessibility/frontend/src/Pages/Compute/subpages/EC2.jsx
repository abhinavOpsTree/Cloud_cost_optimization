import { useState, useMemo, lazy, Suspense } from "react";
import { splitSuggestionText } from "../../../lib/suggestionText";
import { useQueryClient, useQuery, keepPreviousData } from "@tanstack/react-query";
import { AnimatePresence } from "framer-motion";
import { getComputeEC2LifecycleList, getComputeEC2Amis } from "../Compute.api";
import { queryKeys } from "../../../lib/queryKeys";
import { useFilters } from "../../../hooks/useFilters";
import { X,DollarSign, Activity, Box, Info} from "lucide-react";
import PaginationControls from "../../../common/PaginationControls";
import Table from "../../../common/Table";
import CopyableCell from "../../../common/CopyableCell";
const EC2MetaDrawer = lazy(() => import("./EC2MetadataDrawer"));
import { useEC2 } from "../../../hooks/Compute/useEC2";
import { useUnified } from "../../../hooks/useUnified";
import { Linechart } from "../../../common/Charts/LazyLinechart";
// import { StackedBarChart } from "../../../common/Charts/StackedBarChart";
import { Chips } from "../../../common/Chips";
import { RoundedPieChart } from "../../../common/Charts/LazyPiechart";
import { CardSkeleton } from "../../../common/Cardoverview";
import { KpiCard } from "../../../components/common/KpiCard";
// OPTIMIZATION: Code-split drawer components using React.lazy to reduce the initial bundle size.
const AMIMetaDataDrawer = lazy(() => import("./AMIMetaDataDrawer"));
import { Filters } from "../../../common/Filters/Filter";
import { useSuggestions } from "../../../hooks/useSuggestions";
import { Link, useSearchParams } from "react-router-dom";
import { ForecastCardFinance } from "../../../common/MonthtoDate/LazyForecastCardFinance";
const EC2_SEARCH_KEYS = ["instance_name", "instance_id", "instance_type", "pricing_model"];
const EC2_FILTER_CONFIGS = [
    { key: "account", label: "Account" },
    { key: "region", label: "Region" },

];

const AMI_SEARCH_KEYS = ["image_id", "name"];
const AMI_FILTER_CONFIGS = [
    { key: "account_name", label: "Account" },
    { key: "region", label: "Region" },
];

const breakdownOptions = [
    { label: "Instance Type", value: "instance-type" },
    { label: "Instance Family", value: "instance-family" },
    { label: "Instance Type Family", value: "instance-type-family" },
    { label: "Region", value: "region" },
    { label: "Availability Zone", value: "availability-zone" },
    { label: "Pricing Model", value: "pricing-model" },
    { label: "Environment", value: "env" },
    { label: "Owner", value: "owner" },
    { label: "Project", value: "project" },
    { label: "Team", value: "team" },
    { label: "Application", value: "application" },
];

const EC2 = () => {
    const queryClient = useQueryClient();
    const { filters } = useFilters();
    const [currentPage, setCurrentPage] = useState(1);
    const [dimension, setDimension] = useState("instance-type");
    const { summary: EC2summary, instances, instancesQuery, isLoading: summaryLoading, isError: summaryError } = useEC2();
    const {
        trend,
        breakdown,
        isTrendLoading,
        isBreakdownLoading,
        isTrendError,
        isBreakdownError
    } = useUnified(dimension);

    const { suggestions: allSuggestions } = useSuggestions();
    const suggestions = (allSuggestions ?? []).filter(
        (s) => String(s.service).toLowerCase() === "ec2" && s.scope === "page"
    );


    const [searchParams] = useSearchParams();
    const resourceParam = searchParams.get("resource");
    const [prevResourceParam, setPrevResourceParam] = useState(resourceParam);
    const [selectedInstance, setSelectedInstance] = useState(() => {
        return resourceParam ? { instance_id: resourceParam } : null;
    });

    if (resourceParam !== prevResourceParam) {
        setPrevResourceParam(resourceParam);
        if (resourceParam) {
            setSelectedInstance({ instance_id: resourceParam });
        }
    }

    const [selectedAmi, setSelectedAmi] = useState(null);
    const [typeFilter, setTypeFilter] = useState(null);

    const columns = useMemo(() => [
        { 
            key: "instance_name", 
            label: "Instance Name",
            render: (value) => <CopyableCell value={value} />
        },
        {
            key: "instance_type",
            label: "Type",
            render: (value) => (
                <button
                    className="px-2 py-0.5 rounded-md bg-blue-50 text-blue-700 text-xs font-medium hover:bg-blue-100 transition-colors cursor-pointer"
                    onClick={(e) => {
                        e.stopPropagation();
                        setTypeFilter(value);
                        setCurrentPage(1);
                    }}
                    title={`Filter by ${value}`}
                >
                    {value}
                </button>
            ),
        },
        { key: "account", label: "Account" },
        { key: "region", label: "Region" },
        { key: "usage_hours", label: "Active Hours", sortable: true },
        {
            key: "total_cost",
            label: "Total Cost",
            sortable: true,
            align: "right",
            showTotal: true,
            render: (value) => `$${Number(value || 0)}`,
        },
    ], [setTypeFilter]);

    const [amisPage, setAmisPage] = useState(1);
    const amisQuery = useQuery({
        queryKey: queryKeys.ec2.amis({ ...filters }),
        queryFn: () => getComputeEC2Amis({ ...filters }),
        enabled: !!filters.start_date && !!filters.end_date,
        placeholderData: keepPreviousData,
    });

    const amisColumns = useMemo(() => [
        { 
            key: "image_id", 
            label: "Image ID",
            render: (value) => <CopyableCell value={value} />
        },
        { 
            key: "name", 
            label: "Name",
            render: (value) => <CopyableCell value={value} />
        },
        { 
            key: "creation_date", 
            label: "Creation Date",
            sortable: true,
            render: (value) => value ? value.split('T')[0].split(' ')[0] : "—"
        },
        { key: "region", label: "Region" },
        { key: "age_days", label: "Age (days)", sortable: true },
        {
            key: "snapshot_cost_30d",
            label: "Cost",
            sortable: true,
            align: "right",
            showTotal: true,
            render: (value) => `$${Number(value || 0).toFixed(2)}`,
        },
    ], []);

    const [filteredList, setFilteredList] = useState(null);
    const [amisFilteredList, setAmisFilteredList] = useState(null);

    const instancesData = useMemo(() => Array.isArray(instances) ? instances : [], [instances]);
    const amisData = useMemo(() => Array.isArray(amisQuery.data) ? amisQuery.data : [], [amisQuery.data]);
    const amisBaseData = amisFilteredList !== null ? amisFilteredList : amisData;
    const baseData = filteredList !== null ? filteredList : instancesData;

    const filteredData = typeFilter
        ? baseData.filter((row) => row.instance_type === typeFilter)
        : baseData;

    const totalPages = Math.ceil((filteredData.length || 0) / 10) || 1;
    const amisTotalPages = Math.ceil((amisBaseData.length || 0) / 10) || 1;

    // Perf: memoized so the KPI card list keeps a stable identity between renders;
    // recomputed only when the summary data actually changes.
    const card = useMemo(() => [
        { title: "totat cost", value: EC2summary?.total_cost, icon: <DollarSign size={16} className="text-green-500" />, icon2: <DollarSign size={16} className="text-green-500" /> },
        { title: "avg daily cost", value: EC2summary?.avg_daily_cost, icon: <Activity size={16} className="text-green-800" />, icon2: <DollarSign size={16} className="text-green-500" /> },
        { title: "total instances", value: EC2summary?.total_instances, icon: <Box size={16} className="text-indigo-500" /> },
    ], [EC2summary])

    // Perf: memoized so <Table actions={...}> gets a stable prop instead of a fresh
    // array every render. setSelectedInstance (state setter) and queryClient are
    // identity-stable, so this never goes stale.
    const action = useMemo(() => [
        {
            label: "Details",
            onClick: (row) => {
                setSelectedInstance(row);
            },
            onHover: (row) => {
                const iId = row.instance_id || row.instance_name || "";
                queryClient.prefetchQuery({
                    queryKey: ["ec2", "lifecycle-detail", iId],
                    queryFn: () => getComputeEC2LifecycleList({ instance_id: iId, account: row.account }),
                    staleTime: 5 * 60 * 1000
                });
            },
            icon: () => <Info size={16} color="#059669" className="cursor-pointer" />,
            tooltip: "View Instance Lifecycle"
        },
    ], [queryClient, setSelectedInstance]);

    // Perf: same as above for the AMI table — only stable setters inside, so empty deps.
    const amisAction = useMemo(() => [
        {
            label: "Details",
            onClick: (row) => setSelectedAmi(row),
            icon: () => <Info size={16} color="#059669" className="cursor-pointer" />,
            tooltip: "View Metadata"
        },
    ], [setSelectedAmi]);

    return (
        <div className="flex flex-col">
            <div className="space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-2 w-full">
                    {summaryLoading
                        ? Array.from({ length: 5 }).map((_, i) => (
                            <CardSkeleton key={i} />
                        ))
                        : card.map((kpi) => (
                            <KpiCard key={kpi.title} kpi={kpi} />
                        ))
                    }
                    {summaryError && (
                        <div className="flex items-center justify-center h-full col-span-full py-10">
                            <span className="text-destructive font-semibold">Error loading data</span>
                        </div>
                    )}

                </div>
                <div className="py-1">
                    <div className="flex justify-between items-center mb-2.5">
                        <p className="text-sm font-bold uppercase text-[var(--text-primary-color)]">Suggestions</p>
                        <Link to="/recommendation">
                            <button className="text-xs font-bold text-indigo-600 hover:text-indigo-800 transition-colors cursor-pointer bg-transparent border-0 p-0">View all</button>
                        </Link>
                    </div>
                    {suggestions.length > 0 ? (
                        <div className="space-y-2.5">
                            {suggestions.slice(0, 1).map((item) => {
                                const { title, desc } = splitSuggestionText(item.text);
                                return (
                                    <div key={item.id} className="bg-white ring-1 ring-black/10 rounded-lg p-3">
                                        <p className="text-xs font-bold text-gray-900 leading-snug">{title}</p>
                                        {desc && <p className="text-[11px] text-gray-500 mt-1 leading-relaxed whitespace-pre-line">{desc}</p>}
                                        <div className="flex items-center gap-1.5 mt-2 text-[10px] text-gray-400 font-medium">
                                            <span>By {item.created_by || "User"}</span>
                                            <span>·</span>
                                            <span>{new Date(item.created_at).toLocaleDateString()}</span>
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                    ) : (
                        <div className="flex flex-col items-center justify-center py-12 text-center bg-gray-100 border border-dashed border-gray-200 rounded-xl">
                            <span className="text-xs text-[var(--text-secondary-color)] font-medium">No recommendations found.</span>
                        </div>
                    )}
                </div>
                <ForecastCardFinance category="compute" service="ec2" trend={trend} isTrendLoading={isTrendLoading} />

                <Linechart avgCost={EC2summary?.avg_daily_cost} chartdata={trend}
                    name="cost"
                    service="AmazonEC2"
                    isLoading={isTrendLoading}
                    isError={isTrendError}
                />

                <div className="w-full flex flex-col space-y-2 mb-4">
                    <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wider px-1">Breakdown By</h3>
                    <Chips
                        options={breakdownOptions}
                        selected={dimension}
                        onSelect={setDimension}
                    />
                </div>

                <RoundedPieChart
                    title={`${breakdownOptions.find(o => o.value === dimension)?.label} Breakdown`}
                    subtitle={`Total cost distribution by ${breakdownOptions.find(o => o.value === dimension)?.label.toLowerCase()}`}
                    dataKey="cost"
                    nameKey="name"
                    chartData={breakdown}
                    isError={isBreakdownError}
                    isLoading={isBreakdownLoading}
                />

                {/* Active filter badge */}
                {typeFilter && (
                    <div className="flex items-center gap-2">
                        <span className="text-xs text-gray-500 font-medium">Filtered by:</span>
                        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-100 text-blue-800 text-sm font-medium">
                            Type: {typeFilter}
                            <button
                                onClick={() => { setTypeFilter(null); setCurrentPage(1); }}
                                className="hover:bg-blue-200 rounded-full p-0.5 transition-colors"
                            >
                                <X size={14} />
                            </button>
                        </span>
                        <span className="text-xs text-gray-400">
                            ({filteredData.length} of {instancesData.length} instances)
                        </span>
                    </div>
                )}

                <div className="w-full space-y-4">
                    <div className="flex flex-col">
                        <h3 className="font-bold text-lg text-gray-800">
                            EC2 Instances
                        </h3>
                    </div>

                    <Filters
                        data={instancesData}
                        onFilter={(filtered) => {
                            setFilteredList(filtered);
                        }}
                        searchKeys={EC2_SEARCH_KEYS}
                        filterConfigs={EC2_FILTER_CONFIGS}
                        placeholder="Search by instance name, ID, type..."
                    />
                    <Table
                        columns={columns}
                        data={filteredData}
                        actions={action}
                        isLoading={instancesQuery.isLoading}
                        isFiltered={filteredList !== null || typeFilter !== null}
                        emptyState={"No Data Available"}
                        currentPage={currentPage}
                    />
                    <PaginationControls
                        currentPage={currentPage}
                        totalPages={totalPages}
                        onPageChange={setCurrentPage}
                    />
                </div>

                <div className="w-full space-y-4">
                    <div className="flex flex-col">
                        <h3 className="font-bold text-lg text-gray-800">
                            EC2 AMIs
                        </h3>
                    </div>
                    <Filters
                        data={amisData}
                        onFilter={(filtered) => {
                            setAmisFilteredList(filtered);
                        }}
                        searchKeys={AMI_SEARCH_KEYS}
                        filterConfigs={AMI_FILTER_CONFIGS}
                        placeholder="Search by image ID, name..."
                    />
                    <Table
                        columns={amisColumns}
                        data={amisBaseData}
                        isLoading={amisQuery.isLoading}
                        isFiltered={amisFilteredList !== null}
                        emptyState={"No AMIs Available"}
                        actions={amisAction}
                        currentPage={amisPage}
                    />
                    <PaginationControls
                        currentPage={amisPage}
                        totalPages={amisTotalPages}
                        onPageChange={setAmisPage}
                    />
                </div>
                <AnimatePresence>
                    {selectedInstance && (
                        <Suspense fallback={null}>
                            <EC2MetaDrawer
                                key="ec2-drawer"
                                instanceData={selectedInstance}
                                onClose={() => setSelectedInstance(null)}
                            />
                        </Suspense>
                    )}
                </AnimatePresence>
                <AnimatePresence>
                    {selectedAmi && (
                        <Suspense fallback={null}>
                            <AMIMetaDataDrawer
                                key="ami-drawer"
                                amiData={selectedAmi}
                                onClose={() => setSelectedAmi(null)}
                            />
                        </Suspense>
                    )}
                </AnimatePresence>
            </div>
        </div>
    );
};

export default EC2;
