import { useState, useEffect, useMemo, lazy, Suspense } from "react";
import { splitSuggestionText } from "../../../lib/suggestionText";
import { AnimatePresence } from "framer-motion";
import { useQueryClient } from "@tanstack/react-query";
import { getComputeECRMetadata } from "../Compute.api";
import { useFilters } from "../../../hooks/useFilters";
import Table from "../../../common/Table";
import CopyableCell from "../../../common/CopyableCell";
import { useECR } from "../../../hooks/Compute/useECR";
import PaginationControls from "../../../common/PaginationControls";
import { Linechart } from "../../../common/Charts/LazyLinechart";
import { useUnified } from "../../../hooks/useUnified";

import { Chips } from "../../../common/Chips";
import { Filters } from "../../../common/Filters/Filter";
// OPTIMIZATION: Code-split drawer components using React.lazy to reduce the initial bundle size.
const ECRMetadataDrawer = lazy(() => import("./ECRMetadataDrawer"));

const ECR_SEARCH_KEYS = ["repository_name"];
const ECR_FILTER_CONFIGS = [
    { key: "account_name", label: "Account" },
    { key: "region", label: "Region" }
];
// Perf: fully static, so hoisted to module scope — stronger than useMemo (one
// allocation for the app's lifetime) and matches the consts above.
const BREAKDOWN_OPTIONS = [
    { label: "Usage Type", value: "usage-type" },
    { label: "Region", value: "region" },
    { label: "Account", value: "account" },
        { label: "Environment", value: "env" },
        { label: "Owner", value: "owner" },
        { label: "Project", value: "project" },
        { label: "Team", value: "team" },
        { label: "Application", value: "application" },
];
// import { StackedBarChart } from "../../../common/Charts/StackedBarChart";
import { RoundedPieChart } from "../../../common/Charts/LazyPiechart";


import { Activity, Box, Database, DollarSign, Server, Info } from "lucide-react";
import { CardSkeleton } from "../../../common/Cardoverview";
import { KpiCard } from "../../../components/common/KpiCard";
import { useSuggestions } from "../../../hooks/useSuggestions";
import { Link, useSearchParams } from "react-router-dom";
import { ForecastCardFinance } from "../../../common/MonthtoDate/LazyForecastCardFinance";

const ECR = () => {
    const queryClient = useQueryClient();
    const { filters } = useFilters();
    const [dimension, setDimension] = useState("usage-type");
    const { summary: ECRsummary, repositories: ECRinstance, isLoading, isError } = useECR();
    const { suggestions: allSuggestions } = useSuggestions();
    const suggestions = (allSuggestions ?? []).filter(
        (s) => String(s.service).toLowerCase() === "ecr" && s.scope === "page"
    );
    const {
        trend,
        breakdown,
        isTrendLoading,
        isBreakdownLoading,
        isTrendError,
        isBreakdownError
    } = useUnified(dimension);

    const [selectedRepository, setSelectedRepository] = useState(null);
    const [searchParams] = useSearchParams();
    useEffect(() => {
        const resource = searchParams.get("resource");
        if (resource) setSelectedRepository(resource);
    }, [searchParams]);

    // Perf: memoized so <Table columns={...}> gets a stable prop instead of a fresh
    // array every render; the render closure only uses a module-level component.
    const columns = useMemo(() => [
        {
            key: "repository_name",
            label: "Repository Name",
            render: (value) => <CopyableCell value={value} />
        },
        { key: "region", label: "Region"},
        { key: "account_name", label: "Account"},
        { key: "storage_gb", label: "Storage (GB)", sortable: true },
        { key: "total_cost", label: "Total Cost", sortable: true, showTotal: true },
        { key: "transfer_gb", label: "Transfer (GB)", sortable: true }
    ], []);

    const [filteredList, setFilteredList] = useState(null);
    const [currentPage, setCurrentPage] = useState(1);
    const rowsPerPage = 10;

    const displayData = filteredList !== null ? filteredList : (ECRinstance ?? []);
    const totalPages = Math.ceil(displayData.length / rowsPerPage);
    const paginatedData = displayData.slice(
        (currentPage - 1) * rowsPerPage,
        currentPage * rowsPerPage
    );


    // Perf: memoized so the KPI card list keeps a stable identity between renders;
    // recomputed only when the summary data actually changes.
    const card = useMemo(() => [
        { title: "total cost", value: ECRsummary?.total_cost, icon: <DollarSign size={16} className="text-green-500" />, icon2: <DollarSign size={16} className="text-green-600" /> },
        { title: "avg daily cost", value: ECRsummary?.avg_daily_cost, icon: <Activity size={16} className="text-green-800" />, icon2: <DollarSign size={16} className="text-green-600" /> },
        { title: "active repositories", value: ECRsummary?.active_repositories, icon: <Server size={16} className="text-cyan-500" /> },
        { title: "storage cost", value: ECRsummary?.storage_cost, icon: <Database size={16} className="text-amber-500" />, icon2: <DollarSign size={16} className="text-green-600" /> },
        { title: "transfer cost", value: ECRsummary?.transfer_cost, icon: <Box size={16} className="text-sky-500" />, icon2: <DollarSign size={16} className="text-green-600" /> },
    ], [ECRsummary])

    // Perf: memoized table actions. NOTE: the onHover prefetch closes over the
    // current date/account filters, so they are deps — otherwise a filter change
    // would prefetch with stale keys.
    const action = useMemo(() => [
        {
            label: "Metadata",
            onClick: (row) => {
                setSelectedRepository(row.repository_name);
            },
            onHover: (row) => {
                const rName = row.repository_name || row;
                queryClient.prefetchQuery({
                    queryKey: ["ecr", "metadata", rName, filters.start_date, filters.end_date, filters.account],
                    queryFn: () => getComputeECRMetadata({
                        repository_name: rName,
                        start_date: filters.start_date,
                        end_date: filters.end_date,
                        account: filters.account}),
                    staleTime: 5 * 60 * 1000
                });
            },
            icon: () => <Info size={16} className="cursor-pointer" />,
            color: "success",
            tooltip: "View Repository Metadata"
        }], [queryClient, filters.start_date, filters.end_date, filters.account])
    return (
        <div className="flex flex-col pb-6">
            <div className="space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-2 w-full">
                    {isLoading
                        ? Array.from({ length: 5 }).map((_, i) => (
                            <CardSkeleton key={i} />
                        ))
                        : card.map((kpi) => (
                            <KpiCard key={kpi.title} kpi={kpi} />
                        ))
                    }
                    {isError && (
                        <div className="flex items-center justify-center h-full col-span-full py-10">
                            <span className="text-destructive font-semibold">Error loading data</span>
                        </div>
                    )}

                </div>
                <div className="py-1">
                    <div className="flex justify-between items-center mb-2.5">
                        <p className="text-sm font-bold uppercase text-[var(--text-primary-color)]">Suggestions</p>
                        <Link to="/recommendation">
                            <button className="text-xs font-bold text-indigo-600 hover:text-indigo-800 transition-colors cursor-pointer bg-transparent border-0 p-0">View all</button>
                        </Link>
                    </div>
                    {suggestions.length > 0 ? (
                        <div className="space-y-2.5">
                            {suggestions.slice(0, 1).map((item) => {
                                const { title, desc } = splitSuggestionText(item.text);
                                return (
                                    <div key={item.id} className="bg-white ring-1 ring-black/10 rounded-lg p-3">
                                        <p className="text-xs font-bold text-gray-900 leading-snug">{title}</p>
                                        {desc && <p className="text-[11px] text-gray-500 mt-1 leading-relaxed whitespace-pre-line">{desc}</p>}
                                        <div className="flex items-center gap-1.5 mt-2 text-[10px] text-gray-400 font-medium">
                                            <span>By {item.created_by || "User"}</span>
                                            <span>·</span>
                                            <span>{new Date(item.created_at).toLocaleDateString()}</span>
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                    ) : (
                        <div className="flex flex-col items-center justify-center py-12 text-center bg-gray-100 border border-dashed border-gray-200 rounded-xl">
                            <span className="text-xs text-[var(--text-secondary-color)] font-medium">No recommendations found.</span>
                        </div>
                    )}
                </div>
                <ForecastCardFinance category="compute" service="ecr" trend={trend} isTrendLoading={isTrendLoading} />

                <Linechart avgCost={ECRsummary?.avg_daily_cost} chartdata={trend}
                    name="cost"
                    service="AmazonECR"
                    isLoading={isTrendLoading}
                    isError={isTrendError}
                />
                <div className="w-full flex flex-col space-y-2 mb-4">
                    <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wider px-1">Breakdown By</h3>
                    <Chips
                        options={BREAKDOWN_OPTIONS}
                        selected={dimension}
                        onSelect={setDimension}
                    />
                </div>
                <RoundedPieChart
                    title={`${BREAKDOWN_OPTIONS.find(o => o.value === dimension)?.label} Breakdown`}
                    subtitle={`Total cost distribution by ${BREAKDOWN_OPTIONS.find(o => o.value === dimension)?.label.toLowerCase()}`}
                    dataKey="cost"
                    nameKey="name"
                    chartData={breakdown}
                    isError={isBreakdownError}
                    isLoading={isBreakdownLoading}
                />
                <div className="w-full">
                    <h3 className="text-lg font-semibold mb-1">ECR Repositories</h3>
                    <Filters 
                        data={ECRinstance ?? []} 
                        onFilter={(filtered) => {
                            setFilteredList(filtered);
                            setCurrentPage(1);
                        }} 
                        searchKeys={ECR_SEARCH_KEYS}
                        filterConfigs={ECR_FILTER_CONFIGS}
                        placeholder="Search by repository name..."
                    />
                    <Table
                        columns={columns}
                        data={paginatedData}
                        actions={action}
                        isLoading={isLoading}
                        isFiltered={filteredList !== null}
                        emptyState={"No data available"}
                    />
                    <PaginationControls currentPage={currentPage} totalPages={totalPages} onPageChange={setCurrentPage} />
                </div>

                <AnimatePresence>
                    {selectedRepository && (
                        <Suspense fallback={null}>
                            <ECRMetadataDrawer
                                key="ecr-drawer"
                                repositoryName={selectedRepository}
                                onClose={() => setSelectedRepository(null)}
                            />
                        </Suspense>
                    )}
                </AnimatePresence>
            </div>
        </div>
    );
};

export default ECR;
