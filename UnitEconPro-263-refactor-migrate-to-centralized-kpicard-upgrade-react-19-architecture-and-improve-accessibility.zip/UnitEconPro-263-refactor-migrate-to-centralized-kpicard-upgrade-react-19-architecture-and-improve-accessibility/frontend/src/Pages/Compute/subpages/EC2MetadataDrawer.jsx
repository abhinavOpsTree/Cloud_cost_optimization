import { KpiCard } from "../../../components/common/KpiCard";
import { useState, useMemo } from "react";
import { splitSuggestionText } from "../../../lib/suggestionText";
import { useQuery } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { Link, useNavigate } from "react-router-dom";
import { useEC2Metadata } from "../../../hooks/Compute/useEC2";
import { getComputeEC2LifecycleList } from "../Compute.api";
import PaginationControls from "../../../common/PaginationControls";
import AddSuggestionModal from "../../../common/AddSuggestionModal";
import FinOpsFlagsContainer from "../../../common/FinOpsFlagsContainer";
import { useSuggestions } from "../../../hooks/useSuggestions";
import {
    X, Server, Info, Activity, HardDrive,
    Zap, CheckCircle2, Tag,
    StopCircle,
    Lightbulb, Pencil, Box
} from "lucide-react";

// ─────────────────────────────────────────────
// Design primitives (reusing project token colors)
// ─────────────────────────────────────────────

const MONO = "font-mono";
const TAGS_PER_PAGE = 10;

const SectionLabel = ({ children }) => (
    <p className="text-sm font-bold uppercase text-[var(--text-primary-color)] mb-2.5">{children}</p>
);

const MetaRow = ({ label, value, mono, bold, color, highlight }) => (
    <div className="flex justify-between items-center py-1.5 border-b border-slate-200 text-xs last:border-0 gap-3">
        <span className="text-gray-500 shrink-0">{label}</span>
        {highlight ? (
            <span className="relative inline-flex items-center justify-end text-right break-all">
                <span className="absolute inset-0 bg-red-400/30 rounded animate-pulse pointer-events-none -mx-1 -my-0.5" />
                <span className={`relative z-10 ${mono ? `${MONO} text-[11px] text-blue-700` : ""} ${bold ? "font-semibold" : ""} ${color || "text-gray-900"}`}>
                    {value ?? "—"}
                </span>
            </span>
        ) : (
            <span className={`text-right break-all ${mono ? `${MONO} text-[11px] text-blue-700` : ""} ${bold ? "font-semibold" : ""} ${color || "text-gray-900"}`}>
                {value ?? "—"}
            </span>
        )}
    </div>
);

const CpuBar = ({ label, pct, colorClass, textClass, highlight }) => (
    <div className="mb-3.5">
        <div className="flex justify-between mb-1 text-xs">
            <span className="text-gray-500">{label}</span>
            {highlight ? (
                <span className="relative inline-flex items-center justify-end">
                    <span className="absolute inset-0 bg-red-400/30 rounded animate-pulse pointer-events-none -mx-1 -my-0.5" />
                    <span className={`relative z-10 ${MONO} font-semibold text-[12px] ${textClass}`}>
                        {Number(pct || 0).toFixed(1)}%
                    </span>
                </span>
            ) : (
                <span className={`${MONO} font-semibold text-[12px] ${textClass}`}>{Number(pct || 0).toFixed(1)}%</span>
            )}
        </div>
        <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
            <div className={`h-full rounded-full ${colorClass}`} style={{ width: `${Math.min(pct || 0, 100)}%` }} />
        </div>
    </div>
);



const Badge = ({ children, variant }) => {
    const cls = {
        success: "bg-emerald-50 text-emerald-800 border-emerald-200",
        warning: "bg-amber-50 text-amber-800 border-amber-200",
        danger: "bg-red-50 text-red-800 border-red-200",
        info: "bg-blue-50 text-blue-800 border-blue-200",
        purple: "bg-purple-50 text-purple-800 border-purple-200",
    }[variant] || "bg-gray-100 text-gray-700 border-gray-200";
    return (
        <span className={`inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded border ${cls}`}>
            {variant === "success" && <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block" />}
            {children}
        </span>
    );
};

const getStatusVariant = (state) => {
    const s = String(state || "").toLowerCase();
    if (s === "running" || s === "active") return "success";
    if (s === "stopped") return "warning";
    if (s === "terminated") return "danger";
    return "info";
};

// ─────────────────────────────────────────────
// Lifecycle timeline helpers
// ─────────────────────────────────────────────
const fmt = (d) => d.toLocaleDateString("en-US", { month: "short", day: "numeric" });
const fmtT = (d) => d.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit", hour12: false });

const GapCard = ({ g, idx }) => {
    const start = new Date(g.gap_start || g.start_time || g.start);
    const end = new Date(g.gap_end || g.end_time || g.end);
    const rawHours = g.hours ?? (g.duration_days ? (g.duration_days * 24) : null) ?? ((end.getTime() - start.getTime()) / 3_600_000);
    const hoursNum = isNaN(rawHours) ? 0 : Number(rawHours);
    const hours = hoursNum.toFixed(1);
    const dur = hoursNum >= 24
        ? Math.floor(hoursNum / 24) + "d" + (hoursNum % 24 ? " " + Math.round(hoursNum % 24) + "h" : "")
        : hours + "h";
    const pct = Math.min(100, (hoursNum / 720) * 100);
    return (
        <div className="rounded-lg overflow-hidden border border-amber-200/70 mb-2">
            <div className="flex items-center justify-between px-3 py-2 bg-amber-50">
                <div className="flex items-center gap-2">
                    <span className="text-[10px] font-semibold text-amber-700 bg-amber-100 px-2 py-0.5 rounded-full">{idx + 1}</span>
                    <span className="text-xs text-gray-800 font-medium">
                        {!isNaN(start.getTime()) ? fmt(start) + ", " + fmtT(start) : "Invalid Date"} → {!isNaN(end.getTime()) ? fmt(end) + ", " + fmtT(end) : "Invalid Date"}
                    </span>
                </div>
                <span className="text-xs font-semibold text-amber-700">{dur}</span>
            </div>
            <div className="px-3 py-2 bg-white">
                <div className="flex justify-between text-[10px] text-gray-400 mb-1">
                    <span>Stopped duration</span><span>{hours}h of 720h window</span>
                </div>
                <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
                    <div className="h-full bg-red-400 rounded-full" style={{ width: `${pct.toFixed(1)}%` }} />
                </div>
                <p className="text-[10px] text-gray-400 mt-1">{((hoursNum / 720) * 100).toFixed(1)}% of window</p>
            </div>
        </div>
    );
};

// ─────────────────────────────────────────────
// Tab content components
// ─────────────────────────────────────────────

const Overview = ({ data, instanceData }) => (
    <div className="space-y-6">
        <div className="grid grid-cols-1 gap-7">
            <div>
                <SectionLabel>Identity</SectionLabel>
                <MetaRow label="Instance ID" value={data.instance_id || instanceData?.instance_id} mono />
                <MetaRow label="Instance Name" value={data.tags?.Name || data.instance_name || instanceData?.instance_name} bold />
                <MetaRow label="Instance Type" value={data.instance_type || instanceData?.instance_type} bold />
                <MetaRow label="Platform" value={data.platform} />
                <MetaRow label="Architecture" value={data.architecture} highlight={data.graviton_migration_candidate} />
                <MetaRow label="Pricing Model" value={data.pricing_model || instanceData?.pricing_model} highlight={data.graviton_migration_candidate} />
                <MetaRow label="State" value={data.inferred_state || data.state || instanceData?.inferred_state} color="text-emerald-700 font-semibold" />
                <MetaRow label="Last Launch" value={data.last_launch_time} />
            </div>
            <div>
                <SectionLabel>Location & Account</SectionLabel>
                <MetaRow label="Region" value={data.region || instanceData?.region} />
                <MetaRow label="Availability Zone" value={data.availability_zone} />
                <MetaRow label="Account Name" value={data.account_name || instanceData?.account} />
                <MetaRow label="AWS Account ID" value={data.aws_account_id} mono />
                {data.asg_name && <MetaRow label="ASG Name" value={data.asg_name} />}
                {data.criticality && <MetaRow label="Criticality" value={data.criticality} color="text-red-600 font-semibold" />}
            </div>
        </div>
    </div>
);

const Performance = ({ data }) => {
    const hl = !!data.rightsizing_signal;
    return (
        <div>
            <SectionLabel>CPU Utilization</SectionLabel>
            <CpuBar label="Average" pct={data.cpu_avg_pct} colorClass="bg-emerald-500" textClass="text-emerald-700" highlight={hl} />
            <CpuBar label="P95" pct={data.cpu_p95_pct} colorClass="bg-amber-500" textClass="text-amber-700" highlight={hl} />
            <CpuBar label="Max" pct={data.cpu_max_pct} colorClass="bg-red-400" textClass="text-red-700" highlight={hl} />
            <div className="mb-5" />
            <SectionLabel>Network Usage</SectionLabel>
            <MetaRow label="Inbound (Avg)" value={data.net_in_mbps ? `${Number(data.net_in_mbps).toFixed(1)} Mbps` : "—"} highlight={hl} />
            <MetaRow label="Outbound (Avg)" value={data.net_out_mbps ? `${Number(data.net_out_mbps).toFixed(1)} Mbps` : "—"} highlight={hl} />
            <div className="mb-5" />
            <SectionLabel>Data Window</SectionLabel>
            <MetaRow label="Utilization Window" value={data.utilization_days ? `${data.utilization_days} days` : "—"} />
            <MetaRow label="Data Last Updated" value={data.utilization_updated || "—"} />
        </div>
    );
};

const StorageNetwork = ({ data }) => (
    <div>
        <SectionLabel>EBS & Storage</SectionLabel>
        <div className="bg-white rounded-lg px-4 py-1 mb-5">
            <MetaRow label="EBS Optimized" value={data.ebs_optimized ? <span className="flex items-center gap-1 text-emerald-700 font-semibold"><CheckCircle2 size={13} />Enabled</span> : "Disabled"} />
            <MetaRow label="Attached Volumes" value={data.attached_ebs_count} bold />
            <MetaRow label="Root Volume Type" value={data.root_volume_type} />
            <MetaRow label="Root Volume Size" value={data.root_volume_size_gb ? `${data.root_volume_size_gb} GB` : "—"} />
        </div>
        <SectionLabel>Network Config</SectionLabel>
        <div className="bg-white rounded-lg px-4 py-1">
            <MetaRow label="Public IP" value={data.has_public_ip ? "Assigned" : "Not Assigned"} />
            <MetaRow label="Detailed Monitoring" value={data.detailed_monitoring
                ? <span className="text-emerald-700 font-semibold">Enabled</span>
                : <span className="text-amber-700 font-semibold">Disabled</span>}
            />
        </div>
    </div>
);

const OptimiseSignals = ({ data, onSuggest }) => (
    <div>
        <SectionLabel>Optimization Signals</SectionLabel>
        {((data.cost_signals || data.cost_flags) && (data.cost_signals || data.cost_flags).length > 0) ? (
            <FinOpsFlagsContainer
                flags={data.cost_signals || data.cost_flags}
                items={data.cost_signals || data.cost_flags}
                onSuggest={onSuggest}
            />
        ) : (
            <p className="text-xs text-gray-500 italic bg-gray-50 dark:bg-slate-800 p-3 rounded-lg border border-gray-200 dark:border-slate-700 mb-4">
                No active optimization signals found for this instance.
            </p>
        )}

        {data.insight && (
            <div className="mt-4">
                <SectionLabel>Analyst Insight</SectionLabel>
                <button
                    type="button"
                    onClick={() => onSuggest(data.insight)}
                    title="Click to add as suggestion"
                    className="w-full text-left mx-0 mb-4 bg-blue-50 border border-blue-200/60 rounded-lg px-3.5 py-2.5 flex items-start gap-2 cursor-pointer hover:border-blue-400 transition-colors focus:outline-none"
                >
                    <Lightbulb size={15} className="text-blue-700 shrink-0 mt-0.5" />
                    <p className="text-xs text-blue-800 leading-snug">{data.insight}</p>
                </button>
            </div>
        )}
    </div>
);

const LifecycleTab = ({ lifecycleDetail, isLifecycleLoading }) => {
    const detail = Array.isArray(lifecycleDetail) ? lifecycleDetail[0] : lifecycleDetail;
    const gapsData = Array.isArray(detail?.gaps) ? detail.gaps.filter(Boolean) : [];

    const lcStats = detail
        ? [
            { val: detail.active_days ?? "—", lbl: "Active Days", cls: "text-emerald-700", bg: "bg-emerald-50" },
            { val: detail.stopped_days ?? "—", lbl: "Stopped Days", cls: "text-red-700", bg: "bg-red-50" },
            { val: gapsData.length, lbl: "Stop Windows", cls: "text-amber-700", bg: "bg-amber-50" },
            // { val: detail.total_hours ? `${Number(detail.total_hours).toFixed(0)}h` : "—", lbl: "Total Hours", cls: "text-gray-900", bg: "bg-white" },
        ]
        : [];

    if (isLifecycleLoading) {
        return (
            <div className="flex items-center justify-center py-16">
                <div className="w-6 h-6 border-2 border-[var(--button-bg)] border-t-transparent rounded-full animate-spin mr-3" />
                <span className="text-sm text-gray-500">Loading lifecycle data...</span>
            </div>
        );
    }

    if (!detail) {
        return (
            <div className="text-center py-12 text-gray-400 italic text-sm">
                No lifecycle data available for this instance.
            </div>
        );
    }

    return (
        <div>
            {/* Stats strip */}
            <div className="grid grid-cols-4 gap-2 mb-5">
                {lcStats.map((s) => (
                    <div key={s.lbl} className={`${s.bg} rounded-lg px-3 py-2.5`}>
                        <p className={`text-xl font-semibold ${s.cls}`}>{s.val}</p>
                        <p className="text-[10px] font-bold uppercase tracking-widest text-gray-400 mt-0.5">{s.lbl}</p>
                    </div>
                ))}
            </div>

            {/* 30-day timeline */}
            {/* <SectionLabel>30-Day Activity Timeline</SectionLabel>
            <div className="grid gap-0.5 mb-1" style={{ gridTemplateColumns: `repeat(${DAYS}, 1fr)` }}>
                {dayDates.map((d, i) => <DayCell key={d instanceof Date ? d.toISOString() : i} date={d} gaps={gapsData} />)}
            </div>
            <div className="flex justify-between mb-2.5">
                {[0, 10, 20, DAYS - 1].map((dayIdx) => (
                    <span key={dayIdx} className="text-[10px] text-gray-400">{fmt(dayDates[dayIdx] || dayDates[dayDates.length - 1])}</span>
                ))}
            </div>
            <div className="flex gap-4 mb-5">
                {[
                    { color: "bg-emerald-500", label: "Active" },
                    { color: "bg-red-400", label: "Fully stopped" },
                    { color: "", label: "Partial stop", grad: true },
                ].map((l) => (
                    <div key={l.label} className="flex items-center gap-1.5 text-[11px] text-gray-500">
                        <div
                            className={`w-2.5 h-2.5 rounded-sm ${l.color}`}
                            style={l.grad ? { background: "linear-gradient(to bottom,#1D9E75 50%,#E24B4A 50%)" } : {}}
                        />
                        {l.label}
                    </div>
                ))}
            </div> */}

            {gapsData.length > 0 && (
                <>
                    <SectionLabel>Stop Windows ({gapsData.length})</SectionLabel>
                    <div className="w-full h-200 overflow-hidden overflow-y-auto">
                        {gapsData.map((g, i) => <GapCard key={g.id || g.gap_id || `${g.gap_start || g.start_time || g.start}-${g.gap_end || g.end_time || g.end}-${i}`} g={g} idx={i} />)}
                    </div>
                </>
            )}
            {gapsData.length === 0 && (
                <div className="bg-emerald-50 border border-emerald-200/60 rounded-lg px-4 py-3 flex items-center gap-2">
                    <CheckCircle2 size={14} className="text-emerald-600" />
                    <p className="text-xs text-emerald-800 font-medium">This instance has been running continuously in the available history.</p>
                </div>
            )}

            {/* Instance detail rows */}
            <div className="mt-5">
                <SectionLabel>Lifecycle Details</SectionLabel>
                <div className="bg-white rounded-lg px-4 py-1">
                    <MetaRow label="First Seen" value={detail.first_seen} />
                    <MetaRow label="Last Seen" value={detail.last_seen} />
                    {detail.total_cost != null && (
                        <MetaRow label="Total Cost" value={`$${Number(detail.total_cost).toFixed(2)}`} bold />
                    )}
                    {detail.instance_age_days != null && (
                        <MetaRow label="Instance Age" value={`${detail.instance_age_days} days`} />
                    )}
                    {detail.asg_name && <MetaRow label="ASG Name" value={detail.asg_name} />}
                </div>
            </div>
        </div>
    );
};

const TagsTab = ({ data, tagsPage, setTagsPage }) => {
    const tagEntries = useMemo(() => (data.tags ? Object.entries(data.tags) : []), [data.tags]);
    const totalPages = Math.max(1, Math.ceil(tagEntries.length / TAGS_PER_PAGE));
    const paginated = tagEntries.slice((tagsPage - 1) * TAGS_PER_PAGE, tagsPage * TAGS_PER_PAGE);

    return (
        <div>
            <SectionLabel>Resource Tags ({tagEntries.length})</SectionLabel>
            {paginated.length > 0 ? (
                <div className="space-y-1.5">
                    {paginated.map(([k, v]) => (
                        <div key={k} className="flex overflow-hidden border border-slate-200 rounded-lg">
                            <div className={`px-3.5 py-2.5 bg-white min-w-[140px] border-r border-slate-200 ${MONO} text-xs text-blue-700`}>{k}</div>
                            <div className="px-3.5 py-2.5 text-xs text-gray-900">{String(v)}</div>
                        </div>
                    ))}
                </div>
            ) : (
                <div className="text-center py-6 bg-white rounded-2xl border border-dashed border-gray-200">
                    <span className="text-xs text-gray-400">No resource tags available</span>
                </div>
            )}
            {tagEntries.length > TAGS_PER_PAGE && (
                <PaginationControls currentPage={tagsPage} totalPages={totalPages} onPageChange={setTagsPage} />
            )}
        </div>
    );
};

// ─────────────────────────────────────────────
// AMI Tab
// ─────────────────────────────────────────────
const AmiTab = ({ data }) => {
    return (
        <div className="space-y-6">
            {data.ami_description && (
                <div className="bg-blue-50 border border-blue-100 rounded-lg p-3">
                    <p className="text-xs text-blue-800 leading-relaxed">
                        {data.ami_description}
                    </p>
                </div>
            )}
            
            <div>
                <SectionLabel>AMI Details</SectionLabel>
                <div className="bg-white rounded-xl p-4 border border-slate-200 space-y-1">
                    <MetaRow label="AMI ID" value={data.image_id} mono={true} />
                    <MetaRow label="Name" value={data.ami_name} />
                    <MetaRow label="Creation Date" value={data.ami_creation_date ? new Date(data.ami_creation_date).toLocaleString() : "—"} />
                    <MetaRow label="State" value={data.ami_state} />
                    <MetaRow label="Public" value={data.ami_is_public ? "Yes" : "No"} />
                    <MetaRow label="Graviton Candidate" value={data.graviton_migration_candidate ? "Yes" : "No"} />
                </div>
            </div>

            <div>
                <SectionLabel>Snapshot & Costs</SectionLabel>
                <div className="bg-white rounded-xl p-4 border border-slate-200 space-y-1">
                    <MetaRow 
                        label="Snapshot IDs" 
                        value={data.ami_snapshot_ids?.length > 0 ? data.ami_snapshot_ids.join(", ") : "None"} 
                        mono={data.ami_snapshot_ids?.length > 0} 
                    />
                    <MetaRow label="Snapshot Cost (30d)" value={`$${Number(data.ami_snapshot_cost_30d || 0).toFixed(2)}`} bold={true} />
                </div>
            </div>
        </div>
    );
};

// ─────────────────────────────────────────────
// Main merged drawer
// ─────────────────────────────────────────────

const TABS = [
    { id: "overview", label: "Overview", icon: Info },
    { id: "performance", label: "Performance", icon: Activity },
    { id: "storage", label: "Storage & Network", icon: HardDrive },
    { id: "optimise", label: "Optimise Signals", icon: Zap },
    { id: "lifecycle", label: "Lifecycle", icon: StopCircle },
    { id: "ami", label: "AMI", icon: Box },
    { id: "tags", label: "Tags", icon: Tag },
];

const EC2MetaDrawer = ({ instanceData, onClose }) => {
    const [activeTab, setActiveTab] = useState("overview");
    const [tagsPage, setTagsPage] = useState(1);
    const [isSugOpen, setIsSugOpen] = useState(false);
    const [sugPrefill, setSugPrefill] = useState("");
    const openSuggestion = (text = "") => {
        setSugPrefill(text);
        setIsSugOpen(true);
    };

    const navigate = useNavigate();
    const { suggestions } = useSuggestions();

    const instanceId = instanceData?.instance_id || instanceData?.instance_name || "";

    const { metadata, isMetadataLoading } = useEC2Metadata(instanceId);
    const metaRaw = metadata?.[0] || (metadata && typeof metadata === "object" ? metadata : {});

    const resourceSuggestions = useMemo(() => {
        return (suggestions || []).filter(item =>
            String(item.service).toLowerCase() === "ec2" &&
            item.scope === "resource" &&
            String(item.resource_id).toLowerCase() === String(metaRaw.instance_id || instanceId).toLowerCase()
        );
    }, [suggestions, metaRaw.instance_id, instanceId]);

    // Lifecycle from query
    const { data: lifecycleDetail, isLoading: isLifecycleLoading } = useQuery({
        queryKey: ["ec2", "lifecycle-detail", instanceId],
        queryFn: () => getComputeEC2LifecycleList({ instance_id: instanceId, account: instanceData.account }),
        enabled: !!instanceId,
        staleTime: 5 * 60 * 1000,
    });

    const [prevInstanceId, setPrevInstanceId] = useState(instanceId);
    if (instanceId !== prevInstanceId) {
        setPrevInstanceId(instanceId);
        setActiveTab("overview");
        setTagsPage(1);
    }

    // Lifecycle gap count for badge
    const lcDetail = Array.isArray(lifecycleDetail) ? lifecycleDetail[0] : lifecycleDetail;
    const gapsData = Array.isArray(lcDetail?.gaps) ? lcDetail.gaps.filter(Boolean) : [];

    // KPI values (prefer metadata, fallback to instanceData)
    const hasRightsizing = !!metaRaw.rightsizing_signal;
    const kpis = [
        { label: "CPU Avg", value: metaRaw.cpu_avg_pct ? `${Number(metaRaw.cpu_avg_pct).toFixed(1)}` : "—", unit: "%", sub: `max ${metaRaw.cpu_max_pct ? Number(metaRaw.cpu_max_pct).toFixed(1) : "—"}%`, danger: hasRightsizing },
        { label: "CPU P95", value: metaRaw.cpu_p95_pct ? `${Number(metaRaw.cpu_p95_pct).toFixed(1)}` : "—", unit: "%", sub: "utilization window", danger: hasRightsizing },
        { label: "Cost Signals", value: (metaRaw.cost_signals || metaRaw.cost_flags)?.length ?? "0", unit: "active", sub: "action needed", warn: ((metaRaw.cost_signals || metaRaw.cost_flags)?.length || 0) > 0 },
    ];


    return (
        <>
            {/* Backdrop */}
            <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.3 }}
                className="fixed inset-0 z-[999] bg-black/20 backdrop-blur-[1px] h-full" 
                onClick={onClose} 
            />

            {/* Panel */}
            <motion.div 
                initial={{ x: "100%" }}
                animate={{ x: 0 }}
                exit={{ x: "100%" }}
                transition={{ type: "tween", duration: 0.3 }}
                className="fixed right-0 top-0 h-screen w-[70%] max-w-full bg-white shadow-[-8px_0_32px_rgba(0,0,0,0.12)] z-[9999] border-l border-gray-100 flex flex-col"
            >

                {/* ── Header ── */}
                <div className="px-6 py-4 border-b border-slate-200 shrink-0 bg-white">
                    <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3.5">
                            <div className="w-9 h-9 rounded-lg bg-[#FF9900] flex items-center justify-center shrink-0 ">
                                <Server size={18} className="text-white" />
                            </div>
                            <div>
                                <div className="flex items-center gap-1.5 flex-wrap mb-0.5">
                                    <span className={`${MONO} text-[13px] font-semibold text-[var(--text-primary-color)] tracking-tight`}>
                                        {metaRaw.instance_id || instanceId}
                                    </span>
                                    <Badge variant={getStatusVariant(metaRaw.inferred_state || metaRaw.state || instanceData?.inferred_state)}>
                                        {metaRaw.inferred_state || metaRaw.state || instanceData?.inferred_state || "Unknown"}
                                    </Badge>
                                    {metaRaw.criticality && (
                                        <Badge variant="danger">{metaRaw.criticality}</Badge>
                                    )}
                                </div>
                                <p className="text-xs text-[var(--text-secondary-color)]">
                                    {instanceData?.instance_type || metaRaw.instance_type} · {instanceData?.region || metaRaw.region} · {instanceData?.account || metaRaw.account_name}
                                </p>
                            </div>
                        </div>
                        <div className="flex items-center gap-2">
                            <motion.button
                                whileHover={{ scale: 1.02 }}
                                whileTap={{ scale: 0.98 }}
                                onClick={() => openSuggestion("")}
                                className="flex items-center justify-center gap-2 px-4 py-2 bg-[var(--button-bg)] text-white text-xs font-bold rounded-lg  hover:bg-[var(--button-bg)]/90 transition-all cursor-pointer uppercase tracking-wider shrink-0 mr-1"
                            >
                                <Pencil size={14} />
                                Add Suggestion
                            </motion.button>
                            <button
                                className="w-7 h-7 rounded border border-slate-200 flex items-center justify-center text-gray-400 hover:bg-white hover:text-gray-700 transition-colors cursor-pointer"
                                onClick={onClose}
                            >
                                <X size={14} />
                            </button>
                        </div>
                    </div>
                </div>



                {/* ── KPI strip ── */}
                {isMetadataLoading ? (
                    <div className="grid grid-cols-5 gap-2 px-6 py-3 border-b border-slate-200 shrink-0">
                        {Array.from({ length: 5 }).map((_, i) => (
                            <div key={i} className="h-14 bg-gray-100 rounded-lg animate-pulse" />
                        ))}
                    </div>
                ) : (
                    <div className="grid grid-cols-5 gap-2 px-6 py-3 border-b border-slate-200 shrink-0">
                        {kpis.map((k) => <KpiCard variant="compact" key={k.label} {...k} />)}
                    </div>
                )}

                <div className="px-6 py-1">
                    {resourceSuggestions && resourceSuggestions.length > 0 && (
                        <div className="">
                            <div className="flex justify-between items-center">
                                <SectionLabel>Suggestions</SectionLabel>
                                <Link to="/recommendation">
                                    <button
                                        className="text-xs font-bold text-indigo-600 hover:text-indigo-800 transition-colors cursor-pointer"
                                    >
                                        View all
                                    </button>
                                </Link>
                            </div>
                            <div className="space-y-2.5">
                                {resourceSuggestions.slice(0, 1).map((item) => {
                                    const { title, desc } = splitSuggestionText(item.text);
                                    return (
                                        <div key={item.id} className="bg-white/50 border border-slate-200 rounded-lg p-3">
                                            <p className="text-xs font-bold text-gray-900 leading-snug">{title}</p>
                                            {desc && <p className="text-[11px] text-gray-500 mt-1 leading-relaxed whitespace-pre-line">{desc}</p>}
                                            <div className="flex items-center gap-1.5 mt-2 text-[10px] text-gray-400 font-medium">
                                                <span>By {item.created_by || "User"}</span>
                                                <span>·</span>
                                                <span>{new Date(item.created_at).toLocaleDateString()}</span>
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>
                        </div>
                    )}
                </div>


                {/* ── Tab bar ── */}
                <div className="flex border-b border-slate-200 px-6 mt-2.5 shrink-0 gap-0.5 overflow-x-auto scrollbar-none">
                    {TABS.map((t) => {
                        const Icon = t.icon;
                        const isActive = activeTab === t.id;
                        return (
                            <button
                                key={t.id}
                                onClick={() => setActiveTab(t.id)}
                                className={`flex items-center gap-1.5 px-3.5 py-2.5 text-xs whitespace-nowrap border-b-2 transition-colors cursor-pointer -mb-px ${isActive
                                    ? "border-[var(--button-bg)] font-semibold text-[var(--button-bg)]"
                                    : "border-transparent text-gray-500 hover:text-gray-900 font-normal"
                                    }`}
                            >
                                <Icon size={13} />
                                {t.label}
                                {t.id === "overview" && metaRaw.graviton_migration_candidate && (
                                    <span className="ml-0.5 text-[9px] font-bold px-1.5 py-0.5 rounded-full bg-red-100 text-red-600">
                                        2
                                    </span>
                                )}
                                {t.id === "performance" && !!metaRaw.rightsizing_signal && (
                                    <span className="ml-0.5 text-[9px] font-bold px-1.5 py-0.5 rounded-full bg-red-100 text-red-600">
                                        5
                                    </span>
                                )}
                                {t.id === "lifecycle" && gapsData.length > 0 && (
                                    <span className="ml-0.5 text-[9px] font-bold px-1.5 py-0.5 rounded-full bg-red-100 text-red-600">
                                        {gapsData.length}
                                    </span>
                                )}
                                {t.id === "tags" && Object.keys(metaRaw.tags || {}).length > 0 && (
                                    <span className="ml-0.5 text-[9px] font-bold px-1.5 py-0.5 rounded-full bg-gray-100 text-gray-500">
                                        {Object.keys(metaRaw.tags).length}
                                    </span>
                                )}
                            </button>
                        );
                    })}
                </div>


                {/* ── Tab content ── */}
                <div className="flex-1 overflow-y-auto px-6 py-5">
                    {isMetadataLoading && activeTab !== "lifecycle" ? (
                        <div className="flex items-center justify-center py-16">
                            <div className="w-6 h-6 border-2 border-[var(--button-bg)] border-t-transparent rounded-full animate-spin mr-3" />
                            <span className="text-sm text-gray-500">Loading instance data...</span>
                        </div>
                    ) : (
                        <>
                            {activeTab === "overview" && (
                                <Overview
                                    data={metaRaw}
                                    instanceData={instanceData}
                                    suggestions={resourceSuggestions}
                                    onViewAll={() => navigate("/recommendation")}
                                />
                            )}
                            {activeTab === "performance" && <Performance data={metaRaw} />}
                            {activeTab === "storage" && <StorageNetwork data={metaRaw} />}
                            {activeTab === "optimise" && <OptimiseSignals data={metaRaw} onSuggest={openSuggestion} />}
                            {activeTab === "lifecycle" && (
                                <LifecycleTab
                                    lifecycleDetail={lifecycleDetail}
                                    isLifecycleLoading={isLifecycleLoading}
                                />
                            )}
                            {activeTab === "ami" && <AmiTab data={metaRaw} />}
                            {activeTab === "tags" && (
                                <TagsTab data={metaRaw} tagsPage={tagsPage} setTagsPage={setTagsPage} />
                            )}
                        </>
                    )}
                </div>
            </motion.div>
            <AddSuggestionModal
                isOpen={isSugOpen}
                onClose={() => setIsSugOpen(false)}
                service="ec2"
                scope="resource"
                resourceId={metaRaw.instance_id || instanceId}
                resourceName={metaRaw.tags?.Name || metaRaw.instance_name || instanceData?.instance_name || ""}
                initialText={sugPrefill}
            />
        </>
    );
};

export default EC2MetaDrawer;


