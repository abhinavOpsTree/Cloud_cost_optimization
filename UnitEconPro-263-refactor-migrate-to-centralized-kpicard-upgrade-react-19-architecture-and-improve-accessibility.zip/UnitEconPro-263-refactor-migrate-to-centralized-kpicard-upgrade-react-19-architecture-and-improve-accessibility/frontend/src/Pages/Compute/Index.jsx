import { AnimatePresence, motion } from "framer-motion";
import { Check, ChevronDown } from "lucide-react";
import { useState } from "react";
import { Outlet } from "react-router-dom";
import SubPageTabs from "../../common/SubPageTabs";

const ComputeLayout = () => {
    return (
        <div className="w-full min-h-screen space-y-2 px-6 py-2">
            <title>Compute | SpendSmart</title>
            <meta name="description" content="Manage and optimize your cloud compute resources with SpendSmart." />
            {/* <div className="mt-4">
                <Header />
            </div> */}
            <SubPageTabs />
            <div className="mb-4 mt-4">
                <Outlet />
            </div>
        </div>
    );
};

export default ComputeLayout;


const accounts = ["prod-payments", "prod-analytics", "staging-core", "dev-sandbox"];

export const Header = () => {
    const [selectedAccount, setSelectedAccount] = useState(accounts[0]);
    const [dropdownOpen, setDropdownOpen] = useState(false);

    return (
        <div className="w-full flex items-center justify-between mb-2 border-b border-black/20 pb-2 relative">
            <div className="flex items-center gap-4">
                <span className="text-sm text-gray-600">Accounts :</span>
                <div className="relative z-[9999]">
                    <button
                        onClick={(e) => {
                            e.stopPropagation();
                            setDropdownOpen(!dropdownOpen);
                        }}
                        className="flex items-center w-fit gap-2 px-3 py-1 rounded bg-white border border-black/10 shadow-sm shadow-white  transition-all duration-200 cursor-pointer"
                    >
                        <span className="w-2 h-2 rounded-full bg-emerald-500 shadow-sm shadow-emerald-200" />
                        <span className="text-sm font-semibold text-black">{selectedAccount}</span>
                        <ChevronDown size={14} className={`text-neutral-400 transition-transform duration-200 ${dropdownOpen ? "rotate-180" : ""}`} />
                    </button>

                    <AnimatePresence>
                        {dropdownOpen && (
                            <motion.div
                                initial={{ opacity: 0, y: -10, scale: 0.95 }}
                                animate={{ opacity: 1, y: 4, scale: 1 }}
                                exit={{ opacity: 0, y: -10, scale: 0.95 }}
                                transition={{ duration: 0.15, ease: "easeOut" }}
                                className="absolute left-0 top-full z-[9999] min-w-48 bg-white shadow-[0_10px_40px_-10px_rgba(0,0,0,0.15)] border border-black/10 rounded overflow-hidden"
                            >
                                {accounts.map((account) => (
                                    <button
                                        type="button"
                                        key={account}
                                        onClick={(e) => {
                                            e.stopPropagation();
                                            setSelectedAccount(account);
                                            setDropdownOpen(false);
                                        }}
                                        className={`w-full text-left bg-transparent border-none flex items-center justify-between px-3 py-1.5 text-sm font-semibold cursor-pointer transition-colors duration-200 focus:outline-none ${selectedAccount === account
                                            ? "bg-black text-white"
                                            : "text-neutral-600 hover:bg-neutral-50"
                                            }`}
                                    >
                                        <div className="flex items-center gap-2">
                                            <span className={`w-1.5 h-1.5 rounded-full ${selectedAccount === account ? "bg-emerald-400" : "bg-neutral-300"}`} />
                                            {account}
                                        </div>
                                        {selectedAccount === account && (
                                            <Check size={12} strokeWidth={3} />
                                        )}
                                    </button>
                                ))}
                            </motion.div>
                        )}
                    </AnimatePresence>
                </div>
                <SubPageTabs />

            </div>
        </div>
    );
};