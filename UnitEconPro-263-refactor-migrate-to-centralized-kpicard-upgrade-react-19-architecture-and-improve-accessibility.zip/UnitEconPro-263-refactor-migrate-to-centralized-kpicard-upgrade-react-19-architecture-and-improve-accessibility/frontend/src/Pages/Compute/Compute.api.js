import { apiRequest } from "../../lib/apiClient";
import { API_ENDPOINTS } from "../../APIs/ApiEndPoint";
import { buildQueryParams } from "../../lib/BuildQueryParams";

// eks
export const getComputeEKSSummary = async (filters) => {
    const query = buildQueryParams(filters)
    return apiRequest({ endpoint: `${API_ENDPOINTS.computeEKSSummary}?${query}` });
};

export const getComputeEKSClusters = async (filters) => {
    const query = buildQueryParams(filters)
    return apiRequest({ endpoint: `${API_ENDPOINTS.computeEKSClusters}?${query}` });
};

export const getComputeEKSMetadata = async (filters) => {
    const { cluster_name, ...rest } = filters;
    const query = buildQueryParams(rest);
    const encodedClusterName = encodeURIComponent(cluster_name);
    return apiRequest({ endpoint: `${API_ENDPOINTS.computeEKSMetadata(encodedClusterName)}?${query}` });
};

// ec2 
export const getComputeEC2Summary = async (filters) => {
    const query = buildQueryParams(filters)
    return apiRequest({ endpoint: `${API_ENDPOINTS.computeEC2Summary}?${query}` });
};
export const getComputeEC2Instances = async (filters) => {
    const query = buildQueryParams(filters)
    return apiRequest({ endpoint: `${API_ENDPOINTS.computeEC2Instances}?${query}` });
};
export const getComputeEC2Amis = async (filters) => {
    const query = buildQueryParams(filters)
    return apiRequest({ endpoint: `${API_ENDPOINTS.computeEC2Amis}?${query}` });
};
export const getComputeEC2Metadata = async (filters) => {
    const { instance_id, ...rest } = filters;
    const query = buildQueryParams(rest);
    const encodedInstanceId = encodeURIComponent(instance_id);
    return apiRequest({ endpoint: `${API_ENDPOINTS.computeEC2Metadata(encodedInstanceId)}?${query}` });
};
export const getComputeEC2LifecycleList = async (filters) => {
    return apiRequest({ endpoint: `${API_ENDPOINTS.computeEC2Lifecycle(filters.account, filters.instance_id)}` });
};

// ecr
export const getComputeECRSummary = async (filters) => {
    const query = buildQueryParams(filters)
    return apiRequest({ endpoint: `${API_ENDPOINTS.computeECRSummary}?${query}` });
};
export const getComputeECRRepositories = async (filters) => {
    const query = buildQueryParams(filters)
    return apiRequest({ endpoint: `${API_ENDPOINTS.computeECRRepositories}?${query}` });
};

export const getComputeECRMetadata = async (filters) => {
    const { repository_name, ...rest } = filters;
    const query = buildQueryParams(rest);
    return apiRequest({ endpoint: `${API_ENDPOINTS.computeECRMetadata(repository_name)}?${query}` });
};


//ecs
export const getComputeECSSummary = async (filters) => {
    const query = buildQueryParams(filters)
    return apiRequest({ endpoint: `${API_ENDPOINTS.computeECSSummary}?${query}` });
};
export const getComputeECSClusters = async (filters) => {
    const query = buildQueryParams(filters)
    return apiRequest({ endpoint: `${API_ENDPOINTS.computeECSCluster}?${query}` });
};
export const getComputeECSMetadata = async (filters) => {
    const { cluster_name, ...rest } = filters;
    const query = buildQueryParams(rest);
    const encodedClusterName = encodeURIComponent(cluster_name);
    return apiRequest({ endpoint: `${API_ENDPOINTS.computeECSMetadata(encodedClusterName)}?${query}` });
};

export const getComputeFinancials = async (service, accountName) => {
    return apiRequest({ endpoint: API_ENDPOINTS.analyticsFinancials(service, accountName) });
};
