import { useState, useEffect, useMemo } from "react";
import { splitSuggestionText } from "../../../lib/suggestionText";
import { AnimatePresence } from "framer-motion";
import { Filters } from "../../../common/Filters/Filter";
import PaginationControls from "../../../common/PaginationControls";
import Table from "../../../common/Table";
import CopyableCell from "../../../common/CopyableCell";
import { useS3 } from "../../../hooks/Storage/useS3";
import { Linechart } from "../../../common/Charts/LazyLinechart";
import { useUnified } from "../../../hooks/useUnified";
import { Chips } from "../../../common/Chips";
import { RoundedPieChart } from "../../../common/Charts/LazyPiechart";

import { Activity, Box, Database, DollarSign, Info } from "lucide-react";
import { CardSkeleton } from "../../../common/Cardoverview";
import { KpiCard } from "../../../components/common/KpiCard";
import S3MetadataDrawer from "./S3MetadataDrawer";
import { useSuggestions } from "../../../hooks/useSuggestions";
import { Link, useSearchParams } from "react-router-dom";
import { ForecastCardFinance } from "../../../common/MonthtoDate/LazyForecastCardFinance";

const S3_SEARCH_KEYS = ["bucket_name"];
const S3_FILTER_CONFIGS = [
    { key: "account", label: "Account" },
    { key: "region", label: "Region" }
];
// Perf: fully static, so hoisted to module scope — stronger than useMemo (one
// allocation for the app's lifetime) and matches the consts above.
const BREAKDOWN_OPTIONS = [
    { label: "Bucket", value: "bucket" },
    { label: "Region", value: "region" },
    { label: "Account", value: "account" },
    { label: "Operation", value: "operation" },
    { label: "Usage Type", value: "usage-type" },
    { label: "Pricing Model", value: "pricing-model" },
    { label: "Request Type", value: "request-type" },
    { label: "Transfer Direction", value: "transfer-direction" },
        { label: "Environment", value: "env" },
        { label: "Owner", value: "owner" },
        { label: "Project", value: "project" },
        { label: "Team", value: "team" },
        { label: "Application", value: "application" },
];

const S3 = () => {
    const [dimension, setDimension] = useState("bucket");
    const { s3Summary, s3Buckets, isLoading, isError } = useS3();
    const { suggestions: allSuggestions } = useSuggestions();
    const suggestions = (allSuggestions ?? []).filter(
        (s) => String(s.service).toLowerCase() === "s3" && s.scope === "page"
    );
    const {
        trend,
        breakdown,
        isTrendLoading,
        isBreakdownLoading,
        isTrendError,
        isBreakdownError
    } = useUnified(dimension);
    // Perf: memoized so <Table columns={...}> gets a stable prop instead of a fresh
    // array every render; the render closure only uses a module-level component.
    const columns = useMemo(() => [
        {
            key: "bucket_name",
            label: "Bucket Name",
            render: (value) => <CopyableCell value={value} />
        },
        { key: "region", label: "Region" },
        { key: "account", label: "Account" },
        { key: "total_cost", label: "Cost", sortable: true, showTotal: true },
    ], [])

    const [selectedMetadataBucket, setSelectedMetadataBucket] = useState(null);
    const [searchParams] = useSearchParams();
    useEffect(() => {
        const resource = searchParams.get("resource");
        if (resource) setSelectedMetadataBucket({ bucket_name: resource });
    }, [searchParams]);

    // Perf: memoized so <Table actions={...}> gets a stable prop; only a state
    // setter inside, so empty deps are safe.
    const actions = useMemo(() => [
        {
            label: "Metadata",
            onClick: (row) => {
                setSelectedMetadataBucket(row);
            },
            icon: () => <Info size={16} color="#059669" className="cursor-pointer" />,
            tooltip: "View Bucket Metadata"
        }
    ], []);

    const [filteredList, setFilteredList] = useState(null);
    const [currentPage, setCurrentPage] = useState(1);
    const rowsPerPage = 10;
    const safeRows = rowsPerPage || 10

    const s3BucketsData = useMemo(() => Array.isArray(s3Buckets) ? s3Buckets : [], [s3Buckets]);
    const displayData = filteredList !== null ? filteredList : s3BucketsData;

    const totalPages = Math.ceil(displayData.length / safeRows);

    const safePage = Math.max(currentPage, 1)

    const paginatedData = displayData.slice(
        (safePage - 1) * safeRows,
        safePage * safeRows
    )

    // Perf: memoized so the KPI card list keeps a stable identity between renders;
    // recomputed only when the summary data actually changes.
    const card = useMemo(() => [
        { title: "total_cost", value: s3Summary?.total_cost, icon: <DollarSign size={16} className="text-green-500" />, icon2: <DollarSign size={16} className="text-green-600" /> },
        { title: "avg_daily_cost", value: s3Summary?.avg_daily_cost, icon: <Activity size={16} className="text-green-800" />, icon2: <DollarSign size={16} className="text-green-600" /> },
        { title: "total_buckets", value: s3Summary?.total_buckets, icon: <Box size={16} className="text-indigo-500" /> },
        { title: "total_storage_gb", value: s3Summary?.total_storage_gb, icon: <Database size={16} className="text-amber-500" /> },
    ], [s3Summary])

    return (
        <div className="flex flex-col space-y-2 p-2">
            <div className="w-full">
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-2 w-full">
                    {isLoading
                        ? Array.from({ length: 5 }).map((_, i) => (
                            <CardSkeleton key={i} />
                        ))
                        : card.map((kpi) => (
                            <KpiCard key={kpi.title} kpi={kpi} />
                        ))
                    }
                    {isError && (
                        <div className="flex items-center justify-center h-full col-span-full py-10">
                            <span className="text-destructive font-semibold">Error loading data</span>
                        </div>
                    )}

                </div>
            </div>
            <div className="py-1">
                <div className="flex justify-between items-center mb-2.5">
                    <p className="text-sm font-bold uppercase text-[var(--text-primary-color)]">Suggestions</p>
                    <Link to="/recommendation">
                        <button className="text-xs font-bold text-indigo-600 hover:text-indigo-800 transition-colors cursor-pointer bg-transparent border-0 p-0">View all</button>
                    </Link>
                </div>
                {suggestions.length > 0 ? (
                    <div className="space-y-2.5">
                        {suggestions.slice(0, 1).map((item) => {
                            const { title, desc } = splitSuggestionText(item.text);
                            return (
                                <div key={item.id} className="bg-white ring-1 ring-black/10 rounded-lg p-3">
                                    <p className="text-xs font-bold text-gray-900 leading-snug">{title}</p>
                                    {desc && <p className="text-[11px] text-gray-500 mt-1 leading-relaxed whitespace-pre-line">{desc}</p>}
                                    <div className="flex items-center gap-1.5 mt-2 text-[10px] text-gray-400 font-medium">
                                        <span>By {item.created_by || "User"}</span>
                                        <span>·</span>
                                        <span>{new Date(item.created_at).toLocaleDateString()}</span>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                ) : (
                    <div className="flex flex-col items-center justify-center py-12 text-center bg-gray-100 border border-dashed border-gray-200 rounded-xl">
                        <span className="text-xs text-[var(--text-secondary-color)] font-medium">No recommendations found.</span>
                    </div>
                )}
                
            </div>
            <ForecastCardFinance category="storage" service="s3" trend={trend} isTrendLoading={isTrendLoading} />

            <Linechart 
                avgCost={s3Summary?.avg_daily_cost} 
                chartdata={trend} 
                name="cost" 
                service="AmazonS3"
                isLoading={isTrendLoading} 
                isError={isTrendError} 
            />

            <div className="w-full flex flex-col space-y-2 mb-4">
                <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wider px-1">Breakdown By</h3>
                <Chips
                    options={BREAKDOWN_OPTIONS}
                    selected={dimension}
                    onSelect={setDimension}
                />
            </div>

            <RoundedPieChart
                title={`${BREAKDOWN_OPTIONS.find(o => o.value === dimension)?.label} Breakdown`}
                dataKey="cost"
                nameKey="name"
                chartData={breakdown}
                isError={isBreakdownError}
                isLoading={isBreakdownLoading}
            />
            <div className="w-full space-y-4">
                <h3 className="text-md font-semibold ml-2 mb-3">S3 Buckets</h3>
                <Filters 
                    data={s3BucketsData} 
                    onFilter={(filtered) => {
                        setFilteredList(filtered);
                        setCurrentPage(1);
                    }} 
                    searchKeys={S3_SEARCH_KEYS}
                    filterConfigs={S3_FILTER_CONFIGS}
                    placeholder="Search by bucket name..."
                />
                <Table columns={columns} data={paginatedData} actions={actions} isLoading={isLoading} isFiltered={filteredList !== null} />
            </div>

            <PaginationControls currentPage={currentPage} totalPages={totalPages} onPageChange={setCurrentPage} />

            <AnimatePresence>
                {selectedMetadataBucket && (
                    <S3MetadataDrawer
                        key="s3-drawer"
                        bucket={selectedMetadataBucket}
                        onClose={() => setSelectedMetadataBucket(null)}
                    />
                )}
            </AnimatePresence>
        </div>
    );
};

export default S3;