import { KpiCard } from "../../../components/common/KpiCard";
import { useState, useMemo } from "react";
import { splitSuggestionText } from "../../../lib/suggestionText";
import { useEBS } from "../../../hooks/Storage/useEBS";
import PaginationControls from "../../../common/PaginationControls";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { useSuggestions } from "../../../hooks/useSuggestions";
import AddSuggestionModal from "../../../common/AddSuggestionModal";
import FinOpsFlagsContainer from "../../../common/FinOpsFlagsContainer";
import {
    X, Info, HardDrive, Tag, CheckCircle2, DollarSign,
    Activity, Pencil,
} from "lucide-react";

// ─────────────────────────────────────────────
// Design primitives
// ─────────────────────────────────────────────

const MONO = "font-mono";
const TAGS_PER_PAGE = 10;

const SectionLabel = ({ children }) => (
    <p className="text-sm font-bold uppercase text-[var(--text-primary-color)] mb-2.5">{children}</p>
);

const MetaRow = ({ label, value, mono, bold, color }) => (
    <div className="flex justify-between items-center py-1.5 border-b border-slate-200 text-xs last:border-0 gap-3">
        <span className="text-gray-500 shrink-0">{label}</span>
        <span className={`text-right break-all ${mono ? `${MONO} text-[11px] text-blue-700` : ""} ${bold ? "font-semibold" : ""} ${color || "text-gray-900"}`}>
            {value ?? "—"}
        </span>
    </div>
);



const Badge = ({ children, variant }) => {
    const cls = {
        success: "bg-emerald-50 text-emerald-800 border-emerald-200",
        warning: "bg-amber-50 text-amber-800 border-amber-200",
        danger: "bg-red-50 text-red-800 border-red-200",
        info: "bg-blue-50 text-blue-800 border-blue-200",
        purple: "bg-purple-50 text-purple-800 border-purple-200",
    }[variant] || "bg-gray-100 text-gray-700 border-gray-200";
    return (
        <span className={`inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded border ${cls}`}>
            {variant === "success" && <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block" />}
            {children}
        </span>
    );
};

// ─────────────────────────────────────────────
// FinOps Components
// ─────────────────────────────────────────────


// ─────────────────────────────────────────────
// Tab Components
// ─────────────────────────────────────────────

const OverviewTab = ({ volumeId, sizeGb, volumeType, iops, throughput, encrypted, deleteOnTermination, ageDays, data, attachedInstanceId, attachedDevice, multiAttachEnabled, availabilityZone }) => (
    <div className="space-y-6">
        <div className="grid grid-cols-1 gap-7">
            <div>
                <SectionLabel>Volume Specifications</SectionLabel>
                <MetaRow label="Volume ID" value={volumeId} mono />
                <MetaRow label="Size" value={`${sizeGb} GB`} bold />
                <MetaRow label="Volume Type" value={volumeType} />
                <MetaRow label="IOPS" value={iops !== undefined ? iops : "—"} />
                <MetaRow label="Throughput" value={throughput ? `${throughput} MB/s` : "—"} />
                <MetaRow label="Encrypted" value={encrypted ? "Yes" : "No"} color={encrypted ? "text-emerald-700 font-semibold" : "text-amber-700 font-semibold"} />
                {data.kms_key_id && <MetaRow label="KMS Key ID" value={data.kms_key_id} mono />}
                {deleteOnTermination !== undefined && (
                    <MetaRow label="Delete on Termination" value={deleteOnTermination ? "Yes" : "No"} />
                )}
                {ageDays !== undefined && ageDays !== null && ageDays !== -1 && (
                    <MetaRow label="Age" value={`${ageDays} Days`} />
                )}
            </div>
            
            <div>
                <SectionLabel>Attachments & Placement</SectionLabel>
                {attachedInstanceId && <MetaRow label="Attached Instance ID" value={attachedInstanceId} mono />}
                {attachedDevice && <MetaRow label="Device Path" value={attachedDevice} mono />}
                <MetaRow label="Multi-Attach Enabled" value={multiAttachEnabled ? "Yes" : "No"} />
                <MetaRow label="AWS Account ID" value={data.account_id} mono />
                <MetaRow label="Account Name" value={data.account_name || data.account} bold />
                <MetaRow label="Region" value={data.region} />
                {availabilityZone && <MetaRow label="Availability Zone" value={availabilityZone} />}
            </div>
        </div>
    </div>
);

const CostFinOpsTab = ({ storageCost, iopsCost, throughputCost, snapshotCost, costPerGbMonth, billedGBMonths, finopsFlags, estimatedSavings, onSuggest }) => (
    <div className="space-y-6">
        {(storageCost !== undefined || iopsCost !== undefined || throughputCost !== undefined || snapshotCost !== undefined || costPerGbMonth !== undefined) && (
            <div>
                <SectionLabel>Financial Breakdown (30d)</SectionLabel>
                {storageCost !== undefined && <MetaRow label="Storage Cost" value={`$${Number(storageCost).toFixed(4)}`} />}
                {iopsCost !== undefined && <MetaRow label="IOPS Cost" value={`$${Number(iopsCost).toFixed(4)}`} />}
                {throughputCost !== undefined && <MetaRow label="Throughput Cost" value={`$${Number(throughputCost).toFixed(4)}`} />}
                {snapshotCost !== undefined && <MetaRow label="Snapshot Cost" value={`$${Number(snapshotCost).toFixed(4)}`} />}
                {costPerGbMonth !== undefined && <MetaRow label="Cost per GB/Month" value={`$${Number(costPerGbMonth).toFixed(4)}`} />}
                {billedGBMonths !== undefined && <MetaRow label="Billed GB/Months" value={`${Number(billedGBMonths).toFixed(4)}`} />}
            </div>
        )}

        {((finopsFlags && finopsFlags.length > 0) || estimatedSavings > 0) && (
            <div>
                <SectionLabel>Optimization & Savings</SectionLabel>
                {estimatedSavings > 0 && (
                    <button
                        type="button"
                        onClick={() => onSuggest(`Estimated monthly savings: $${Number(estimatedSavings).toFixed(2)}`)}
                        title="Click to add as suggestion"
                        className="w-full text-left mb-4 bg-emerald-50 border border-emerald-200/60 rounded-lg px-4 py-3 flex items-center gap-3 cursor-pointer hover:border-emerald-400 transition-colors focus:outline-none">
                        <Activity size={18} className="text-emerald-600 shrink-0" />
                        <div>
                            <p className="text-[10px] font-bold text-emerald-800 uppercase">Estimated Monthly Savings</p>
                            <p className="text-xl font-black text-emerald-700">${Number(estimatedSavings).toFixed(2)}</p>
                        </div>
                    </button>
                )}

                <FinOpsFlagsContainer flags={finopsFlags} onSuggest={onSuggest} />
            </div>
        )}
    </div>
);

const TagsTab = ({ tagsPage, setTagsPage, tagsTotalPages, tagEntries, paginatedTags }) => (
    <div className="space-y-6">
        <div>
            <SectionLabel>Tags ({tagEntries.length})</SectionLabel>
            {paginatedTags.length > 0 ? (
                <div className="space-y-1.5">
                    {paginatedTags.map(([k, v]) => (
                        <div key={k} className="flex overflow-hidden border border-slate-200 rounded-lg">
                            <div className={`px-3.5 py-2.5 bg-white min-w-[140px] border-r border-slate-200 ${MONO} text-xs text-blue-700`}>{k}</div>
                            <div className="px-3.5 py-2.5 text-xs text-gray-900">{String(v)}</div>
                        </div>
                    ))}
                </div>
            ) : (
                <div className="text-center py-6 bg-white rounded-2xl border border-dashed border-gray-200">
                    <span className="text-xs text-gray-400">No resource tags available</span>
                </div>
            )}
            {tagEntries.length > TAGS_PER_PAGE && (
                <PaginationControls currentPage={tagsPage} totalPages={tagsTotalPages} onPageChange={setTagsPage} />
            )}
        </div>
    </div>
);


// ─────────────────────────────────────────────
// Main Drawer
// ─────────────────────────────────────────────

const TABS = [
    { id: "overview", label: "Overview", icon: Info },
    { id: "cost_finops", label: "Cost & FinOps", icon: DollarSign },
    { id: "tags", label: "Tags", icon: Tag },
];

const EBSMetadataDrawer = ({ volume, onClose }) => {
    const [activeTab, setActiveTab] = useState("overview");
    const [tagsPage, setTagsPage] = useState(1);
    const [isSugOpen, setIsSugOpen] = useState(false);
    const [sugPrefill, setSugPrefill] = useState("");
    const openSuggestion = (text = "") => {
        setSugPrefill(text);
        setIsSugOpen(true);
    };

    const { suggestions } = useSuggestions();

    const volumeId = volume?.volume_id || "";
    const { metadata, isMetadataLoading: isLoading } = useEBS(volumeId);
    
    const data = { ...volume, ...(Array.isArray(metadata) ? metadata[0] : metadata) };

    const resourceSuggestions = useMemo(() => {
        return (suggestions || []).filter(item =>
            String(item.service).toLowerCase() === "ebs" &&
            item.scope === "resource" &&
            String(item.resource_id).toLowerCase() === String(volumeId).toLowerCase()
        );
    }, [suggestions, volumeId]);

    const volumeType = data.metadata?.volume_type || data.volume_type || "";
    const sizeGb = data.metadata?.size_gb || data.size_gb || data.storage_gb || 0;
    const state = data.metadata?.state || data.state || data.status || "";
    const attachedInstanceId = data.metadata?.attached_instance_id || data.instance_id || "";
    const attachedDevice = data.metadata?.attached_device || data.device || "";
    const iops = data.metadata?.iops ?? data.iops;
    const throughput = data.metadata?.throughput ?? data.throughput_mbps ?? data.throughput;
    const encrypted = data.metadata?.encrypted ?? data.encrypted;
    const multiAttachEnabled = data.metadata?.multi_attach_enabled ?? data.multi_attach_enabled;
    const deleteOnTermination = data.metadata?.delete_on_termination ?? data.delete_on_termination;
    const snapshotCount = data.metadata?.snapshot_count ?? data.snapshot_count;
    const lastSnapshotAgeDays = data.metadata?.last_snapshot_age_days ?? data.last_snapshot_age_days;
    const ageDays = data.metadata?.age_days ?? data.age_days;
    const tags = data.metadata?.tags || data.tags;
    const availabilityZone = data.availability_zone || data.metadata?.availability_zone || "";

    const totalCost = data.financials?.total_cost_30d ?? data.total_cost ?? 0;
    const storageCost = data.financials?.storage_cost;
    const iopsCost = data.financials?.iops_cost;
    const throughputCost = data.financials?.throughput_cost;
    const snapshotCost = data.financials?.snapshot_cost;
    const costPerGbMonth = data.cost_per_gb_month;
    const billedGBMonths = data.financials?.billed_gb_months;

    const estimatedSavings = data.estimated_savings_potential ?? 0;
    const finopsFlags = data.finops_flags || [];
    const metadataLastSynced = data.metadata_last_synced || data.last_synced;

    const tagEntries = tags ? Object.entries(tags) : [];
    const tagsTotalPages = Math.max(1, Math.ceil(tagEntries.length / TAGS_PER_PAGE));
    const paginatedTags = tagEntries.slice((tagsPage - 1) * TAGS_PER_PAGE, tagsPage * TAGS_PER_PAGE);
    const [prevVolumeId, setPrevVolumeId] = useState(volumeId);
    if (volumeId !== prevVolumeId) {
        setPrevVolumeId(volumeId);
        setTagsPage(1);
        setActiveTab("overview");
    }

    if (!volume) return null;

    const getStatusVariant = (state) => {
        const s = String(state || '').toLowerCase();
        if (s === 'in-use' || s === 'attached' || s === 'available') return 'success';
        if (s === 'creating' || s === 'deleting') return 'warning';
        if (s === 'error') return 'danger';
        return 'info';
    };

    const kpis = [
        { label: "Total Cost", value: `$${Number(totalCost).toFixed(2)}`, unit: "/mo", sub: "30d trailing" },
        { label: "Capacity", value: `${sizeGb}`, unit: "GB", sub: encrypted ? "encrypted" : "unencrypted" },
        { label: "Volume Age", value: ageDays !== undefined && ageDays !== null && ageDays !== -1 ? `${ageDays}` : "—", unit: "days", sub: state },
        { label: "Snapshots", value: snapshotCount !== undefined && snapshotCount !== null ? `${snapshotCount}` : "—", unit: "", sub: lastSnapshotAgeDays !== undefined && lastSnapshotAgeDays >= 0 ? `last ${lastSnapshotAgeDays}d ago` : "no backups" },
    ];

    return (
        <>
            <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.3 }}
                className="fixed inset-0 z-[999] bg-black/20 backdrop-blur-[1px] h-full cursor-pointer" 
                onClick={onClose} 
            />
            <motion.div 
                initial={{ x: "100%" }}
                animate={{ x: 0 }}
                exit={{ x: "100%" }}
                transition={{ type: "tween", duration: 0.3 }}
                className="fixed right-0 top-0 h-screen w-[70%] max-w-full bg-white shadow-[-8px_0_32px_rgba(0,0,0,0.12)] z-[9999] border-l border-gray-100 flex flex-col"
            >
                
                {/* ── Header ── */}
                <div className="px-6 py-4 border-b border-slate-200 shrink-0 bg-white">
                    <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3.5">
                            <div className="w-9 h-9 rounded-lg bg-[#3F8624] flex items-center justify-center shrink-0 ">
                                <HardDrive size={18} className="text-white" />
                            </div>
                            <div>
                                <div className="flex items-center gap-1.5 flex-wrap mb-0.5">
                                    <span className={`${MONO} text-[13px] font-semibold text-[var(--text-primary-color)] tracking-tight`}>
                                        {volumeId}
                                    </span>
                                    {state && (
                                        <Badge variant={getStatusVariant(state)}>
                                            {state || 'Unknown'}
                                        </Badge>
                                    )}
                                </div>
                                <p className="text-xs text-[var(--text-secondary-color)]">
                                    {volumeType && <span className="font-medium text-gray-600">{volumeType}</span>}
                                    {availabilityZone && <span> · {availabilityZone}</span>}
                                </p>
                            </div>
                        </div>
                        <div className="flex items-center gap-2">
                            <motion.button
                                whileHover={{ scale: 1.02 }}
                                whileTap={{ scale: 0.98 }}
                                onClick={() => openSuggestion("")}
                                className="flex items-center justify-center gap-2 px-4 py-2 bg-[var(--button-bg)] text-white text-xs font-bold rounded-lg  hover:bg-[var(--button-bg)]/90 transition-all cursor-pointer uppercase tracking-wider shrink-0 mr-1"
                            >
                                <Pencil size={14} />
                                Add Suggestion
                            </motion.button>
                            <button
                                className="w-7 h-7 rounded border border-slate-200 flex items-center justify-center text-gray-400 hover:bg-white hover:text-gray-700 transition-colors cursor-pointer"
                                onClick={onClose}
                            >
                                <X size={14} />
                            </button>
                        </div>
                    </div>
                </div>

                {/* ── KPI strip ── */}
                {isLoading ? (
                    <div className="grid grid-cols-4 gap-2 px-6 py-3 border-b border-slate-200 shrink-0">
                        {Array.from({ length: 4 }).map((_, i) => (
                            <div key={i} className="h-14 bg-gray-100 rounded-lg animate-pulse" />
                        ))}
                    </div>
                ) : (
                    <div className="grid grid-cols-4 gap-2 px-6 py-3 border-b border-slate-200 shrink-0">
                        {kpis.map((k) => <KpiCard variant="compact" key={k.label} {...k} />)}
                    </div>
                )}

                <div className="px-6 py-1">
                    {resourceSuggestions && resourceSuggestions.length > 0 && (
                        <div className="">
                            <div className="flex justify-between items-center">
                                <SectionLabel>Suggestions</SectionLabel>
                                <Link to="/recommendation">
                                    <button className="text-xs font-bold text-indigo-600 hover:text-indigo-800 transition-colors cursor-pointer">
                                        View all
                                    </button>
                                </Link>
                            </div>
                            <div className="space-y-2.5">
                                {resourceSuggestions.slice(0, 1).map((item) => {
                                    const { title, desc } = splitSuggestionText(item.text);
                                    return (
                                        <div key={item.id} className="bg-white/50 border border-slate-200 rounded-lg p-3">
                                            <p className="text-xs font-bold text-gray-900 leading-snug">{title}</p>
                                            {desc && <p className="text-[11px] text-gray-500 mt-1 leading-relaxed whitespace-pre-line">{desc}</p>}
                                            <div className="flex items-center gap-1.5 mt-2 text-[10px] text-gray-400 font-medium">
                                                <span>By {item.created_by || "User"}</span>
                                                <span>·</span>
                                                <span>{new Date(item.created_at).toLocaleDateString()}</span>
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>
                        </div>
                    )}
                </div>

                {/* ── Tab bar ── */}
                <div className="flex border-b border-slate-200 px-6 mt-2.5 shrink-0 gap-0.5 overflow-x-auto scrollbar-none">
                    {TABS.map((t) => {
                        const Icon = t.icon;
                        const isActive = activeTab === t.id;
                        return (
                            <button
                                key={t.id}
                                onClick={() => setActiveTab(t.id)}
                                className={`flex items-center gap-1.5 px-3.5 py-2.5 text-xs whitespace-nowrap border-b-2 transition-colors cursor-pointer -mb-px ${isActive
                                    ? "border-[var(--button-bg)] font-semibold text-[var(--button-bg)]"
                                    : "border-transparent text-gray-500 hover:text-gray-900 font-normal"
                                    }`}
                            >
                                <Icon size={13} />
                                {t.label}
                                {t.id === "tags" && Object.keys(tags || {}).length > 0 && (
                                    <span className="ml-1 px-1.5 py-0.5 rounded-full text-[10px] bg-slate-100 text-[var(--text-primary-color)] font-bold">
                                        {Object.keys(tags || {}).length}
                                    </span>
                                )}
                            </button>
                        );
                    })}
                </div>

                {/* ── Tab content ── */}
                <div className="flex-1 overflow-y-auto px-6 py-5">
                    {isLoading ? (
                        <div className="flex items-center justify-center py-16">
                            <div className="w-6 h-6 border-2 border-[var(--button-bg)] border-t-transparent rounded-full animate-spin mr-3" />
                            <span className="text-sm text-gray-500">Fetching volume details...</span>
                        </div>
                    ) : (
                        <div className="pb-8">
                            {activeTab === "overview" && <OverviewTab volumeId={volumeId} sizeGb={sizeGb} volumeType={volumeType} iops={iops} throughput={throughput} encrypted={encrypted} deleteOnTermination={deleteOnTermination} ageDays={ageDays} data={data} attachedInstanceId={attachedInstanceId} attachedDevice={attachedDevice} multiAttachEnabled={multiAttachEnabled} availabilityZone={availabilityZone} />}
                            {activeTab === "cost_finops" && <CostFinOpsTab storageCost={storageCost} iopsCost={iopsCost} throughputCost={throughputCost} snapshotCost={snapshotCost} costPerGbMonth={costPerGbMonth} billedGBMonths={billedGBMonths} finopsFlags={finopsFlags} estimatedSavings={estimatedSavings} onSuggest={openSuggestion} />}
                            {activeTab === "tags" && <TagsTab tagsPage={tagsPage} setTagsPage={setTagsPage} tagsTotalPages={tagsTotalPages} tagEntries={tagEntries} paginatedTags={paginatedTags} />}

                            {/* ── Footer ── */}
                            <div className="pt-6 mt-6 border-t border-gray-100 text-center">
                                <div className="inline-flex items-center gap-2 px-3 py-1 bg-gray-100 rounded-full">
                                    <CheckCircle2 size={12} className="text-emerald-500" />
                                    <span className="text-[10px] font-medium text-gray-500 uppercase tracking-tight">
                                        Last Synced: {metadataLastSynced || "-"}
                                    </span>
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            </motion.div>
            
            <AddSuggestionModal
                isOpen={isSugOpen}
                onClose={() => setIsSugOpen(false)}
                service="ebs"
                scope="resource"
                resourceId={volumeId}
                resourceName={volumeId}
                initialText={sugPrefill}
            />
        </>
    );
};

export default EBSMetadataDrawer;


