import { useState, useEffect, useMemo } from "react";
import { splitSuggestionText } from "../../../lib/suggestionText";
import { AnimatePresence } from "framer-motion";
import { Filters } from "../../../common/Filters/Filter";
import PaginationControls from "../../../common/PaginationControls";
import Table from "../../../common/Table";
import CopyableCell from "../../../common/CopyableCell";
import { useEBS } from "../../../hooks/Storage/useEBS";
import { Linechart } from "../../../common/Charts/LazyLinechart";
import { useUnified } from "../../../hooks/useUnified";
import { Chips } from "../../../common/Chips";
import { RoundedPieChart } from "../../../common/Charts/LazyPiechart";


import { CardSkeleton } from "../../../common/Cardoverview";
import { KpiCard } from "../../../components/common/KpiCard";

const EBS_SEARCH_KEYS = ["volume_id", "volume_type"];
const EBS_FILTER_CONFIGS = [
    { key: "account", label: "Account" },
    { key: "region", label: "Region" },
    { key: "volume_type", label: "Volume Type" }
];

const SNAPSHOT_SEARCH_KEYS = ["snapshot_id"];
const SNAPSHOT_FILTER_CONFIGS = [
    { key: "account", label: "Account" },
    { key: "region", label: "Region" }
];
// Perf: fully static, so hoisted to module scope — stronger than useMemo (one
// allocation for the app's lifetime) and matches the consts above.
const BREAKDOWN_OPTIONS = [
    { label: "Volume Type", value: "volume-type" },
    { label: "Region", value: "region" },
    { label: "Account", value: "account" },
    { label: "Operation", value: "operation" },
    { label: "Product Family", value: "product-family" },
    { label: "Usage Type", value: "usage-type" },
    { label: "Pricing Model", value: "pricing-model" },
        { label: "Environment", value: "env" },
        { label: "Owner", value: "owner" },
        { label: "Project", value: "project" },
        { label: "Team", value: "team" },
        { label: "Application", value: "application" },
];
import { Activity, Box, Database, DollarSign, Info } from "lucide-react";
import EBSMetadataDrawer from "./EBSMetadataDrawer";
import { useSuggestions } from "../../../hooks/useSuggestions";
import { Link, useSearchParams } from "react-router-dom";
import { ForecastCardFinance } from "../../../common/MonthtoDate/LazyForecastCardFinance";

const EBS = () => {
    const [dimension, setDimension] = useState("region");
    const { ebsSummary, ebsVolumes, ebsSnapshots, isLoading, isError } = useEBS();
    const { suggestions: allSuggestions } = useSuggestions();
    const suggestions = (allSuggestions ?? []).filter(
        (s) => String(s.service).toLowerCase() === "ebs" && s.scope === "page"
    );
    const {
        trend,
        breakdown,
        isTrendLoading,
        isBreakdownLoading,
        isTrendError,
        isBreakdownError
    } = useUnified(dimension);

    const [selectedMetadataVolume, setSelectedMetadataVolume] = useState(null);
    const [searchParams] = useSearchParams();
    useEffect(() => {
        const resource = searchParams.get("resource");
        if (resource) setSelectedMetadataVolume({ volume_id: resource });
    }, [searchParams]);

    // Perf: memoized so <Table actions={...}> gets a stable prop instead of a fresh
    // array every render; only a state setter inside, so empty deps are safe.
    const actions = useMemo(() => [
        {
            label: "Metadata",
            onClick: (row) => {
                setSelectedMetadataVolume(row);
            },
            icon: () => <Info size={16} color="#059669" className="cursor-pointer" />,
            tooltip: "View Volume Metadata"
        }
    ], []);

    // Perf: memoized so the KPI card list keeps a stable identity between renders;
    // recomputed only when the summary data actually changes.
    const card = useMemo(() => [
        { title: "total_cost", value: ebsSummary?.total_cost, icon: <DollarSign size={16} className="text-green-500" />, icon2: <DollarSign size={16} className="text-green-600" /> },
        { title: "avg_daily_cost", value: ebsSummary?.avg_daily_cost, icon: <Activity size={16} className="text-green-800" />, icon2: <DollarSign size={16} className="text-green-600" /> },
        { title: "total_volumes", value: ebsSummary?.total_volumes, icon: <Box size={16} className="text-blue-500" /> },
        { title: "total_snapshots", value: ebsSummary?.total_snapshots, icon: <Database size={16} className="text-amber-500" /> },
        { title: "total_storage_gb", value: ebsSummary?.total_storage_gb, icon: <Box size={16} className="text-blue-500" /> },
        { title: "total_snapshot_gb", value: ebsSummary?.total_snapshot_gb, icon: <Database size={16} className="text-amber-500" /> },
    ], [ebsSummary])

    // Perf: memoized so <Table columns={...}> gets a stable prop; render closures
    // only use module-level components/pure string ops, so empty deps are safe.
    const columns = useMemo(() => [
        {
            key: "volume_id",
            label: "Volume ID",
            render: (value) => <CopyableCell value={value} />
        },
        { key: "volume_type", label: "Volume Type" },
        { key: "region", label: "Region" },
        { key: "account", label: "Account" },
        { key: "storage_gb", label: "Storage (GB)", sortable: true },
        { key: "total_cost", label: "Total Cost", sortable: true, showTotal: true },
    ], [])

    // Perf: same for the snapshots table.
    const snapshotColumns = useMemo(() => [
        {
            key: "snapshot_id",
            label: "Snapshot ID",
            render: (val) => {
                let displayVal = val;
                if (!val) return "-";
                if (typeof val === "string") {
                    const parts = val.split(/[:/]/);
                    displayVal = parts[parts.length - 1];
                }
                return <CopyableCell value={displayVal} />;
            }
        },
        { key: "region", label: "Region" },
        { key: "account", label: "Account" },
        { key: "total_cost", label: "Total Cost", sortable: true, showTotal: true },
        {
            key: "snapshot_gb", label: "Snapshot Storage (GB)", sortable: true
        }
    ], [])

    const [filteredList, setFilteredList] = useState(null);
    const [filteredSnapshotList, setFilteredSnapshotList] = useState(null);
    const [currentPage, setCurrentPage] = useState(1);
    const [snapshotCurrentPage, setSnapshotCurrentPage] = useState(1);
    const rowsPerPage = 10;
    const safeRows = rowsPerPage || 10

    const ebsVolumesData = useMemo(() => Array.isArray(ebsVolumes) ? ebsVolumes : [], [ebsVolumes]);
    const displayData = filteredList !== null ? filteredList : ebsVolumesData;

    const totalPages = Math.ceil(displayData.length / safeRows);

    const safePage = Math.max(currentPage, 1)

    const paginatedData = displayData.slice(
        (safePage - 1) * safeRows,
        safePage * safeRows
    )

    const ebsSnapshotsData = useMemo(() => Array.isArray(ebsSnapshots) ? ebsSnapshots : [], [ebsSnapshots]);
    const displaySnapshotData = filteredSnapshotList !== null ? filteredSnapshotList : ebsSnapshotsData;

    const snapshotTotalPages = Math.ceil(displaySnapshotData.length / safeRows);

    const safeSnapshotPage = Math.max(snapshotCurrentPage, 1);

    const paginatedSnapshotData = displaySnapshotData.slice(
        (safeSnapshotPage - 1) * safeRows,
        safeSnapshotPage * safeRows
    );



    return (
        <div className="flex flex-col space-y-2 p-2">
            <div className="w-full">
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-2 w-full ">
                    {isLoading
                        ? Array.from({ length: 5 }).map((_, i) => (
                            <CardSkeleton key={i} />
                        ))
                        : card.map((kpi) => (
                            <KpiCard key={kpi.title} kpi={kpi} />
                        ))
                    }
                    {isError && (
                        <div className="flex items-center justify-center h-full col-span-full py-10">
                            <span className="text-destructive font-semibold">Error loading data</span>
                        </div>
                    )}
                </div>
            </div>
            <div className="py-1">
                <div className="flex justify-between items-center mb-2.5">
                    <p className="text-sm font-bold uppercase text-[var(--text-primary-color)]">Suggestions</p>
                    <Link to="/recommendation">
                        <button className="text-xs font-bold text-indigo-600 hover:text-indigo-800 transition-colors cursor-pointer bg-transparent border-0 p-0">View all</button>
                    </Link>
                </div>
                {suggestions.length > 0 ? (
                    <div className="space-y-2.5">
                        {suggestions.slice(0, 1).map((item) => {
                            const { title, desc } = splitSuggestionText(item.text);
                            return (
                                <div key={item.id} className="bg-white ring-1 ring-black/10 rounded-lg p-3">
                                    <p className="text-xs font-bold text-gray-900 leading-snug">{title}</p>
                                    {desc && <p className="text-[11px] text-gray-500 mt-1 leading-relaxed whitespace-pre-line">{desc}</p>}
                                    <div className="flex items-center gap-1.5 mt-2 text-[10px] text-gray-400 font-medium">
                                        <span>By {item.created_by || "User"}</span>
                                        <span>·</span>
                                        <span>{new Date(item.created_at).toLocaleDateString()}</span>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                ) : (
                    <div className="flex flex-col items-center justify-center py-12 text-center bg-gray-100 border border-dashed border-gray-200 rounded-xl">
                        <span className="text-xs text-[var(--text-secondary-color)] font-medium">No recommendations found.</span>
                    </div>
                )}
            </div>
            <ForecastCardFinance category="storage" service="ebs" trend={trend} isTrendLoading={isTrendLoading} />

            <Linechart 
                avgCost={ebsSummary?.avg_daily_cost} 
                chartdata={trend} 
                name="cost" 
                service="AmazonEBS"
                isLoading={isTrendLoading} 
                isError={isTrendError} 
            />

            <div className="w-full flex flex-col space-y-2 mb-4">
                <h3 className="text-sm font-medium text-muted-foreground uppercase tracking-wider px-1">Breakdown By</h3>
                <Chips
                    options={BREAKDOWN_OPTIONS}
                    selected={dimension}
                    onSelect={setDimension}
                />
            </div>

            <RoundedPieChart
                title={`${BREAKDOWN_OPTIONS.find(o => o.value === dimension)?.label} Breakdown`}
                dataKey="cost"
                nameKey="name"
                chartData={breakdown}
                isError={isBreakdownError}
                isLoading={isBreakdownLoading}
            />
            <div className="w-full space-y-4">
                <h3 className="text-lg font-semibold mb-2">EBS Volumes</h3>
                <Filters 
                    data={ebsVolumesData} 
                    onFilter={(filtered) => {
                        setFilteredList(filtered);
                        setCurrentPage(1);
                    }} 
                    searchKeys={EBS_SEARCH_KEYS}
                    filterConfigs={EBS_FILTER_CONFIGS}
                    placeholder="Search by Volume ID, volume type..."
                />
                <Table columns={columns} data={paginatedData} actions={actions} isLoading={isLoading} isFiltered={filteredList !== null} />
            </div>
            <PaginationControls currentPage={currentPage} totalPages={totalPages} onPageChange={setCurrentPage} />

            {ebsSnapshots && ebsSnapshots.length > 0 && (
                <div className="w-full mt-8 space-y-4">
                    <h3 className="text-lg font-semibold mb-2">EBS Snapshots</h3>
                    <Filters 
                        data={ebsSnapshotsData} 
                        onFilter={(filtered) => {
                            setFilteredSnapshotList(filtered);
                            setSnapshotCurrentPage(1);
                        }} 
                        searchKeys={SNAPSHOT_SEARCH_KEYS}
                        filterConfigs={SNAPSHOT_FILTER_CONFIGS}
                        placeholder="Search by Snapshot ID..."
                    />
                    <Table columns={snapshotColumns} data={paginatedSnapshotData} isLoading={isLoading} isFiltered={filteredSnapshotList !== null} />
                </div>
            )}
            <PaginationControls currentPage={snapshotCurrentPage} totalPages={snapshotTotalPages} onPageChange={setSnapshotCurrentPage} />

            <AnimatePresence>
                {selectedMetadataVolume && (
                    <EBSMetadataDrawer
                        key="ebs-drawer"
                        volume={selectedMetadataVolume}
                        onClose={() => setSelectedMetadataVolume(null)}
                    />
                )}
            </AnimatePresence>
        </div>
    );
};

export default EBS;