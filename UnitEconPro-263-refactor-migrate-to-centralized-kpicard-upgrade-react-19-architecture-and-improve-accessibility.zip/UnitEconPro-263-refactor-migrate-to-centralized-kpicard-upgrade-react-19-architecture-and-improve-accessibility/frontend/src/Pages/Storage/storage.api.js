import { apiRequest } from "../../lib/apiClient";
import { API_ENDPOINTS } from "../../APIs/ApiEndPoint";
import { buildQueryParams } from "../../lib/BuildQueryParams";

export const getStorageSummary = async (filters) => {
  const query = buildQueryParams(filters)
  return apiRequest({ endpoint: `${API_ENDPOINTS.storageS3Summary}?${query}` });
};
export const getStorageBuckets = async (filters) => {
  const query = buildQueryParams(filters)
  return apiRequest({ endpoint: `${API_ENDPOINTS.storageS3Buckets}?${query}` });
};

export const getStorageS3Metadata = async (bucket_name, filters) => {
  const query = buildQueryParams(filters);
  return apiRequest({ endpoint: `${API_ENDPOINTS.storageS3Metadata(bucket_name)}?${query}` });
};

export const getStorageEBSSummary = async (filters) => {
  const query = buildQueryParams(filters)
  return apiRequest({ endpoint: `${API_ENDPOINTS.storageEBSSummary}?${query}` });
};


export const getStorageEBSVolumes = async (filters) => {
  const query = buildQueryParams(filters)
  return apiRequest({ endpoint: `${API_ENDPOINTS.storageEBSVolumes}?${query}` });
};

export const getStorageEBSSnapshots = async (filters) => {
  const query = buildQueryParams(filters)
  return apiRequest({ endpoint: `${API_ENDPOINTS.storageEBSSnapshots}?${query}` });
};

export const getStorageEBSMetadata = async (volume_id, filters) => {
  const query = buildQueryParams(filters);
  return apiRequest({ endpoint: `${API_ENDPOINTS.storageEBSMetadata(volume_id)}?${query}` });
};

export const getStorageFinancials = async (service, accountName) => {
  return apiRequest({ endpoint: API_ENDPOINTS.analyticsFinancials(service, accountName) });
};
