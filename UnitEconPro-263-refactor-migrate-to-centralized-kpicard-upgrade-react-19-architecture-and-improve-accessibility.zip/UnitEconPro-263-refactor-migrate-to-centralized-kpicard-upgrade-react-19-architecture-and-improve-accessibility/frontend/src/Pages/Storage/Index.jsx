import { Outlet } from "react-router-dom";
import SubPageTabs from "../../common/SubPageTabs";

const Storage = () => {
    return (
        <div className="w-full min-h-screen space-y-2 px-6 py-2">
            <title>Storage | SpendSmart</title>
            <meta name="description" content="Manage and optimize your cloud storage resources." />
            <SubPageTabs />
            <div className="mb-4 mt-4">
                <Outlet />
            </div>
        </div>
    );
};

export default Storage;