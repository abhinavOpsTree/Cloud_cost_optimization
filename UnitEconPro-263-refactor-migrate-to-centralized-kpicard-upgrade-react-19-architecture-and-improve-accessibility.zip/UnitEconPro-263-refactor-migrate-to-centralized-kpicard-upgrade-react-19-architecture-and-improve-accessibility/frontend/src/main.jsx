import { StrictMode, Suspense } from 'react'
import { createRoot } from 'react-dom/client'
import { ToastContainer, toast } from 'react-toastify'
import 'react-toastify/dist/ReactToastify.css'
import App from './App.jsx'
import './index.css'
import { ThemeProvider } from './lib/ThemeProvider.jsx'
import { AuthProvider } from './providers/AuthProvider.jsx'
import { QueryProvider } from './providers/QueryProvider.jsx'
import { SettingsProvider } from './providers/SettingsProvider.jsx'
import { FiltersProvider } from './providers/Filtercontext.jsx'
import ErrorBoundary from './common/ErrorBoundary.jsx'

createRoot(document.getElementById('root'), {
  onCaughtError: (error, errorInfo) => {
    console.error('Caught rendering error:', error, errorInfo);
    toast.error(error.message ? `Caught error: ${error.message}` : 'A rendering error was caught');
  },
  onUncaughtError: (error, errorInfo) => {
    console.error('Uncaught rendering error:', error, errorInfo);
    toast.error(error.message ? `Uncaught error: ${error.message}` : 'An uncaught rendering error occurred');
  },
  onRecoverableError: (error, errorInfo) => {
    console.error('Recoverable rendering error:', error, errorInfo);
    toast.warning(error.message ? `Recoverable error: ${error.message}` : 'A recoverable rendering error occurred');
  }
}).render(
  <StrictMode>
    <ToastContainer
      position="bottom-right"
      autoClose={2000}
      hideProgressBar={false}
      newestOnTop={false}
      closeOnClick
      pauseOnFocusLoss
      draggable
      pauseOnHover
      theme="light"
    />
    <ErrorBoundary>
      <ThemeProvider>
        <QueryProvider>
          <Suspense fallback={<div className="w-screen h-screen flex items-center justify-center font-medium text-neutral-500">Loading authentication...</div>}>
            <AuthProvider>
              <SettingsProvider>
                <FiltersProvider>
                  <App />
                </FiltersProvider>
              </SettingsProvider>
            </AuthProvider>
          </Suspense>
        </QueryProvider>
      </ThemeProvider>
    </ErrorBoundary>
  </StrictMode>,
)
