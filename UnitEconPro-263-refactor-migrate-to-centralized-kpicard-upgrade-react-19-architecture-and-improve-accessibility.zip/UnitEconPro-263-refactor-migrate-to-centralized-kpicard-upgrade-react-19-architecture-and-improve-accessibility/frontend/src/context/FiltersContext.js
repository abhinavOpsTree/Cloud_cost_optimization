import { createContext } from 'react';
import dayjs from 'dayjs';

export const getDefaultStartDate = () => dayjs().subtract(30, 'day').format('YYYY-MM-DD');
export const getDefaultEndDate = () => dayjs().subtract(1, 'day').format('YYYY-MM-DD');

export const FiltersContext = createContext({
    start_date: null,
    end_date: null,
    compare_date_a: null,
    compare_date_b: null,
    account: "All",
    service: "All"
});
