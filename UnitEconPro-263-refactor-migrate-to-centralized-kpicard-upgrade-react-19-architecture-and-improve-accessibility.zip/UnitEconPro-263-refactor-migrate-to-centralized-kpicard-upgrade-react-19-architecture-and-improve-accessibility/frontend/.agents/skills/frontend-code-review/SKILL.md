---
name: frontend-code-review
description: Use this skill whenever auditing, reviewing, or assessing frontend code built in HTML, CSS, JavaScript, or React 19 — an existing codebase, a specific file, or a pull request/diff. Trigger this any time the user mentions "review my frontend," "audit this React app," "is this production-ready," "best practices check," "security check," "accessibility check," or uploads/points at .jsx, .tsx, .html, .css files for evaluation. This skill is for auditing existing code only — not for generating new frontend code from scratch.
---

# Frontend Quality Auditor (HTML / CSS / JS / React 19)

A comprehensive checklist-driven skill for auditing frontend code. Given existing code — a file, a folder, a whole repo, or a diff — it scans against best-practice, architecture, and security checklists and produces a severity-ranked, prioritized report.

## How to use this skill

1. **Establish scope.** What was actually provided — one file, a folder, a full repo, a specific PR/diff? Note this up front; it determines both how deep you can go and what to say you *couldn't* check (e.g. "I can't run `npm audit` without execution access — here's what to run yourself").
2. **Detect the surface area.** Not every project touches every category (a static marketing page has no auth tokens to check; a form-heavy dashboard does). Skim the codebase first, then only pull in the reference files that are relevant — don't force irrelevant checks into the report.
3. **Learn the project's own conventions before flagging deviations.** If the codebase consistently does something one way (e.g. always uses a particular styling approach, always uses a specific error-handling wrapper), treat deviations *from the project's own pattern* as real findings, and don't flag the project's chosen convention itself just because a different valid approach exists elsewhere in this skill's checklists.
4. **Load the relevant reference file(s)** from `references/` (see table below) rather than trying to hold every rule in working memory at once. Each file is self-contained with the "why," the "what to check," and concrete code examples of good vs. bad.
5. **Verify before flagging** (see "Avoiding false positives" below) — don't report an issue you haven't actually traced through the code.
6. **For anything beyond a handful of files**, follow "Auditing at scale" below before writing the report.
7. **Produce the report** using the format in "Report format" below.

## Avoiding false positives

A wrong finding costs more trust than a missed one. Before listing anything as an issue:
- If flagging a missing sanitization/validation step, check whether it happens elsewhere in the call chain (a parent component, a shared wrapper, a server-side layer visible in the codebase) before assuming it's absent.
- If flagging something as "should use X pattern instead," confirm X is actually available in this codebase's stated dependencies/React version — don't recommend a React 19 API in a codebase pinned to React 18.
- If unable to verify something with certainty (e.g. whether a security header is set at the infra/server level, which frontend code alone won't show), say so explicitly rather than assuming it's missing. Mark these as **"Unverified — check separately"** rather than folding them into a severity bucket.
- Don't repeat the same underlying issue as five separate findings just because it appears in five files — group repeated instances of one root cause into a single finding with a file list.

## Reference files — load only what's relevant

| File | Covers | Load when... |
|---|---|---|
| `references/html-accessibility.md` | Semantic HTML, ARIA, keyboard nav, WCAG basics, SEO meta | Any `.html`/JSX markup is involved (almost always) |
| `references/css-practices.md` | Responsiveness, maintainability, naming, specificity | Any styling exists (CSS/Tailwind/CSS-in-JS) |
| `references/javascript-quality.md` | Core JS correctness, error handling, async patterns, strict TypeScript typing, general hygiene | Any `.js`/`.ts` logic |
| `references/react19-practices.md` | React 19-specific: `ref` as prop, Context as direct element, `use()`, hooks rules, rendering performance, keys | Any React component code |
| `references/architecture-patterns.md` | Folder structure/separation of concerns, Server vs. Client Component boundaries (RSC) | Reviewing overall project structure, or any Next.js/Remix-style RSC codebase |
| `references/state-data-fetching.md` | State classification (local/global/server-cache), `use()` for promises, centralized HTTP layer with retries/circuit-breaking | Any component managing state or fetching data |
| `references/forms-actions.md` | `useTransition`, `useActionState`, `useFormStatus`, `useOptimistic` — React 19's Actions model | Any form or async user-triggered action |
| `references/error-handling-telemetry.md` | Root-level error handlers (`createRoot` options), Error Boundaries, telemetry hygiene | Any production-bound app, or when error handling/monitoring is in scope |
| `references/metadata-preloading.md` | Document `<title>`/`<meta>` hoisting, `preconnect`/`preload`/`preinit` resource hints | Public/SEO-facing pages, or performance-critical asset loading |
| `references/testing-strategies.md` | React Testing Library patterns, testing async Actions, MSW network mocking, coverage calibration | Reviewing or writing tests |
| `references/security-deep.md` | XSS, CSP/HSTS headers, CORS, auth token storage, secrets, dependency CVEs, input validation, injection | Always load — security should be checked in every audit |
| `references/performance-build.md` | React Compiler readiness, bundle size, code-splitting, image optimization, Core Web Vitals, lint/format/test tooling | Load when reviewing production-readiness or when the project is beyond a single prototype page |

## Severity levels (use consistently)

- 🔴 **Critical** — security vulnerability, data leak, or broken-for-users bug. Fix before shipping.
- 🟠 **High** — violates core best practice with real user/business impact (broken keyboard nav, missing input validation, N+1 re-renders on a large list).
- 🟡 **Medium** — maintainability or performance debt that will hurt later but isn't urgent.
- 🟢 **Low / polish** — nice-to-have, style consistency, minor a11y gaps.

## Auditing at scale (more than a handful of files)

Reading every line of a large repo isn't feasible or the best use of the review. Prioritize by risk, not by file order:

1. **Start with the highest-stakes surfaces first**: authentication/login flows, payment or checkout code, anywhere user input is rendered back to the page, anywhere API keys/tokens are handled, and anything public-facing (SEO/marketing pages). Bugs here matter more than bugs in an internal admin-only debug panel.
2. **Check config and dependency files before diving into components**: `package.json` (dependency versions, known-old majors), `.eslintrc*`/`eslint.config.*` (is linting even configured), `tsconfig.json` (is `strict` on), any CSP/security header config, `.env.example` vs. what's actually referenced in code. These single files reveal systemic issues faster than reading component-by-component.
3. **Grep before you read**: use the "Quick verification approach" sections at the bottom of each reference file (they contain concrete search patterns like `dangerouslySetInnerHTML`, `useEffect.*fetch`, `forwardRef`) to find candidate files fast, then read only those in full rather than every file in the repo.
4. **Sample the rest**: for a large, fairly uniform codebase (e.g. 40 similar CRUD components), deeply review 2-3 representative ones rather than all 40, then state explicitly in the report that findings were extrapolated from a sample and name which files were actually inspected.
5. **If scope is still too large for a thorough pass**, say so directly and ask whether to focus on a specific area (e.g. "just the auth flow" or "just this PR's diff") rather than silently producing a shallow pass over everything and presenting it as complete.

## Report format

```
## Frontend Quality Report

### Scope
[What was reviewed: files/folders, and how — full read vs. sampled. Note anything explicitly out of reach, e.g. "couldn't run npm audit — no execution access."]

### Summary
[1-3 sentence overall verdict + counts per severity]

### Scorecard
| Category | Verdict |
|---|---|
| Accessibility | 🔴/🟠/🟡/🟢 |
| Security | ... |
| React/Architecture patterns | ... |
| Performance | ... |
| Code quality & tooling | ... |
[Only include rows for categories actually reviewed]

### Fix this first (top priority)
[The 1-4 findings that matter most — usually the highest severity items, or lower-severity items that are trivial to fix and worth doing immediately. This section exists so a busy reader gets value without reading the full report.]

### 🔴 Critical
- [Issue] — [file:line if known] — [why it matters] — [concrete fix]

### 🟠 High
...

### 🟡 Medium
...

### 🟢 Low
...

### Unverified — check separately
[Anything that couldn't be confirmed from the code alone, e.g. server-level headers, infra config, whether a dependency audit is clean]

### What's already done well
[Don't skip this — call out good patterns you saw, it calibrates trust in the report]
```

Never mark something as an issue just to pad the report — if a category is genuinely fine, say so briefly instead of inventing nitpicks. Never inflate the scorecard or omit the "already done well" section either — the report is only useful if it's calibrated in both directions.
