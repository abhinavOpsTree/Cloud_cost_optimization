# Testing Strategies Checklist (React 19)

## Testing Library philosophy
- [ ] Component tests query the DOM the way a user/screen-reader would — `getByRole`, `findByText`, `getByLabelText` — rather than reaching into implementation details like CSS class names or component internals (`container.querySelector('.foo')`). Tests coupled to class names break on every unrelated style refactor.
- [ ] Tests assert on visible behavior/output ("clicking submit shows a success message") rather than internal state ("component's `isPending` state becomes false") — the former survives refactors, the latter doesn't.

## Async Actions & transitions in tests
- [ ] Interactions that trigger React 19 transitions/actions are awaited properly: `await userEvent.click(button)` (from `@testing-library/user-event`, which already wraps interactions in `act()` and handles async updates) rather than a raw `fireEvent.click` followed by an unguarded assertion that can race the pending state.
- [ ] Tests wait for the resulting UI change with `findBy*` queries (which retry until found) instead of asserting immediately after a click when the update is asynchronous (a common source of flaky tests).

## Mocking network requests
- [ ] API calls in tests are mocked at the network boundary using **Mock Service Worker (MSW)** (or equivalent) rather than mocking `fetch`/axios module internals directly — network-level mocking exercises the real request code path and is far less brittle than replacing the HTTP client itself.
- [ ] Check for the anti-pattern of manually reassigning `global.fetch = jest.fn(...)` scattered per test file — a shared MSW handler setup is more maintainable and realistic.

## Coverage expectations (calibrate to project stage)
- [ ] Critical user flows (auth, checkout, form submission, anything with business/financial consequences) have at least one test covering the happy path and one covering a failure path.
- [ ] Pure utility/business-logic functions (formatters, calculators, validators) have unit tests — these are cheap to test and catch regressions early.
- [ ] Don't expect (or demand) 100% coverage on a small project or POC — flag missing tests on critical flows as 🟠/🔴 depending on stakes, and treat missing tests on trivial presentational components as low priority at most.

## Verification approach
- Search test files for `fireEvent` usage without a following `await`/`findBy*` — a common flakiness source with React 19's async transitions.
- Check if a `mocks/` or `msw` setup exists, versus scattered manual `jest.mock('axios')`-style mocking throughout individual test files.