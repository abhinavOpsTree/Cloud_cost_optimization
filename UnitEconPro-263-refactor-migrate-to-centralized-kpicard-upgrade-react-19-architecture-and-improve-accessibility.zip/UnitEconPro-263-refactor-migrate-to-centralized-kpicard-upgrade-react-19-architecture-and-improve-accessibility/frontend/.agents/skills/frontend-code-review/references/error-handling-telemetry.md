# Global Error Handling & Telemetry Checklist

## Root-level error reporting
- [ ] `createRoot` is configured with `onCaughtError`, `onUncaughtError`, and `onRecoverableError` handlers to route rendering exceptions to a telemetry/error-tracking service (Sentry, Datadog, Faro, or equivalent) — not just left to the browser's default console output.
- [ ] These handlers actually forward to a real telemetry SDK in production builds, not just `console.error` (console-only "handling" is equivalent to having none once the app ships, since nobody's watching the browser console of a real user).

```jsx
const root = createRoot(document.getElementById('root'), {
  onCaughtError(error, errorInfo) {
    telemetry.captureException(error, { extra: errorInfo });
  },
  onUncaughtError(error, errorInfo) {
    telemetry.captureException(error);
  },
  onRecoverableError(error, errorInfo) {
    console.warn('Recoverable error:', error, errorInfo);
  }
});
```

## Declarative Error Boundaries
- [ ] At least one Error Boundary wraps the app at a high level so a crash in one component doesn't blank the entire page.
- [ ] For larger apps, Error Boundaries are placed around **route/feature-level** sections too, not just one at the very top — this way a crash in one widget/feature doesn't take down unrelated parts of the same page.
- [ ] Each boundary's fallback UI is actually useful (a clear "something went wrong, try again" state with a retry action where feasible) — not a blank div or a raw stack trace shown to end users.
- [ ] Error Boundaries only catch **rendering** errors — check that async errors (inside event handlers, `useEffect`, promises) are still separately handled with try/catch, since a boundary alone won't catch those.

## Telemetry hygiene (cross-check with security)
- [ ] Error payloads sent to telemetry don't accidentally include sensitive data — auth tokens, full request bodies with PII, or password fields captured in a form-state dump. Scrub/allowlist what's sent rather than forwarding raw state objects.
- [ ] Telemetry/error tracking is only active in environments where it should be (e.g. not spamming a third-party service with every local dev error, and not silently disabled in production either).

## Verification approach
- Check the app's entry file (`main.jsx`/`index.jsx`/root layout) for `createRoot` options and confirm handlers exist and forward somewhere real.
- Search for `<ErrorBoundary` usage and check it's not just a single wrapper around the entire app with no finer granularity for a large/complex app.