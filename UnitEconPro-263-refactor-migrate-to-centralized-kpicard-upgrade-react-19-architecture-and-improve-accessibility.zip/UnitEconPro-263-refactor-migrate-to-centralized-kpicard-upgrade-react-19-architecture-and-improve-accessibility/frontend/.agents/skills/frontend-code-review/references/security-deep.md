# Frontend Security Checklist (Deep)

Always load this file in Audit mode. In Build mode, load it whenever the app has forms, authentication, API calls, or renders any user-generated / external content.

## 1. Cross-Site Scripting (XSS)
- [ ] No use of `dangerouslySetInnerHTML` (React) or raw `innerHTML`/`outerHTML` (vanilla JS) with any value that originates from user input, a URL param, or an external API — unless it's passed through a sanitizer (e.g. DOMPurify) first.
- [ ] No use of `eval()`, `new Function()`, or `setTimeout("string code")` — these execute arbitrary strings as code and are almost never actually necessary.
- [ ] URLs used in `href`/`src` that come from user input are validated (block `javascript:` scheme URLs, which is a classic injection vector via a seemingly-innocent link field).
- [ ] Any markdown/rich-text rendering (e.g. rendering user comments) goes through a sanitizing renderer, not a raw HTML dump.

**Bad:**
```jsx
<div dangerouslySetInnerHTML={{ __html: comment.text }} />
```
**Good:**
```jsx
import DOMPurify from 'dompurify';
<div dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(comment.text) }} />
```

## 2. Secrets & sensitive data
- [ ] No API keys, database credentials, or private tokens hardcoded anywhere in frontend source — anything shipped to the browser is fully visible via view-source/devtools, regardless of minification. Only genuinely public keys (e.g. a publishable Stripe key, a public map API key restricted by domain) belong in frontend code.
- [ ] Environment variables exposed to the frontend build (e.g. Vite's `VITE_*`, Next.js `NEXT_PUBLIC_*`) are double-checked — anything with that prefix is bundled into the public JS and is not actually secret.
- [ ] Sensitive business logic (pricing rules, permission checks, validation that matters) is enforced server-side, not just in the frontend — client-side checks are a UX convenience, never a security boundary, since anyone can bypass frontend JS entirely.

## 3. Authentication token storage
- [ ] Auth tokens (JWTs, session tokens) are **not** stored in `localStorage` or `sessionStorage` if avoidable — both are readable by any JS running on the page, so a single XSS bug anywhere in the app becomes full account takeover. Prefer `httpOnly` cookies (set by the server) which JS cannot read at all.
- [ ] If a token must live in memory/JS-accessible storage (e.g. for architectural reasons), the app has strong XSS defenses elsewhere (CSP, sanitization) to compensate, and token lifetime is kept short with refresh handled server-side.
- [ ] Tokens are never logged to the console or sent to third-party analytics/error-tracking tools by accident (check error boundary / Sentry-style integrations for accidental payload leakage).
- [ ] Logout actually clears all stored tokens/session state client-side, not just redirects.

## 4. CSRF & cookies
- [ ] If using cookie-based auth, cookies are set with `SameSite=Lax` or `Strict` (mitigates CSRF) and `Secure` (HTTPS-only transmission).
- [ ] State-changing requests (POST/PUT/DELETE) from cookie-authenticated sessions are protected by a CSRF token or rely on `SameSite` cookies — don't assume cookies alone are safe without checking `SameSite`.

## 5. Content Security Policy (CSP)
- [ ] A CSP header (or `<meta http-equiv="Content-Security-Policy">`) is present in production, at minimum restricting `script-src` to trusted origins and disallowing `unsafe-inline`/`unsafe-eval` where feasible.
- [ ] Third-party scripts (analytics, ads, widgets) are limited to what's actually needed — every added third-party script is an added trust boundary and potential supply-chain risk.
- [ ] `X-Content-Type-Options: nosniff` and `X-Frame-Options: DENY`/`SAMEORIGIN` (or CSP `frame-ancestors`) are set to prevent MIME-sniffing attacks and clickjacking respectively.
- [ ] `Strict-Transport-Security` (HSTS) is set in production to force browsers to only ever connect over HTTPS for the domain, even if a user types or follows an `http://` link.

## 6. CORS
- [ ] Backend CORS configuration (if Claude can see it / if asked to review full-stack) doesn't use a wildcard `Access-Control-Allow-Origin: *` combined with `Access-Control-Allow-Credentials: true` — that combination is invalid/dangerous and browsers reject it, but a misconfigured reflect-any-origin setup achieves the same unsafe effect and should be flagged.
- [ ] Frontend only calls APIs over HTTPS in production; no mixed content (HTTPS page fetching an HTTP resource).

## 7. Input validation
- [ ] All user input is validated for type/format/length on the client (for UX) **and** treated as untrusted, re-validated on the server (client validation is never sufficient alone — mention this even if the server isn't in scope for the current review).
- [ ] File upload inputs (if any) restrict accepted file types/size on the client as a first pass, understanding this must be re-enforced server-side.

## 8. Dependency & supply-chain hygiene
- [ ] `npm audit` (or `pnpm audit`/`yarn audit`) run and no unresolved high/critical vulnerabilities in production dependencies.
- [ ] Dependencies are reasonably up to date — a `package.json` with major versions years out of date is itself a signal worth flagging even without a specific known CVE.
- [ ] No suspicious or unmaintained packages pulled in for trivial functionality (e.g. a whole library for a one-line utility) — each dependency is a piece of code running with full access to the app.

## 9. General hardening
- [ ] `.env` files and other local secret files are in `.gitignore` and not committed to version control (check git history too, not just current state, if reviewing a real repo).
- [ ] Source maps are not deployed to production publicly if the codebase contains anything sensitive in comments/logic (source maps can reconstruct readable source from minified bundles).

## Quick verification approach
- Search the codebase for: `dangerouslySetInnerHTML`, `innerHTML`, `eval(`, `localStorage`, `document.cookie`, hardcoded strings that look like API keys (`sk_`, `AKIA`, long hex/base64 strings assigned to a const).
- Check `package.json` for outdated major versions and run an audit command if you have execution access.
- Ask what auth mechanism is used (cookies vs. bearer tokens) early — several checks above depend on that answer.