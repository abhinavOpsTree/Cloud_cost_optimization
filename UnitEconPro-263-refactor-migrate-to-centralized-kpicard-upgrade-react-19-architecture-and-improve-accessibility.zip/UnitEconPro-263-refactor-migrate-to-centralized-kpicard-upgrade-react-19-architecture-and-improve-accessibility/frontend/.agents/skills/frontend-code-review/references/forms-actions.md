# Forms, Actions & Optimistic UI Checklist (React 19)

React 19's Actions model replaces a lot of hand-rolled pending/error `useState` boilerplate. This is one of the highest-value things to check in any React 19 codebase, since old-style patterns are the clearest sign code hasn't been updated to current idioms.

## `useTransition` for async operations outside forms
- [ ] Any button/action that triggers an async operation (not a form submission specifically) and needs a pending/loading indicator uses `useTransition` instead of a manual `const [isLoading, setIsLoading] = useState(false)` wrapped around manual try/finally toggling.

```jsx
const [isPending, startTransition] = useTransition();
const handlePublish = () => startTransition(async () => { await onPublish(id); });
// <button disabled={isPending}>{isPending ? 'Publishing...' : 'Publish'}</button>
```

- [ ] Check for the anti-pattern: manually setting a loading boolean to `true`, awaiting, then setting it back to `false` in a `finally` — this is exactly what `useTransition` replaces.

## Form Actions & `useActionState`
- [ ] Forms use the native `<form action={formAction}>` pattern combined with `useActionState`, rather than `onSubmit={handleSubmit}` + manual `preventDefault()` + manual state juggling for success/error/pending.
- [ ] The action function itself (`async (prevState, formData) => {...}`) returns a consistent shape (e.g. `{ success, data, error }`) that the component then reads from `state` — not scattered separate state variables for each possible outcome.
- [ ] Validation errors from the server are surfaced through this returned state and rendered next to the relevant field, not just alerted or console-logged.

```jsx
async function submitFormAction(prevState, formData) {
  try {
    const username = formData.get('username');
    const response = await registerUser({ username });
    return { success: true, data: response };
  } catch (error) {
    return { success: false, error: error.message };
  }
}
const [state, formAction, isPending] = useActionState(submitFormAction, null);
```

## `useFormStatus` for deep children
- [ ] Submit buttons or status indicators nested inside a `<form>` read pending state via `useFormStatus()` instead of receiving it through prop drilling from the parent form component.
- [ ] `useFormStatus` is only called from a component that is actually a **child** of the `<form>` — calling it in the same component that renders the `<form>` itself won't work (a common mistake) since it reads context from an ancestor form.

## `useOptimistic` for instant UI feedback
- [ ] Actions where instant feedback matters for perceived speed (toggling a checkbox, liking a post, adding a comment/message) use `useOptimistic` rather than manually mutating local state and writing custom rollback logic on failure.
- [ ] The optimistic update function is a pure reducer-style function `(state, optimisticValue) => newState` — it shouldn't perform side effects itself.
- [ ] The actual mutation (the real API call) still happens and is awaited — `useOptimistic` only handles the *visual* update; check that a real request follows, and that a genuine failure path exists (React automatically reverts optimistic state if the surrounding action rejects, but only if the action is structured to actually throw/reject on failure).

```jsx
const [optimisticTasks, setOptimisticTasks] = useOptimistic(
  initialTasks,
  (state, taskId) => state.map(t => t.id === taskId ? { ...t, completed: !t.completed } : t)
);
const handleToggle = async (taskId) => {
  setOptimisticTasks(taskId);
  await onToggleTask(taskId); // if this throws, React rolls back automatically
};
```

## Verification approach
- Search for `preventDefault()` inside form submit handlers — a strong signal the form predates the Actions model and could be modernized.
- Search for manual `isSubmitting`/`isLoading` state paired with try/catch/finally around an async call — same signal for `useTransition`/`useActionState` opportunities.
- Search for optimistic-looking code (updating local state immediately before an await, with a manual catch block that reverts it) — flag as a `useOptimistic` opportunity.