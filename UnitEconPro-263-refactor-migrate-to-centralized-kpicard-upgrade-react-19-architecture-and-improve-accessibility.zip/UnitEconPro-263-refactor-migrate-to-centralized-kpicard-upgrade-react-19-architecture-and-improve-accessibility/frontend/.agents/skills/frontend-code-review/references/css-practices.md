# CSS Best Practices Checklist

## Responsiveness
- [ ] Layout adapts across at least mobile (~375px), tablet (~768px), and desktop (~1280px+) widths — uses media queries or a responsive grid/flex system, not a fixed pixel-width container.
- [ ] Uses relative units (`rem`, `%`, `fr`, `vw`/`vh` where appropriate) for sizing/spacing instead of hardcoded `px` everywhere, especially for font sizes (respects user's browser zoom/font settings).
- [ ] Images/media use `max-width: 100%` (or equivalent) so they don't overflow their container on small screens.
- [ ] Touch targets (buttons, links on mobile) are at least ~44x44px — small tap targets are a common mobile usability failure.

## Maintainability
- [ ] Consistent styling approach across the codebase (pick one: CSS Modules, Tailwind, styled-components/CSS-in-JS, or plain CSS with a naming convention like BEM) — mixing multiple approaches inconsistently is a red flag.
- [ ] No excessive use of `!important` — it usually signals a specificity fight rather than a real necessity. A handful of justified uses (e.g. utility overrides) is fine; sprinkled everywhere is not.
- [ ] Selectors aren't overly deep/nested (e.g. `.a .b .c .d span` is fragile and hard to override). Prefer flatter, component-scoped selectors.
- [ ] Design tokens/variables (CSS custom properties or a theme file) used for colors, spacing, and font sizes rather than repeated magic numbers/hex codes scattered through the codebase.

## Layout technique sanity checks
- [ ] Flexbox/Grid used for layout instead of legacy float-based layouts or absolute-positioning hacks for things that aren't actually meant to overlay.
- [ ] No fixed heights on containers that hold dynamic/variable-length content (causes overflow or clipping when content grows).

## Common visual bugs to check for
- [ ] Text contrast against background meets at least WCAG AA (4.5:1 for normal text, 3:1 for large text) — this is both an accessibility and a CSS concern.
- [ ] Dark mode (if supported) doesn't leave any hardcoded light-only colors that break readability.
- [ ] `overflow` is handled intentionally on scrollable containers (no unexpected horizontal scrollbars from an unconstrained child).

## Quick verification approach
- Resize the viewport from 320px to 1920px mentally (or actually, if you can render it) and check nothing breaks or overlaps.
- Search the codebase for `!important` and inline `style={{...}}` usage as a quick smell test for how disciplined the styling approach is.