# Performance & Build Tooling Checklist

## React Compiler ("Forget") readiness
- [ ] Component functions are kept pure and idiomatic (no mutating props/state directly, no relying on render order side effects) — the React Compiler auto-memoizes components and hooks, but only if the code is written in a way it can safely analyze.
- [ ] `useMemo`/`useCallback` aren't spammed reflexively around trivial values/inline functions — with the compiler handling routine memoization automatically, manual memoization should be reserved for genuinely expensive computations (verified by profiling, not guessed). Excess manual memoization adds complexity without benefit once the compiler is in play, and can occasionally fight with it.
- [ ] If the project has the compiler enabled, `eslint-plugin-react-compiler` is part of the lint setup to catch patterns the compiler can't safely optimize.

## Bundle size & code-splitting
- [ ] Routes/large feature areas are code-split with `React.lazy` + `Suspense` (or the framework's built-in route-based splitting) rather than one giant bundle shipped for the whole app on first load.
- [ ] Large third-party libraries are checked for lighter alternatives where the full library isn't needed (e.g. importing all of `lodash` vs. importing individual functions, importing a whole date library for one format call).
- [ ] Unused imports/exports and dead code are removed — tree-shaking only helps if the code is actually structured to allow it (avoid `import * as X`-style barrel imports of huge libraries where possible).

## Images & media
- [ ] Images use modern formats (WebP/AVIF) with fallbacks where broad support matters, and are appropriately sized/compressed for their display size (not a 4000px source image displayed in a 200px box).
- [ ] Below-the-fold images use `loading="lazy"`.
- [ ] `width`/`height` attributes (or aspect-ratio CSS) are set on images/embeds so the browser can reserve space and avoid layout shift while they load.

## Core Web Vitals awareness
- [ ] **LCP** (Largest Contentful Paint): the main hero image/text isn't blocked behind unnecessary JS execution or slow font loading.
- [ ] **CLS** (Cumulative Layout Shift): no content injecting above existing content after load (ads, late-loading banners) without reserved space; fonts use `font-display: swap` or are preloaded to avoid a flash-of-invisible-text shift.
- [ ] **INP** (Interaction to Next Paint): expensive synchronous work on the main thread during user interactions (typing, clicking) is broken up or deferred so the UI doesn't feel frozen.

## Network
- [ ] API calls aren't duplicated unnecessarily (e.g. the same data fetched independently by multiple sibling components instead of being fetched once and shared/cached — React Query, SWR, or simple lifting of state helps here).
- [ ] Static assets are served with appropriate caching headers in production (not strictly frontend code, but worth flagging if visible in config).

## Tooling signals for a "properly built" project
- [ ] Linting configured (ESLint) and clean.
- [ ] Formatting configured (Prettier or equivalent) and consistent.
- [ ] At least some automated tests exist for non-trivial logic (unit tests for utility functions, component tests for critical flows) — doesn't need to be exhaustive, but zero tests on a production app is a flag worth raising.
- [ ] A build step exists and succeeds cleanly (no warnings being ignored, no `// @ts-ignore` sprinkled to silence real type errors).
- [ ] Environment-specific config (dev/staging/prod) is handled via env vars, not hardcoded URLs that need manual editing per environment.

## Calibration note
Not every project needs all of this. A quick internal POC or hackathon prototype (weigh this against what the user says the project's purpose is) reasonably skips code-splitting, exhaustive testing, and CWV tuning — flag those as "future work" rather than "critical," and reserve 🔴/🟠 severity for things that would actually break or embarrass the project at its current stage.