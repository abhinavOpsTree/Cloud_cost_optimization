# State Management & Data Fetching Checklist

## State classification — every state variable should fall cleanly into one bucket
1. **Local UI state** (`isOpen`, `activeTab`, form input drafts) → `useState`/`useReducer`, kept local to the component that owns it. Don't lift this to context/global state "just in case" — that causes unnecessary re-renders elsewhere.
2. **Global shared UI state** (theme, sidebar collapsed/expanded, feature flags) → a lightweight Context or a client state library (Zustand, Jotai). Don't reach for a heavy state library for state that's really only local.
3. **Server cache state** (anything fetched from an API) → **must not** be synced into plain `useState` + `useEffect`. This is one of the most common React anti-patterns and causes stale data, race conditions, and duplicate fetches. Use a server-state library — TanStack Query (React Query) v5, SWR, or equivalent — which handles caching, background refetching, pagination, dedup, and invalidation for free.

**Bad (server data manually synced into local state):**
```jsx
const [user, setUser] = useState(null);
useEffect(() => {
  fetch('/api/user').then(r => r.json()).then(setUser);
}, []);
```
**Good:**
```jsx
const { data: user } = useQuery({ queryKey: ['user'], queryFn: fetchUser });
```

- [ ] Check every `useEffect` + `useState` pair that fetches data — is it actually server cache state that belongs in a query library instead?
- [ ] Derived values (computed from existing state/props) aren't duplicated into their own `useState` kept in sync via `useEffect` — compute them directly during render.

## The `use()` API (React 19)
- [ ] Promises/context read conditionally (inside an `if`, after an early return, or in a loop) use the `use()` hook rather than restructuring the component around `useEffect` to work around the old "hooks can't be conditional" rule for this specific case.
- [ ] Any component calling `use()` on a promise has a `<Suspense>` boundary above it in the tree to handle the pending state.

## Centralized HTTP layer (resilience)
Check whether the codebase has a single shared request layer (fetch wrapper or Axios instance) rather than raw `fetch` calls scattered everywhere, and whether it handles:
- [ ] **Timeouts**: hanging requests are aborted via `AbortController` rather than left to hang indefinitely.
- [ ] **Auth injection**: `Authorization` headers (and any tenant/context headers) are added centrally via an interceptor, not manually re-typed at every call site.
- [ ] **Circuit breaking**: repeated failures to a specific endpoint/domain are tracked and further requests to it are short-circuited temporarily, instead of hammering a known-down dependency.
- [ ] **Retries with backoff**: transient errors (`429`, `502`, `503`, `504`) are retried with exponential backoff + jitter — not retried instantly in a tight loop, and not left unretried when a simple retry would likely succeed.

This is a "nice to have" for a small app but becomes important for anything talking to multiple/unreliable backends — calibrate how hard to push on this based on project scale.

## Verification approach
- Grep for `useEffect` combined with `fetch(` or an API client call — each hit is worth checking against the "should this be a query library instead" question.
- Check if there's exactly one HTTP client setup file, or if `fetch`/axios calls are constructed ad hoc throughout the codebase.