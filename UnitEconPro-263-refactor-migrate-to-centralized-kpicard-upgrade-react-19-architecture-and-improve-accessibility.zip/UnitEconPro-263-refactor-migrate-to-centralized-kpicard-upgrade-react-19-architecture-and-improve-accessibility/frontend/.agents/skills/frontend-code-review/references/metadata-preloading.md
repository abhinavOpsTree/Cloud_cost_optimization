# Document Metadata & Resource Preloading Checklist (React 19)

## Metadata hoisting
- [ ] Page-level components render `<title>`, `<meta>`, and `<link>` tags directly in their JSX where the content is dynamic per-page (e.g. a blog post title, a product description) — React 19 automatically hoists these into `<head>`, so a separate head-management library (react-helmet, etc.) is no longer necessary for this simple case.
- [ ] Each route/page sets a distinct, meaningful `<title>` — check this isn't left as one static title reused across every route (bad for SEO and for users with many tabs open).
- [ ] `<meta name="description">` is present and content-specific (not a generic boilerplate description repeated everywhere) on public/marketing-facing pages.
- [ ] Canonical URLs (`<link rel="canonical">`) are set on pages that could otherwise be reached via multiple URL variants, to avoid duplicate-content SEO issues.

```jsx
function BlogDetails({ post }) {
  return (
    <article>
      <title>{post.title} | Blog</title>
      <meta name="description" content={post.summary} />
      <link rel="canonical" href={`https://example.com/blog/${post.slug}`} />
      <h1>{post.title}</h1>
    </article>
  );
}
```

## Resource preloading APIs
- [ ] For known-critical external resources (fonts, key stylesheets, an API domain that will definitely be called), the app uses React 19's preloading functions rather than leaving the browser to discover them late:
  - `preconnect(url)` — establish the connection (DNS + TLS) to a domain ahead of time (e.g. an API host).
  - `prefetchDNS(url)` — cheaper DNS-only pre-resolution for domains that might be needed (e.g. a CDN).
  - `preload(url, { as })` — fetch a specific critical asset (font, image) early so it's ready by the time it's needed.
  - `preinit(url, { as: 'style' | 'script' })` — fetch **and** execute/apply a resource immediately (e.g. a theme stylesheet needed for first paint).
- [ ] These are used deliberately for genuinely critical resources — not sprinkled on every asset in the app, which would just front-load unnecessary network activity and work against performance instead of for it.

```jsx
import { prefetchDNS, preconnect, preload, preinit } from 'react-dom';

function Home() {
  preconnect('https://api.example.com');
  prefetchDNS('https://cdn.example.com');
  preload('https://cdn.example.com/fonts/inter.woff2', { as: 'font' });
  preinit('https://cdn.example.com/styles/theme.css', { as: 'style' });
  return <main>Homepage Content</main>;
}
```

## Verification approach
- Check whether pages that clearly need distinct SEO metadata (marketing pages, blog posts, product pages) actually render distinct `<title>`/`<meta>` per page, versus one static title in a root layout used everywhere.
- Check font-loading: is a webfont requested only via CSS `@font-face` (late discovery, causes layout shift) or preloaded explicitly for pages where it's critical to first paint?