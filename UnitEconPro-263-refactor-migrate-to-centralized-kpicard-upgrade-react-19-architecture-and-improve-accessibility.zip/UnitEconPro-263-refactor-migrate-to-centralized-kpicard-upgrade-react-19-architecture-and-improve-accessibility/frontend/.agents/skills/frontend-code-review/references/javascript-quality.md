# JavaScript Quality Checklist

## Correctness & error handling
- [ ] Every `fetch`/API call has error handling (`.catch` or `try/catch` around `await`) — not just the happy path. A failed network request shouldn't leave the UI silently broken.
- [ ] Loading and error states are represented in the UI (spinner/skeleton while pending, a visible error message on failure) — not just console-logged and ignored.
- [ ] No unhandled promise rejections (async functions called without `await` or a `.catch` in a context where failure is possible).
- [ ] Array/object operations guard against `null`/`undefined` where the data can legitimately be missing (e.g. optional chaining `?.`, default values) instead of assuming an API response is always fully populated.

## Async patterns
- [ ] Race conditions are considered for anything that can be triggered multiple times in quick succession (e.g. a search-as-you-type calling an API on every keystroke should debounce and/or cancel stale requests, so an old slow response can't overwrite a newer fast one).
- [ ] Cleanup happens for anything with a lifecycle (timers, subscriptions, event listeners) — no dangling `setInterval`/`addEventListener` that's never cleared.

## Code hygiene
- [ ] No leftover `console.log`/`debugger` statements in code meant to ship.
- [ ] Consistent use of `const`/`let` (no `var`); prefer `const` by default.
- [ ] Functions are reasonably small and named for what they do; deeply nested callbacks are refactored into named functions or async/await instead of callback pyramids.
- [ ] No dead code / commented-out blocks left in the codebase.

## Data handling
- [ ] Dates, currency, and numbers are formatted with locale-aware APIs (`Intl.DateTimeFormat`, `Intl.NumberFormat`) rather than manual string concatenation, if the app has any international audience.
- [ ] Large lists/datasets rendered in the UI are paginated, virtualized, or otherwise bounded — rendering thousands of DOM nodes at once is a common performance killer.

## Linting & tooling signals (fast smell tests)
- [ ] ESLint is configured and passing (presence of `.eslintrc*`/`eslint.config.*` plus no suppressed errors littered with blanket `eslint-disable`).
- [ ] Prettier or equivalent formatting is consistent across files (mixed tabs/spaces or inconsistent quote styles suggest no formatting discipline).
- [ ] TypeScript, if used, has `strict` mode on rather than loose `any`-everywhere typing — heavy `any` usage defeats the purpose of using TypeScript at all. React elements are typed as `React.ReactNode`, event handlers use the specific event type (e.g. `React.MouseEvent<HTMLButtonElement>`), and API response shapes have real interfaces/types rather than being treated as `any`.
- [ ] If the project uses the React Compiler, `eslint-plugin-react-compiler` is included alongside the standard rules-of-hooks ESLint plugin to catch patterns the compiler can't safely handle.
- [ ] Design tokens (colors, spacing, typography, dark-mode variants) live in CSS variables or a shared theme file rather than being hardcoded per-component — keeps styling decoupled from component logic and consistent across the app.

## Note on security-related JS issues
Anything involving user input, `innerHTML`, secrets, or dynamic code execution (`eval`, `new Function`) is covered in `security-deep.md` — always cross-check that file too since it overlaps heavily with JS code review.