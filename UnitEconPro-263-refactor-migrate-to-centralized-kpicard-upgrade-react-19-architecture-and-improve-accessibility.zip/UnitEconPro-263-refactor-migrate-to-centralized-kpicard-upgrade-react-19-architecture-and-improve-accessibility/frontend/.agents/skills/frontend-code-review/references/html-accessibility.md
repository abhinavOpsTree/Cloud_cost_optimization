# HTML & Accessibility Checklist

## Semantic structure
- [ ] Uses semantic elements (`<header>`, `<nav>`, `<main>`, `<article>`, `<section>`, `<footer>`) instead of generic `<div>` soup for page structure.
- [ ] Only one `<h1>` per page; heading levels don't skip (`h2` shouldn't jump to `h4`).
- [ ] Interactive elements use real `<button>`/`<a>` tags — not `<div onClick={...}>`. A div can't be focused with Tab or activated with Enter/Space by default, and screen readers won't announce it as interactive.
- [ ] Links (`<a>`) are used for navigation; buttons (`<button>`) are used for actions. Don't use `<a href="#">` as a fake button.

**Bad:**
```jsx
<div className="btn" onClick={submit}>Submit</div>
```
**Good:**
```jsx
<button type="button" onClick={submit}>Submit</button>
```

## Forms
- [ ] Every input has an associated `<label>` (via `htmlFor`/`id`, not just placeholder text — placeholders disappear on focus and aren't reliably read by screen readers).
- [ ] Required fields are marked with `required` / `aria-required`, not just a visual asterisk.
- [ ] Error messages are programmatically associated with the field (`aria-describedby`) so screen readers announce them.
- [ ] Form submission works via native `<form onSubmit>`, not just a button click handler — this preserves Enter-to-submit and browser autofill.

## Images & media
- [ ] All `<img>` have meaningful `alt` text. Decorative images use `alt=""` (not omitted — omitting it makes screen readers announce the filename).
- [ ] Icon-only buttons have `aria-label` (e.g. a trash icon button needs `aria-label="Delete item"`).

## Keyboard & focus
- [ ] Everything clickable is reachable and operable via keyboard alone (Tab, Enter, Space, Escape for modals).
- [ ] Visible focus indicator is never removed with `outline: none` unless replaced with an equally visible custom style.
- [ ] Modals/dialogs trap focus while open and return focus to the trigger element on close.
- [ ] Logical tab order (matches visual layout; avoid manual `tabIndex` values other than `0` or `-1` unless there's a specific reason).

## ARIA — use sparingly and correctly
- [ ] ARIA is only added where semantic HTML can't express the state (e.g. `aria-expanded` on a custom dropdown toggle, `aria-live` for toast notifications).
- [ ] No contradicting ARIA (e.g. `role="button"` on an element that's already a `<button>`).
- [ ] Rule of thumb: "No ARIA is better than bad ARIA." Prefer fixing semantics over patching with ARIA.

## Meta / document-level
- [ ] `<meta name="viewport" content="width=device-width, initial-scale=1">` present for mobile rendering.
- [ ] `<title>` is descriptive and unique per page/route.
- [ ] `<meta name="description">` present for SEO on public-facing pages.
- [ ] `lang` attribute set on `<html>` (e.g. `<html lang="en">`) — screen readers use this to pick pronunciation rules.

## Quick verification approach
- Try tabbing through the whole page with a keyboard only — can you reach and activate everything?
- Turn off CSS mentally: does the raw HTML order still make logical sense (that's roughly what a screen reader experiences)?
- Run an automated pass if tooling is available (axe, Lighthouse accessibility audit) but don't rely on automated tools alone — they catch ~30-40% of real issues; manual keyboard/screen-reader spot checks catch the rest.