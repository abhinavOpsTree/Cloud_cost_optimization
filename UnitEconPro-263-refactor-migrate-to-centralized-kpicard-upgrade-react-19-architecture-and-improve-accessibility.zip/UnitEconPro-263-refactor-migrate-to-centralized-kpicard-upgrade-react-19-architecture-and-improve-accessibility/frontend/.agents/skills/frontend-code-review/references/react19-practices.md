# React 19 Practices Checklist

## Rules of Hooks (still fundamental, still frequently violated)
- [ ] Hooks are only called at the top level of a component/custom hook — never inside conditionals, loops, or after an early `return`.
- [ ] Custom hooks are named starting with `use` and follow the same rule.
- [ ] `useEffect` dependency arrays are complete and accurate (no silently-suppressed `eslint-disable-next-line react-hooks/exhaustive-deps` hiding a real bug) — a stale closure over old state/props is one of the most common React bugs.
- [ ] Effects that subscribe to something (event listener, socket, timer, interval) return a cleanup function.

## Lists & keys
- [ ] Every list item rendered with `.map()` has a stable, unique `key` — an ID from the data, never the array index if the list can reorder, filter, or have items inserted/removed (index keys cause state to attach to the wrong item after reorder).

## React 19-specific features — check whether they're used where appropriate
- [ ] **Actions / `useActionState`**: forms that submit data use `useActionState` (or the `action` prop on `<form>`) instead of manually wiring `useState` for pending/error/success state. This is the new idiomatic pattern in React 19 — hand-rolled pending-state booleans are now a "smell" signaling the code wasn't updated to current patterns.
- [ ] **`useOptimistic`**: for actions where the UI should update instantly before the server confirms (e.g. liking a post, sending a chat message), `useOptimistic` is used instead of manual optimistic-state juggling with rollback logic.
- [ ] **`ref` as a normal prop**: function components that need to accept a ref from a parent just declare `ref` as a prop directly — `forwardRef` is no longer necessary in React 19 and its presence in new code is a sign of outdated patterns (though it's not wrong, just no longer needed).
- [ ] **Context as a direct element**: providers render `<SomeContext value={...}>{children}</SomeContext>` instead of `<SomeContext.Provider value={...}>{children}</SomeContext.Provider>` — both work, but the direct form is the current React 19 idiom.
- [ ] **`use()` hook**: for reading a promise or context value conditionally (e.g. inside an `if` or after a conditional return), `use()` is the correct tool rather than restructuring the whole component around `useEffect` + `useState` to fetch the same data.
- [ ] **Document metadata**: components can render `<title>`, `<meta>`, `<link>` directly in JSX and React 19 hoists them into `<head>` automatically — no need for a separate head-management library for simple cases.

## Rendering performance
- [ ] Expensive computations inside a component are wrapped in `useMemo` only when profiling actually shows a need — don't blanket-wrap everything (premature memoization adds complexity and can itself hurt performance).
- [ ] Callbacks passed to memoized child components are wrapped in `useCallback` where it actually prevents a measured re-render, not reflexively everywhere.
- [ ] Large components aren't re-rendering more often than necessary — check for state living higher in the tree than it needs to (state lifted to a shared parent when only one child uses it forces siblings to re-render unnecessarily).
- [ ] Context values that change frequently aren't causing wide re-render storms — split contexts by how often their data changes, or use a state library, instead of one giant context object.

## State management sanity
- [ ] Local component state (`useState`) is used for UI-only state; global/shared state (URL params, context, or a state library) is used for anything multiple distant components need — not everything crammed into one giant top-level state object "just in case."
- [ ] Derived values are computed during render, not duplicated into their own `useState` + kept in sync with `useEffect` (a very common anti-pattern: storing a value in state that could just be calculated from existing props/state).

## Error boundaries
- [ ] At least one Error Boundary exists around major sections of the app so a single component crash doesn't take down the whole page with a blank white screen.

## Quick verification approach
- Search for `forwardRef` and manual pending/error `useState` pairs around form submissions — both are signals the code predates React 19 patterns and could be modernized.
- Search for `.map((item, index) =>` and check whether `index` is used as the `key`.