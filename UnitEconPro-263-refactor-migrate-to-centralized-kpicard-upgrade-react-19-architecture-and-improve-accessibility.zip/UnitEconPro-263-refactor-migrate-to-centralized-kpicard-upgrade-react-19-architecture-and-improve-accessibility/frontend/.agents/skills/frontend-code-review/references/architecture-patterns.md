# Architecture & Component Boundaries Checklist

## Folder structure — separation of concerns
- [ ] `components/common/` (or `shared/`) holds only stateless, generic UI (buttons, inputs, modals, loaders, badges) with zero business logic or API calls.
- [ ] `components/features/[FeatureName]/` holds domain-specific components tied to a functional feature (e.g. `ProfileCard`, `IncidentTimeline`) — not mixed in with generic UI.
- [ ] `hooks/` holds reusable stateful custom hooks (`useApi`, `useAuth`, `useLocalStorage`) rather than duplicating the same stateful logic inline across components.
- [ ] `contexts/` holds shared global providers (Theme, Auth, Tenant, Permissions) — not ad-hoc contexts declared inline wherever needed.
- [ ] `pages/` (or `routes/`) holds container/route-level components that orchestrate feature components and layout — pages shouldn't contain deep business logic themselves, just composition.
- [ ] `services/` (or `api/`) holds HTTP client wrappers and endpoint configs — components don't call `fetch`/axios directly with inline URLs scattered through the codebase.

A quick smell test: if a "common" component imports from `services/` or knows about a specific API shape, it's misplaced — it should live under `features/` instead.

## Server Components vs. Client Components (if using an RSC framework: Next.js App Router, Remix, etc.)
- [ ] Components are Server Components **by default** — data fetching happens close to the source, and `"use client"` isn't sprinkled everywhere out of habit.
- [ ] `"use client"` only appears on genuine **leaves** of the tree that need browser APIs, `useState`/`useReducer`, or interactive event handlers (`onClick`, `onChange`) — not on a large parent component just because one small child needs interactivity (that drags the whole subtree to the client unnecessarily).
- [ ] `"use server"` is used exclusively to define Server Actions (secure server-side functions callable from client code) — not as a blanket marker on unrelated files.
- [ ] Check for the common mistake: marking a component `"use client"` just to silence a hook-usage error, without considering whether the state should actually live further down the tree.

## React 19 component upgrades — quick presence checks
- [ ] `ref` is accepted as a plain prop on function components needing it, instead of wrapping in `forwardRef` (forwardRef isn't wrong, but its presence in new code signals the component wasn't written against current React 19 idioms).
- [ ] Context providers render `<SomeContext value={...}>` directly instead of `<SomeContext.Provider value={...}>` — both work, but the direct form is the current idiom and worth flagging as an upgrade opportunity if seen throughout a codebase being modernized.

## Verification approach
- Open the top-level `src/` (or `app/`) folder listing and check it roughly matches this shape before diving into individual files — architecture problems are easier to spot from the folder tree than from reading code line by line.
- For RSC codebases, grep for `"use client"` and sanity-check the count/placement — a huge proportion of the tree being client components defeats the purpose of using RSCs at all.