#!/bin/sh
set -e

echo "🔧 Injecting environment variables into env-config.js ..."
sed -i "s|%VITE_API_BASE_URL%|${VITE_API_BASE_URL}|g" /usr/share/nginx/html/env-config.js
sed -i "s|%VITE_KEYCLOAK_URL%|${VITE_KEYCLOAK_URL}|g" /usr/share/nginx/html/env-config.js
sed -i "s|%VITE_KEYCLOAK_REALM%|${VITE_KEYCLOAK_REALM}|g" /usr/share/nginx/html/env-config.js
sed -i "s|%VITE_KEYCLOAK_CLIENT_ID%|${VITE_KEYCLOAK_CLIENT_ID}|g" /usr/share/nginx/html/env-config.js
sed -i "s|%VITE_CLOUD_SENTRY_API_BASE_URL%|${VITE_CLOUD_SENTRY_API_BASE_URL}|g" /usr/share/nginx/html/env-config.js
echo "✅ Environment variables injected successfully. Starting Nginx..."
exec nginx -g 'daemon off;'
